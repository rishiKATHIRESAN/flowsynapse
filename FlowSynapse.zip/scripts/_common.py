"""Shared helpers for FlowSynapse scripts (stdlib only; runs before setup)."""
from __future__ import annotations

import json
import os
import platform
import shutil
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BACKEND = ROOT / "backend"
FRONTEND = ROOT / "frontend"
IS_WIN = sys.platform == "win32"
VENV_PY = BACKEND / ".venv" / ("Scripts/python.exe" if IS_WIN else "bin/python")
MIN_PY = (3, 10)
MIN_NODE = 18
MIN_FREE_MB = 1024


def say(msg: str) -> None:
    print(msg, flush=True)


def fail(msg: str, code: int = 1) -> "NoReturn":  # type: ignore[name-defined]
    print(f"ERROR: {msg}", file=sys.stderr, flush=True)
    sys.exit(code)


def run(cmd: list[str], cwd: Path | None = None, env: dict[str, str] | None = None, check: bool = True,
        capture: bool = False, timeout: float | None = None) -> subprocess.CompletedProcess[str]:
    say("> " + " ".join(cmd))
    return subprocess.run(cmd, cwd=str(cwd) if cwd else None, env=env, check=check, text=True,
                          capture_output=capture, timeout=timeout)


def node_exe() -> str | None:
    return shutil.which("node")


def npm_exe() -> str | None:
    return shutil.which("npm.cmd" if IS_WIN else "npm") or shutil.which("npm")


def node_major() -> int | None:
    exe = node_exe()
    if not exe:
        return None
    out = subprocess.run([exe, "--version"], capture_output=True, text=True).stdout.strip()
    try:
        return int(out.lstrip("v").split(".")[0])
    except ValueError:
        return None


def environment_report() -> dict[str, str]:
    npm = npm_exe()
    npm_v = subprocess.run([npm, "--version"], capture_output=True, text=True).stdout.strip() if npm else "missing"
    node = node_exe()
    node_v = subprocess.run([node, "--version"], capture_output=True, text=True).stdout.strip() if node else "missing"
    free = shutil.disk_usage(str(ROOT)).free // (1024 * 1024)
    return {
        "os": f"{platform.system()} {platform.release()} ({platform.machine()})",
        "python": platform.python_version(),
        "node": node_v,
        "npm": npm_v,
        "free_disk_mb": str(free),
    }


def check_toolchain() -> None:
    rep = environment_report()
    for k, v in rep.items():
        say(f"  {k:13s} {v}")
    if platform.system() not in ("Windows", "Linux", "Darwin"):
        fail(f"Unsupported OS {platform.system()}: FlowSynapse scripts support Windows, macOS and Linux.")
    if sys.version_info < MIN_PY:
        fail(f"Python {MIN_PY[0]}.{MIN_PY[1]}+ is required (found {platform.python_version()}). "
             "Install Python 3.12 from https://www.python.org/downloads/ and re-run.")
    major = node_major()
    if major is None:
        fail("Node.js was not found. Install Node.js 20 LTS from https://nodejs.org/ and re-run.")
    if major < MIN_NODE:
        fail(f"Node.js {MIN_NODE}+ is required (found v{major}). Install Node.js 20 LTS from https://nodejs.org/.")
    if not npm_exe():
        fail("npm was not found. It ships with Node.js; reinstall Node.js 20 LTS.")
    if int(rep["free_disk_mb"]) < MIN_FREE_MB:
        fail(f"At least {MIN_FREE_MB} MB of free disk space is required (found {rep['free_disk_mb']} MB).")


# ---------------------------------------------------------------------------
# Ports and health
# ---------------------------------------------------------------------------

def port_free(port: int, host: str = "127.0.0.1") -> bool:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        if not IS_WIN:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((host, port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def fetch_json(url: str, timeout: float = 2.0) -> dict | None:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:  # noqa: S310 - loopback only
            return json.loads(r.read().decode("utf-8"))
    except (urllib.error.URLError, OSError, ValueError):
        return None


def http_ok(url: str, timeout: float = 2.0) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:  # noqa: S310
            return 200 <= r.status < 500
    except urllib.error.HTTPError as e:
        return e.code < 500
    except (urllib.error.URLError, OSError):
        return False


def describe_port_owner(port: int) -> str:
    h = fetch_json(f"http://127.0.0.1:{port}/api/health")
    if h and h.get("app") == "flowsynapse":
        return f"another FlowSynapse instance (instance {h.get('instance_id')}, status {h.get('status')})"
    return "an unrelated service (not FlowSynapse)"


def wait_for(predicate, timeout: float, interval: float = 0.5, proc: subprocess.Popen | None = None) -> bool:  # type: ignore[type-arg]
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if proc is not None and proc.poll() is not None:
            return False
        if predicate():
            return True
        time.sleep(interval)
    return False


# ---------------------------------------------------------------------------
# Process trees
# ---------------------------------------------------------------------------

def spawn(cmd: list[str], cwd: Path, env: dict[str, str], log_file: Path | None = None) -> subprocess.Popen:  # type: ignore[type-arg]
    kwargs: dict = {"cwd": str(cwd), "env": env}
    if IS_WIN:
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP  # type: ignore[attr-defined]
    else:
        kwargs["start_new_session"] = True
    if log_file is not None:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        fh = open(log_file, "ab")
        kwargs["stdout"] = fh
        kwargs["stderr"] = subprocess.STDOUT
    return subprocess.Popen(cmd, **kwargs)


def stop_tree(proc: subprocess.Popen, name: str, graceful_timeout: float = 20.0) -> None:  # type: ignore[type-arg]
    """Graceful stop (Ctrl+Break / SIGTERM to the group), then kill the whole tree."""
    if proc.poll() is not None:
        return
    try:
        if IS_WIN:
            proc.send_signal(signal.CTRL_BREAK_EVENT)  # type: ignore[attr-defined]
        else:
            os.killpg(proc.pid, signal.SIGTERM)
    except (OSError, ValueError):
        pass
    try:
        proc.wait(timeout=graceful_timeout)
    except subprocess.TimeoutExpired:
        say(f"  {name} did not stop within {graceful_timeout:.0f}s; terminating process tree")
    if IS_WIN:
        # Kill any remaining children (e.g. esbuild under vite).
        subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True)
    else:
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except (OSError, ProcessLookupError):
            pass
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        pass


def backend_env(backend_port: int, frontend_port: int, extra: dict[str, str] | None = None) -> dict[str, str]:
    env = dict(os.environ)
    env["PORT"] = str(backend_port)
    env["FRONTEND_PORT"] = str(frontend_port)
    env.setdefault(
        "CORS_ORIGINS",
        f"http://127.0.0.1:{frontend_port},http://localhost:{frontend_port}",
    )
    env["PYTHONUNBUFFERED"] = "1"
    if extra:
        env.update(extra)
    return env
