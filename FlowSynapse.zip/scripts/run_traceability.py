"""Generate requirement verification statuses from real test results (master prompt 17.1).

Runs the backend (pytest, JUnit XML with ``req`` properties) and frontend (Vitest
JUnit; titles prefixed ``[FS-...]``) suites, then computes each requirement's
status and rewrites the generated column of the matrix in
``IMPLEMENTATION_CHECKLIST.md``. Writes ``reports/traceability.json``.

Exit codes: 0 = consistent (gaps are printed), 1 = rule violation or test run
problem, 2 = usage error.

Staleness: a run is current if its commit equals HEAD, or if the only files
changed between that commit and HEAD are the generated progress documents
(this file's outputs), and the working tree had no other changes at run time.
"""
from __future__ import annotations

import argparse
import ast
import json
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from _common import BACKEND, FRONTEND, ROOT, VENV_PY, npm_exe

CHECKLIST = ROOT / "IMPLEMENTATION_CHECKLIST.md"
REPORTS = ROOT / "reports"
JUNIT_BACKEND = REPORTS / "junit-backend.xml"
JUNIT_FRONTEND = REPORTS / "junit-frontend.xml"
OUT_JSON = REPORTS / "traceability.json"
DOC_ONLY = {"IMPLEMENTATION_CHECKLIST.md", "docs/BUILD_STATE.md"}
REQ_RE = re.compile(r"\[(FS-(?:SYS|M\d)-\d{3})\]")
KINDS = {"unit", "integration", "api", "e2e", "frontend", "negative"}
MODULE_NAMES = {
    "M1": "M1 Campaign Intelligence",
    "M2": "M2 Funnel Builder",
    "M3": "M3 SEO Audit",
    "M4": "M4 Website Intelligence",
    "M5": "M5 Bulk Blog",
    "M6": "M6 Social Calendar",
}


@dataclass
class TestResult:
    name: str
    file: str
    outcome: str  # passed | failed | skipped
    reqs: list[tuple[str, set[str]]] = field(default_factory=list)
    layer: str = "backend"


@dataclass
class Requirement:
    rid: str
    cells: list[str]
    required: set[str]
    criteria: list[str]
    status: str = ""


def git(*args: str) -> str:
    return subprocess.run(["git", *args], cwd=str(ROOT), capture_output=True, text=True).stdout.strip()


def head() -> str:
    return git("rev-parse", "HEAD")


def dirty_files() -> list[str]:
    out = git("status", "--porcelain")
    files = []
    for line in out.splitlines():
        path = line[3:].strip().strip('"')
        if path and path not in DOC_ONLY and not path.startswith("reports/"):
            files.append(path)
    return files


def run_suites(skip_frontend: bool) -> bool:
    REPORTS.mkdir(exist_ok=True)
    ok = True
    print("Running backend tests (pytest)...", flush=True)
    rc = subprocess.call(
        [str(VENV_PY), "-m", "pytest", "-q", "-p", "no:randomly", f"--junitxml={JUNIT_BACKEND}"],
        cwd=str(BACKEND),
    )
    if rc not in (0, 1):
        print(f"pytest exited with {rc} (collection/usage error)")
        ok = False
    if not skip_frontend:
        print("Running frontend tests (vitest)...", flush=True)
        npm = npm_exe()
        assert npm
        rc = subprocess.call([npm, "run", "test", "--silent"], cwd=str(FRONTEND))
        if rc not in (0, 1):
            ok = False
    return ok


def parse_backend() -> list[TestResult]:
    if not JUNIT_BACKEND.exists():
        return []
    results = []
    for tc in ET.parse(JUNIT_BACKEND).getroot().iter("testcase"):
        outcome = "passed"
        if tc.find("failure") is not None or tc.find("error") is not None:
            outcome = "failed"
        elif tc.find("skipped") is not None:
            outcome = "skipped"
        reqs: list[tuple[str, set[str]]] = []
        props = tc.find("properties")
        if props is not None:
            for p in props.iter("property"):
                if p.get("name") == "req":
                    rid, _, kind = (p.get("value") or "").partition("|")
                    reqs.append((rid, {k for k in kind.split("+") if k}))
        file = tc.get("file") or tc.get("classname", "").replace(".", "/") + ".py"
        results.append(TestResult(tc.get("name", ""), file, outcome, reqs, "backend"))
    return results


def parse_frontend() -> list[TestResult]:
    if not JUNIT_FRONTEND.exists():
        return []
    results = []
    for tc in ET.parse(JUNIT_FRONTEND).getroot().iter("testcase"):
        outcome = "passed"
        if tc.find("failure") is not None or tc.find("error") is not None:
            outcome = "failed"
        elif tc.find("skipped") is not None:
            outcome = "skipped"
        name = tc.get("name", "")
        kinds = {"frontend"} | ({"negative"} if "negative" in name.lower() else set())
        reqs = [(m, set(kinds)) for m in REQ_RE.findall(name)]
        results.append(TestResult(name, tc.get("classname", ""), outcome, reqs, "frontend"))
    return results


def parse_matrix(text: str) -> tuple[list[str], list[Requirement], str, str]:
    start = text.index("<!-- TRACE:BEGIN -->")
    end = text.index("<!-- TRACE:END -->")
    block = text[start:end].splitlines()[1:]
    header = block[0]
    reqs = []
    for line in block[2:]:
        if not line.startswith("| FS-"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        required = {k for k in cells[6].split("+") if k}
        bad = required - KINDS
        if bad:
            raise SystemExit(f"{cells[0]}: unknown test kind(s) {bad}")
        criteria = re.findall(r"M\d-AC\d{2}", cells[7])
        reqs.append(Requirement(cells[0], cells, required, criteria))
    return [header], reqs, text[:start], text[end:]


def test_has_assertion(file: Path, func: str) -> bool:
    try:
        tree = ast.parse(file.read_text(encoding="utf-8"))
    except (OSError, SyntaxError):
        return True  # cannot scan -> do not flag
    base = func.split("[")[0]
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == base:
            for sub in ast.walk(node):
                if isinstance(sub, ast.Assert):
                    return True
                if isinstance(sub, ast.Call):
                    fn = sub.func
                    name = fn.attr if isinstance(fn, ast.Attribute) else getattr(fn, "id", "")
                    if name in ("raises", "fail") or name.startswith(("assert", "expect", "check_", "verify_")):
                        return True
            return False
    return True


def compute(reqs: list[Requirement], results: list[TestResult], current: bool) -> dict[str, dict]:
    by_req: dict[str, list[TestResult]] = {r.rid: [] for r in reqs}
    kinds_by_req: dict[str, set[str]] = {r.rid: set() for r in reqs}
    for t in results:
        for rid, kinds in t.reqs:
            if rid in by_req:
                by_req[rid].append(t)
                if t.outcome == "passed":
                    kinds_by_req[rid] |= kinds
    out = {}
    for r in reqs:
        tests = by_req[r.rid]
        if not tests:
            impl = r.cells[3]
            paths = [p.strip() for p in re.split(r"[,;]", impl) if "/" in p]
            exists = any((ROOT / p).exists() or (BACKEND / p).exists() or (BACKEND / "app" / p).exists()
                         or (FRONTEND / p).exists() for p in paths)
            status = "TESTING GAP" if exists else "NOT STARTED"
        elif any(t.outcome == "failed" for t in tests):
            status = "FAILING"
        elif any(t.outcome == "skipped" for t in tests):
            status = "NOT RUN"
        else:
            missing = r.required - kinds_by_req[r.rid]
            if missing:
                status = f"INSUFFICIENT COVERAGE (missing: {'+'.join(sorted(missing))})"
            elif not current:
                status = "STALE — re-run"
            else:
                status = "VERIFIED"
        out[r.rid] = {
            "status": status,
            "tests": [{"name": t.name, "file": t.file, "outcome": t.outcome, "layer": t.layer} for t in tests],
            "kinds_passed": sorted(kinds_by_req[r.rid]),
            "required": sorted(r.required),
            "criteria": r.criteria,
        }
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-run", action="store_true", help="use existing JUnit files")
    ap.add_argument("--skip-frontend", action="store_true")
    args = ap.parse_args()

    errors: list[str] = []
    warnings: list[str] = []
    commit = head()
    dirty = dirty_files()
    if not args.no_run and not run_suites(args.skip_frontend):
        errors.append("a test suite failed to run (collection/usage error)")

    text = CHECKLIST.read_text(encoding="utf-8")
    _, reqs, before, after = parse_matrix(text)
    known = {r.rid for r in reqs}
    results = parse_backend() + parse_frontend()

    # Rule: markers must reference existing requirement ids.
    for t in results:
        for rid, _ in t.reqs:
            if rid not in known:
                errors.append(f"test {t.file}::{t.name} references unknown requirement {rid}")

    # Rule: mapped backend tests must contain an assertion.
    for t in results:
        if t.reqs and t.layer == "backend":
            f = BACKEND / t.file if not Path(t.file).is_absolute() else Path(t.file)
            if f.exists() and not test_has_assertion(f, t.name):
                errors.append(f"mapped test has no assertion: {t.file}::{t.name}")
    # Frontend: warn on mapped tests without expect( (static scan)
    for spec in (FRONTEND / "src").rglob("*.test.ts*"):
        src = spec.read_text(encoding="utf-8")
        for m in re.finditer(r"it\(\s*'(\[FS-[^']+)'", src):
            body = src[m.end(): m.end() + 4000].split("\n  it(")[0]
            if "expect(" not in body:
                warnings.append(f"frontend test may lack assertions: {spec.name}: {m.group(1)[:60]}")

    # Rule: test paths named in the matrix must exist.
    for r in reqs:
        for p in re.findall(r"tests/[\w/]+\.py", r.cells[3]):
            if not (BACKEND / p).exists():
                if r.rid and "NOT STARTED" not in r.cells[8]:
                    warnings.append(f"{r.rid}: matrix references missing test file {p}")

    # Rule: no hand-marked VERIFIED.
    prev = {}
    if OUT_JSON.exists():
        try:
            prev = json.loads(OUT_JSON.read_text(encoding="utf-8")).get("requirements", {})
        except ValueError:
            prev = {}
    for r in reqs:
        if r.cells[8] == "VERIFIED" and prev.get(r.rid, {}).get("status") != "VERIFIED":
            errors.append(f"{r.rid} is marked VERIFIED in the checklist but no recorded run verified it (hand edit?)")

    current = not dirty
    computed = compute(reqs, results, current)

    # Module completion
    module_state = {}
    for mod, label in MODULE_NAMES.items():
        mod_reqs = [r for r in reqs if r.rid.startswith(f"FS-{mod}-")]
        crit: dict[str, list[str]] = {}
        for r in mod_reqs:
            for c in r.criteria:
                crit.setdefault(c, []).append(computed[r.rid]["status"])
        all_ok = bool(mod_reqs) and all(computed[r.rid]["status"] == "VERIFIED" for r in mod_reqs) and all(
            all(s == "VERIFIED" for s in v) for v in crit.values()
        )
        module_state[label] = "COMPLETE" if all_ok else "NOT COMPLETE"
    mstart, mend = after.find("<!-- MODULES:BEGIN -->"), after.find("<!-- MODULES:END -->")
    if mstart >= 0:
        for line in after[mstart:mend].splitlines():
            m = re.match(r"\| (M\d [^|]+?) \| (\w[\w ]*) \|", line)
            if m and m.group(2).strip() == "COMPLETE" and module_state.get(m.group(1).strip()) != "COMPLETE":
                errors.append(f"module {m.group(1)} is marked COMPLETE but its acceptance criteria are not all VERIFIED")

    # Rewrite matrix
    lines = text[text.index("<!-- TRACE:BEGIN -->"): text.index("<!-- TRACE:END -->")].splitlines()
    new_lines = []
    for line in lines:
        if line.startswith("| FS-"):
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            cells[8] = computed[cells[0]]["status"]
            line = "| " + " | ".join(cells) + " |"
        new_lines.append(line)
    new_after = after
    if mstart >= 0:
        mod_lines = ["<!-- MODULES:BEGIN -->", "| Module | State |", "|---|---|"]
        mod_lines += [f"| {k} | {v} |" for k, v in module_state.items()]
        new_after = after[:mstart] + "\n".join(mod_lines) + "\n" + after[mend:]
    CHECKLIST.write_text(before + "\n".join(new_lines) + "\n" + new_after, encoding="utf-8", newline="\n")

    # Consistency: generated status must agree with recorded outcomes.
    for rid, info in computed.items():
        if info["status"] == "VERIFIED" and any(t["outcome"] != "passed" for t in info["tests"]):
            errors.append(f"{rid}: VERIFIED but a mapped test did not pass")

    totals = {"passed": 0, "failed": 0, "skipped": 0}
    for t in results:
        totals[t.outcome] = totals.get(t.outcome, 0) + 1
    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "commit": commit,
        "dirty_files": dirty,
        "current": current,
        "totals": totals,
        "requirements": computed,
        "modules": module_state,
        "errors": errors,
        "warnings": warnings,
    }
    REPORTS.mkdir(exist_ok=True)
    OUT_JSON.write_text(json.dumps(report, indent=2), encoding="utf-8")

    # Summary
    counts: dict[str, int] = {}
    for info in computed.values():
        key = info["status"].split(" (")[0]
        counts[key] = counts.get(key, 0) + 1
    print("\nTraceability summary (commit %s%s)" % (commit[:10], "" if current else ", DIRTY -> STALE"))
    print(f"  tests: {totals}")
    for k in sorted(counts):
        print(f"  {k:28s} {counts[k]}")
    for rid, info in computed.items():
        st = info["status"]
        if st.startswith(("TESTING GAP", "INSUFFICIENT", "STALE", "FAILING", "NOT RUN")):
            print(f"  ! {rid}: {st}")
    for m, st in module_state.items():
        print(f"  module {m}: {st}")
    for w in warnings:
        print(f"  WARNING: {w}")
    for e in errors:
        print(f"  ERROR: {e}")
    if dirty:
        print(f"  NOTE: working tree has uncommitted changes ({len(dirty)} files): statuses are STALE until committed and re-run.")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
