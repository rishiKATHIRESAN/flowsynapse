#!/usr/bin/env sh
# FlowSynapse: runs scripts/smoke_test.py with the system Python (3.10+).
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PY=$(command -v python3 || command -v python)
[ -z "$PY" ] && { echo "Python 3.10+ not found" >&2; exit 1; }
exec "$PY" "$DIR/smoke_test.py" "$@"
