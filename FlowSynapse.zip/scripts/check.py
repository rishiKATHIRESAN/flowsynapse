"""Run every verification and print a PASS/FAIL summary. Non-zero exit on failure.

  scripts/check          full: backend tests, frontend typecheck/tests/build,
                         start/health/stop cycle, smoke test, docs check, traceability
  scripts/check --fast   backend unit+integration+api tests, frontend typecheck/tests/build
"""
from __future__ import annotations

import argparse
import subprocess
import sys
import time

from _common import BACKEND, FRONTEND, ROOT, VENV_PY, fail, npm_exe, say

results: list[tuple[str, str, float, str]] = []


def step(name: str, cmd: list[str], cwd=ROOT, timeout: float = 3600) -> bool:  # type: ignore[no-untyped-def]
    say(f"\n=== {name} ===\n> {' '.join(cmd)}")
    t0 = time.monotonic()
    try:
        rc = subprocess.call(cmd, cwd=str(cwd), timeout=timeout)
    except subprocess.TimeoutExpired:
        rc = -1
    dt = time.monotonic() - t0
    status = "PASS" if rc == 0 else "FAIL"
    results.append((name, status, dt, " ".join(cmd)))
    return rc == 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--fast", action="store_true")
    args = ap.parse_args()
    if not VENV_PY.exists():
        fail("backend/.venv missing; run scripts/setup first")
    npm = npm_exe()
    py = sys.executable

    if args.fast:
        step("backend tests (unit+integration+api)",
             [str(VENV_PY), "-m", "pytest", "-q", "tests/unit", "tests/integration", "tests/api", f"--junitxml={ROOT / 'reports' / 'junit-backend.xml'}"], BACKEND)
    else:
        step("backend tests (all layers)", [str(VENV_PY), "-m", "pytest", "-q", f"--junitxml={ROOT / 'reports' / 'junit-backend.xml'}"], BACKEND)
    if npm:
        step("frontend typecheck (tsc)", [npm, "run", "typecheck"], FRONTEND)
        step("frontend tests (vitest)", [npm, "run", "test", "--silent"], FRONTEND)
        step("frontend production build", [npm, "run", "build"], FRONTEND)
    else:
        results.append(("frontend", "NOT RUN", 0, "npm not found"))
    if not args.fast:
        step("start/health/stop cycle", [py, "scripts/start.py", "--cycle",
                                         "--backend-port", "8010", "--frontend-port", "5180"])
        if (ROOT / "scripts" / "smoke_test.py").exists():
            step("end-to-end smoke test", [py, "scripts/smoke_test.py"])
        if (ROOT / "scripts" / "check_docs.py").exists():
            step("docs check", [py, "scripts/check_docs.py"])
        step("traceability", [py, "scripts/run_traceability.py", "--no-run"])

    say("\n================ SUMMARY ================")
    for name, status, dt, _cmd in results:
        say(f"  {status:8s} {name}  ({dt:.1f}s)")
    failed = [r for r in results if r[1] == "FAIL"]
    say(f"\nOverall: {'FAIL' if failed else 'PASS'}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
