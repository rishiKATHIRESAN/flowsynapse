@echo off
rem FlowSynapse: runs scripts$name.py with the system Python (3.10+).
where python >nul 2>nul
if %ERRORLEVEL%==0 (
  python "%~dp0migrate.py" %*
) else (
  py -3 "%~dp0migrate.py" %*
)
exit /b %ERRORLEVEL%
