"""Run a test layer: scripts/test unit|integration|api|frontend|e2e|all [extra pytest args]."""
import subprocess
import sys

from _common import BACKEND, FRONTEND, VENV_PY, fail, npm_exe

LAYERS = ("unit", "integration", "api", "e2e")


def pytest(paths: list[str], extra: list[str]) -> int:
    return subprocess.call([str(VENV_PY), "-m", "pytest", *paths, *extra], cwd=str(BACKEND))


def main() -> int:
    if len(sys.argv) < 2:
        fail("usage: scripts/test unit|integration|api|frontend|e2e|all")
    layer, extra = sys.argv[1], sys.argv[2:]
    if layer in LAYERS:
        return pytest([f"tests/{layer}"], extra)
    if layer == "frontend":
        npm = npm_exe()
        assert npm
        return subprocess.call([npm, "run", "test"], cwd=str(FRONTEND))
    if layer == "all":
        rc = pytest(["tests"], extra)
        npm = npm_exe()
        assert npm
        return rc or subprocess.call([npm, "run", "test"], cwd=str(FRONTEND))
    fail(f"unknown layer {layer}")
    return 2


sys.exit(main())
