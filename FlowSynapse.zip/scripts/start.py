"""Start FlowSynapse: backend (127.0.0.1:8000) + Vite dev server (127.0.0.1:5173).

Checks dependencies and ports, waits for a valid backend health payload, then the
frontend, verifies /api/health through the Vite proxy, and on Ctrl+C stops both
process trees and confirms the ports are released.

``--cycle`` performs start -> health -> stop and exits (used by scripts/check).
"""
from __future__ import annotations

import argparse
import os
import signal
import sys
import time

from _common import (
    BACKEND,
    FRONTEND,

    VENV_PY,
    backend_env,
    describe_port_owner,
    fail,
    fetch_json,
    http_ok,
    node_exe,
    port_free,
    say,
    spawn,
    stop_tree,
    wait_for,
)


def main() -> int:
    ap = argparse.ArgumentParser(description="Start FlowSynapse")
    ap.add_argument("--backend-port", type=int, default=int(os.environ.get("FLOWSYNAPSE_BACKEND_PORT", "8000")))
    ap.add_argument("--frontend-port", type=int, default=int(os.environ.get("FLOWSYNAPSE_FRONTEND_PORT", "5173")))
    ap.add_argument("--cycle", action="store_true", help="start, verify health, stop, exit")
    ap.add_argument("--backend-only", action="store_true")
    ap.add_argument("--startup-timeout", type=float, default=90.0)
    args = ap.parse_args()
    bport, fport = args.backend_port, args.frontend_port

    # Dependencies
    if not VENV_PY.exists():
        fail("backend/.venv is missing. Run scripts/setup first.")
    vite_js = FRONTEND / "node_modules" / "vite" / "bin" / "vite.js"
    if not args.backend_only and not vite_js.exists():
        fail("frontend/node_modules is missing. Run scripts/setup first.")
    node = node_exe()
    if not args.backend_only and not node:
        fail("Node.js not found on PATH.")

    # Ports
    for port, name, flag in ((bport, "Backend", "--backend-port"), (fport, "Frontend", "--frontend-port")):
        if args.backend_only and name == "Frontend":
            continue
        if not port_free(port):
            fail(
                f"{name} port {port} is already in use by {describe_port_owner(port)}.\n"
                f"  Stop that process, or choose another port: scripts/start {flag} <port> "
                f"(or set FLOWSYNAPSE_{name.upper()}_PORT)."
            )

    logs = BACKEND / "data" / "logs"
    env = backend_env(bport, fport)
    procs: list[tuple[str, object]] = []

    def shutdown(code: int) -> int:
        say("\nStopping FlowSynapse...")
        for name, p in reversed(procs):
            stop_tree(p, name)  # type: ignore[arg-type]
        released = wait_for(lambda: port_free(bport) and (args.backend_only or port_free(fport)), 15)
        say("Ports released." if released else f"WARNING: ports {bport}/{fport} still in use; see README 'orphaned processes'.")
        return code if released else (code or 1)

    say(f"Starting backend on http://127.0.0.1:{bport} ...")
    backend = spawn([str(VENV_PY), "-m", "app.cli", "serve", "--port", str(bport)], BACKEND, env, logs / "backend-console.log")
    procs.append(("backend", backend))

    def backend_healthy() -> bool:
        h = fetch_json(f"http://127.0.0.1:{bport}/api/health")
        return bool(h and h.get("app") == "flowsynapse" and h.get("status") == "ok")

    try:
        if not wait_for(backend_healthy, args.startup_timeout, proc=backend):
            say(f"Backend failed to become healthy. See {logs / 'backend-console.log'}")
            return shutdown(1)
        health = fetch_json(f"http://127.0.0.1:{bport}/api/health") or {}
        say(f"  backend healthy (instance {health.get('instance_id')}, db {health.get('db_revision')})")

        if not args.backend_only:
            say(f"Starting frontend on http://127.0.0.1:{fport} ...")
            fenv = dict(os.environ, FLOWSYNAPSE_BACKEND_PORT=str(bport), FLOWSYNAPSE_FRONTEND_PORT=str(fport))
            frontend = spawn([node, str(vite_js), "--port", str(fport), "--strictPort", "--host", "127.0.0.1"],
                             FRONTEND, fenv, logs / "frontend-console.log")
            procs.append(("frontend", frontend))
            if not wait_for(lambda: http_ok(f"http://127.0.0.1:{fport}/"), args.startup_timeout, proc=frontend):
                say(f"Frontend failed to start. See {logs / 'frontend-console.log'}")
                return shutdown(1)
            proxied = fetch_json(f"http://127.0.0.1:{fport}/api/health")
            if not proxied or proxied.get("instance_id") != health.get("instance_id"):
                say("Frontend proxy cannot reach this backend's /api/health (proxy misconfigured?).")
                return shutdown(1)
            say("  frontend reachable; /api/health verified through the proxy")

        say("")
        if not args.backend_only:
            say(f"  FlowSynapse UI : http://127.0.0.1:{fport}")
        say(f"  API docs       : http://127.0.0.1:{bport}/docs")
        say("")
        if args.cycle:
            return shutdown(0)
        say("Press Ctrl+C to stop.")
        while True:
            time.sleep(1)
            for name, p in procs:
                if p.poll() is not None:  # type: ignore[attr-defined]
                    say(f"{name} exited unexpectedly (code {p.returncode}).")  # type: ignore[attr-defined]
                    return shutdown(1)
    except KeyboardInterrupt:
        return shutdown(0)


if __name__ == "__main__":
    if sys.platform == "win32":
        # Closing the console window delivers CTRL_CLOSE_EVENT; treat like Ctrl+C.
        signal.signal(signal.SIGBREAK, signal.default_int_handler)  # type: ignore[attr-defined]
    else:
        signal.signal(signal.SIGTERM, signal.default_int_handler)
        signal.signal(signal.SIGHUP, signal.default_int_handler)
    sys.exit(main())
