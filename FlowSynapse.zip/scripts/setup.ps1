# FlowSynapse: runs scripts/setup.py with the system Python (3.10+).
$ErrorActionPreference = 'Stop'
$py = Get-Command python -ErrorAction SilentlyContinue
if (-not $py) { $py = Get-Command py -ErrorAction SilentlyContinue }
if (-not $py) { Write-Error 'Python 3.10+ not found. Install it from https://www.python.org/downloads/'; exit 1 }
& $py.Source "$PSScriptRoot$name.py" @args
exit $LASTEXITCODE
