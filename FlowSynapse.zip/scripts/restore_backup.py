"""Restore a verified database backup: scripts/restore_backup <backup-file>.

Verifies integrity + manifest, saves a safety backup of the current DB, then swaps.
The backend must be stopped first.
"""
import subprocess
import sys
from pathlib import Path

from _common import BACKEND, VENV_PY, fail

if len(sys.argv) != 2:
    fail("usage: scripts/restore_backup <path-to-backup.db>")
if not VENV_PY.exists():
    fail("backend/.venv is missing. Run scripts/setup first.")
target = str(Path(sys.argv[1]).resolve())
sys.exit(subprocess.call([str(VENV_PY), "-m", "app.cli", "restore-backup", target], cwd=str(BACKEND)))
