#!/usr/bin/env sh
# FlowSynapse: runs scripts/run_traceability.py with the system Python (3.10+).
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PY=$(command -v python3 || command -v python)
[ -z "$PY" ] && { echo "Python 3.10+ not found" >&2; exit 1; }
exec "$PY" "$DIR/run_traceability.py" "$@"
