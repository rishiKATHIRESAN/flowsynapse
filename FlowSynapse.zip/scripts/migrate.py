"""Run the safe migration procedure (same code path as startup)."""
import subprocess
import sys

from _common import BACKEND, VENV_PY, fail

if not VENV_PY.exists():
    fail("backend/.venv is missing. Run scripts/setup first.")
sys.exit(subprocess.call([str(VENV_PY), "-m", "app.cli", "migrate"], cwd=str(BACKEND)))
