@echo off
rem FlowSynapse: runs scripts$name.py with the system Python (3.10+).
where python >nul 2>nul
if %ERRORLEVEL%==0 (
  python "%~dp0test.py" %*
) else (
  py -3 "%~dp0test.py" %*
)
exit /b %ERRORLEVEL%
