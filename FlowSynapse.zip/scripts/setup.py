"""FlowSynapse setup (idempotent): toolchain checks, venv, dependencies, .env, database."""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys

from _common import BACKEND, FRONTEND, IS_WIN, VENV_PY, check_toolchain, fail, npm_exe, run, say


def main() -> int:
    ap = argparse.ArgumentParser(description="Set up FlowSynapse")
    ap.add_argument("--skip-frontend", action="store_true")
    args = ap.parse_args()

    say("[1/6] Checking toolchain")
    check_toolchain()

    say("[2/6] Backend virtual environment")
    if not VENV_PY.exists():
        run([sys.executable, "-m", "venv", str(BACKEND / ".venv")])
    else:
        say("  backend/.venv already exists")

    say("[3/6] Backend dependencies (pinned in backend/requirements.txt)")
    try:
        run([str(VENV_PY), "-m", "pip", "install", "--disable-pip-version-check", "-q", "-r",
             str(BACKEND / "requirements.txt")], timeout=1800)
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
        fail(f"pip install failed ({exc}). Check your network/proxy, then re-run setup. See README troubleshooting.")
    chk = run([str(VENV_PY), "-m", "pip", "check"], check=False, capture=True)
    if chk.returncode != 0:
        fail("pip check reported broken requirements:\n" + chk.stdout + chk.stderr)
    say("  pip check: OK")

    if not args.skip_frontend:
        say("[4/6] Frontend dependencies (package-lock.json)")
        if not (FRONTEND / "package-lock.json").exists():
            fail("frontend/package-lock.json is missing; cannot do a reproducible install.")
        npm = npm_exe()
        assert npm
        try:
            run([npm, "ci", "--no-audit", "--no-fund"], cwd=FRONTEND, timeout=1800)
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
            fail(f"npm ci failed ({exc}). Check your network, delete frontend/node_modules and re-run setup.")
    else:
        say("[4/6] Frontend dependencies: skipped (--skip-frontend)")

    say("[5/6] Configuration")
    env_file = BACKEND / ".env"
    if not env_file.exists():
        shutil.copyfile(BACKEND / ".env.example", env_file)
        say("  created backend/.env from backend/.env.example (mock provider, no API key needed)")
    else:
        say("  backend/.env already exists (left unchanged)")

    say("[6/6] Database (safe migrations)")
    res = run([str(VENV_PY), "-m", "app.cli", "migrate"], cwd=BACKEND, check=False)
    if res.returncode != 0:
        fail("Database migration failed; see the message above. Your data was not modified.")

    start = r".\scripts\start.ps1" if IS_WIN else "./scripts/start.sh"
    say(f"\nSetup complete. Start FlowSynapse with: {start}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
