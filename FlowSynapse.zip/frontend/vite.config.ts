/// <reference types="vitest/config" />
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

const backendPort = process.env.FLOWSYNAPSE_BACKEND_PORT ?? '8000'
const frontendPort = Number(process.env.FLOWSYNAPSE_FRONTEND_PORT ?? '5173')

export default defineConfig({
  plugins: [react()],
  server: {
    host: '127.0.0.1',
    port: frontendPort,
    strictPort: true,
    proxy: {
      '/api': { target: `http://127.0.0.1:${backendPort}`, changeOrigin: false },
    },
  },
  preview: { host: '127.0.0.1', port: frontendPort, strictPort: true },
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['./src/test/setup.ts'],
    css: false,
    reporters: ['default', 'junit'],
    outputFile: { junit: '../reports/junit-frontend.xml' },
  },
})
