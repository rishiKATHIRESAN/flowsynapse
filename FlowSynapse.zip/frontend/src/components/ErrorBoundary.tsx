import { Component, type ErrorInfo, type ReactNode } from 'react'

interface State {
  error: Error | null
}

/** Shows a recoverable message instead of a blank page. */
export class ErrorBoundary extends Component<{ children: ReactNode }, State> {
  state: State = { error: null }

  static getDerivedStateFromError(error: Error): State {
    return { error }
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    console.error('UI error', error, info.componentStack)
  }

  render() {
    if (this.state.error) {
      return (
        <div className="alert alert-error" role="alert">
          <h2>This page hit an unexpected error</h2>
          <p>{this.state.error.message}</p>
          <p>Your saved data is safe on the server. You can retry or go back to the dashboard.</p>
          <button type="button" className="btn" onClick={() => this.setState({ error: null })}>
            Retry
          </button>{' '}
          <a className="btn" href="/">
            Dashboard
          </a>
        </div>
      )
    }
    return this.props.children
  }
}
