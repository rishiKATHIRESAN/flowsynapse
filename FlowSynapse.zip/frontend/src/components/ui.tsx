/** Shared presentational components (master prompt 4). */
import { useEffect, useId, useRef, useState, type ReactNode } from 'react'
import { ApiError, downloadFile, saveBlob, type RequestOptions } from '../api/client'
import type { ContentStatus, ExecutionStatus, StageStatus } from '../types/api'

const STATUS_LABEL: Record<string, string> = {
  PENDING: 'Pending',
  RUNNING: 'Running',
  COMPLETED: 'Completed',
  COMPLETED_WITH_WARNINGS: 'Completed with warnings',
  FAILED: 'Failed',
  CANCELLED: 'Cancelled',
  SKIPPED: 'Skipped',
  CARRIED_FORWARD: 'Carried forward',
  OUTDATED: 'Outdated',
  DRAFT: 'Draft',
  READY: 'Ready',
  READY_FOR_REVIEW: 'Ready for review',
  NEEDS_REVISION: 'Needs revision',
  READY_TO_EXPORT: 'Ready to export',
  VALID: 'Valid',
  INVALID: 'Invalid',
  INVALID_DRAFT: 'Invalid draft',
  COMPLETE: 'Complete',
  PARTIAL: 'Partial',
}

export function StatusBadge({ status, outdated }: { status: ExecutionStatus | StageStatus | ContentStatus | string; outdated?: boolean }) {
  const s = outdated && (status === 'COMPLETED' || status === 'CARRIED_FORWARD') ? 'OUTDATED' : status
  return (
    <span className={`badge badge-${s.toLowerCase()}`} data-testid="status-badge">
      {STATUS_LABEL[s] ?? s}
    </span>
  )
}

export function ProviderBadge({ provider, model, isMock }: { provider: string | null | undefined; model?: string | null; isMock?: boolean | null }) {
  if (!provider) return null
  if (isMock || provider === 'mock') {
    return (
      <span className="badge badge-mock" title="Deterministic mock output built from your inputs">
        Demo/Mock mode - not real AI output
      </span>
    )
  }
  return <span className="badge badge-provider">{model ? `${provider} / ${model}` : provider}</span>
}

export function DemoBadge({ isDemo }: { isDemo: boolean | undefined }) {
  if (!isDemo) return null
  return (
    <span className="badge badge-demo" title="Synthetic demonstration data">
      Demo data
    </span>
  )
}

export function Spinner({ label = 'Loading...' }: { label?: string }) {
  return (
    <span className="spinner" role="status" aria-live="polite">
      <span className="spinner-dot" aria-hidden="true" />
      {label}
    </span>
  )
}

export function EmptyState({ title, children, action }: { title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="empty">
      <h3>{title}</h3>
      {children && <p>{children}</p>}
      {action}
    </div>
  )
}

export function errorText(e: unknown): string {
  if (e instanceof ApiError) return e.message
  if (e instanceof Error) return e.message
  return 'Something went wrong.'
}

export function ErrorBanner({ error, onRetry, title = 'Something went wrong' }: { error: unknown; onRetry?: () => void; title?: string }) {
  if (!error) return null
  const api = error instanceof ApiError ? error : null
  return (
    <div className="alert alert-error" role="alert">
      <strong>{title}:</strong> {errorText(error)}
      {api?.code && <span className="muted"> ({api.code})</span>}
      {onRetry && (
        <button type="button" className="btn btn-small" onClick={onRetry}>
          Try again
        </button>
      )}
    </div>
  )
}

export function Notice({ kind = 'info', children }: { kind?: 'info' | 'warning' | 'success'; children: ReactNode }) {
  return (
    <div className={`alert alert-${kind}`} role={kind === 'warning' ? 'alert' : 'status'}>
      {children}
    </div>
  )
}

export interface Column<T> {
  key: string
  header: string
  render: (row: T) => ReactNode
}

export function DataTable<T>({ columns, rows, rowKey, empty }: { columns: Column<T>[]; rows: T[]; rowKey: (r: T) => string; empty?: ReactNode }) {
  if (!rows.length) return <>{empty ?? <p className="muted">No rows.</p>}</>
  return (
    <div className="table-wrap">
      <table className="table">
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c.key} scope="col">
                {c.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={rowKey(r)}>
              {columns.map((c) => (
                <td key={c.key}>{c.render(r)}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export function Pagination({ total, limit, offset, onChange }: { total: number; limit: number; offset: number; onChange: (offset: number) => void }) {
  if (total <= limit) return null
  const page = Math.floor(offset / limit) + 1
  const pages = Math.ceil(total / limit)
  return (
    <nav className="pagination" aria-label="Pagination">
      <button type="button" className="btn btn-small" disabled={offset === 0} onClick={() => onChange(Math.max(0, offset - limit))}>
        Previous
      </button>
      <span>
        Page {page} of {pages} ({total} total)
      </span>
      <button type="button" className="btn btn-small" disabled={offset + limit >= total} onClick={() => onChange(offset + limit)}>
        Next
      </button>
    </nav>
  )
}

/** Modal confirmation that names exactly what will happen; traps focus. */
export function ConfirmDialog({
  open,
  title,
  children,
  confirmLabel = 'Confirm',
  danger,
  busy,
  onConfirm,
  onCancel,
}: {
  open: boolean
  title: string
  children: ReactNode
  confirmLabel?: string
  danger?: boolean
  busy?: boolean
  onConfirm: () => void
  onCancel: () => void
}) {
  const ref = useRef<HTMLDivElement>(null)
  const titleId = useId()
  useEffect(() => {
    if (!open) return
    const prev = document.activeElement as HTMLElement | null
    const el = ref.current
    el?.querySelector<HTMLElement>('button')?.focus()
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onCancel()
      if (e.key === 'Tab' && el) {
        const items = Array.from(el.querySelectorAll<HTMLElement>('button, [href], input, select, textarea'))
        if (!items.length) return
        const first = items[0]
        const last = items[items.length - 1]
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault()
          last.focus()
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault()
          first.focus()
        }
      }
    }
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('keydown', onKey)
      prev?.focus()
    }
  }, [open, onCancel])
  if (!open) return null
  return (
    <div className="modal-backdrop">
      <div className="modal" role="dialog" aria-modal="true" aria-labelledby={titleId} ref={ref}>
        <h2 id={titleId}>{title}</h2>
        <div className="modal-body">{children}</div>
        <div className="modal-actions">
          <button type="button" className="btn" onClick={onCancel} disabled={busy}>
            Cancel
          </button>
          <button type="button" className={`btn ${danger ? 'btn-danger' : 'btn-primary'}`} onClick={onConfirm} disabled={busy}>
            {busy ? 'Working...' : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  )
}

/** Download control with its own loading and error state. Never reports
 * success unless the backend returned a file. */
export function DownloadButton({
  path,
  query,
  label,
  fallbackName,
  disabled,
  disabledReason,
}: {
  path: string
  query?: RequestOptions['query']
  label: string
  fallbackName: string
  disabled?: boolean
  disabledReason?: string
}) {
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const run = async () => {
    setBusy(true)
    setError(null)
    try {
      saveBlob(await downloadFile(path, query, fallbackName))
    } catch (e) {
      setError(errorText(e))
    } finally {
      setBusy(false)
    }
  }
  return (
    <span className="download">
      <button type="button" className="btn" onClick={run} disabled={busy || disabled} title={disabled ? disabledReason : undefined}>
        {busy ? `Preparing ${label}...` : label}
      </button>
      {disabled && disabledReason && <span className="muted small"> {disabledReason}</span>}
      {error && (
        <span className="field-error" role="alert">
          {error}
        </span>
      )}
    </span>
  )
}

const CONTENT_NEXT: Record<ContentStatus, ContentStatus[]> = {
  DRAFT: ['READY_FOR_REVIEW'],
  READY_FOR_REVIEW: ['NEEDS_REVISION', 'READY_TO_EXPORT', 'DRAFT'],
  NEEDS_REVISION: ['DRAFT', 'READY_FOR_REVIEW'],
  READY_TO_EXPORT: ['NEEDS_REVISION', 'DRAFT'],
}

export function ContentStatusControl({
  status,
  onChange,
  disabled,
  disabledReason,
}: {
  status: ContentStatus | null
  onChange: (to: ContentStatus) => Promise<void>
  disabled?: boolean
  disabledReason?: string
}) {
  const current = status ?? 'DRAFT'
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const id = useId()
  return (
    <span className="content-status">
      <StatusBadge status={current} />
      <label htmlFor={id} className="sr-only">
        Change content status
      </label>
      <select
        id={id}
        value=""
        disabled={busy || disabled}
        title={disabled ? disabledReason : undefined}
        onChange={async (e) => {
          const to = e.target.value as ContentStatus
          if (!to) return
          setBusy(true)
          setError(null)
          try {
            await onChange(to)
          } catch (err) {
            setError(errorText(err))
          } finally {
            setBusy(false)
          }
        }}
      >
        <option value="">Move to...</option>
        {CONTENT_NEXT[current].map((s) => (
          <option key={s} value={s}>
            {STATUS_LABEL[s]}
          </option>
        ))}
      </select>
      {error && (
        <span className="field-error" role="alert">
          {error}
        </span>
      )}
    </span>
  )
}

export function Field({
  label,
  name,
  required,
  error,
  hint,
  children,
}: {
  label: string
  name: string
  required?: boolean
  error?: string
  hint?: string
  children: (props: { id: string; 'aria-invalid': boolean; 'aria-describedby': string | undefined }) => ReactNode
}) {
  const id = `f-${name}`
  const describedBy = [error ? `${id}-err` : null, hint ? `${id}-hint` : null].filter(Boolean).join(' ') || undefined
  return (
    <div className={`field ${error ? 'field-invalid' : ''}`}>
      <label htmlFor={id}>
        {label}
        {required && (
          <span className="req" aria-hidden="true">
            {' '}
            *
          </span>
        )}
      </label>
      {children({ id, 'aria-invalid': Boolean(error), 'aria-describedby': describedBy })}
      {hint && (
        <span id={`${id}-hint`} className="hint">
          {hint}
        </span>
      )}
      {error && (
        <span id={`${id}-err`} className="field-error" role="alert">
          {error}
        </span>
      )}
    </div>
  )
}

export function formatDate(iso: string | null | undefined): string {
  if (!iso) return '-'
  const d = new Date(iso)
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleString()
}
