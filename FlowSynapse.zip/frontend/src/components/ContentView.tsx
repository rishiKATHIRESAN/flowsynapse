/** Readable, escaped rendering of structured output content (no innerHTML). */
function label(k: string): string {
  return k.replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase())
}

function isTagged(v: unknown): v is { text: string; source: string } {
  return typeof v === 'object' && v !== null && 'text' in v && 'source' in v && Object.keys(v).length === 2
}

export function ContentView({ value, depth = 0 }: { value: unknown; depth?: number }) {
  if (value === null || value === undefined || value === '') return <span className="muted">-</span>
  if (isTagged(value)) {
    return (
      <span>
        {value.text} <span className={`badge badge-source-${value.source}`}>{value.source.replace('_', ' ')}</span>
      </span>
    )
  }
  if (Array.isArray(value)) {
    if (value.length === 0) return <span className="muted">none</span>
    if (value.every((x) => typeof x !== 'object' || x === null || isTagged(x))) {
      return (
        <ul className="content-list">
          {value.map((x, i) => (
            <li key={i}>
              <ContentView value={x} depth={depth + 1} />
            </li>
          ))}
        </ul>
      )
    }
    return (
      <div>
        {value.map((x, i) => (
          <div key={i} className="content-block">
            <ContentView value={x} depth={depth + 1} />
          </div>
        ))}
      </div>
    )
  }
  if (typeof value === 'object') {
    return (
      <dl className="kv">
        {Object.entries(value as Record<string, unknown>).map(([k, v]) => (
          <div key={k} style={{ display: 'contents' }}>
            <dt>{label(k)}</dt>
            <dd>
              <ContentView value={v} depth={depth + 1} />
            </dd>
          </div>
        ))}
      </dl>
    )
  }
  if (typeof value === 'boolean') return <span>{value ? 'yes' : 'no'}</span>
  return <span>{String(value)}</span>
}
