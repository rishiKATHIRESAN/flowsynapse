import { useState } from 'react'
import { NavLink, Outlet } from 'react-router-dom'
import { useBackendHealth } from '../hooks/useBackendHealth'
import { MODULES } from '../modules/catalogue'
import { ConnectionIndicator } from './ConnectionIndicator'
import { ErrorBoundary } from './ErrorBoundary'

export function Layout() {
  const health = useBackendHealth()
  const [open, setOpen] = useState(false)
  return (
    <div className="shell">
      <a href="#main" className="skip-link">
        Skip to content
      </a>
      <header className="topbar">
        <button type="button" className="btn btn-small nav-toggle" aria-expanded={open} aria-controls="sidebar" onClick={() => setOpen((o) => !o)}>
          Menu
        </button>
        <NavLink to="/" className="brand">
          FlowSynapse
        </NavLink>
        <ConnectionIndicator state={health} />
      </header>
      <div className="body">
        <nav id="sidebar" className={`sidebar ${open ? 'open' : ''}`} aria-label="Main navigation">
          <ul>
            <li>
              <NavLink to="/" end onClick={() => setOpen(false)}>
                Dashboard
              </NavLink>
            </li>
            {MODULES.map((m, i) => (
              <li key={m.key}>
                <NavLink to={m.route} onClick={() => setOpen(false)}>
                  <span className="nav-num">{i + 1}</span> {m.short}
                </NavLink>
              </li>
            ))}
            <li>
              <NavLink to="/settings" onClick={() => setOpen(false)}>
                Settings
              </NavLink>
            </li>
          </ul>
        </nav>
        <main id="main" className="main" tabIndex={-1}>
          {health.kind === 'unreachable' && (
            <div className="alert alert-error" role="alert">
              {health.detail}
            </div>
          )}
          {health.kind === 'foreign' && (
            <div className="alert alert-error" role="alert">
              {health.detail} FlowSynapse will not send requests to it. Stop that service or change the backend port.
            </div>
          )}
          <ErrorBoundary>
            <Outlet />
          </ErrorBoundary>
        </main>
      </div>
    </div>
  )
}
