import type { ConnectionState } from '../api/health'

const LABELS: Record<ConnectionState['kind'], string> = {
  checking: 'Checking backend...',
  connected: 'Backend connected',
  starting: 'Backend starting',
  foreign: 'Wrong service on backend port',
  unreachable: 'Backend unreachable',
}

export function ConnectionIndicator({ state }: { state: ConnectionState }) {
  const title =
    state.kind === 'connected' || state.kind === 'starting'
      ? `FlowSynapse ${state.health.version} (db ${state.health.db_revision ?? 'none'})`
      : state.kind === 'foreign' || state.kind === 'unreachable'
        ? state.detail
        : undefined
  return (
    <div className={`conn conn-${state.kind}`} role="status" aria-live="polite" title={title} data-testid="connection-indicator">
      <span className="conn-dot" aria-hidden="true" />
      <span>{LABELS[state.kind]}</span>
    </div>
  )
}
