import type { Execution, Stage } from '../types/api'
import { ProviderBadge, StatusBadge } from './ui'

export interface StageView {
  stage: Stage
  label: string
  outdated?: boolean
  outdatedReason?: string | null
}

/** Timeline driven only by persisted stage states from the API. Progress is
 * the count of actually completed stages - no timers or fake percentages. */
export function StageTimeline({
  execution,
  labels,
  outdated,
  selected,
  onSelect,
}: {
  execution: Execution
  labels?: Record<string, string>
  outdated?: Record<string, { is_outdated: boolean; outdated_reason: string | null }>
  selected?: string
  onSelect?: (stageKey: string) => void
}) {
  const { completed, total } = execution.progress
  return (
    <div className="timeline" aria-label="Stage timeline">
      <p className="muted" data-testid="progress">
        {completed} of {total} stages completed
      </p>
      <ol className="timeline-list">
        {execution.stages.map((s) => {
          const o = outdated?.[s.stage_key]
          const name = labels?.[s.stage_key] ?? s.stage_key
          const label = s.item_id ? `${name} - ${s.item_id}` : name
          return (
            <li key={s.id} className={`timeline-item status-${s.status.toLowerCase()} ${selected === s.stage_key ? 'selected' : ''}`}>
              <button type="button" className="timeline-btn" onClick={() => onSelect?.(s.stage_key)} aria-pressed={selected === s.stage_key}>
                <span className="timeline-pos">{s.position + 1}</span>
                <span className="timeline-name">{label}</span>
                <StatusBadge status={s.status} outdated={o?.is_outdated} />
                {s.provider && <ProviderBadge provider={s.provider} model={s.model} isMock={s.is_mock} />}
              </button>
              {s.error_message && (
                <p className="timeline-error" role="alert">
                  {s.error_message}
                  {s.retryable === false ? ' (not retryable - change inputs or provider)' : s.retryable ? ' (retry is possible)' : ''}
                </p>
              )}
              {o?.is_outdated && o.outdated_reason && <p className="timeline-outdated">Outdated: {o.outdated_reason}</p>}
            </li>
          )
        })}
      </ol>
    </div>
  )
}
