import { RouterProvider, createBrowserRouter, type RouteObject } from 'react-router-dom'
import { Layout } from './components/Layout'
import { ToastProvider } from './components/Toast'
import { MODULES } from './modules/catalogue'
import { Dashboard } from './pages/Dashboard'
import { NotFound, NotImplemented } from './pages/Placeholders'
import { SettingsPage } from './pages/Settings'
import { moduleRoutes } from './modules/routes'

export const routes: RouteObject[] = [
  {
    path: '/',
    element: <Layout />,
    children: [
      { index: true, element: <Dashboard /> },
      ...MODULES.map((m) => moduleRoutes[m.key] ?? { path: m.route.slice(1) + '/*', element: <NotImplemented module={m} /> }),
      { path: 'settings', element: <SettingsPage /> },
      { path: '*', element: <NotFound /> },
    ],
  },
]

export default function App({ router }: { router?: ReturnType<typeof createBrowserRouter> }) {
  return (
    <ToastProvider>
      <RouterProvider router={router ?? createBrowserRouter(routes)} />
    </ToastProvider>
  )
}
