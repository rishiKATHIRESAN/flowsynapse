/** The six automation modules in final priority order (master prompt 1). */
export interface ModuleInfo {
  key: string
  title: string
  short: string
  route: string
  purpose: string
}

export const MODULES: ModuleInfo[] = [
  {
    key: 'campaigns',
    title: 'AI Marketing Campaign Intelligence Engine',
    short: 'Campaign Intelligence',
    route: '/campaigns',
    purpose: 'Brief to 12-stage strategy, concepts, Google/Meta proposals, social plan, tracking, budget, QA and campaign pack.',
  },
  {
    key: 'funnels',
    title: 'AI Marketing Funnel Builder',
    short: 'Funnel Builder',
    route: '/funnels',
    purpose: 'Configurable customer-journey funnel with an interactive diagram, validation and per-stage content recommendations.',
  },
  {
    key: 'seo',
    title: 'Website SEO Audit & SEO Report Generator',
    short: 'SEO Audit',
    route: '/seo',
    purpose: 'Verifiable technical and on-page SEO findings from an actual crawl, with a report.',
  },
  {
    key: 'website',
    title: 'Website Intelligence & Website Report Generator',
    short: 'Website Intelligence',
    route: '/website-reports',
    purpose: 'Evidence-based assessment of structure, navigation, content and conversion paths.',
  },
  {
    key: 'blogs',
    title: 'AI Bulk Blog & Content Generator',
    short: 'Bulk Blog',
    route: '/blogs',
    purpose: 'Batch blog drafts with per-item status and failed-only retry.',
  },
  {
    key: 'social',
    title: 'AI Social Media Campaign & Content Calendar Generator',
    short: 'Social Calendar',
    route: '/social',
    purpose: 'Platform-specific content on a cadence-based calendar.',
  },
]
