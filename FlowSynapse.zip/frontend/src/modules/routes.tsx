import type { RouteObject } from 'react-router-dom'
import { CampaignDetail } from './campaigns/CampaignDetail'
import { CampaignList } from './campaigns/CampaignList'
import { CampaignNew } from './campaigns/CampaignNew'
import { useSearchParams, Navigate } from 'react-router-dom'

function CampaignIndex() {
  const [params] = useSearchParams()
  return params.get('new') ? <Navigate to="/campaigns/new" replace /> : <CampaignList />
}

/** Module routes, keyed by catalogue key. Modules register here as they are built. */
export const moduleRoutes: Record<string, RouteObject> = {
  campaigns: {
    path: 'campaigns',
    children: [
      { index: true, element: <CampaignIndex /> },
      { path: 'new', element: <CampaignNew /> },
      { path: ':id', element: <CampaignDetail /> },
    ],
  },
}
