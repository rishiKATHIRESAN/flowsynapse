import { useCallback, useEffect, useState } from 'react'
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { ApiError } from '../../api/client'
import { StageTimeline } from '../../components/StageTimeline'
import { useToast } from '../../components/Toast'
import {
  ConfirmDialog,
  DemoBadge,
  DownloadButton,
  ErrorBanner,
  Notice,
  ProviderBadge,
  Spinner,
  StatusBadge,
  errorText,
  formatDate,
} from '../../components/ui'
import { useAsync, useExecutionPolling, useUnsavedChanges } from '../../hooks/hooks'
import { TERMINAL_STATUSES, type Execution } from '../../types/api'
import { campaignsApi, type Brief, type CampaignDetail as Detail } from './api'
import { BriefForm, errorsByField } from './BriefForm'
import { StagePanel } from './StagePanel'

type Tab = 'run' | 'brief' | 'exports' | 'history'

export function CampaignDetail() {
  const { id = '' } = useParams()
  const [params, setParams] = useSearchParams()
  const tab = (params.get('tab') as Tab) || 'run'
  const { data, error, loading, reload, setData } = useAsync((s) => campaignsApi.get(id, s), [id])
  const setTab = (t: Tab) => setParams({ tab: t }, { replace: true })

  if (loading && !data) return <Spinner />
  if (error) return <ErrorBanner error={error} onRetry={reload} title="Could not load the campaign" />
  if (!data) return null
  return (
    <div>
      <p className="small">
        <Link to="/campaigns">All campaigns</Link>
      </p>
      <div className="page-head">
        <h1>
          {data.name} <DemoBadge isDemo={data.is_demo} />
        </h1>
        <span className="chips">
          <StatusBadge status={data.status} />
          <span className="muted small">{data.identifier}</span>
        </span>
      </div>
      {data.healthcare_disclaimer && <Notice kind="warning">{data.healthcare_disclaimer}</Notice>}
      {data.outdated_stages.length > 0 && (
        <Notice kind="warning">
          Outdated: {data.outdated_stages.map((s) => data.stage_labels[s]).join(', ')}. Regenerate them before exporting.
        </Notice>
      )}
      <div className="tabs" role="tablist">
        {(['run', 'brief', 'exports', 'history'] as Tab[]).map((t) => (
          <button key={t} role="tab" type="button" aria-selected={tab === t} onClick={() => setTab(t)}>
            {{ run: 'Run & outputs', brief: 'Brief', exports: 'Downloads', history: 'History' }[t]}
          </button>
        ))}
      </div>
      {tab === 'run' && <RunTab campaign={data} onChanged={reload} />}
      {tab === 'brief' && <BriefTab campaign={data} onSaved={(c) => setData(c)} />}
      {tab === 'exports' && <ExportsTab campaign={data} />}
      {tab === 'history' && <HistoryTab campaign={data} />}
    </div>
  )
}

function RunTab({ campaign, onChanged }: { campaign: Detail; onChanged: () => void }) {
  const toast = useToast()
  const latest = campaign.latest_execution
  const active = latest && !TERMINAL_STATUSES.includes(latest.status) ? latest : null
  const [execId, setExecId] = useState<string | null>(active?.id ?? null)
  const [busy, setBusy] = useState<string | null>(null)
  const [actionError, setActionError] = useState<unknown>(null)
  const [selected, setSelected] = useState<string>('OBJECTIVE_ANALYSIS')
  const onTerminal = useCallback(() => onChanged(), [onChanged])
  const polled = useExecutionPolling(execId ? `/api/campaigns/${campaign.id}/executions/${execId}` : null, onTerminal)
  const execution: Execution | null = polled.execution ?? latest
  const running = execution && !TERMINAL_STATUSES.includes(execution.status)

  useEffect(() => {
    if (active && active.id !== execId) setExecId(active.id)
  }, [active, execId])

  const act = async (name: string, fn: () => Promise<Execution | void>, okMsg: string) => {
    setBusy(name)
    setActionError(null)
    try {
      const ex = await fn()
      if (ex) setExecId(ex.id)
      toast.push('success', okMsg)
    } catch (e) {
      setActionError(e)
    } finally {
      setBusy(null)
    }
  }

  const failed = execution?.stages.find((s) => s.status === 'FAILED')
  return (
    <div className="split">
      <section className="panel">
        <h2>Workflow</h2>
        <div className="btn-row">
          <button
            type="button"
            className="btn btn-primary"
            disabled={busy !== null || Boolean(running)}
            title={running ? 'An execution is already running' : undefined}
            onClick={() => act('run', () => campaignsApi.start(campaign.id), 'Execution requested.')}
          >
            {busy === 'run' ? 'Starting...' : execution ? 'Run again (full)' : 'Run Campaign Intelligence'}
          </button>
          {running && execution && (
            <button type="button" className="btn btn-danger" disabled={busy !== null || execution.cancel_requested} onClick={() => act('cancel', () => campaignsApi.cancel(campaign.id, execution.id), 'Cancellation requested. Completed stages are preserved.')}>
              {execution.cancel_requested ? 'Cancelling...' : 'Cancel'}
            </button>
          )}
          {!running && execution && failed && (
            <button
              type="button"
              className="btn"
              disabled={busy !== null || failed.retryable === false}
              title={failed.retryable === false ? 'Not retryable: change the inputs or the provider' : undefined}
              onClick={() => act('retry', () => campaignsApi.retryStage(campaign.id, execution.id, failed.stage_key), `Retrying ${campaign.stage_labels[failed.stage_key]}.`)}
            >
              Retry failed stage ({campaign.stage_labels[failed.stage_key]})
            </button>
          )}
        </div>
        {!campaign.brief_valid && <Notice kind="warning">The brief has blocking validation errors; the run will stop at input validation. Open the Brief tab to fix them.</Notice>}
        <ErrorBanner error={actionError} title="Action failed" />
        {polled.error ? <ErrorBanner error={polled.error} title="Lost contact while polling (will keep trying)" /> : null}
        {execution ? (
          <>
            <p className="small chips">
              <StatusBadge status={execution.status} /> <ProviderBadge provider={execution.provider} model={execution.model} isMock={execution.is_mock} />
              {execution.scope !== 'FULL' && <span className="muted">{execution.scope} (attempt {execution.attempt_number})</span>}
            </p>
            {execution.error_message && (
              <p className="field-error" role="alert">
                {execution.error_message} {execution.retryable ? '(retry is possible)' : execution.retryable === false ? '(change inputs or provider)' : ''}
              </p>
            )}
            <StageTimeline execution={execution} labels={campaign.stage_labels} outdated={campaign.stage_states} selected={selected} onSelect={setSelected} />
          </>
        ) : (
          <p className="muted">Not run yet. Run Campaign Intelligence to generate the stages.</p>
        )}
      </section>
      <section className="panel">
        <StagePanel campaign={campaign} stageKey={selected} refreshKey={`${execution?.id}-${execution?.status}-${campaign.content_version}`} onExecution={(ex) => setExecId(ex.id)} onChanged={onChanged} />
      </section>
    </div>
  )
}

function BriefTab({ campaign, onSaved }: { campaign: Detail; onSaved: (c: Detail) => void }) {
  const toast = useToast()
  const [brief, setBrief] = useState<Brief>(campaign.brief)
  const [dirty, setDirty] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>(errorsByField(campaign.validation?.errors))
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<unknown>(null)
  const [result, setResult] = useState<string | null>(null)
  useUnsavedChanges(dirty && !busy)
  const running = campaign.latest_execution && !TERMINAL_STATUSES.includes(campaign.latest_execution.status)

  const save = async () => {
    setBusy(true)
    setError(null)
    setResult(null)
    try {
      const r = await campaignsApi.updateBrief(campaign.id, brief, campaign.brief_version)
      setDirty(false)
      setErrors(errorsByField(r.validation.errors))
      onSaved(r.campaign)
      if (r.changed_fields.length === 0) setResult('No changes to save.')
      else
        setResult(
          `Saved. Changed: ${r.changed_fields.join(', ')}. ` +
            (r.outdated_stages.length ? `Now outdated: ${r.outdated_stages.map((s) => campaign.stage_labels[s]).join(', ')}.` : 'No generated stages were affected.'),
        )
      toast.push('success', 'Brief saved.')
    } catch (e) {
      setError(e)
      if (e instanceof ApiError && e.code === 'VALIDATION_ERROR') setErrors(errorsByField((e.details as { fields?: never[] })?.fields))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div>
      {running && <Notice kind="warning">The campaign is running; the brief cannot be edited until it finishes or is cancelled.</Notice>}
      {campaign.assumptions.length > 0 && (
        <details className="panel">
          <summary>Assumptions recorded for this brief ({campaign.assumptions.length})</summary>
          <ul className="small">
            {campaign.assumptions.map((a, i) => (
              <li key={i}>
                <strong>{a.field}</strong>: {a.value} - <em>{a.note}</em>
              </li>
            ))}
          </ul>
        </details>
      )}
      <ErrorBanner error={error} title="Could not save the brief" />
      {error instanceof ApiError && error.code === 'VERSION_CONFLICT' && (
        <Notice kind="warning">
          The brief changed elsewhere. <button type="button" className="btn btn-small" onClick={() => window.location.reload()}>Reload</button>
        </Notice>
      )}
      {result && <Notice kind="success">{result}</Notice>}
      <BriefForm
        brief={brief}
        errors={errors}
        disabled={busy || Boolean(running)}
        onChange={(b) => {
          setBrief(b)
          setDirty(true)
        }}
      />
      <div className="btn-row">
        <button type="button" className="btn btn-primary" disabled={!dirty || busy || Boolean(running)} onClick={save}>
          {busy ? 'Saving...' : 'Save brief'}
        </button>
        {dirty && <span className="muted small">Unsaved changes</span>}
      </div>
    </div>
  )
}

function ExportsTab({ campaign }: { campaign: Detail }) {
  const stale = campaign.outdated_stages.length > 0
  const reason = stale ? 'Blocked: outdated outputs' : undefined
  return (
    <section className="panel">
      <h2>Download campaign pack</h2>
      <p className="muted">Files are generated from the latest saved outputs. Exports are blocked while outputs are outdated or blocking QA findings exist.</p>
      <div className="btn-row">
        <DownloadButton path={`/api/campaigns/${campaign.id}/export.pdf`} label="PDF pack" fallbackName="campaign.pdf" disabled={stale} disabledReason={reason} />
        <DownloadButton path={`/api/campaigns/${campaign.id}/export.xlsx`} label="Excel workbook" fallbackName="campaign.xlsx" disabled={stale} disabledReason={reason} />
        <DownloadButton path={`/api/campaigns/${campaign.id}/export.zip`} label="CSV (all datasets, ZIP)" fallbackName="campaign.zip" disabled={stale} disabledReason={reason} />
        <DownloadButton path={`/api/campaigns/${campaign.id}/export.csv`} query={{ dataset: 'Normalized Brief' }} label="Normalized brief CSV" fallbackName="brief.csv" disabled={stale} disabledReason={reason} />
      </div>
      {stale && (
        <div className="btn-row">
          <DownloadButton path={`/api/campaigns/${campaign.id}/export.pdf`} query={{ allow_stale: true }} label="PDF anyway (marked STALE)" fallbackName="campaign_STALE.pdf" />
        </div>
      )}
    </section>
  )
}

function HistoryTab({ campaign }: { campaign: Detail }) {
  const nav = useNavigate()
  const toast = useToast()
  const { data, error, loading } = useAsync((s) => campaignsApi.executions(campaign.id, s), [campaign.id])
  const [confirm, setConfirm] = useState(false)
  const [busy, setBusy] = useState(false)
  const [delError, setDelError] = useState<string | null>(null)
  return (
    <div>
      <section className="panel">
        <h2>Execution history</h2>
        {loading && <Spinner />}
        <ErrorBanner error={error} />
        {data && (
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th scope="col">Started</th>
                  <th scope="col">Scope</th>
                  <th scope="col">Status</th>
                  <th scope="col">Progress</th>
                  <th scope="col">Lineage</th>
                </tr>
              </thead>
              <tbody>
                {data.items.map((e) => (
                  <tr key={e.id}>
                    <td>{formatDate(e.created_at)}</td>
                    <td>{e.scope}</td>
                    <td>
                      <StatusBadge status={e.status} /> {e.error_code && <span className="small muted">{e.error_code}</span>}
                    </td>
                    <td>
                      {e.progress.completed}/{e.progress.total}
                    </td>
                    <td className="small">{e.retry_of_execution_id ? `attempt ${e.attempt_number}, retry of ${e.retry_of_execution_id.slice(0, 8)}` : 'original'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
      <section className="panel">
        <h2>Delete campaign</h2>
        <button type="button" className="btn btn-danger" onClick={() => setConfirm(true)}>
          Delete this campaign
        </button>
        {delError && <p className="field-error" role="alert">{delError}</p>}
      </section>
      <ConfirmDialog
        open={confirm}
        title={`Delete "${campaign.name}"?`}
        danger
        busy={busy}
        confirmLabel="Delete campaign"
        onCancel={() => setConfirm(false)}
        onConfirm={async () => {
          setBusy(true)
          try {
            await campaignsApi.remove(campaign.id)
            toast.push('success', 'Campaign deleted.')
            nav('/campaigns')
          } catch (e) {
            setDelError(errorText(e))
            setConfirm(false)
          } finally {
            setBusy(false)
          }
        }}
      >
        This permanently deletes campaign {campaign.identifier}, its brief, all generated outputs and their versions, its execution history and its export files.
      </ConfirmDialog>
    </div>
  )
}
