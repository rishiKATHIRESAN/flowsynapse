/** Brief form definition (master prompt 5.2). Required fields marked. */
export type FieldKind = 'text' | 'textarea' | 'date' | 'number' | 'url' | 'list' | 'select' | 'multi' | 'money'

export interface BriefField {
  name: string
  label: string
  kind: FieldKind
  required?: boolean
  hint?: string
  options?: { value: string; label: string }[]
}

export interface BriefSection {
  title: string
  fields: BriefField[]
}

export const BRIEF_SECTIONS: BriefSection[] = [
  {
    title: 'Business',
    fields: [
      { name: 'business_name', label: 'Business name', kind: 'text', required: true },
      { name: 'industry', label: 'Industry', kind: 'text', required: true, hint: 'Healthcare industries enable the healthcare responsibility rules.' },
      { name: 'business_description', label: 'Business description', kind: 'textarea', required: true },
      { name: 'website_url', label: 'Website URL', kind: 'url' },
      { name: 'location', label: 'Location', kind: 'text', required: true, hint: 'e.g. Locality, City, State, Country' },
      { name: 'service_areas', label: 'Service areas', kind: 'list', hint: 'One per line' },
      { name: 'primary_service', label: 'Primary service/product', kind: 'text', required: true },
      { name: 'secondary_services', label: 'Secondary services', kind: 'list', hint: 'One per line' },
      { name: 'value_proposition', label: 'Value proposition', kind: 'textarea', hint: 'If empty, a labelled assumption is used.' },
      { name: 'brand_messaging', label: 'Existing brand messaging', kind: 'textarea' },
    ],
  },
  {
    title: 'Campaign',
    fields: [
      { name: 'campaign_name', label: 'Campaign name', kind: 'text', required: true },
      { name: 'objective', label: 'Objective', kind: 'textarea', required: true },
      { name: 'primary_conversion_goal', label: 'Primary conversion goal', kind: 'text', required: true },
      { name: 'secondary_goals', label: 'Secondary goals', kind: 'list', hint: 'One per line' },
      { name: 'start_date', label: 'Start date', kind: 'date', required: true },
      { name: 'end_date', label: 'End date', kind: 'date', hint: 'Inclusive. Give an end date or a duration.' },
      { name: 'duration_days', label: 'Duration (days)', kind: 'number', hint: 'Inclusive of start and end dates.' },
      { name: 'total_budget', label: 'Total paid-media budget', kind: 'money', required: true, hint: 'Across the selected paid channels. Organic work is not budgeted.' },
      {
        name: 'currency',
        label: 'Currency',
        kind: 'select',
        required: true,
        options: ['INR', 'USD', 'EUR', 'GBP', 'JPY', 'AED', 'SGD', 'AUD', 'CAD'].map((c) => ({ value: c, label: c })),
      },
      {
        name: 'paid_channels',
        label: 'Paid channels',
        kind: 'multi',
        required: true,
        options: [
          { value: 'google_ads', label: 'Google Ads' },
          { value: 'meta_ads', label: 'Meta Ads' },
        ],
      },
      {
        name: 'organic_channels',
        label: 'Organic channels',
        kind: 'multi',
        options: [
          { value: 'instagram', label: 'Instagram' },
          { value: 'facebook', label: 'Facebook' },
          { value: 'linkedin', label: 'LinkedIn' },
        ],
      },
      { name: 'language', label: 'Language', kind: 'text', required: true },
      { name: 'tone', label: 'Tone', kind: 'text' },
      { name: 'competitors', label: 'Competitors', kind: 'list', hint: 'One per line' },
      { name: 'existing_campaign_info', label: 'Existing campaign info', kind: 'textarea' },
      { name: 'concept_count', label: 'Number of creative concepts', kind: 'number', hint: '1 to 6 (default 3)' },
    ],
  },
  {
    title: 'Audience',
    fields: [
      { name: 'target_geography', label: 'Target geography', kind: 'text', required: true },
      { name: 'age_range', label: 'Age range', kind: 'text' },
      { name: 'audience_description', label: 'Audience description', kind: 'textarea', required: true },
      { name: 'needs_interests', label: 'Needs / interests', kind: 'textarea' },
      { name: 'problems', label: 'Problems', kind: 'textarea' },
      { name: 'intent', label: 'Intent', kind: 'textarea' },
      { name: 'exclusions', label: 'Exclusions / restrictions', kind: 'textarea' },
      { name: 'existing_research', label: 'Existing research', kind: 'textarea' },
    ],
  },
  {
    title: 'Offer & landing page',
    fields: [
      { name: 'offer_details', label: 'Offer/service details', kind: 'textarea', required: true },
      { name: 'landing_page_url', label: 'Landing page URL', kind: 'url' },
      { name: 'call_to_action', label: 'Call to action', kind: 'text', required: true },
      { name: 'contact_method', label: 'Contact/conversion method', kind: 'text', required: true },
      { name: 'booking_method', label: 'Booking/enquiry method', kind: 'text' },
      { name: 'approved_claims', label: 'Approved claims', kind: 'list', hint: 'One per line' },
      { name: 'prohibited_claims', label: 'Prohibited claims', kind: 'list', hint: 'One per line' },
      { name: 'brand_guidelines', label: 'Brand guidelines', kind: 'textarea' },
      { name: 'additional_instructions', label: 'Additional instructions', kind: 'textarea' },
    ],
  },
]

export function emptyBrief(): Record<string, unknown> {
  return {
    currency: 'INR',
    paid_channels: [],
    organic_channels: [],
    service_areas: [],
    secondary_services: [],
    secondary_goals: [],
    competitors: [],
    approved_claims: [],
    prohibited_claims: [],
    concept_count: 3,
    posting_cadence: { type: 'every_n_days', n: 2, weekdays: null, times_per_week: null, custom_dates: null, max_gap_days: 3 },
    is_healthcare: null,
  }
}

/** Inclusive day count, or null if dates are incomplete/invalid (UI preview only; backend is authoritative). */
export function inclusiveDays(start: unknown, end: unknown): number | null {
  if (typeof start !== 'string' || typeof end !== 'string') return null
  const re = /^\d{4}-\d{2}-\d{2}$/
  if (!re.test(start) || !re.test(end)) return null
  const a = Date.parse(start + 'T00:00:00Z')
  const b = Date.parse(end + 'T00:00:00Z')
  if (Number.isNaN(a) || Number.isNaN(b)) return null
  return Math.round((b - a) / 86400000) + 1
}
