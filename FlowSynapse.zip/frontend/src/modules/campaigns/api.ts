import { api, newIdempotencyKey } from '../../api/client'
import type { Execution, OutputItem, Page } from '../../types/api'

export type Brief = Record<string, unknown> & {
  campaign_name?: string | null
  business_name?: string | null
  start_date?: string | null
  end_date?: string | null
  duration_days?: number | string | null
  posting_cadence?: Cadence
}

export interface Cadence {
  type: 'daily' | 'every_n_days' | 'weekdays' | 'times_per_week' | 'custom'
  n?: number | null
  weekdays?: number[] | null
  times_per_week?: number | null
  custom_dates?: string[] | null
  max_gap_days?: number
}

export interface FieldIssue {
  field: string
  code: string
  message: string
}

export interface ValidationResult {
  valid: boolean
  errors: FieldIssue[]
  warnings: FieldIssue[]
}

export interface StageState {
  is_outdated: boolean
  outdated_reason: string | null
  outdated_at: string | null
  completed_at: string | null
}

export interface CampaignSummary {
  id: string
  identifier: string
  name: string
  status: string
  business_name: string | null
  is_demo: boolean
  brief_valid: boolean
  content_version: number
  provider: string | null
  is_mock: boolean | null
  latest_execution_id: string | null
  outdated_stages: string[]
  created_at: string
  updated_at: string
}

export interface CampaignDetail extends CampaignSummary {
  brief: Brief
  brief_version: number
  normalized_brief: Record<string, unknown> | null
  assumptions: { field: string; value: string; source: string; note: string }[]
  validation: ValidationResult | null
  stage_states: Record<string, StageState>
  stage_labels: Record<string, string>
  stages: string[]
  latest_execution: Execution | null
  healthcare_disclaimer: string | null
}

export interface StageDetail {
  stage_key: string
  label: string
  is_outdated: boolean
  outdated_reason: string | null
  outputs: OutputItem[]
  output_ref: unknown
  validation?: ValidationResult | null
  original_brief?: Brief
  normalized_brief?: Record<string, unknown> | null
  findings?: Finding[]
}

export interface Finding {
  id: string
  rule_id: string
  severity: 'BLOCKER' | 'WARNING' | 'INFO'
  category: string
  description: string
  evidence: string | null
  field: string | null
  recommended_correction: string | null
  blocks_completion: boolean
}

const base = '/api/campaigns'

export const campaignsApi = {
  list: (q: { limit: number; offset: number; q?: string; demo?: string; status?: string }, signal?: AbortSignal) =>
    api.get<Page<CampaignSummary>>(base, q, signal),
  demoBrief: () => api.get<{ brief: Brief; is_demo: boolean; note: string }>(`${base}/demo-brief`),
  validateUnsaved: (brief: Brief) => api.post<ValidationResult>(`${base}/validate-brief`, { brief }),
  create: (brief: Brief, isDemo: boolean) => api.post<CampaignDetail>(base, { brief, is_demo: isDemo }, { idempotencyKey: newIdempotencyKey() }),
  get: (id: string, signal?: AbortSignal) => api.get<CampaignDetail>(`${base}/${id}`, undefined, signal),
  updateBrief: (id: string, brief: Brief, version: number) =>
    api.patch<{ changed_fields: string[]; outdated_stages: string[]; validation: ValidationResult; campaign: CampaignDetail }>(
      `${base}/${id}/brief`,
      { brief },
      { ifMatch: version },
    ),
  validate: (id: string) => api.post<ValidationResult>(`${base}/${id}/validate`, {}),
  start: (id: string) => api.post<Execution>(`${base}/${id}/executions`, {}, { idempotencyKey: newIdempotencyKey() }),
  cancel: (id: string, eid: string) => api.post<Execution>(`${base}/${id}/executions/${eid}/cancel`, {}),
  retryStage: (id: string, eid: string, stage: string) =>
    api.post<Execution>(`${base}/${id}/executions/${eid}/stages/${stage}/retry`, {}, { idempotencyKey: newIdempotencyKey() }),
  regenerateStage: (id: string, stage: string) =>
    api.post<Execution>(`${base}/${id}/stages/${stage}/regenerate`, {}, { idempotencyKey: newIdempotencyKey() }),
  executions: (id: string, signal?: AbortSignal) => api.get<Page<Execution>>(`${base}/${id}/executions`, { limit: 50 }, signal),
  stage: (id: string, stage: string, signal?: AbortSignal) => api.get<StageDetail>(`${base}/${id}/stages/${stage}`, undefined, signal),
  outputs: (id: string, type?: string, versions = false) =>
    api.get<{ items: OutputItem[] }>(`${base}/${id}/outputs`, { output_type: type, versions }),
  findings: (id: string) => api.get<{ items: Finding[] }>(`${base}/${id}/findings`),
  remove: (id: string) => api.del<{ deleted: string }>(`${base}/${id}`),
  editOutput: (id: string, outputType: string, outputId: string, content: unknown, version: number, summary?: string) =>
    api.patch<{ output: OutputItem; outdated_stages: string[]; noop: boolean }>(
      `${base}/${id}/outputs/${outputType}/${outputId}`,
      { content, edit_summary: summary },
      { ifMatch: version },
    ),
  setStatus: (id: string, outputType: string, outputId: string, status: string) =>
    api.patch<OutputItem>(`${base}/${id}/outputs/${outputType}/${outputId}/status`, { status }),
  restoreVersion: (id: string, outputType: string, outputId: string, versionId: string, version: number) =>
    api.post<OutputItem>(`${base}/${id}/outputs/${outputType}/${outputId}/restore`, { version_id: versionId }, { ifMatch: version }),
  regenerateOutput: (id: string, outputType: string, outputId: string) =>
    api.post<Execution>(`${base}/${id}/outputs/${outputType}/${outputId}/regenerate`, {}, { idempotencyKey: newIdempotencyKey() }),
}
