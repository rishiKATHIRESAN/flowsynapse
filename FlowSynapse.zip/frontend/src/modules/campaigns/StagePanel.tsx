import { ContentView } from '../../components/ContentView'
import { ErrorBanner, Notice, ProviderBadge, Spinner, StatusBadge } from '../../components/ui'
import { useAsync } from '../../hooks/hooks'
import type { Execution } from '../../types/api'
import { campaignsApi, type CampaignDetail } from './api'
import { OutputEditor } from './OutputEditor'

/** Detail of one stage: current outputs (latest saved), outdated state, provenance. */
export function StagePanel({
  campaign,
  stageKey,
  refreshKey,
  onExecution,
  onChanged,
}: {
  campaign: CampaignDetail
  stageKey: string
  refreshKey: string
  onExecution: (e: Execution) => void
  onChanged: () => void
}) {
  const { data, error, loading, reload } = useAsync((s) => campaignsApi.stage(campaign.id, stageKey, s), [campaign.id, stageKey, refreshKey])
  return (
    <div>
      <h2>{campaign.stage_labels[stageKey] ?? stageKey}</h2>
      {loading && !data && <Spinner />}
      <ErrorBanner error={error} onRetry={reload} />
      {data && (
        <>
          {data.is_outdated && <Notice kind="warning">Outdated - {data.outdated_reason}. This output is not current.</Notice>}
          {stageKey === 'INPUT_VALIDATION' && (data.validation ? <ContentView value={data.validation} /> : <p className="muted">Not validated yet.</p>)}
          {stageKey === 'BRIEF_NORMALIZATION' && (
            <div className="split">
              <div>
                <h3>Original input (unchanged)</h3>
                <ContentView value={data.original_brief} />
              </div>
              <div>
                <h3>Normalized brief</h3>
                {data.normalized_brief ? <ContentView value={data.normalized_brief} /> : <p className="muted">Not normalized yet (brief invalid).</p>}
              </div>
            </div>
          )}
          {data.outputs.length === 0 && !['INPUT_VALIDATION', 'BRIEF_NORMALIZATION', 'QUALITY_ASSURANCE', 'PACK_GENERATION'].includes(stageKey) && (
            <p className="muted">No output yet for this stage.</p>
          )}
          {data.outputs
            .filter((o) => !o.is_discarded)
            .map((o) => (
              <div key={o.id} className={`output-card ${o.is_outdated ? 'outdated' : ''} ${o.validity === 'INVALID' ? 'invalid' : ''}`}>
                <div className="chips">
                  <strong>
                    {o.output_type.replace(/_/g, ' ')} {o.item_key && `#${o.item_key}`}
                  </strong>
                  <span className="small muted">v{o.version}</span>
                  <span className="small">{o.provenance_label}</span>
                  {o.origin !== 'MANUALLY_EDITED' && <ProviderBadge provider={o.provider} model={o.model} isMock={o.is_mock} />}
                  {o.is_outdated && <StatusBadge status="OUTDATED" />}
                  {o.validity === 'INVALID' && <StatusBadge status="INVALID" />}
                </div>
                <OutputEditor campaign={campaign} output={o} onSaved={() => { reload(); onChanged() }} onExecution={onExecution} />
              </div>
            ))}
          {data.findings && data.findings.length > 0 && (
            <table className="table">
              <thead>
                <tr>
                  <th scope="col">Severity</th>
                  <th scope="col">Finding</th>
                  <th scope="col">Correction</th>
                </tr>
              </thead>
              <tbody>
                {data.findings.map((f) => (
                  <tr key={f.id}>
                    <td>
                      <StatusBadge status={f.severity === 'BLOCKER' ? 'FAILED' : f.severity === 'WARNING' ? 'COMPLETED_WITH_WARNINGS' : 'PENDING'} /> {f.severity}
                    </td>
                    <td>
                      {f.description}
                      {f.field && <div className="small muted">{f.field}</div>}
                    </td>
                    <td>{f.recommended_correction}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {data.output_ref != null && stageKey === 'PACK_GENERATION' && <ContentView value={data.output_ref} />}
        </>
      )}
    </div>
  )
}
