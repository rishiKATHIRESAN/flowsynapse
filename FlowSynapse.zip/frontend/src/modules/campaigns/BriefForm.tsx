import { Field } from '../../components/ui'
import type { Brief, Cadence, FieldIssue } from './api'
import { BRIEF_SECTIONS, inclusiveDays, type BriefField } from './briefFields'

function listToText(v: unknown): string {
  return Array.isArray(v) ? v.join('\n') : ''
}

function textToList(t: string): string[] {
  return t
    .split('\n')
    .map((s) => s.trim())
    .filter(Boolean)
}

export function errorsByField(issues: FieldIssue[] | undefined): Record<string, string> {
  const out: Record<string, string> = {}
  for (const i of issues ?? []) {
    const key = i.field.replace(/^brief\./, '')
    if (!out[key]) out[key] = i.message
  }
  return out
}

const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

export function BriefForm({
  brief,
  onChange,
  errors,
  disabled,
}: {
  brief: Brief
  onChange: (b: Brief) => void
  errors: Record<string, string>
  disabled?: boolean
}) {
  const set = (name: string, value: unknown) => onChange({ ...brief, [name]: value })
  const cadence: Cadence = (brief.posting_cadence as Cadence) ?? { type: 'every_n_days', n: 2 }
  const setCadence = (c: Partial<Cadence>) => set('posting_cadence', { ...cadence, ...c })
  const days = inclusiveDays(brief.start_date, brief.end_date)

  const render = (f: BriefField) => (
    <Field key={f.name} label={f.label} name={f.name} required={f.required} error={errors[f.name]} hint={f.hint}>
      {(p) => {
        const value = brief[f.name]
        switch (f.kind) {
          case 'textarea':
            return <textarea {...p} value={(value as string) ?? ''} onChange={(e) => set(f.name, e.target.value)} disabled={disabled} />
          case 'list':
            return (
              <textarea {...p} value={listToText(value)} onChange={(e) => set(f.name, textToList(e.target.value))} disabled={disabled} />
            )
          case 'select':
            return (
              <select {...p} value={(value as string) ?? ''} onChange={(e) => set(f.name, e.target.value)} disabled={disabled}>
                {f.options?.map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
            )
          case 'multi': {
            const arr = Array.isArray(value) ? (value as string[]) : []
            return (
              <div role="group" id={p.id} aria-describedby={p['aria-describedby']}>
                {f.options?.map((o) => (
                  <label key={o.value} className="radio-row">
                    <input
                      type="checkbox"
                      checked={arr.includes(o.value)}
                      disabled={disabled}
                      onChange={(e) => set(f.name, e.target.checked ? [...arr, o.value] : arr.filter((x) => x !== o.value))}
                    />{' '}
                    {o.label}
                  </label>
                ))}
              </div>
            )
          }
          case 'date':
            return <input {...p} type="date" value={(value as string) ?? ''} onChange={(e) => set(f.name, e.target.value || null)} disabled={disabled} />
          case 'number':
            return (
              <input
                {...p}
                type="number"
                min={1}
                value={value === null || value === undefined ? '' : String(value)}
                onChange={(e) => set(f.name, e.target.value === '' ? null : Number(e.target.value))}
                disabled={disabled}
              />
            )
          case 'money':
            return (
              <input {...p} type="text" inputMode="decimal" value={value === null || value === undefined ? '' : String(value)} onChange={(e) => set(f.name, e.target.value)} disabled={disabled} />
            )
          default:
            return <input {...p} type={f.kind === 'url' ? 'url' : 'text'} value={(value as string) ?? ''} onChange={(e) => set(f.name, e.target.value)} disabled={disabled} />
        }
      }}
    </Field>
  )

  return (
    <div>
      {BRIEF_SECTIONS.map((s) => (
        <fieldset key={s.title}>
          <legend>{s.title}</legend>
          <div className="form-grid">{s.fields.map(render)}</div>
          {s.title === 'Campaign' && (
            <>
              <p className="small muted" data-testid="duration-preview" aria-live="polite">
                {days !== null ? (days > 0 ? `Dates cover ${days} day${days === 1 ? '' : 's'} (inclusive).` : 'End date is before the start date.') : 'Enter start and end dates to see the duration.'}
              </p>
              <fieldset>
                <legend>Social posting cadence</legend>
                <div className="form-grid">
                  <Field label="Cadence" name="cadence_type" error={errors.posting_cadence}>
                    {(p) => (
                      <select {...p} value={cadence.type} onChange={(e) => setCadence({ type: e.target.value as Cadence['type'] })} disabled={disabled}>
                        <option value="every_n_days">Every N days</option>
                        <option value="daily">Daily</option>
                        <option value="weekdays">Selected weekdays</option>
                        <option value="times_per_week">Times per week</option>
                        <option value="custom">Custom dates</option>
                      </select>
                    )}
                  </Field>
                  {cadence.type === 'every_n_days' && (
                    <Field label="Every N days" name="cadence_n">
                      {(p) => <input {...p} type="number" min={1} value={cadence.n ?? ''} onChange={(e) => setCadence({ n: Number(e.target.value) || null })} disabled={disabled} />}
                    </Field>
                  )}
                  {cadence.type === 'times_per_week' && (
                    <Field label="Posts per week" name="cadence_k">
                      {(p) => (
                        <input {...p} type="number" min={1} max={7} value={cadence.times_per_week ?? ''} onChange={(e) => setCadence({ times_per_week: Number(e.target.value) || null })} disabled={disabled} />
                      )}
                    </Field>
                  )}
                  {cadence.type === 'weekdays' && (
                    <div role="group" aria-label="Weekdays">
                      {WEEKDAYS.map((d, i) => {
                        const sel = cadence.weekdays ?? []
                        return (
                          <label key={d} className="radio-row">
                            <input
                              type="checkbox"
                              checked={sel.includes(i)}
                              disabled={disabled}
                              onChange={(e) => setCadence({ weekdays: e.target.checked ? [...sel, i].sort() : sel.filter((x) => x !== i) })}
                            />{' '}
                            {d}
                          </label>
                        )
                      })}
                    </div>
                  )}
                  {cadence.type === 'custom' && (
                    <Field label="Custom dates" name="cadence_custom" hint="One ISO date per line">
                      {(p) => (
                        <textarea {...p} value={(cadence.custom_dates ?? []).join('\n')} onChange={(e) => setCadence({ custom_dates: textToList(e.target.value) })} disabled={disabled} />
                      )}
                    </Field>
                  )}
                </div>
              </fieldset>
            </>
          )}
        </fieldset>
      ))}
      <fieldset>
        <legend>Healthcare rules</legend>
        <label className="radio-row">
          <input type="radio" name="hc" checked={brief.is_healthcare === null || brief.is_healthcare === undefined} onChange={() => set('is_healthcare', null)} disabled={disabled} /> Detect from industry (default)
        </label>
        <label className="radio-row">
          <input type="radio" name="hc" checked={brief.is_healthcare === true} onChange={() => set('is_healthcare', true)} disabled={disabled} /> Always apply healthcare rules
        </label>
        <label className="radio-row">
          <input type="radio" name="hc" checked={brief.is_healthcare === false} onChange={() => set('is_healthcare', false)} disabled={disabled} /> Not a healthcare business
        </label>
      </fieldset>
    </div>
  )
}
