import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ApiError } from '../../api/client'
import { ErrorBanner, Notice } from '../../components/ui'
import { useToast } from '../../components/Toast'
import { useUnsavedChanges } from '../../hooks/hooks'
import { campaignsApi, type Brief, type ValidationResult } from './api'
import { BriefForm, errorsByField } from './BriefForm'
import { emptyBrief } from './briefFields'

export function CampaignNew() {
  const nav = useNavigate()
  const toast = useToast()
  const [brief, setBrief] = useState<Brief>(emptyBrief() as Brief)
  const [isDemo, setIsDemo] = useState(false)
  const [dirty, setDirty] = useState(false)
  const [validation, setValidation] = useState<ValidationResult | null>(null)
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({})
  const [busy, setBusy] = useState<string | null>(null)
  const [error, setError] = useState<unknown>(null)
  const [demoNote, setDemoNote] = useState<string | null>(null)
  useUnsavedChanges(dirty && busy === null)

  const change = (b: Brief) => {
    setBrief(b)
    setDirty(true)
  }

  const loadDemo = async () => {
    setBusy('demo')
    setError(null)
    try {
      const d = await campaignsApi.demoBrief()
      setBrief(d.brief)
      setIsDemo(true)
      setDirty(true)
      setDemoNote(d.note)
      setFieldErrors({})
      setValidation(null)
    } catch (e) {
      setError(e)
    } finally {
      setBusy(null)
    }
  }

  const validate = async () => {
    setBusy('validate')
    setError(null)
    try {
      const v = await campaignsApi.validateUnsaved(brief)
      setValidation(v)
      setFieldErrors(errorsByField(v.errors))
    } catch (e) {
      setError(e)
      if (e instanceof ApiError) setFieldErrors(e.fieldErrors)
    } finally {
      setBusy(null)
    }
  }

  const save = async (run: boolean) => {
    setBusy(run ? 'run' : 'save')
    setError(null)
    try {
      const c = await campaignsApi.create(brief, isDemo)
      setDirty(false)
      if (run) {
        if (!c.validation?.valid) {
          setFieldErrors(errorsByField(c.validation?.errors))
          setValidation(c.validation)
          toast.push('info', 'Draft saved. Fix the highlighted fields before running.')
          nav(`/campaigns/${c.id}`, { replace: true })
          return
        }
        await campaignsApi.start(c.id)
        toast.push('success', 'Campaign saved and execution requested.')
        nav(`/campaigns/${c.id}?tab=run`, { replace: true })
      } else {
        toast.push('success', 'Draft saved.')
        nav(`/campaigns/${c.id}`, { replace: true })
      }
    } catch (e) {
      setError(e)
      if (e instanceof ApiError) setFieldErrors(errorsByField((e.details as { fields?: never[] })?.fields))
    } finally {
      setBusy(null)
    }
  }

  return (
    <div>
      <div className="page-head">
        <h1>New campaign brief</h1>
        <button type="button" className="btn" onClick={loadDemo} disabled={busy !== null}>
          {busy === 'demo' ? 'Loading...' : 'Load demo brief'}
        </button>
      </div>
      {isDemo && <Notice kind="warning">Demonstration data (Be Well Hospitals). {demoNote} Values marked DEMO ASSUMPTION are not facts.</Notice>}
      <ErrorBanner error={error} title="Could not complete the action" />
      {validation && validation.valid && <Notice kind="success">No blocking validation errors.</Notice>}
      {validation && !validation.valid && (
        <Notice kind="warning">{validation.errors.length} field(s) need attention. Your inputs are kept; fix the highlighted fields.</Notice>
      )}
      {validation && validation.warnings.length > 0 && (
        <Notice kind="info">
          Warnings: {validation.warnings.map((w) => w.message).join(' | ')}
        </Notice>
      )}
      <BriefForm brief={brief} onChange={change} errors={fieldErrors} disabled={busy !== null} />
      <div className="btn-row">
        <button type="button" className="btn" onClick={validate} disabled={busy !== null}>
          {busy === 'validate' ? 'Validating...' : 'Validate'}
        </button>
        <button type="button" className="btn" onClick={() => save(false)} disabled={busy !== null}>
          {busy === 'save' ? 'Saving...' : 'Save Draft'}
        </button>
        <button type="button" className="btn btn-primary" onClick={() => save(true)} disabled={busy !== null}>
          {busy === 'run' ? 'Starting...' : 'Run Campaign Intelligence'}
        </button>
      </div>
    </div>
  )
}
