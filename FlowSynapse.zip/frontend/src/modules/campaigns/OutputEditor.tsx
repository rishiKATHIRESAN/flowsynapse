import { ContentView } from '../../components/ContentView'
import type { Execution, OutputItem } from '../../types/api'
import type { CampaignDetail } from './api'

/** Displays an output. Editing arrives with output versioning (Phase 7). */
export function OutputEditor({
  output,
}: {
  campaign: CampaignDetail
  output: OutputItem
  onSaved: () => void
  onExecution: (e: Execution) => void
}) {
  return (
    <div>
      <ContentView value={output.content} />
      <button type="button" className="btn btn-small" disabled title="Not implemented yet: editing arrives in a later phase">
        Edit (not yet implemented)
      </button>
    </div>
  )
}
