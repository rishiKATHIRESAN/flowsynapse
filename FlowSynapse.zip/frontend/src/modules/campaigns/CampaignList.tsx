import { useState } from 'react'
import { Link } from 'react-router-dom'
import { DemoBadge, EmptyState, ErrorBanner, Pagination, ProviderBadge, Spinner, StatusBadge, formatDate } from '../../components/ui'
import { useAsync } from '../../hooks/hooks'
import { campaignsApi } from './api'

const LIMIT = 20

export function CampaignList() {
  const [offset, setOffset] = useState(0)
  const [q, setQ] = useState('')
  const [query, setQuery] = useState('')
  const [demo, setDemo] = useState('all')
  const { data, error, loading, reload } = useAsync((s) => campaignsApi.list({ limit: LIMIT, offset, q: query, demo }, s), [offset, query, demo])
  return (
    <div>
      <div className="page-head">
        <h1>AI Marketing Campaign Intelligence Engine</h1>
        <Link className="btn btn-primary" to="/campaigns/new">
          Create Campaign
        </Link>
      </div>
      <p className="muted">Turn a campaign brief into a validated 12-stage campaign pack: strategy, concepts, Google/Meta proposals, social plan, tracking, budget and QA.</p>
      <form
        className="btn-row"
        role="search"
        onSubmit={(e) => {
          e.preventDefault()
          setOffset(0)
          setQuery(q)
        }}
      >
        <label htmlFor="cq" className="sr-only">
          Search campaigns
        </label>
        <input id="cq" type="text" placeholder="Search name, identifier or brief" value={q} onChange={(e) => setQ(e.target.value)} />
        <button type="submit" className="btn">
          Search
        </button>
        <label htmlFor="cdemo" className="sr-only">
          Filter demo data
        </label>
        <select
          id="cdemo"
          value={demo}
          onChange={(e) => {
            setOffset(0)
            setDemo(e.target.value)
          }}
        >
          <option value="all">All</option>
          <option value="mine">Mine</option>
          <option value="demo">Demo</option>
        </select>
      </form>
      {loading && !data && <Spinner />}
      <ErrorBanner error={error} onRetry={reload} title="Could not load campaigns" />
      {data && data.items.length === 0 && (
        <EmptyState title="No campaigns yet" action={<Link className="btn btn-primary" to="/campaigns/new">Create Campaign</Link>}>
          Create a campaign from a brief, or load the Be Well demo brief in the form.
        </EmptyState>
      )}
      {data && data.items.length > 0 && (
        <>
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th scope="col">Campaign</th>
                  <th scope="col">Status</th>
                  <th scope="col">Provider</th>
                  <th scope="col">Updated</th>
                </tr>
              </thead>
              <tbody>
                {data.items.map((c) => (
                  <tr key={c.id}>
                    <td>
                      <Link to={`/campaigns/${c.id}`}>{c.name}</Link> <DemoBadge isDemo={c.is_demo} />
                      <div className="small muted">
                        {c.identifier} {c.business_name ? `- ${c.business_name}` : ''}
                      </div>
                    </td>
                    <td>
                      <StatusBadge status={c.status} /> {c.outdated_stages.length > 0 && <StatusBadge status="OUTDATED" />}
                    </td>
                    <td>
                      <ProviderBadge provider={c.provider} isMock={c.is_mock} />
                    </td>
                    <td>{formatDate(c.updated_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination total={data.total} limit={LIMIT} offset={offset} onChange={setOffset} />
        </>
      )}
    </div>
  )
}
