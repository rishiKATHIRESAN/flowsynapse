import { useEffect, useState } from 'react'
import { checkHealth, type ConnectionState } from '../api/health'

/** Polls /api/health. Never reports "connected" before a valid FlowSynapse payload. */
export function useBackendHealth(intervalMs = 5000): ConnectionState {
  const [state, setState] = useState<ConnectionState>({ kind: 'checking' })
  useEffect(() => {
    let cancelled = false
    let timer: ReturnType<typeof setTimeout> | undefined
    const ctrl = new AbortController()
    const tick = async () => {
      try {
        const s = await checkHealth(ctrl.signal)
        if (!cancelled) setState(s)
      } catch {
        return
      }
      if (!cancelled) timer = setTimeout(tick, intervalMs)
    }
    void tick()
    return () => {
      cancelled = true
      ctrl.abort()
      if (timer) clearTimeout(timer)
    }
  }, [intervalMs])
  return state
}
