import { useCallback, useEffect, useRef, useState } from 'react'
import { useBlocker } from 'react-router-dom'
import { api } from '../api/client'
import { TERMINAL_STATUSES, type Execution } from '../types/api'

/** Generic async loader with reload; never fabricates data. */
export function useAsync<T>(fn: (signal: AbortSignal) => Promise<T>, deps: unknown[]) {
  const [data, setData] = useState<T | null>(null)
  const [error, setError] = useState<unknown>(null)
  const [loading, setLoading] = useState(true)
  const [nonce, setNonce] = useState(0)
  const fnRef = useRef(fn)
  fnRef.current = fn
  useEffect(() => {
    const ctrl = new AbortController()
    setLoading(true)
    setError(null)
    fnRef
      .current(ctrl.signal)
      .then((d) => {
        if (!ctrl.signal.aborted) setData(d)
      })
      .catch((e) => {
        if (!ctrl.signal.aborted) setError(e)
      })
      .finally(() => {
        if (!ctrl.signal.aborted) setLoading(false)
      })
    return () => ctrl.abort()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, nonce])
  const reload = useCallback(() => setNonce((n) => n + 1), [])
  return { data, error, loading, reload, setData }
}

/** Polls an execution every 1.5 s until it reaches a terminal state; stops on unmount. */
export function useExecutionPolling(path: string | null, onTerminal?: (e: Execution) => void, intervalMs = 1500) {
  const [execution, setExecution] = useState<Execution | null>(null)
  const [error, setError] = useState<unknown>(null)
  const cb = useRef(onTerminal)
  cb.current = onTerminal
  useEffect(() => {
    if (!path) {
      setExecution(null)
      return
    }
    let stopped = false
    let timer: ReturnType<typeof setTimeout> | undefined
    const ctrl = new AbortController()
    const tick = async () => {
      try {
        const e = await api.get<Execution>(path, undefined, ctrl.signal)
        if (stopped) return
        setExecution(e)
        setError(null)
        if (TERMINAL_STATUSES.includes(e.status)) {
          cb.current?.(e)
          return
        }
      } catch (err) {
        if (stopped) return
        setError(err)
      }
      timer = setTimeout(tick, intervalMs)
    }
    void tick()
    return () => {
      stopped = true
      ctrl.abort()
      if (timer) clearTimeout(timer)
    }
  }, [path, intervalMs])
  return { execution, error }
}

/** Warn before leaving with unsaved changes (router navigation + tab close). */
export function useUnsavedChanges(dirty: boolean) {
  const blocker = useBlocker(({ currentLocation, nextLocation }) => dirty && currentLocation.pathname !== nextLocation.pathname)
  useEffect(() => {
    if (!dirty) return
    const handler = (e: BeforeUnloadEvent) => {
      e.preventDefault()
      e.returnValue = ''
    }
    window.addEventListener('beforeunload', handler)
    return () => window.removeEventListener('beforeunload', handler)
  }, [dirty])
  useEffect(() => {
    if (blocker.state === 'blocked') {
      if (window.confirm('You have unsaved changes. Leave this page and discard them?')) blocker.proceed()
      else blocker.reset()
    }
  }, [blocker])
}
