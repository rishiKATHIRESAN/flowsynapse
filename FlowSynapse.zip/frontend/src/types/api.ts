/** Types mirroring backend response schemas. */

export type ExecutionStatus = 'PENDING' | 'RUNNING' | 'COMPLETED' | 'COMPLETED_WITH_WARNINGS' | 'FAILED' | 'CANCELLED'
export type StageStatus = 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'CANCELLED' | 'SKIPPED' | 'CARRIED_FORWARD'
export type ContentStatus = 'DRAFT' | 'READY_FOR_REVIEW' | 'NEEDS_REVISION' | 'READY_TO_EXPORT'

export const TERMINAL_STATUSES: ExecutionStatus[] = ['COMPLETED', 'COMPLETED_WITH_WARNINGS', 'FAILED', 'CANCELLED']

export interface Stage {
  id: string
  stage_key: string
  item_id: string | null
  position: number
  status: StageStatus
  required: boolean
  carried_from_stage_id: string | null
  error_code: string | null
  error_message: string | null
  retryable: boolean | null
  attempt_count: number
  ai_calls_used: number
  provider: string | null
  model: string | null
  is_mock: boolean | null
  warnings: string[]
  started_at: string | null
  finished_at: string | null
  duration_seconds: number | null
}

export interface Execution {
  id: string
  parent_type: string
  parent_id: string
  scope: string
  status: ExecutionStatus
  retry_of_execution_id: string | null
  attempt_number: number
  cancel_requested: boolean
  error_code: string | null
  error_message: string | null
  retryable: boolean | null
  ai_calls_used: number
  provider: string | null
  model: string | null
  is_mock: boolean
  is_demo: boolean
  warnings_count: number
  created_at: string
  started_at: string | null
  finished_at: string | null
  heartbeat_at: string | null
  progress: { completed: number; total: number }
  stages: Stage[]
}

export interface OutputVersionInfo {
  id: string
  version_number: number
  is_active: boolean
  origin: string
  provider: string | null
  model: string | null
  is_mock: boolean
  generated_at: string | null
  edit_summary: string | null
  created_at: string
  content: unknown
}

export interface OutputItem<C = Record<string, unknown>> {
  id: string
  output_type: string
  item_key: string
  position: number
  inputs: Record<string, unknown> | null
  content: C | null
  version: number
  content_status: ContentStatus | null
  generation_status: string
  generation_error: string | null
  is_outdated: boolean
  outdated_reason: string | null
  validity: string
  validity_details: unknown
  is_discarded: boolean
  is_demo: boolean
  origin: string | null
  provider: string | null
  model: string | null
  is_mock: boolean | null
  provenance_label: string
  updated_at: string
  versions?: OutputVersionInfo[]
}

export interface Page<T> {
  items: T[]
  total: number
  limit: number
  offset: number
}

export interface ExportRow {
  id: string
  format: string
  status: string
  download_name: string | null
  source_version: string | null
  warnings: string[]
  error: string | null
  is_demo: boolean
  is_stale: boolean
  purged: boolean
  created_at: string
}

export interface RunRow {
  module: string
  title: string
  status: ExecutionStatus
  scope: string
  provider: string | null
  is_mock: boolean
  is_demo: boolean
  parent_id: string
  execution_id: string
  created_at: string
  finished_at: string | null
}
