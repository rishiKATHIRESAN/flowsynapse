import { useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api/client'
import { DemoBadge, ErrorBanner, ProviderBadge, Spinner, StatusBadge, formatDate } from '../components/ui'
import { useAsync } from '../hooks/hooks'
import type { RunRow } from '../types/api'

interface ModuleStats {
  key: string
  title: string
  route: string
  total: number
  by_status: Record<string, number>
  available: boolean
  last_run: { status: string; title: string; created_at: string; parent_id: string; is_mock: boolean } | null
}

interface DashboardPayload {
  include_demo: boolean
  modules: ModuleStats[]
  recent_runs: RunRow[]
}

const CTA: Record<string, string> = {
  campaigns: 'Create Campaign',
  funnels: 'Create Funnel',
  seo: 'Start SEO Audit',
  website: 'Start Website Report',
  blogs: 'Create Blog Batch',
  social: 'Create Social Calendar',
}

export function Dashboard() {
  const [includeDemo, setIncludeDemo] = useState(false)
  const { data, error, loading, reload } = useAsync(
    (signal) => api.get<DashboardPayload>('/api/dashboard', { include_demo: includeDemo }, signal),
    [includeDemo],
  )
  return (
    <div>
      <div className="page-head">
        <h1>Dashboard</h1>
        <label className="toggle">
          <input type="checkbox" checked={includeDemo} onChange={(e) => setIncludeDemo(e.target.checked)} /> Include demo data in counts
        </label>
      </div>
      {loading && !data && <Spinner />}
      <ErrorBanner error={error} onRetry={reload} title="Could not load the dashboard" />
      {data && (
        <>
          <div className="cards" data-testid="module-cards">
            {data.modules.map((m, i) => (
              <section key={m.key} className={`card ${i === 0 ? 'card-primary' : ''}`} aria-labelledby={`card-${m.key}`} data-testid={`card-${m.key}`}>
                <h2 id={`card-${m.key}`}>
                  <span className="nav-num">{i + 1}</span> {m.title}
                </h2>
                {m.total === 0 ? (
                  <p className="muted">Nothing here yet. Start with your first {m.key === 'campaigns' ? 'campaign brief' : 'record'}.</p>
                ) : (
                  <p>
                    <strong>{m.total}</strong> record{m.total === 1 ? '' : 's'}
                    {Object.entries(m.by_status).map(([s, n]) => (
                      <span key={s} className="stat-chip">
                        {s}: {n}
                      </span>
                    ))}
                  </p>
                )}
                {m.last_run && (
                  <p className="small">
                    Last run: <StatusBadge status={m.last_run.status} /> {m.last_run.title} - {formatDate(m.last_run.created_at)}
                  </p>
                )}
                <Link className={`btn ${i === 0 ? 'btn-primary' : ''}`} to={`${m.route}${i === 0 ? '?new=1' : ''}`}>
                  {i === 0 ? CTA[m.key] : `Open ${CTA[m.key].replace(/^(Create|Start) /, '')}`}
                </Link>
              </section>
            ))}
          </div>
          <section className="panel">
            <h2>Recent executions</h2>
            {data.recent_runs.length === 0 ? (
              <p className="muted">No executions yet. Runs appear here once you start a workflow.</p>
            ) : (
              <div className="table-wrap">
                <table className="table">
                  <thead>
                    <tr>
                      <th scope="col">Module</th>
                      <th scope="col">Title</th>
                      <th scope="col">Status</th>
                      <th scope="col">Provider</th>
                      <th scope="col">Started</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.recent_runs.map((r) => (
                      <tr key={r.execution_id}>
                        <td>{r.module}</td>
                        <td>
                          {r.title} <DemoBadge isDemo={r.is_demo} />
                        </td>
                        <td>
                          <StatusBadge status={r.status} /> {r.scope !== 'FULL' && <span className="muted small">{r.scope}</span>}
                        </td>
                        <td>
                          <ProviderBadge provider={r.provider} isMock={r.is_mock} />
                        </td>
                        <td>{formatDate(r.created_at)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        </>
      )}
    </div>
  )
}
