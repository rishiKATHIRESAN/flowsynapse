import { useState } from 'react'
import { ApiError, api } from '../api/client'
import { ConfirmDialog, ErrorBanner, Notice, Spinner, errorText } from '../components/ui'
import { useToast } from '../components/Toast'
import { useAsync } from '../hooks/hooks'

interface ProviderInfo {
  name: string
  configured: boolean
  config_error: string | null
  model: string | null
  requires_network: boolean
  may_incur_charges: boolean
}

interface SettingsPayload {
  active_provider: string
  active_model: string | null
  is_mock: boolean
  config_error: string | null
  providers: ProviderInfo[]
  allow_demo_site: boolean
  demo_site_port: number
}

interface HealthResult {
  ok: boolean
  provider: string
  model: string | null
  message: string
  details?: { hint?: string }
  cached: boolean
}

interface DemoStatus {
  modules: Record<string, { demo_records: number }>
}

export function SettingsPage() {
  const toast = useToast()
  const { data, error, loading, reload, setData } = useAsync((s) => api.get<SettingsPayload>('/api/settings', undefined, s), [])
  const demo = useAsync((s) => api.get<DemoStatus>('/api/demo-data', undefined, s), [])
  const [saving, setSaving] = useState(false)
  const [test, setTest] = useState<HealthResult | null>(null)
  const [testing, setTesting] = useState(false)
  const [testError, setTestError] = useState<string | null>(null)
  const [demoBusy, setDemoBusy] = useState(false)
  const [demoMsg, setDemoMsg] = useState<string | null>(null)
  const [demoErr, setDemoErr] = useState<unknown>(null)
  const [confirmRemove, setConfirmRemove] = useState(false)

  const choose = async (name: string) => {
    setSaving(true)
    try {
      setData(await api.put<SettingsPayload>('/api/settings', { ai_provider: name }))
      setTest(null)
      toast.push('success', `Active provider set to ${name}.`)
    } catch (e) {
      toast.push('error', errorText(e))
    } finally {
      setSaving(false)
    }
  }

  const runTest = async () => {
    setTesting(true)
    setTestError(null)
    try {
      setTest(await api.post<HealthResult>('/api/settings/test-provider', {}))
    } catch (e) {
      setTest(null)
      setTestError(errorText(e))
    } finally {
      setTesting(false)
    }
  }

  const loadDemo = async () => {
    setDemoBusy(true)
    setDemoErr(null)
    setDemoMsg(null)
    try {
      const r = await api.post<{ results: Record<string, { created?: boolean; error?: string }> }>('/api/demo-data', {})
      const lines = Object.entries(r.results).map(([k, v]) => `${k}: ${v.error ? `not created - ${v.error}` : 'ready'}`)
      setDemoMsg(lines.join('; ') || 'No demo modules are available yet.')
      demo.reload()
    } catch (e) {
      setDemoErr(e)
    } finally {
      setDemoBusy(false)
    }
  }

  const removeDemo = async () => {
    setDemoBusy(true)
    setDemoErr(null)
    try {
      await api.del('/api/demo-data')
      setDemoMsg('Demo data removed. Your own records were not touched.')
      demo.reload()
      setConfirmRemove(false)
    } catch (e) {
      setDemoErr(e)
      setConfirmRemove(false)
    } finally {
      setDemoBusy(false)
    }
  }

  const dependents = demoErr instanceof ApiError && demoErr.code === 'DEMO_DATA_REFERENCED'
    ? ((demoErr.details as { dependents?: { description: string }[] })?.dependents ?? [])
    : []

  return (
    <div>
      <h1>Settings</h1>
      {loading && !data && <Spinner />}
      <ErrorBanner error={error} onRetry={reload} title="Could not load settings" />
      {data && (
        <section className="panel">
          <h2>AI provider</h2>
          <p>
            The active provider is a global setting. Each execution records the provider it used and keeps it; FlowSynapse never switches
            providers on its own.
          </p>
          <fieldset disabled={saving}>
            <legend>Active provider</legend>
            {data.providers.map((p) => (
              <label key={p.name} className="radio-row">
                <input type="radio" name="provider" value={p.name} checked={data.active_provider === p.name} onChange={() => choose(p.name)} />
                <strong>{p.name}</strong> {p.model && <span className="muted">({p.model})</span>}
                {p.name === 'mock' && <span className="muted"> - deterministic, offline, free; labelled as mock (not real AI)</span>}
                {p.requires_network && <span className="muted"> - requires internet; may incur charges (verify current quotas)</span>}
                {p.name === 'ollama' && <span className="muted"> - local; the model must already be pulled and Ollama running</span>}
                {!p.configured && <span className="field-error"> {p.config_error}</span>}
              </label>
            ))}
          </fieldset>
          {data.config_error && <Notice kind="warning">Active provider is not configured: {data.config_error}</Notice>}
          <button type="button" className="btn" onClick={runTest} disabled={testing}>
            {testing ? 'Testing...' : 'Test provider'}
          </button>
          {testError && <p className="field-error" role="alert">{testError}</p>}
          {test && (
            <Notice kind={test.ok ? 'success' : 'warning'}>
              {test.ok ? 'OK' : 'Not available'}: {test.message}
              {test.details?.hint && <> - {test.details.hint}</>}
              {test.cached && <span className="muted"> (cached result)</span>}
            </Notice>
          )}
        </section>
      )}
      <section className="panel">
        <h2>Demonstration data</h2>
        <p>
          Loads synthetic demo records for every module by running the real workflows with the mock provider. Demo records are labelled
          everywhere. SEO and website demos crawl the bundled local demo site and require <code>ALLOW_DEMO_SITE=true</code>
          {data && !data.allow_demo_site && <strong> (currently disabled - those two demos will not be created)</strong>}.
        </p>
        {demo.data && (
          <ul className="small">
            {Object.entries(demo.data.modules).map(([k, v]) => (
              <li key={k}>
                {k}: {v.demo_records} demo record(s)
              </li>
            ))}
            {Object.keys(demo.data.modules).length === 0 && <li>No module demo loaders are available yet.</li>}
          </ul>
        )}
        <button type="button" className="btn btn-primary" onClick={loadDemo} disabled={demoBusy}>
          {demoBusy ? 'Working...' : 'Load demo data'}
        </button>{' '}
        <button type="button" className="btn btn-danger" onClick={() => setConfirmRemove(true)} disabled={demoBusy}>
          Remove demo data
        </button>
        {demoMsg && <Notice kind="success">{demoMsg}</Notice>}
        {demoErr !== null && dependents.length === 0 && <ErrorBanner error={demoErr} title="Demo data" />}
        {dependents.length > 0 && (
          <Notice kind="warning">
            Removal refused because your own records reference demo records:
            <ul>
              {dependents.map((d, i) => (
                <li key={i}>{d.description}</li>
              ))}
            </ul>
            Open the demo record and choose "Keep as my own", or detach the reference, then try again.
          </Notice>
        )}
        <ConfirmDialog
          open={confirmRemove}
          title="Remove all demo data?"
          danger
          busy={demoBusy}
          confirmLabel="Remove demo data"
          onCancel={() => setConfirmRemove(false)}
          onConfirm={removeDemo}
        >
          This deletes every record marked as demo data (and only their own runs, outputs and exports). Your own records are never deleted.
        </ConfirmDialog>
      </section>
    </div>
  )
}
