import { Link } from 'react-router-dom'
import type { ModuleInfo } from '../modules/catalogue'

export function NotImplemented({ module }: { module: ModuleInfo }) {
  return (
    <div>
      <h1>{module.title}</h1>
      <p>{module.purpose}</p>
      <div className="alert alert-warning" role="status">
        Not implemented yet: this module is scheduled in a later build phase. No actions are available here.
      </div>
      <button type="button" className="btn" disabled title="Not implemented yet">
        Create (not yet implemented)
      </button>
    </div>
  )
}

export function NotFound() {
  return (
    <div>
      <h1>Page not found</h1>
      <p>
        <Link to="/">Go to the dashboard</Link>
      </p>
    </div>
  )
}
