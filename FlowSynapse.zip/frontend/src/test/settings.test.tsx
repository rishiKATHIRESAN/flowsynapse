import { fireEvent, screen, waitFor, within } from '@testing-library/react'
import { describe, expect, it } from 'vitest'
import { apiError, mockApi, renderAt } from './utils'

const SETTINGS = {
  active_provider: 'mock',
  active_model: 'mock-deterministic-v1',
  is_mock: true,
  config_error: null,
  allow_demo_site: false,
  demo_site_port: 8765,
  providers: [
    { name: 'mock', configured: true, config_error: null, model: 'mock-deterministic-v1', requires_network: false, may_incur_charges: false },
    { name: 'ollama', configured: false, config_error: 'Ollama requires OLLAMA_MODEL', model: null, requires_network: false, may_incur_charges: false },
    { name: 'gemini', configured: false, config_error: 'Gemini requires GEMINI_API_KEY', model: null, requires_network: true, may_incur_charges: true },
  ],
}

describe('settings page', () => {
  it('[FS-SYS-052] shows providers, switches provider and runs a real provider test', async () => {
    const { calls } = mockApi({
      'GET /api/settings': () => SETTINGS,
      'PUT /api/settings': () => ({ ...SETTINGS, active_provider: 'gemini', config_error: 'Gemini requires GEMINI_API_KEY' }),
      'POST /api/settings/test-provider': () => ({ ok: false, provider: 'gemini', model: null, message: 'Gemini requires key', cached: false }),
      '/api/demo-data': () => ({ modules: {} }),
    })
    renderAt('/settings')
    expect(await screen.findByText('Gemini requires GEMINI_API_KEY')).toBeInTheDocument()
    fireEvent.click(screen.getByRole('radio', { name: /gemini/ }))
    await waitFor(() => expect(calls.some((c) => c.method === 'PUT' && (c.body as { ai_provider: string }).ai_provider === 'gemini')).toBe(true))
    expect(await screen.findByText(/Active provider is not configured/)).toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: 'Test provider' }))
    expect(await screen.findByText(/Not available: Gemini requires key/)).toBeInTheDocument()
  })

  it('[FS-SYS-052] negative: demo removal refusal lists dependents and never reports success', async () => {
    mockApi({
      'GET /api/settings': () => SETTINGS,
      '/api/demo-data': () => ({ modules: { campaigns: { demo_records: 1 } } }),
      'DELETE /api/demo-data': () => apiError(409, 'DEMO_DATA_REFERENCED', 'refused', { dependents: [{ description: 'Funnel "Mine" uses demo campaign' }] }),
    })
    renderAt('/settings')
    fireEvent.click(await screen.findByRole('button', { name: 'Remove demo data' }))
    const dialog = screen.getByRole('dialog')
    fireEvent.click(within(dialog).getByRole('button', { name: 'Remove demo data' }))
    expect(await screen.findByText(/Funnel "Mine" uses demo campaign/)).toBeInTheDocument()
    expect(screen.queryByText(/Demo data removed/)).not.toBeInTheDocument()
  })
})
