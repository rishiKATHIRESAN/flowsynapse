import { render } from '@testing-library/react'
import { createMemoryRouter } from 'react-router-dom'
import { vi } from 'vitest'
import App, { routes } from '../App'

export type Handler = (url: URL, init: RequestInit | undefined) => unknown

export interface Call {
  method: string
  url: URL
  body: unknown
  headers: Record<string, string>
}

/** Route-aware fetch mock. Handlers keyed by "METHOD /path" or "/path" (query ignored). */
export function mockApi(handlers: Record<string, Handler>) {
  const calls: Call[] = []
  const spy = vi.spyOn(globalThis, 'fetch').mockImplementation(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = new URL(typeof input === 'string' ? input : input.toString(), 'http://localhost')
    const method = (init?.method ?? 'GET').toUpperCase()
    const body = init?.body ? JSON.parse(String(init.body)) : undefined
    calls.push({ method, url, body, headers: (init?.headers ?? {}) as Record<string, string> })
    const h = handlers[method + ' ' + url.pathname] ?? handlers[url.pathname]
    if (url.pathname === '/api/health' && !h) {
      return json({ app: 'flowsynapse', status: 'ok', version: '0.1.0', db_revision: 'x', instance_id: 'i' })
    }
    if (!h) return json({ error: { code: 'NOT_FOUND', message: 'unmocked ' + method + ' ' + url.pathname } }, 404)
    const out = await h(url, init)
    return out instanceof Response ? out : json(out)
  })
  return { spy, calls }
}

export function json(body: unknown, status = 200, headers: Record<string, string> = {}) {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json', ...headers } })
}

export function apiError(status: number, code: string, message: string, details?: unknown) {
  return json({ error: { code, message, details } }, status)
}

export function renderAt(path: string) {
  const router = createMemoryRouter(routes, { initialEntries: [path] })
  return { router, ...render(<App router={router} />) }
}
