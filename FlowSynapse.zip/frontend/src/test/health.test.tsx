import { screen, waitFor } from '@testing-library/react'
import { describe, expect, it, vi } from 'vitest'
import { classifyHealth } from '../api/health'
import { mockApi, renderAt } from './utils'

const SETTINGS_STUBS = { '/api/settings': () => ({ providers: [] }), '/api/demo-data': () => ({ modules: {} }) }

describe('backend connection indicator', () => {
  it('[FS-SYS-002] classifies only app=flowsynapse payloads as FlowSynapse', () => {
    expect(classifyHealth({ app: 'other', status: 'ok' }).kind).toBe('foreign')
    expect(classifyHealth(null).kind).toBe('foreign')
    expect(classifyHealth({ app: 'flowsynapse', status: 'starting', version: '1' }).kind).toBe('starting')
    expect(classifyHealth({ app: 'flowsynapse', status: 'ok', version: '1' }).kind).toBe('connected')
  })

  it('[FS-SYS-002] shows connected only after a valid health response', async () => {
    mockApi(SETTINGS_STUBS)
    renderAt('/settings')
    expect(screen.getByTestId('connection-indicator')).toHaveTextContent('Checking backend')
    await waitFor(() => expect(screen.getByTestId('connection-indicator')).toHaveTextContent('Backend connected'))
  })

  it('[FS-SYS-002] reports a foreign service instead of connecting', async () => {
    mockApi({ ...SETTINGS_STUBS, '/api/health': () => ({ app: 'something-else', status: 'ok' }) })
    renderAt('/settings')
    await waitFor(() => expect(screen.getByTestId('connection-indicator')).toHaveTextContent('Wrong service'))
  })

  it('[FS-SYS-002] reports backend unreachable on network failure', async () => {
    vi.spyOn(globalThis, 'fetch').mockRejectedValue(new TypeError('Failed to fetch'))
    renderAt('/settings')
    await waitFor(() => expect(screen.getByTestId('connection-indicator')).toHaveTextContent('Backend unreachable'))
    expect((await screen.findAllByText(/Is the FlowSynapse backend running/)).length).toBeGreaterThan(0)
  })
})
