import { fireEvent, screen, waitFor, within } from '@testing-library/react'
import { describe, expect, it } from 'vitest'
import { apiError, mockApi, renderAt } from './utils'

const DEMO = {
  is_demo: true,
  note: 'Synthetic demonstration brief.',
  brief: {
    business_name: 'Be Well Hospitals', industry: 'Healthcare - hospital / orthopaedics', business_description: 'DEMO ASSUMPTION: x',
    location: 'Selaiyur, Chennai, Tamil Nadu, India', primary_service: 'Orthopaedic consultation', campaign_name: 'Be Well Demo',
    objective: 'Generate leads', primary_conversion_goal: 'Enquiry', start_date: '2026-11-02', end_date: '2026-11-15', duration_days: 14,
    total_budget: '15000', currency: 'INR', paid_channels: ['google_ads', 'meta_ads'], organic_channels: ['instagram'], language: 'English',
    target_geography: 'Selaiyur', audience_description: 'Adults', offer_details: 'Consultation', call_to_action: 'Book', contact_method: 'Form',
    posting_cadence: { type: 'every_n_days', n: 2 }, concept_count: 3, is_healthcare: null,
  },
}

function stage(key: string, position: number, status: string, extra: Record<string, unknown> = {}) {
  return { id: key, stage_key: key, item_id: null, position, status, required: true, carried_from_stage_id: null, error_code: null, error_message: null, retryable: null, attempt_count: 1, ai_calls_used: 0, provider: 'mock', model: 'm', is_mock: true, warnings: [], started_at: null, finished_at: null, duration_seconds: null, ...extra }
}

function detail(over: Record<string, unknown> = {}) {
  return {
    id: 'c1', identifier: 'CMP-1', name: 'Be Well Demo', status: 'FAILED', business_name: 'Be Well', is_demo: true, brief_valid: true, content_version: 3,
    provider: 'mock', is_mock: true, latest_execution_id: 'e1', outdated_stages: [], created_at: '2026-10-21T00:00:00Z', updated_at: '2026-10-21T00:00:00Z',
    brief: DEMO.brief, brief_version: 1, normalized_brief: null, assumptions: [], validation: { valid: true, errors: [], warnings: [] },
    stage_states: {}, stage_labels: { INPUT_VALIDATION: 'Input validation', BRIEF_NORMALIZATION: 'Brief normalization', OBJECTIVE_ANALYSIS: 'Objective analysis' },
    stages: ['INPUT_VALIDATION', 'BRIEF_NORMALIZATION', 'OBJECTIVE_ANALYSIS'], healthcare_disclaimer: 'Healthcare advertising: review policies.',
    latest_execution: {
      id: 'e1', parent_type: 'campaign', parent_id: 'c1', scope: 'FULL', status: 'FAILED', retry_of_execution_id: null, attempt_number: 1, cancel_requested: false,
      error_code: 'MOCK_INJECTED_FAILURE', error_message: 'OBJECTIVE_ANALYSIS: Mock provider failure', retryable: true, ai_calls_used: 3, provider: 'mock', model: 'm', is_mock: true, is_demo: true,
      warnings_count: 0, created_at: '2026-10-21T00:00:00Z', started_at: null, finished_at: null, heartbeat_at: null, progress: { completed: 2, total: 3 },
      stages: [stage('INPUT_VALIDATION', 0, 'COMPLETED'), stage('BRIEF_NORMALIZATION', 1, 'COMPLETED'), stage('OBJECTIVE_ANALYSIS', 2, 'FAILED', { error_message: 'Mock provider failure', retryable: true })],
    },
    ...over,
  }
}

describe('campaign module UI', () => {
  it('[FS-M1-023] load demo brief populates the form and live-computes duration', async () => {
    mockApi({ '/api/campaigns/demo-brief': () => DEMO })
    renderAt('/campaigns/new')
    fireEvent.click(screen.getByRole('button', { name: 'Load demo brief' }))
    expect(await screen.findByDisplayValue('Be Well Hospitals')).toBeInTheDocument()
    expect(screen.getByText(/Demonstration data \(Be Well Hospitals\)/)).toBeInTheDocument()
    expect(screen.getByTestId('duration-preview')).toHaveTextContent('Dates cover 14 days (inclusive)')
    fireEvent.change(screen.getByLabelText(/End date/), { target: { value: '2026-11-01' } })
    expect(screen.getByTestId('duration-preview')).toHaveTextContent('End date is before the start date')
  })

  it('[FS-M1-023] negative: validation shows field-level errors and keeps inputs', async () => {
    mockApi({
      'POST /api/campaigns/validate-brief': () => ({ valid: false, errors: [{ field: 'business_name', code: 'REQUIRED', message: 'Business name is required' }, { field: 'end_date', code: 'END_BEFORE_START', message: 'End date is before the start date' }], warnings: [] }),
    })
    renderAt('/campaigns/new')
    fireEvent.change(screen.getByLabelText(/Industry/), { target: { value: 'Bakery' } })
    fireEvent.click(screen.getByRole('button', { name: 'Validate' }))
    expect(await screen.findByText('Business name is required')).toBeInTheDocument()
    const name = screen.getByLabelText(/Business name/)
    expect(name).toHaveAttribute('aria-invalid', 'true')
    expect(screen.getByLabelText(/Industry/)).toHaveValue('Bakery')
    expect(screen.queryByText('No blocking validation errors.')).not.toBeInTheDocument()
  })

  it('[FS-M1-023] save draft sends an Idempotency-Key and never shows success on failure', async () => {
    const { calls } = mockApi({ 'POST /api/campaigns': () => apiError(500, 'INTERNAL_ERROR', 'Database unavailable') })
    renderAt('/campaigns/new')
    fireEvent.click(screen.getByRole('button', { name: 'Save Draft' }))
    expect(await screen.findByText(/Database unavailable/)).toBeInTheDocument()
    expect(screen.queryByText('Draft saved.')).not.toBeInTheDocument()
    const post = calls.find((c) => c.method === 'POST' && c.url.pathname === '/api/campaigns')
    expect(post?.headers['Idempotency-Key']).toMatch(/[0-9a-f-]{20,}/)
  })

  it('[FS-M1-023] detail shows the timeline from persisted stage states with retry for the failed stage', async () => {
    const { calls } = mockApi({
      'GET /api/campaigns/c1': () => detail(),
      'GET /api/campaigns/c1/stages/OBJECTIVE_ANALYSIS': () => ({ stage_key: 'OBJECTIVE_ANALYSIS', label: 'Objective analysis', is_outdated: false, outdated_reason: null, outputs: [], output_ref: null }),
      'POST /api/campaigns/c1/executions/e1/stages/OBJECTIVE_ANALYSIS/retry': () => ({ ...detail().latest_execution, id: 'e2', status: 'PENDING' }),
      'GET /api/campaigns/c1/executions/e2': () => ({ ...detail().latest_execution, id: 'e2', status: 'RUNNING' }),
    })
    renderAt('/campaigns/c1')
    expect(await screen.findByTestId('progress')).toHaveTextContent('2 of 3 stages completed')
    const list = screen.getByLabelText('Stage timeline')
    expect(within(list).getAllByTestId('status-badge').map((b) => b.textContent)).toEqual(['Completed', 'Completed', 'Failed'])
    expect(screen.getAllByText(/retry is possible/).length).toBeGreaterThan(0)
    expect(screen.getByText(/Healthcare advertising/)).toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: /Retry failed stage/ }))
    await waitFor(() => expect(calls.some((c) => c.url.pathname.endsWith('/retry'))).toBe(true))
    expect(await screen.findByText('Running')).toBeInTheDocument()
  })

  it('[FS-M1-023] non-retryable failure disables retry with an explanation', async () => {
    const d = detail()
    d.latest_execution.stages[2] = stage('OBJECTIVE_ANALYSIS', 2, 'FAILED', { error_message: 'Invalid output', retryable: false })
    mockApi({ 'GET /api/campaigns/c1': () => d, 'GET /api/campaigns/c1/stages/OBJECTIVE_ANALYSIS': () => ({ stage_key: 'x', label: 'x', is_outdated: false, outdated_reason: null, outputs: [], output_ref: null }) })
    renderAt('/campaigns/c1')
    const btn = await screen.findByRole('button', { name: /Retry failed stage/ })
    expect(btn).toBeDisabled()
    expect(screen.getByText(/not retryable - change inputs or provider/)).toBeInTheDocument()
  })
})
