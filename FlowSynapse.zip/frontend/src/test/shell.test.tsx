import { fireEvent, render, screen, waitFor, within } from '@testing-library/react'
import { useState } from 'react'
import { describe, expect, it } from 'vitest'
import { ErrorBoundary } from '../components/ErrorBoundary'
import { ConfirmDialog, StatusBadge } from '../components/ui'
import { json, mockApi, renderAt } from './utils'

function mod(key: string, title: string, route: string, total = 0) {
  return { key, title, route, total, by_status: total ? { COMPLETED: 2, FAILED: 1 } : {}, available: true, last_run: null }
}

const DASH = {
  include_demo: false,
  modules: [
    mod('campaigns', 'AI Marketing Campaign Intelligence Engine', '/campaigns', 3),
    mod('funnels', 'AI Marketing Funnel Builder', '/funnels'),
    mod('seo', 'Website SEO Audit & SEO Report Generator', '/seo'),
    mod('website', 'Website Intelligence & Website Report Generator', '/website-reports'),
    mod('blogs', 'AI Bulk Blog & Content Generator', '/blogs'),
    mod('social', 'AI Social Media Campaign & Content Calendar Generator', '/social'),
  ],
  recent_runs: [],
}

describe('application shell', () => {
  it('[FS-SYS-050] sidebar lists Dashboard, the six modules in catalogue order, then Settings', () => {
    mockApi({ '/api/dashboard': () => DASH })
    renderAt('/')
    const nav = screen.getByRole('navigation', { name: 'Main navigation' })
    const links = within(nav)
      .getAllByRole('link')
      .map((a) => (a.textContent ?? '').replace(/^\d\s*/, '').trim())
    expect(links).toEqual(['Dashboard', 'Campaign Intelligence', 'Funnel Builder', 'SEO Audit', 'Website Intelligence', 'Bulk Blog', 'Social Calendar', 'Settings'])
  })

  it('[FS-SYS-051] dashboard shows real API counts with Campaign first and Funnel second', async () => {
    mockApi({ '/api/dashboard': () => DASH })
    renderAt('/')
    const cards = await screen.findByTestId('module-cards')
    const headings = within(cards)
      .getAllByRole('heading', { level: 2 })
      .map((h) => h.textContent ?? '')
    expect(headings[0]).toContain('Campaign Intelligence Engine')
    expect(headings[1]).toContain('Funnel Builder')
    const first = screen.getByTestId('card-campaigns')
    expect(first).toHaveTextContent('3 records')
    expect(within(first).getByRole('link', { name: 'Create Campaign' })).toHaveAttribute('href', '/campaigns?new=1')
    expect(screen.getByTestId('card-funnels')).toHaveTextContent('Nothing here yet')
  })

  it('[FS-SYS-051] dashboard demo toggle requests include_demo and shows load errors', async () => {
    const { calls } = mockApi({
      '/api/dashboard': (url) => (url.searchParams.get('include_demo') === 'true' ? DASH : json({ error: { code: 'X', message: 'boom' } }, 500)),
    })
    renderAt('/')
    expect(await screen.findByText(/boom/)).toBeInTheDocument()
    fireEvent.click(screen.getByLabelText(/Include demo data/))
    await screen.findByTestId('module-cards')
    expect(calls.some((c) => c.url.searchParams.get('include_demo') === 'true')).toBe(true)
  })

  it('[FS-SYS-050] error boundary shows a recoverable message instead of a blank page', () => {
    function Boom(): never {
      throw new Error('kaboom')
    }
    const err = console.error
    console.error = () => undefined
    render(
      <ErrorBoundary>
        <Boom />
      </ErrorBoundary>,
    )
    console.error = err
    expect(screen.getByRole('alert')).toHaveTextContent('kaboom')
    expect(screen.getByRole('button', { name: 'Retry' })).toBeInTheDocument()
  })

  it('[FS-SYS-050] confirm dialog names the action and only confirms on click', async () => {
    let confirmed = 0
    function Host() {
      const [open, setOpen] = useState(true)
      return (
        <ConfirmDialog open={open} title="Delete campaign X?" danger onCancel={() => setOpen(false)} onConfirm={() => (confirmed += 1)}>
          This deletes campaign X and its outputs.
        </ConfirmDialog>
      )
    }
    render(<Host />)
    expect(screen.getByRole('dialog', { name: 'Delete campaign X?' })).toHaveTextContent('deletes campaign X')
    fireEvent.click(screen.getByRole('button', { name: 'Confirm' }))
    expect(confirmed).toBe(1)
    fireEvent.keyDown(document, { key: 'Escape' })
    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument())
  })

  it('[FS-SYS-050] completed-but-outdated work is shown as Outdated', () => {
    render(<StatusBadge status="COMPLETED" outdated />)
    expect(screen.getByTestId('status-badge')).toHaveTextContent('Outdated')
  })
})
