import { api } from './client'

export interface HealthPayload {
  app: string
  version: string
  db_revision: string | null
  instance_id: string
  status: string
}

export type ConnectionState =
  | { kind: 'checking' }
  | { kind: 'connected'; health: HealthPayload }
  | { kind: 'starting'; health: HealthPayload }
  | { kind: 'foreign'; detail: string }
  | { kind: 'unreachable'; detail: string }

/** Only a payload with app === "flowsynapse" counts as FlowSynapse. */
export function classifyHealth(payload: unknown): ConnectionState {
  const p = payload as Partial<HealthPayload> | null
  if (!p || typeof p !== 'object' || p.app !== 'flowsynapse') {
    return { kind: 'foreign', detail: 'A different service is answering on the backend port.' }
  }
  const health = p as HealthPayload
  return health.status === 'ok' ? { kind: 'connected', health } : { kind: 'starting', health }
}

export async function checkHealth(signal?: AbortSignal): Promise<ConnectionState> {
  try {
    const payload = await api.get<unknown>('/api/health', undefined, signal)
    return classifyHealth(payload)
  } catch (e) {
    if (e instanceof DOMException && e.name === 'AbortError') throw e
    return { kind: 'unreachable', detail: e instanceof Error ? e.message : 'Backend unreachable' }
  }
}
