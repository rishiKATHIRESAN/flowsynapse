/**
 * Typed API client. Relative URLs only (Vite proxies /api to the backend).
 * Parses the standard error format {"error": {code, message, details}} and
 * reports "Backend unreachable" on network failure.
 */

export interface FieldError {
  field: string
  code: string
  message: string
}

export class ApiError extends Error {
  readonly status: number
  readonly code: string
  readonly details: unknown

  constructor(status: number, code: string, message: string, details?: unknown) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.code = code
    this.details = details
  }

  /** Field-level validation errors keyed by field path. */
  get fieldErrors(): Record<string, string> {
    const out: Record<string, string> = {}
    const d = this.details as { fields?: FieldError[] } | null | undefined
    for (const f of d?.fields ?? []) {
      if (!out[f.field]) out[f.field] = f.message
    }
    return out
  }

  get retryable(): boolean {
    const d = this.details as { retryable?: boolean } | null | undefined
    return Boolean(d?.retryable) || this.status === 503 || this.code === 'BACKEND_UNREACHABLE'
  }
}

export const UNREACHABLE_MESSAGE =
  'Backend unreachable. Is the FlowSynapse backend running on port 8000? Start it with scripts/start.'

export function newIdempotencyKey(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID()
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`
}

export interface RequestOptions {
  method?: string
  body?: unknown
  idempotencyKey?: string
  ifMatch?: string | number
  signal?: AbortSignal
  query?: Record<string, string | number | boolean | undefined | null>
}

function buildUrl(path: string, query?: RequestOptions['query']): string {
  const url = path.startsWith('/api') ? path : `/api${path}`
  if (!query) return url
  const params = new URLSearchParams()
  for (const [k, v] of Object.entries(query)) {
    if (v !== undefined && v !== null && v !== '') params.set(k, String(v))
  }
  const qs = params.toString()
  return qs ? `${url}?${qs}` : url
}

async function toApiError(res: Response): Promise<ApiError> {
  let code = 'HTTP_ERROR'
  let message = `Request failed with status ${res.status}`
  let details: unknown = undefined
  try {
    const data = (await res.json()) as { error?: { code?: string; message?: string; details?: unknown } }
    if (data?.error) {
      code = data.error.code ?? code
      message = data.error.message ?? message
      details = data.error.details
    }
  } catch {
    // non-JSON body (e.g. proxy error page)
    if (res.status === 502 || res.status === 504) {
      return new ApiError(res.status, 'BACKEND_UNREACHABLE', UNREACHABLE_MESSAGE)
    }
  }
  return new ApiError(res.status, code, message, details)
}

async function send(path: string, opts: RequestOptions = {}): Promise<Response> {
  const headers: Record<string, string> = { Accept: 'application/json' }
  let body: string | undefined
  if (opts.body !== undefined) {
    headers['Content-Type'] = 'application/json'
    body = JSON.stringify(opts.body)
  }
  if (opts.idempotencyKey) headers['Idempotency-Key'] = opts.idempotencyKey
  if (opts.ifMatch !== undefined) headers['If-Match'] = String(opts.ifMatch)
  let res: Response
  try {
    res = await fetch(buildUrl(path, opts.query), {
      method: opts.method ?? (body ? 'POST' : 'GET'),
      headers,
      body,
      signal: opts.signal,
    })
  } catch (e) {
    if (e instanceof DOMException && e.name === 'AbortError') throw e
    throw new ApiError(0, 'BACKEND_UNREACHABLE', UNREACHABLE_MESSAGE)
  }
  if (!res.ok) throw await toApiError(res)
  return res
}

export async function request<T>(path: string, opts: RequestOptions = {}): Promise<T> {
  const res = await send(path, opts)
  if (res.status === 204) return undefined as T
  const text = await res.text()
  return (text ? JSON.parse(text) : undefined) as T
}

export const api = {
  get: <T>(path: string, query?: RequestOptions['query'], signal?: AbortSignal) =>
    request<T>(path, { method: 'GET', query, signal }),
  post: <T>(path: string, body?: unknown, opts: Omit<RequestOptions, 'body' | 'method'> = {}) =>
    request<T>(path, { ...opts, method: 'POST', body: body ?? {} }),
  patch: <T>(path: string, body: unknown, opts: Omit<RequestOptions, 'body' | 'method'> = {}) =>
    request<T>(path, { ...opts, method: 'PATCH', body }),
  put: <T>(path: string, body: unknown, opts: Omit<RequestOptions, 'body' | 'method'> = {}) =>
    request<T>(path, { ...opts, method: 'PUT', body }),
  del: <T>(path: string, opts: Omit<RequestOptions, 'method'> = {}) => request<T>(path, { ...opts, method: 'DELETE' }),
}

/** Parse a Content-Disposition header, preferring RFC 5987 filename*. */
export function filenameFromDisposition(header: string | null, fallback: string): string {
  if (!header) return fallback
  const star = /filename\*=UTF-8''([^;]+)/i.exec(header)
  if (star) {
    try {
      return decodeURIComponent(star[1])
    } catch {
      /* fall through */
    }
  }
  const plain = /filename="?([^";]+)"?/i.exec(header)
  return plain ? plain[1] : fallback
}

export interface DownloadResult {
  filename: string
  blob: Blob
}

/** Download a file honoring Content-Disposition. */
export async function downloadFile(path: string, query?: RequestOptions['query'], fallback = 'download'): Promise<DownloadResult> {
  const res = await send(path, { method: 'GET', query })
  const blob = await res.blob()
  const filename = filenameFromDisposition(res.headers.get('Content-Disposition'), fallback)
  return { filename, blob }
}

export function saveBlob({ filename, blob }: DownloadResult): void {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}
