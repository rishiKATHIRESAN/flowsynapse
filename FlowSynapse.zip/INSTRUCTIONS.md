# FlowSynapse — Instructions for the Next Developer

Read this file first. It covers how to run the project from a ZIP, the current state, and the exact steps to continue building it.

- Full specification: `docs/FlowSynapse_Master_Prompt_v6.md` (the source of truth for all requirements)
- Progress and what is not done: `docs/BUILD_STATE.md`
- Phase plan and requirement tracking: `IMPLEMENTATION_CHECKLIST.md`
- Design decisions: `docs/ARCHITECTURE.md`

---

## 1. What you are receiving

FlowSynapse is a local web app with six marketing automation modules. It runs entirely on your PC and needs no paid services.

| Part | Technology | Folder |
|---|---|---|
| Backend | Python, FastAPI, SQLite, Alembic | `backend/` |
| Frontend | React, Vite, TypeScript | `frontend/` |
| Scripts | Setup, start, check and test (Python, with `.ps1` / `.bat` / `.sh` launchers) | `scripts/` |

The default AI provider is **mock**. It is offline and free, and its output is always labelled "not real AI output".

### Current state (Phase 6 of 21)

| Area | Status |
|---|---|
| App shell, dashboard, settings (AI provider choice and test, demo data) | Working |
| Job engine (background runs, cancel, retry, recovery after restart) | Working |
| Safe database migrations with backups | Working |
| Export system (PDF, Excel, CSV, ZIP) | Working |
| **1. Campaign Intelligence** | **Partial**: stages 1–3 of 12 work (validation, normalization, objective analysis) |
| 2. Funnel Builder | Not started (page says "Not implemented yet") |
| 3. SEO Audit | Not started |
| 4. Website Intelligence | Not started |
| 5. Bulk Blog Generator | Not started |
| 6. Social Calendar | Not started |

---

## 2. Requirements (install these first)

| Tool | Version | Download |
|---|---|---|
| Python | 3.10 or newer (3.12 recommended) | https://www.python.org/downloads/ — on Windows, tick **"Add Python to PATH"** |
| Node.js | 18 or newer (20 LTS recommended) | https://nodejs.org/ |
| Git | optional, but recommended | https://git-scm.com/ |

You also need about 1 GB of free disk space.

Check the versions in a terminal:

```
python --version
node --version
npm --version
```

---

## 3. How to run it (from the ZIP)

The ZIP does **not** include installed packages, the database or the `.env` file. The setup script creates all of these.

### Windows (verified)

1. Unzip the archive, for example to `C:\FlowSynapse`.
2. Open **PowerShell** in that folder.
3. Run setup once. It checks versions, creates `backend\.venv`, installs packages, creates `backend\.env` and creates the database.

   ```
   .\scripts\setup.ps1
   ```

   If PowerShell blocks the script, run this instead:

   ```
   powershell -ExecutionPolicy Bypass -File .\scripts\setup.ps1
   ```

   You can also double-click or run `scripts\setup.bat`.

4. Start the app:

   ```
   .\scripts\start.ps1
   ```

5. Open http://127.0.0.1:5173 in a browser. The API docs are at http://127.0.0.1:8000/docs
6. To stop the app, press **Ctrl+C** in the terminal. Both processes stop and the ports are released.

### macOS / Linux (not yet verified)

```
chmod +x scripts/*.sh
./scripts/setup.sh
./scripts/start.sh
```

### Try the working demo

1. Open **Campaign Intelligence** and click **Create Campaign**.
2. Click **Load demo brief**. This loads the Be Well Hospitals example.
3. Click **Run Campaign Intelligence**.
4. Watch the stage timeline update live.
5. Click a stage to see its output.
6. Use the **Downloads** tab to get a CSV of the results.
7. Stop and restart the app; the campaign is still there.

### Manual start (if the scripts fail)

Run the backend in one terminal and the frontend in another.

```
# Terminal 1 - backend
cd backend
.venv\Scripts\python -m app.cli serve        # macOS/Linux: .venv/bin/python -m app.cli serve

# Terminal 2 - frontend
cd frontend
npm run dev
```

### Troubleshooting

| Problem | Fix |
|---|---|
| "Port 8000/5173 already in use" | Stop the other program, or run `.\scripts\start.ps1 --backend-port 8010 --frontend-port 5180` |
| "Backend unreachable" in the UI | The backend did not start. Read `backend\data\logs\backend-console.log` |
| `pip install` or `npm ci` fails | Check your internet or proxy settings, delete `backend\.venv` or `frontend\node_modules`, then run setup again |
| "Another FlowSynapse backend (PID n) is using this database" | A previous copy is still running. Close it, or end that process in Task Manager |
| Want a fresh, empty database | Stop the app, delete `backend\data\flowsynapse.db*`, then run `.\scripts\migrate.ps1` |
| Want to use real AI | Edit `backend\.env`. For Ollama, set `OLLAMA_MODEL` (the model must already be pulled). For Gemini, set `GEMINI_API_KEY` and `GEMINI_MODEL`; Gemini needs internet and may cost money. Then choose the provider in **Settings** |

---

## 4. Tests and checks

Run these from the project root.

| Command | What it does |
|---|---|
| `python scripts/check.py --fast` | Backend unit, integration and API tests; frontend typecheck, tests and build. **Run this before every commit.** |
| `python scripts/test.py e2e` | Starts a real backend process (tests restart persistence) |
| `python scripts/test.py unit` | Runs one layer. Replace `unit` with `integration`, `api`, `frontend` or `all` |
| `python scripts/run_traceability.py` | Runs all tests and updates the requirement status table in `IMPLEMENTATION_CHECKLIST.md`. Statuses are generated; never edit them by hand |

Last results (Windows): 169 backend tests passed, 17 frontend tests passed, 8 e2e tests passed.

---

## 5. Project map (where things live)

```
backend/
  app/
    main.py, runtime.py         app factory; startup order (lock -> migrate -> recover -> workers)
    config.py                   all settings (documented in backend/.env.example)
    database.py                 SQLite engines (normal + BEGIN IMMEDIATE)
    migrations.py               safe migration: backup -> verify -> migrate a copy -> swap
    models/                     SQLAlchemy models (jobs, outputs, campaign, exports, ...)
    api/                        HTTP routes (campaigns.py is the module example to copy)
    ai/                         mock / ollama / gemini providers; runner.py = budgets, retries, repair
    services/
      jobs/                     state_machine, engine (create/cancel/retry), worker, recovery
      content/                  versioning.py, content_status.py, health_claims.py, similarity.py
      reporting/                pdf.py, tabular.py, charts.py, lifecycle.py (export pipeline)
      campaign/                 module 1: brief, validation, dates, budget, dependency_graph,
                                orchestrator, service, stages/, exports, pack
      handlers.py               imports every module so it registers itself
  alembic/versions/             one migration per schema change (0001..0006)
  tests/                        unit/ integration/ api/ e2e/ (+ fixtures/db_snapshots)
frontend/src/
  App.tsx, components/          layout, shared UI, StageTimeline, ContentView
  modules/campaigns/            module 1 UI (copy this pattern for new modules)
  modules/routes.tsx            register module pages here
  test/                         Vitest tests (test/utils.tsx has mockApi + renderAt)
scripts/                        setup, start, check, test, migrate, restore_backup, run_traceability
```

---

## 6. Rules to follow (from the specification)

- **Never fake anything.** No made-up metrics, fake progress bars, or "success" shown after a failure. A button that does not work yet must be visibly disabled with a "Not implemented" note.
- **Every AI result goes through `ctx.ai.generate(...)`** with a Pydantic schema.
  - Register a mock template with `@register_mock("TASK_KEY")`.
  - Build mock output from the user's inputs; never hard-code it to the demo business.
- **Every generated or editable output is stored with `services/content/versioning.py`.** Use `upsert_generated`, `edit_output` and `restore_version`. Do not create per-module version tables.
- **All long work runs through the job engine.**
  - Write a `JobHandler` (see `services/campaign/orchestrator.py`) and register it.
  - Never do long work inside a web request.
- **Schema changes need an Alembic migration.**

  ```
  cd backend
  .venv\Scripts\python -c "import sys; sys.argv=['x','0007_name','message']; exec(open('tests/fixtures/autogen_revision.py').read())"
  ```

  Then:
  - rename the generated file to `0007_name.py`;
  - add seed rows for new tables to `tests/fixtures/make_snapshot.py`;
  - run `.venv\Scripts\python -m tests.fixtures.make_snapshot phase07_0007_name 0007_name`.
- **Tests declare what they verify.**
  - Backend: `@pytest.mark.req("FS-M1-007", kind="integration")`.
  - Frontend: start the test title with `[FS-M1-007]`.
  - The requirement IDs are in `IMPLEMENTATION_CHECKLIST.md`.
- **Never weaken or delete a test to make it pass.** Fix the cause instead.
- **End every phase the same way:**
  1. `scripts/check --fast` passes.
  2. Commit.
  3. Run `scripts/run_traceability`.
  4. Update `docs/BUILD_STATE.md`.
  5. Commit again.

---

## 7. Steps to implement next (in this order)

Each phase is one small increment: model → service → API → test → UI → test. The spec section numbers are in brackets.

### Phase 7 — Campaign stages 4–5 and output editing (§5.3, §5.5, §3.2)

1. **Stage files.** Create `services/campaign/stages/strategy.py` and `stages/concepts.py`. Copy the pattern in `stages/objective.py`:
   - a Pydantic schema;
   - a `@register_mock` template;
   - `run()`, which passes only the brief fields listed for that stage in `dependency_graph.STAGE_FIELDS`, plus upstream outputs;
   - `commit()`, which calls `save(...)`.
2. **Concepts details.**
   - The number of concepts comes from the brief's `concept_count`.
   - Use `similarity.near_duplicates` to flag near-duplicate concepts in `validity_details`.
3. **Register the stages.** Import the new stage modules in `orchestrator.py`. `implemented_stages()` then adds them to every run automatically.
4. **Editing API.** Add these to `api/campaigns.py` (the frontend already calls them; see `frontend/src/modules/campaigns/api.ts`):
   - `PATCH /{id}/outputs/{type}/{output_id}` (If-Match = version): call `versioning.edit_output`. If a new version was created, call `service.mark_outdated(..., affected_stages(Change(outputs={stage})))`.
   - `PATCH .../status`: call `versioning.set_content_status`.
   - `POST .../restore`: call `versioning.restore_version`.
   - `POST .../regenerate`: call `service.regenerate_stage`.
   - Discard a concept by setting `is_discarded=True`.
5. **Editing UI.** Replace the placeholder in `frontend/src/modules/campaigns/OutputEditor.tsx` with:
   - a form or JSON editor;
   - version history with Restore;
   - Regenerate;
   - `ContentStatusControl`.
6. **Tests.**
   - `affected_stages()` cases: budget-only, dates-only, landing URL, concept edit, social edit (see §5.5 examples).
   - A no-op edit invalidates nothing.
   - A version conflict returns 409.
   - Regenerating while upstream is stale returns 409.

### Phase 8 — Google Ads and Meta Ads stages (§5.3 stages 6–7)

- Outputs: `google_ads_plan` + `google_ad_group`, and `meta_ads_plan` + `meta_ad_variant` (names already listed in `constants.STAGE_OUTPUTS`).
- **Character limits are checked in code, not by AI.**
  - Defaults: headline ≤ 30, description ≤ 90, display path ≤ 15.
  - Over-limit assets get `validity="INVALID"` and cannot be set to `READY_TO_EXPORT` (block this in the status endpoint).
- Never invent keyword volumes or costs. Label keywords "generated proposal, not platform research".

### Phase 9 — Social plan, tracking plan, budget (§10, §5.3 stages 8–10, §5.8)

1. **Shared social service.** Create `services/content/social_content.py`:
   - cadence → schedule slots (`daily`, `every_n_days`, `weekdays`, `times_per_week`, `custom`), all inside the inclusive start/end period;
   - gap-rule warnings.
   - **Module 6 must reuse this same service.**
2. **Tracking stage.** Build UTMs in `services/campaign/utm.py`:
   - lowercase slugs;
   - encode with `urllib.parse`;
   - keep existing query parameters and fragments.
3. **Budget stage.** Use the existing, still-untested `services/campaign/budget.py` (`allocate`, `check_manual`).
   - AI writes only the rationale text; numbers come from code.
   - Write its tests first: ₹15,000 → 9,000 + 6,000; ₹10,001 across 3 channels; and the "no floats" check.

### Phase 10 — QA, pack, exports (§5.3 stages 11–12)

1. **QA stage** (`qa_rules.py`, deterministic):
   - writes `CampaignFinding` rows;
   - `BLOCKER` findings block export.
   - Cover every rule in §5.3 stage 11, including the health-claim scan via `health_claims.scan_content`.
2. **Pack stage.** Fill sections 5–13 in `services/campaign/pack_sections.py`. They currently say "not generated yet".
3. **Export tests.** Re-open each PDF, XLSX and CSV file and compare its values with the database.
4. **Module gate.** Make the Module 1 acceptance criteria M1-AC01 to M1-AC12 (§15.12) pass.

### Phases 11–13 — Funnel Builder (§6)

- Models: `Funnel`, `FunnelNode`, `FunnelEdge` (real tables, for graph integrity) and `FunnelGraphVersion`.
- `graph_validation.py`: rules V01–V14, with one test per rule.
- Server-side layout in Python.
- Seven-stage execution through the job engine.
- Campaign context snapshot.
- Exports: PDF, XLSX, CSV and SVG.
- UI: an SVG diagram (drag, connect, delete) plus a keyboard-accessible list view.

### Phase 14 — Crawl infrastructure (§7, §7.1)

- `services/crawl/url_safety.py` (SSRF guard). Block private, loopback and metadata addresses, and re-check every redirect.
- `fetcher.py` with limits on pages, depth, size, redirects and timeouts.
- `robots.py` and `sitemap.py`.
- A bundled `demo_site/` folder and `scripts/serve_demo_site.py`. Only allow it when `ALLOW_DEMO_SITE=true`.
- Evidence model and coverage reporting.

### Phases 15–16 — SEO Audit and Website Intelligence (§7, §8)

- Separate rule engines that share the crawler.
- Every finding must have stored evidence.
- Use the completeness states `COMPLETE`, `PARTIAL` and `FAILED`.
- Triage notes go in a separate table.
- Retrying failed pages creates a new linked run.

### Phase 17 — Bulk Blog Generator (§9)

- One execution stage per topic.
- In the handler, `continue_on_failure()` returns `True`.
- Failed-only retry uses `engine.create_retry_execution`. Completed items must stay byte-identical.
- Exports: MD, TXT, CSV and ZIP.

### Phase 18 — Social Calendar module (§10)

- A standalone UI on top of the shared social service from Phase 9.
- Add, remove and reschedule items, with revalidation after each change.
- Exports: CSV and XLSX.
- No item is ever labelled "scheduled" or "published".

### Phases 19–21 — Integration and final checks

- Phase 19: the Ollama and Gemini providers already exist with tests, so only verification is left.
- Register dashboard counters and demo loaders for each module (copy `services/campaign/demo.py`).
- Write `scripts/smoke_test.py` (§15.8) and `scripts/check_docs.py`.
- Write the remaining docs: `docs/API_REFERENCE.md`, `TEST_PLAN.md`, `MANUAL_TEST_CHECKLIST.md`, `ZERO_COST_SETUP.md`.
- Run a full `scripts/check`.
- Test from a clean clone, and on macOS/Linux.

---

## 8. Making a clean ZIP to share

Do **not** zip the folder as-is. It contains about 1 GB of installed packages, your database and your `.env` file.

If you use git, this includes only committed files:

```
git archive --format=zip -o FlowSynapse.zip HEAD
```

If you zip by hand, exclude these:

- `backend\.venv`
- `frontend\node_modules`
- `frontend\dist`
- `backend\data\*` (keep `backend\data\.gitkeep`)
- `backend\.env`
- `reports\`
- `__pycache__` folders

The receiver then follows **Section 3**.
