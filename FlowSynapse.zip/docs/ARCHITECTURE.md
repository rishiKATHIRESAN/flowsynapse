# FlowSynapse Architecture

## Stack
- **Backend:** Python 3.13 (3.10+ supported), FastAPI, Pydantic v2, SQLAlchemy 2.x, SQLite (WAL), Alembic, ReportLab, matplotlib (Agg), openpyxl, requests, BeautifulSoup4.
- **Frontend:** React 19 + Vite + TypeScript (strict), React Router, Vitest + React Testing Library.
- **Process model:** single backend process with an in-process worker pool; job state persisted in SQLite (§2.6).

## Startup order (§2.6)
1. Load config (invalid provider config is non-fatal) → 2. acquire OS lock `backend/data/flowsynapse.lock` (msvcrt / fcntl) → 3. disk check + safe migrations under the lock → 4. init engines (WAL, `foreign_keys=ON`, `busy_timeout=5000`) → 5. recovery hooks → 6. start workers/watchdog/cleanup; `/api/health` reports `status: ok` only now.

## Database access
Two SQLAlchemy engines point at the same file: `engine` (deferred `BEGIN`, request sessions) and `immediate_engine` (`BEGIN IMMEDIATE`, job-engine decision points). Timestamps are stored as UTC via the `UTCDateTime` type and always returned timezone-aware.

## Migrations (§2.4)
`app/migrations.py::safe_migrate`: fresh/empty DB → `upgrade head`. Existing DB with pending revisions → disk check → backup via SQLite backup API + manifest → verify backup (integrity, revision, row counts, checksum) → migrate a `.migrating` working copy (FKs off during batch ops) → verify (integrity, FK check, head, row counts of pre-existing tables unless declared in `INTENTIONAL_ROW_CHANGES`, required indexes) → `os.replace` swap → drift check. Failure at any step leaves the original byte-identical and removes the working copy. Newer/unknown revision → refuse. Downgrades unsupported; backups (5 kept) are the rollback mechanism.

## Decisions and defaults
| # | Decision | Reason |
|---|---|---|
| D1 | Startup/check scripts are stdlib Python (`scripts/*.py`) with thin `.ps1`/`.bat`/`.sh` wrappers | One implementation for all OSes; no shell-specific logic in project code |
| D2 | Windows graceful stop = `CTRL_BREAK_EVENT` to a child started with `CREATE_NEW_PROCESS_GROUP` (uvicorn handles SIGBREAK), then `taskkill /T /F` for any remaining tree | Ensures the backend runs its controlled shutdown (WAL checkpoint, lock release) |
| D3 | Process lock: stdlib `msvcrt.locking` on a byte at offset 64 KiB (Windows mandatory locks would otherwise block reading the PID payload) / `fcntl.flock` on POSIX | No extra dependency; OS releases on death |
| D4 | Traceability staleness: a run is current only if the working tree had no uncommitted changes outside the generated progress docs; workflow is commit code → run traceability → commit docs | Generated docs necessarily change after the verifying run |
| D5 | Fonts: DejaVu Sans (+Bold) copied from matplotlib's bundled fonts with `LICENSE_DEJAVU` into `app/services/reporting/fonts/` | Open licence; renders `₹` |
| D6 | Request sessions use deferred transactions; job-engine decisions use `BEGIN IMMEDIATE` | Avoid SQLITE_BUSY on read→write upgrade at contention points |
| D7 | One shared `executions`/`execution_stages`/`workflow_runs` table set for all modules (`parent_type`, `parent_id`) | Identical job semantics everywhere; allowed by §2.3 |
| D8 | Generated/editable outputs of every module are rows in one generic `outputs` table with versions in `output_versions` (FK → no orphans). Derived artifacts (QA findings, pack) are not versioned outputs | One versioning mechanism (§3.2) instead of per-module duplicates |
| D9 | **Resolved contradiction:** §5.7 example "2028-02-28 → 2028-03-01 = 4 days" contradicts its formula `duration_days = (end − start).days + 1` (= 3). The formula is implemented and tested | The formula is the stated single source of truth |
| D10 | Campaign brief edits are blocked (409 `EXECUTION_ACTIVE`) while an execution is pending/running; the brief has its own `brief_version` ETag separate from `content_version` | Avoids generating from a half-edited brief and spurious edit conflicts during runs |
| D11 | Each campaign stage receives only the brief fields declared for it in the dependency graph (`dependency_graph.STAGE_FIELDS`) | Keeps §5.5 invalidation truthful: an unchanged input set means an unchanged output |
