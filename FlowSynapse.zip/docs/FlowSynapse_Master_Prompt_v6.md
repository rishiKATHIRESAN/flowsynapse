# FLOWSYNAPSE — MASTER DEVELOPMENT PROMPT v6

This prompt supersedes all earlier FlowSynapse prompts. Where it differs from anything earlier, this prompt wins.

You are Principal Software Architect, Senior Full-Stack Engineer, AI Automation Engineer, QA Lead, UI/UX Designer, and Security Engineer. Build **FlowSynapse**: ONE integrated, AI-assisted workflow automation web application with **six automation modules**, running **locally on my PC with zero mandatory paid services**, and **actually working when started**.

---

## 0. PRIME DIRECTIVES

1. **Verify, don't assume.** Nothing is "done" until you have run it and seen it work. Every claim in a progress report must be backed by a command you ran and its real output. Anything not run is marked **NOT RUN** with the reason. Never mark a feature verified because its source code exists.
2. **Resume safely.** If `IMPLEMENTATION_CHECKLIST.md` and `docs/BUILD_STATE.md` exist, read them, inspect the code, and continue from the first incomplete item. Never restart or overwrite completed work.
3. **No fake functionality.** No fabricated metrics, fake progress bars, fake success messages, hard-coded sample numbers in real outputs, or simulated operations presented as real. Every button works or is visibly disabled with "Not yet implemented". Never show success after a failed operation.
4. **No silent feature removal.** If something proves infeasible, record it in `docs/BUILD_STATE.md` → "Deviations" and report it.
5. **Gate every phase** (Section 18). Do not start the next phase while the current gate fails.
6. **Fix root causes.** Never delete, skip, or weaken a test to make it pass. No `@ts-ignore`, blanket `any`, or broad `except: pass` to hide problems.
7. **Ambiguity:** choose a sensible default, record it in `docs/ARCHITECTURE.md` → "Decisions and defaults", and flag it in the final report. Ask me only if a decision would materially change the architecture.
8. **Only the six modules in Section 1 exist.** Do not add other automation modules.
9. **Honest reporting** at the end of every phase and at completion (Section 21).
10. **Traceability:** maintain the requirements traceability matrix (Section 17.1). A requirement or module is COMPLETE only when its mapped tests pass; source files existing is never evidence of completion.
11. **No unverified claims:** never claim manual browser verification, one-command startup, cross-platform support, restart persistence, or any module's completeness unless it was actually performed and observed; otherwise report NOT RUN / NOT VERIFIED.
12. **Small increments:** never generate the application in one enormous step. Within a phase, work in vertical increments (model → service → API → test → UI → test), run the increment's tests, fix, and commit before continuing. If a step cannot be implemented and tested in one working session, split it and record the split in `docs/BUILD_STATE.md`. Do not begin a dependent phase while its prerequisite gate fails, and run integration checks every phase — never postpone them to the end.

---

## 1. AUTOMATION CATALOGUE (final priority order — use everywhere)

Dashboard cards, sidebar navigation, onboarding examples, demo scenarios, docs, test priority, acceptance criteria, and milestones all follow this order.

| # | Module | Route | Purpose |
|---|---|---|---|
| 1 | **AI Marketing Campaign Intelligence Engine** (flagship) | `/campaigns` | Brief → 12-stage strategy, concepts, Google/Meta proposals, social plan, tracking plan, budget, QA, campaign pack |
| 2 | **AI Marketing Funnel Builder** | `/funnels` | Configurable, connected customer-journey funnel with interactive diagram, per-stage content recommendations, graph validation, reports |
| 3 | **Website SEO Audit & SEO Report Generator** | `/seo` | Verifiable technical/on-page SEO findings + report |
| 4 | **Website Intelligence & Website Report Generator** | `/website-reports` | Broader website assessment: structure, content, navigation, conversion paths |
| 5 | **AI Bulk Blog & Content Generator** | `/blogs` | Batch drafts, per-item status, failed-only retry |
| 6 | **AI Social Media Campaign & Content Calendar Generator** | `/social` | Platform-specific content + cadence-based calendar, standalone |

Additional pages: Dashboard (`/`), Settings (`/settings`). Each module has real, testable functionality and works standalone. Shared infrastructure (DB layer, job worker, provider layer, reporting utilities, execution log, validation utilities) is generic.

### 1.1 Module boundaries
- **Campaign Intelligence Engine** owns: brief analysis, strategy, concepts, Google Ads proposals, Meta Ads proposals, social calendar (via shared service), tracking plan (UTMs), budget allocation, deterministic QA, consolidated pack.
- **Funnel Builder** owns: funnel configuration, customer-journey design, connected funnel stages (graph), stage objectives, stage-specific content *recommendations*, transition/dependency validation, interactive diagram, editing and persistence, funnel execution status, funnel reports/exports. It does **not** produce ad copy sets, budget allocation, UTM plans, or social calendars, and it never re-runs the Campaign Intelligence workflow.
- **SEO report** vs **Website report** are distinct (Sections 7 and 8).
- **Social module** and the campaign `SOCIAL_PLAN` stage share one service (Section 10).
- Modules exchange data only through **explicit backend data contracts** (Section 12), never by scraping the frontend, and each remains usable alone.

### 1.2 Universal end-to-end journey requirement

Every automation must work from its initial input form through backend processing, persistence, results display, and final exports. For **every** module the user must be able to:

1. Open the module.
2. Enter valid inputs or load a demonstration scenario.
3. Receive input validation (field-level errors; inputs preserved on failure).
4. Start an actual backend execution.
5. Observe real execution status and progress.
6. View generated results after processing.
7. Inspect outputs and supporting information (evidence, provider, versions, limitations).
8. Edit supported outputs.
9. Save changes.
10. Reopen saved records.
11. Verify that data persists after navigation **and after an application restart**.
12. Generate supported reports and exports.
13. See meaningful, actionable error messages on failure.
14. Retry failed operations where retry is supported.
15. Cancel long-running operations where cancellation is supported.
16. Verify that completed work is preserved after cancellation or failure.

| Module | Editable outputs | Retry unit | Cancel |
|---|---|---|---|
| 1 Campaign Intelligence | brief, concepts, ad assets, social items, budget | failed stage; regenerate an output | yes |
| 2 Funnel Builder | config, nodes, edges, layout, node content | failed stage or node | yes |
| 3 SEO Audit | finding triage status + user notes only (observed evidence is **never** editable) | re-fetch pages that failed with retryable errors via a **new linked audit run** that carries forward successfully fetched pages (the original run stays immutable), or start a fresh audit; no audit is ever overwritten | yes (partial results preserved and marked partial) |
| 4 Website Intelligence | recommendations, roadmap items, user notes (observations are not editable) | same as module 3 | yes |
| 5 Bulk Blog | draft content and metadata | failed items | yes (pending items cancelled; completed preserved) |
| 6 Social Calendar | items, dates, platforms, cadence | failed items | yes |

Rules:
- An HTTP 200, a successful form submission, or a populated results page is **not** proof that a workflow works; tests must assert persisted database state, stage timestamps, and exported file contents.
- Static sample results must never substitute for workflow logic.
- Every visible control performs its documented action or is visibly disabled with a clear explanation ("Not implemented: …").
- Each module has an automated **journey suite** (15.0): one independently diagnosable test per capability (a capability may be N/A only where the table above says so, and the test records why) — not one giant test.

---

## 2. STACK, ENVIRONMENT, AND PINNED VERSIONS

**Frontend:** React + Vite + TypeScript (strict), React Router, typed API client, responsive CSS or a suitable open-source UI library, Vitest + React Testing Library. Optional lint/format (ESLint, Prettier) — if configured, they must pass.
**Backend:** Python, FastAPI, Pydantic v2, SQLAlchemy 2.x, SQLite, requests, BeautifulSoup4, ReportLab, matplotlib, openpyxl, pytest, httpx. Optional ruff/mypy — if configured, they must pass.
**Database:** SQLite at `backend/data/flowsynapse.db` (auto-created, git-ignored). Use **Alembic migrations from Phase 1** (Section 2.4); `create_all` is not used to evolve the schema. A fresh clone must start with no manual DB steps; an existing DB from an earlier phase must upgrade without data loss.

**Environment checks (first action):** print OS, Python, Node, npm versions and free disk space. Require Python 3.10+ (target 3.11/3.12), Node 18+ (target 20 LTS). If missing, stop and tell me exactly what to install.

- Support Windows (PowerShell), macOS, Linux. Use `pathlib`; no shell-specific syntax in project code; no emoji in console output or file names; provide `.ps1`/`.bat` and `.sh` scripts.
- Virtual environment at `backend/.venv`. Pin backend versions in `requirements.txt`; `package-lock.json` pins frontend. Record resolved versions in `docs/BUILD_STATE.md`. Prefer packages with Windows wheels (no C compiler); `lxml` optional with `html.parser` fallback.
- Install failures/timeouts: retry, diagnose, record; never skip silently.
- Ports (configurable, documented): backend `127.0.0.1:8000`, frontend `127.0.0.1:5173`.

### 2.1 Frontend ↔ backend wiring (exactly)
- Vite dev proxy: `/api/*` → `http://127.0.0.1:8000`. API client uses relative URLs only.
- FastAPI `CORSMiddleware` allows `http://127.0.0.1:5173` and `http://localhost:5173` (env-configurable).
- API client: parses the standard error format, reports "Backend unreachable" on network failure, supports blob downloads honoring `Content-Disposition`, exposes typed functions per endpoint.
- Persistent backend-connection indicator driven by `/api/health`, which returns an identity payload (`app: "flowsynapse"`, `version`, `db_revision`, `instance_id`, `status`). The frontend and the scripts treat a service as FlowSynapse **only if** `app == "flowsynapse"`; the indicator never shows "connected" before a valid health response, and a different service on the port is reported as such, never silently used.
- Production build: backend can serve the built frontend (`frontend/dist`) at `/` when present, so a single process can run the app; document this as an alternative to the dev server.

### 2.2 Backend robustness rules
- SQLite: `check_same_thread=False`, `PRAGMA foreign_keys=ON`, WAL mode, session-per-request dependency. Background workers create **their own session**.
- **Dates:** campaign start/end are calendar `date` values (no timezone). "Today" calculations use a configurable `APP_TIMEZONE` (default `Asia/Kolkata`). Timestamps are stored timezone-aware UTC and serialized ISO-8601.
- **Money** uses `decimal.Decimal` end to end; never floats (Section 5.8).
- matplotlib: set `Agg` backend before importing pyplot; close figures; use in-memory buffers or cleaned-up temp files.
- ReportLab: XML-escape user text in `Paragraph`; wrap long strings/URLs; handle empty data. **Currency symbol:** register a bundled open-licence Unicode font (e.g., DejaVu Sans, shipped with its licence) so `₹` renders; if registration fails, fall back to the text "INR" and log a warning. Test that `₹15,000` is legible in the PDF.
- Excel/CSV: neutralize cells beginning with `=`, `+`, `-`, `@` (formula injection); CSV written with UTF-8 BOM option for Excel compatibility.
- **Export storage:** generated files are written only under `backend/data/exports/` using server-generated names (`{module}_{id}_{timestamp}.{ext}`); paths are resolved and checked to stay inside that directory; temp files cleaned up; retention/cleanup command documented. `Content-Disposition` file names are sanitized (no illegal Windows characters, length-limited).
- Don't block the event loop: plain `def` routes or background workers for long work.
- Global exception handler → standard error JSON; stack traces only in server logs. **Standard error format:** `{"error": {"code": "...", "message": "...", "details": ...}}`, including 422s remapped with field-level details.
- **List endpoints** support pagination (`limit` default 25, max 100; `offset`), search/filter parameters where useful, and request bodies have size limits.
- **Duplicate-submission protection:** create/start endpoints accept an `Idempotency-Key` header; a repeated key within 24 h returns the original response instead of creating a second record or execution (stored in the database). The frontend sends a fresh key per user action and also disables the control while a request is in flight — but correctness never relies on the frontend alone.
- **Logging:** structured, request IDs, log rotation; do not log full briefs, crawled page bodies, or secrets (log IDs and sizes).

### 2.3 Job engine: persisted state machine, claiming, cancellation, retry

Applies to **every** AI-invoking or crawling operation in all modules: campaign executions, funnel executions, SEO audits, website reports, blog batches, social generation, and scoped re-generation of a single output (which runs as a small scoped execution). The engine is an in-process worker pool with job state persisted in SQLite; the UI polls real status endpoints (1–2 s; stops on terminal state and on unmount).

**Execution record fields** (shared `Execution` base or per-module tables with identical semantics): `id`, `parent_type`, `parent_id`, `scope` (`FULL` | `STAGE_RETRY` | `STAGE_REGENERATE` | `OUTPUT_REGENERATE` | `ITEM_RETRY`), `status`, `retry_of_execution_id`, `attempt_number` (lineage count), `claimed_by` (worker id), `claim_token` (UUID), `claimed_at`, `heartbeat_at`, `cancel_requested`, `error_code`, `error_message` (sanitized), `retryable`, `ai_calls_used`, `started_at`, `finished_at`, `row_version`.

**Job states are distinct from record lifecycle status.** Execution (job) states: `PENDING`, `RUNNING`, `COMPLETED`, `COMPLETED_WITH_WARNINGS`, `FAILED`, `CANCELLED`. A campaign's own status (`DRAFT`, `READY`, `RUNNING`, `COMPLETED`, `COMPLETED_WITH_WARNINGS`, `FAILED`, `CANCELLED`) is a **derived mirror** of its latest execution (or `DRAFT`/`READY` before any run) and is never written independently of it.

**Legal execution transitions (all others are rejected):**

| From | To | Trigger |
|---|---|---|
| (new) | `PENDING` | start request accepted |
| `PENDING` | `RUNNING` | worker claim (guarded atomic update) |
| `PENDING` | `CANCELLED` | cancel before claim |
| `RUNNING` | `COMPLETED` / `COMPLETED_WITH_WARNINGS` | final required output committed |
| `RUNNING` | `FAILED` | non-recoverable error, exhausted budget, stale heartbeat, max duration, restart recovery |
| `RUNNING` | `CANCELLED` | cancel observed before the point of no return |

**Stage/item states within an execution:** `PENDING`, `RUNNING`, `COMPLETED`, `FAILED`, `CANCELLED`, `SKIPPED`, `CARRIED_FORWARD`. Legal: `PENDING→RUNNING`, `PENDING→SKIPPED`, `PENDING→CANCELLED`, `RUNNING→COMPLETED|FAILED|CANCELLED`; `CARRIED_FORWARD` is an initial, terminal state for stages reused by a retry execution.

One module (`jobs/state_machine.py`) defines both tables. Every status write goes through it as a **guarded UPDATE** (`WHERE id=:id AND status=:expected [AND claim_token=:t]`); an illegal or lost-race transition raises `IllegalTransition`, is logged, is never applied, and surfaces as 409 where user-triggered. An exhaustive test iterates every (from, to) pair.

**Terminal immutability and retry (resolved):**
- A terminal execution row **never changes again** (status, timestamps, error fields, output references).
- A retry/regenerate request **creates a new execution** (`retry_of_execution_id`, `attempt_number + 1`, `scope` naming what to re-run). Stages that completed earlier and are still current are created as `CARRIED_FORWARD` rows that **reference** the original committed output version — no recomputation, no copying, no overwriting. Only failed/cancelled/pending/outdated stages and their dependents (per the module's dependency graph) are `PENDING`.
- A retry writes only to its own new rows and to new output versions; it never modifies unrelated records.
- **Staleness is not a job state.** `is_outdated` / `outdated_reason` live on the mutable **current-state records** (campaign stage state, funnel nodes/edges, content items); historical execution rows are never mutated to mark them outdated. The UI shows "COMPLETED + outdated" as "Outdated". Lineage (`retry_of`) is visible in history; the dashboard shows each parent's current execution.
- The one-active-execution rule is unaffected: a retry can only be created when the parent has no `PENDING`/`RUNNING` execution.

**Creation and claiming (transactionally safe):**
- One active execution per parent, enforced by the database: partial unique index on `(parent_type, parent_id) WHERE status IN ('PENDING','RUNNING')`. A duplicate start returns 409 `EXECUTION_ALREADY_ACTIVE` regardless of frontend state.
- Creation is one transaction (execution row + initial stage rows). Queue depth is capped (`MAX_QUEUED_JOBS`); beyond it → 429 `QUEUE_FULL`.
- Workers claim with `UPDATE … SET status='RUNNING', claimed_by=:w, claim_token=:t, claimed_at=:now, heartbeat_at=:now WHERE id=:id AND status='PENDING'`, proceeding only if exactly one row changed. **Every later worker write includes `claim_token` and `status='RUNNING'` in its WHERE clause**; zero rows updated means the claim was lost (stale-job recovery, cancellation) — the worker discards its in-flight result and stops. A job can therefore never be claimed or finalized twice.

**Heartbeats and stale detection (precise):** a heartbeat thread per worker updates `heartbeat_at` every `HEARTBEAT_INTERVAL_SECONDS` (default 5), independent of blocking AI/network calls. A watchdog runs every 15 s and marks `RUNNING` executions with `now − heartbeat_at > STALE_AFTER_SECONDS` (default 60; must exceed 3× the heartbeat interval) as `FAILED` (`STALE_HEARTBEAT`, retryable) using a guarded update that compares the observed `claim_token`. Executions exceeding `JOB_MAX_DURATION_SECONDS` (default 1800; per-module overrides) become `FAILED` (`TIMEOUT`, retryable). A stalled worker that later wakes fails its guarded writes and abandons the job. Tests use a fake clock.

**Commit boundaries:** each stage/item output **and** its status transition commit in **one transaction**; a stage is never `COMPLETED` before its validated output (and `OutputVersion`, 3.2) is committed. The execution becomes `COMPLETED`/`COMPLETED_WITH_WARNINGS` only in a final guarded transaction after the last required output is committed. A crash between stages leaves earlier stages committed and the execution recoverable.

**Cancellation and completion races (deterministic):** `POST …/cancel` is accepted only for `PENDING`/`RUNNING` (otherwise 409 with the current state) and sets `cancel_requested`. Decision points (before claiming each stage/item, after each AI call/fetch returns, and at finalization) run in `BEGIN IMMEDIATE` transactions so SQLite serializes them. **The point of no return is the commit of the last required output**: if cancellation is observed before that commit, the in-flight result is discarded, the stage becomes `CANCELLED`, the execution `CANCELLED`, and previously committed outputs are preserved (marked partial where relevant); if the final commit wins, the execution completes and the cancel request gets 409 `ALREADY_COMPLETED`. Cancelling never leaves an execution `RUNNING`.

**Failure classification:**
- **Retryable:** provider timeouts, 429/5xx, transient network errors, transient SQLite lock errors, fetch timeouts, stale heartbeat, restart interruption, AI-call budget exhaustion.
- **Non-retryable (fail immediately with a "what to change" hint):** validation errors, invalid/missing credentials (401/403), invalid structured output after the single repair attempt, SSRF/URL-policy rejections, budget/date inconsistencies, programming errors.
- **Retry budget:** automatic retries exist **only** at the provider-call layer and are bounded by the per-stage and per-execution AI-call budgets in 3.4; there are **no** automatic stage-level or job-level re-queues. Manual retries are user-initiated, create a new execution with a fresh call budget, and are capped by `JOB_MAX_ATTEMPTS` (default 5) per stage lineage, after which the UI tells the user to change inputs or provider.
- Failing one stage/item never discards other committed outputs.

**SQLite contention:** WAL mode, `busy_timeout` 5000 ms, short transactions, **no write transaction held across any AI call, fetch, or file generation**, bounded retry with backoff on `database is locked`; persistent lock failure surfaces as a retryable error, never a silent loss. Each worker thread uses its own SQLAlchemy session.

**Timeouts and cleanup:** per-AI-call timeout (`AI_TIMEOUT_SECONDS`), per-fetch timeouts, max job duration, bounded `WORKER_CONCURRENCY` (default 2), temp-resource cleanup in `finally`.

**Frontend:** displays only persisted state from the API. After a start request it shows `PENDING` until the backend reports `RUNNING`; it never infers or fabricates terminal states.

**Restart recovery:** see 2.6.

### 2.4 Database migrations (Alembic from the beginning; copy–verify–migrate–verify–swap)

SQLite caveats this design respects: DDL is transactional but Alembic's `batch_alter_table` recreates tables (foreign keys must be handled), not every change is reversible, and file-level copies of a WAL-mode database are unsafe unless done through SQLite's backup API.

- **Setup:** `alembic.ini`, `alembic/env.py` bound to the app metadata with a constraint **naming convention**, `render_as_batch=True`. Revisions are linear (single head; a test fails if multiple heads exist) and tracked in `alembic_version`. Phase 1 creates the baseline; every schema-changing phase adds a revision. `create_all` is never used on an existing database.
- **Where migrations run:** only during startup *after* the startup lock (2.6) is held and *before* workers start, or via `scripts/migrate` (same code path). `AUTO_MIGRATE=false` makes startup refuse to run with pending migrations and print the explicit command.
- **Procedure for an existing, non-empty DB with pending revisions:**
  1. **Disk-space check:** require free space ≥ 2 × DB size + `MIN_FREE_DISK_MB`; otherwise abort with an actionable message — nothing has been changed.
  2. **Backup** using SQLite's online backup API (not a raw file copy) to `backend/data/backups/flowsynapse_<timestamp>_pre_<revision>.db` plus a manifest (source revision, SHA-256, per-table row counts, size).
  3. **Verify the backup:** open it read-only; `PRAGMA integrity_check` returns `ok`; schema revision and per-table row counts equal the source. If verification fails → abort; do not migrate.
  4. **Migrate a working copy** (`flowsynapse.db.migrating`, created via the backup API), never the live file. With `PRAGMA foreign_keys=OFF` during batch table recreation, then `PRAGMA foreign_key_check` after.
  5. **Verify the migrated copy:** `PRAGMA integrity_check` = `ok`; `foreign_key_check` empty; revision = head; **row counts of every pre-existing table equal the pre-migration counts** unless the migration explicitly declares an intentional change (declared in the revision's metadata and asserted by its test); required constraints/indexes exist (including the partial unique index in 2.3).
  6. **Swap atomically:** with no open connections, `os.replace` the verified copy over the live DB (original retained as the verified backup). Then run the schema-drift check.
  - **Any failure at any step:** delete the working copy, leave the original database **byte-identical** (asserted by checksum in tests), exit with a non-zero code and a message stating the failing step, the original error, the backup location, and the exact recovery command. **Never** delete or recreate the database, never "fix" a failure by resetting data, and never claim the original is intact unless this procedure was executed (the tests below verify it).
- **Startup rules:** if `alembic_version` is **newer** than the code's head (or unknown) → refuse to start, change nothing, and say to upgrade the code or restore a backup. Leftover `*.migrating` files from an interrupted run are removed on the next start and never mistaken for a database. A fresh/empty DB runs `upgrade head` directly (no backup needed).
- **Restore:** `scripts/restore_backup <file>` verifies the backup (integrity + manifest), copies the *current* DB to a safety backup first, then swaps — documented in the README and tested.
- **Schema-drift detection:** a test and a startup self-check compare model metadata with the migrated schema (Alembic autogenerate yields no diff); drift is reported, not auto-fixed.
- **Retention:** keep the 5 most recent backups (never delete the newest verified one).
- **Downgrades are not supported** (documented). Backups are the rollback mechanism.
- **Tests (run in every schema-changing phase gate):** fresh create; upgrade from **each** earlier-phase committed snapshot with seeded rows → rows and key-column checksums preserved, FK check clean; idempotent re-run; injected failing migration → original checksum unchanged and working copy removed; injected backup-verification failure → no migration attempted; simulated insufficient disk → abort with no change; newer-revision DB refused with no change; interrupted-run leftover cleanup; restore script round-trip; multiple-heads detection; drift check.

### 2.5 Idempotency and duplicate submissions (database-enforced)

`POST` endpoints that create records or start executions accept an optional `Idempotency-Key` header (1–128 chars, `[A-Za-z0-9._:-]`). The frontend sends a fresh UUID per user action; correctness never depends on the frontend.

- **Storage:** table `idempotency_keys`: `id`, `key`, `scope` (HTTP method + route template, e.g., `POST /api/campaigns/{id}/executions`, plus the path parameters), `operation`, `request_fingerprint`, `state` (`IN_PROGRESS` | `COMPLETED`), `response_status`, `response_body` (JSON, size-capped), `resource_type`, `resource_id`, `created_at`, `expires_at` (= created + 24 h). **Unique constraint on `(scope, key)`.**
- **Fingerprint:** SHA-256 of the canonical JSON (sorted keys, normalized numbers/strings, volatile fields excluded) of the request body + path parameters + relevant query parameters.
- **Flow (one transaction around the operation):** insert the key row as `IN_PROGRESS`; perform the operation; on success store `response_status`/`response_body`/resource ref and set `COMPLETED` **in the same transaction as the resource creation**, so a replay returns exactly what was created.
- **Repeated key, same fingerprint, `COMPLETED`, not expired** → return the stored response with header `Idempotent-Replayed: true` (no new work).
- **Same key, `IN_PROGRESS` (concurrent request)** → 409 `IDEMPOTENCY_IN_PROGRESS` with `Retry-After: 1`; the unique constraint guarantees exactly one request proceeds.
- **Same key, different fingerprint** → 422 `IDEMPOTENCY_KEY_REUSED`; nothing is created and the stored response is not returned.
- **Failed requests:** only 2xx/202 outcomes are stored. A request that fails (4xx validation, 5xx, lost race) rolls back its key row, so the client can fix the payload and retry with the same key. An `IN_PROGRESS` row older than the job-creation timeout (5 min; crash) is reclaimable.
- **Interaction with retries and the one-active-execution rule:** a manual retry is a different operation with its own scope/key (the UI generates a fresh key per click); the same key replays the original retry response. A new key while an execution is active still gets 409 `EXECUTION_ALREADY_ACTIVE` (2.3) — the key table never overrides that rule.
- **Expiry and cleanup:** rows with `expires_at < now` are treated as absent (replaced atomically on reuse). A cleanup task at startup and hourly deletes expired rows in batches of ≤ 500 per transaction, never `IN_PROGRESS` rows younger than the timeout. A missing header means the request is processed without idempotency (start endpoints are still protected by 2.3).
- **Tests:** replay returns the identical response and creates nothing; concurrent same-key requests (parallel) → one success, the rest 409/replay; different payload → 422; failed request frees the key; expiry (fake clock) and cleanup safety; key reuse across different scopes is independent; retry with a new key vs the same key.

### 2.6 Process model: single process, startup order, lock, and shutdown

The local release is a **single-process** backend with an in-process worker pool. No distributed or multi-process job reliability is claimed or implemented (no extra database or queue service).

**Startup order (any failure aborts startup safely with a clear message; workers never start before step 6):**
1. Load and validate configuration (invalid provider config is reported, not fatal).
2. **Acquire the exclusive process lock** `backend/data/flowsynapse.lock` using an OS-level advisory lock held for the process lifetime (`fcntl.flock` on POSIX, `msvcrt.locking` on Windows, or a pinned pure-Python equivalent); write PID, start time, and port into it. If the lock is held: exit with "Another FlowSynapse backend (PID n) is using this database."
3. Disk-space check; run the safe migration procedure (2.4) **under the lock**.
4. Initialize the database engine (WAL, pragmas, partial indexes verified).
5. **Recovery:** `RUNNING` executions (any claim token from a previous process) and executions with stale heartbeats → `FAILED` (`INTERRUPTED`, retryable, "Interrupted by restart"). Completed stage/item outputs are preserved. **`PENDING` executions that were never claimed remain `PENDING`** and are eligible for normal claiming once startup succeeds. An interrupted in-flight AI request is **never resumed or assumed to have completed**; its stage is re-run by an explicit retry. The UI shows interrupted work with its preserved stages and a Retry action (which creates a new execution, 2.3).
6. Start worker pool and watchdog; start the idempotency/export cleanup tasks; begin serving requests; `/api/health` reports `status: ok` only now.

**Stale-lock recovery:** OS-level locks are released automatically when a process dies, so a leftover lock *file* with no held lock is safe to acquire. Never delete or "steal" a lock held by a live process, and never rely on PID inspection alone.

**Controlled shutdown (SIGINT/SIGTERM, Windows Ctrl+C/Ctrl+Break, and the start script):** stop accepting new jobs; set `shutdown_requested`; request cancellation of active executions; wait up to `SHUTDOWN_GRACE_SECONDS` for workers to reach a boundary (their committed outputs are preserved, in-flight results discarded); mark any still-`RUNNING` execution `FAILED` (`INTERRUPTED`, retryable) with guarded updates; close sessions, run `PRAGMA wal_checkpoint(TRUNCATE)`, release the lock. A hard kill is handled by the next startup's recovery (step 5).

**Workers:** bounded by `WORKER_CONCURRENCY`; each uses its own SQLAlchemy session; no write transaction is open across AI/network/file calls (tested by performing a write from a second connection during a slow mock provider call and asserting it succeeds immediately).

**Tests:** second-instance refusal; lock released after clean exit and after kill; stale lock file without a held lock is acquired; startup aborts without starting workers if migration fails; recovery marks `RUNNING`→`FAILED/INTERRUPTED` and leaves `PENDING` claimable and completed stages intact; interrupted AI call not resumed; controlled-shutdown sequencing and WAL checkpoint; no write transaction across provider calls.

### 2.7 Export reliability

- Exports read **committed, persisted data inside a single read transaction** (WAL snapshot), so the file is internally consistent even if edits occur during generation. The export row records the source `content_version` / `graph_version` and the `source_versions` map (output → version id); the UI shows "Export from version N (current: M)".
- Lifecycle: `FileExport` row `PENDING` → `COMPLETED` | `FAILED` | `COMPLETED_WITH_WARNINGS`. A failed export **never reports success** and leaves no file (generate to a temp file in the export directory, then `os.replace` into its final server-generated unique name `{module}_{id}_{timestamp}_{uuid8}.{ext}`; temp files removed in `finally`). A data-table failure fails the export; a non-essential element failure (e.g., a chart) may produce `COMPLETED_WITH_WARNINGS` with a visible "Section unavailable: reason" in the file — never a silently partial file.
- Paths: user-controlled strings never form paths; resolved paths are asserted to stay inside `backend/data/exports/`. `Content-Disposition` uses sanitized names (RFC 5987 `filename*` for non-ASCII).
- Safety and rendering: formula-injection neutralization (XLSX/CSV), XML-escaped PDF text, wrapping of long text/URLs, graceful empty datasets, tested `₹`/"INR" fallback, SVG text escaped; demo exports carry the demonstration banner.
- Concurrency: unique file names per export; concurrent exports never overwrite each other.
- Retention: delete exports older than `EXPORT_RETENTION_DAYS` (default 7) at startup and daily, **skipping** files accessed within the last 10 minutes (`last_accessed_at`) or referenced by a non-terminal export row; deletion failures (e.g., Windows file in use) are logged and retried next run. A download of a purged export returns 410 with a "regenerate" action.
- Local filesystem only; no storage service.
- Tests: failed export leaves no file and a `FAILED` row; interrupted generation cleans temp files; path-traversal names; concurrent exports; retention skips recently accessed files; snapshot consistency with a concurrent edit; empty dataset; very long text/URL; demo banner.

---

## 3. AI PROVIDER ARCHITECTURE

`backend/app/ai/`: `base.py`, `mock_provider.py`, `ollama_provider.py`, `gemini_provider.py`, `factory.py`, `schemas.py`. Selected by `AI_PROVIDER` = `mock` | `ollama` | `gemini`.

- **MockProvider:** deterministic and offline. Returns realistic **structured** outputs per workflow stage, built from the user's actual input fields (parameterized templates — never hard-coded to the demo business). Supports failure injection (a configurable trigger token or test hook), simulated timeouts, and invalid-structure injection for tests. All output is labelled mock.
- **OllamaProvider:** `OLLAMA_BASE_URL` (default `http://localhost:11434`), `OLLAMA_MODEL`; timeouts; detects "not running", "model missing", timeout; actionable errors. No key. Works without a hosted provider **provided the model is already installed locally**.
- **GeminiProvider:** only when `GEMINI_API_KEY` and `GEMINI_MODEL` are set; handles 401/403/429/5xx/timeouts; never logs the key. Follow the provider's current documented interface — verify it rather than relying on memory. Requires network access and may incur charges; docs say so.
- **Structured output:** every AI response is parsed into a Pydantic schema before saving. On invalid output: one bounded repair attempt (re-prompt with the validation error), then fail the stage/item with a clear message. Never trust model-generated arithmetic, dates, enum/status values, or character counts — recompute/validate deterministically.
- **Untrusted text:** user briefs, website content fetched by the crawler, and reference material are **data, not instructions**. Prompts must delimit them and instruct the model to ignore instructions inside them. Tests include a fixture page containing a prompt-injection string and assert that output schema/validation is unaffected.
- **Provider selection and switching:** the active provider is a global setting, and each execution **records the provider/model/is_mock it used**. The app never switches providers on its own. If a hosted provider fails: record the failure (no secrets), apply timeouts and rate-limit handling, offer controlled retry, preserve successful stages, and let the **user** explicitly choose to re-run with mock mode (clearly labelled). Results from different providers within one execution are individually labelled.
- **Every generated record stores `provider`, `model` (if any), and `is_mock`.** The UI shows the provider on every result and a visible "Demo/Mock mode — not real AI output" label when applicable. Mock output is never called AI-generated.
- Settings page: active provider, "Test provider" (real health check), status.
- `backend/.env.example` (placeholders only): `AI_PROVIDER=mock`, `GEMINI_API_KEY=`, `GEMINI_MODEL=`, `OLLAMA_BASE_URL=http://localhost:11434`, `OLLAMA_MODEL=`, `DATABASE_URL`, `CORS_ORIGINS`, `HOST=127.0.0.1`, `ALLOW_LAN=false`, `APP_TIMEZONE=Asia/Kolkata`, `ALLOW_PRIVATE_TARGETS=false` (tests only), `ALLOW_DEMO_SITE=false`, `DEMO_SITE_PORT=8765`, `PROVIDER_MAX_ATTEMPTS=3`, `STAGE_AI_CALL_BUDGET=4`, `EXECUTION_AI_CALL_BUDGET=` (default derived: 6 × stages), `JOB_MAX_ATTEMPTS=5`, `FETCH_MAX_ATTEMPTS=2`, `WORKER_CONCURRENCY=2`, `MAX_QUEUED_JOBS=20`, `HEARTBEAT_INTERVAL_SECONDS=5`, `STALE_AFTER_SECONDS=60`, `JOB_MAX_DURATION_SECONDS=1800`, `SHUTDOWN_GRACE_SECONDS=15`, `MAX_BODY_BYTES=2000000`, `EXPORT_RETENTION_DAYS=7`, `MIN_FREE_DISK_MB=200`, `AUTO_MIGRATE=true`, `SEO_MAX_DEPTH=5`, `SEO_MAX_PAGES_LIMIT=200`, `AI_TIMEOUT_SECONDS`, `LOG_LEVEL=INFO`.
- The app starts if `.env` is missing or provider config is invalid (error shown in Settings and on affected tasks, not a crash).
- Secrets only in `backend/.env`; `.env` git-ignored; never in the frontend, logs, tests, examples, screenshots, or ZIPs.
- Docs: hosted free tiers/quotas/models can change and must be verified by me; never claim a provider is free without that caveat.
- **AI output is never executed** as code or commands.

### 3.1 Local mode and external dependencies (accurate claims only)
| Operation | Network needed? | Notes |
|---|---|---|
| App start, UI, database, exports | No | Local only |
| Mock-provider generation (all modules) | No | Deterministic, labelled mock |
| Ollama generation | No (hosted), but model must already be installed and Ollama running | Local resources required |
| Gemini generation | Yes | May incur charges; quotas change |
| Crawling a public website (SEO, Website report) | Yes | Fails with an actionable error if offline |
| Crawling the bundled local demo site | No (loopback) | Requires `ALLOW_DEMO_SITE=true`, which allowlists **only** `127.0.0.1:DEMO_SITE_PORT` and nothing else |
| Optional integrations (Search Console, PageSpeed, ad platforms, social APIs) | Yes | Separate, optional, need configuration |
| Demo data | No | Seeded synthetic data supports offline demos |

Do not claim every operation works offline. When an operation needs the network and it is unavailable, show an actionable error and **never report a successful analysis if the crawl did not complete** (incomplete crawls are marked `FAILED` or `COMPLETED_WITH_WARNINGS` with the exact scope actually covered).

### 3.2 Output provenance and versioning

Use one shared, maintainable mechanism rather than per-module duplicates: an `OutputVersion` table (plus thin helpers in `services/content/versioning.py`) referenced by every generated or editable output (campaign stage outputs, concepts, ad assets, social items, funnel nodes/edges content, blog drafts, website-report recommendations, SEO triage notes).

`OutputVersion` fields: `id`, `output_type`, `output_id`, `version_number`, `is_active`, `content` (JSON), `origin` (`AI_GENERATED` | `MOCK_GENERATED` | `MANUALLY_EDITED` | `REGENERATED`), `provider`, `model`, `is_mock`, `generated_at`, `execution_id`, `stage_key` or `item_id`, `source_input_version` (parent `content_version` or input hash at generation time), `previous_version_id`, `original_generation_version_id` (the AI/mock version an edit descends from), `edit_summary`, `created_at`. The output row holds `active_version_id` (and may denormalize the active content for queries).

Rules:
- **Generation** creates version 1 with full provenance (provider, model, is_mock, timestamp, execution, stage/item, source-input version).
- **Manual edit** creates a new version with `origin=MANUALLY_EDITED`, keeps `original_generation_version_id` so the **original generation provenance is preserved**, records an edit summary, sets content status per 4.1, and marks dependent outputs outdated per the relevant dependency graph. The UI shows "AI-generated, edited by you" (or "Mock-generated, edited by you") — never "raw AI output" for edited content.
- **Regeneration** creates a new version (`origin=REGENERATED`) with the new provider/model/is_mock, switches `is_active`, and **keeps prior versions**. The user can view version history and **restore** an earlier version (restore creates a new version copying the old content, so history is never rewritten).
- Per-stage provider provenance is recorded; results from different providers in one execution stay individually labelled and are never silently mixed.
- Retention: keep at least the last `OUTPUT_VERSIONS_KEEP` (default 20) versions per output, but never delete the original generation version or the active version.
- Exports state the origin and provider of each output and flag manually edited content.
- Tests: see 15.15.

### 3.3 Offline demonstration mode (all six modules)

All six modules are demonstrable without a hosted AI API key. Mock mode explores the core workflow of every module; it is **not** a claim that everything works offline (see 3.1).

| Module | Demo scenario (synthetic; assumptions labelled `DEMO ASSUMPTION`) |
|---|---|
| 1 Campaign | Be Well Hospitals orthopaedic-consultation brief (5.1) |
| 2 Funnel | Be Well consultation-booking funnel (template `consultation_booking`), optionally linked to the demo campaign |
| 3 SEO | A real crawl of the **bundled synthetic demo site** (`demo_site/`, a small deliberately imperfect multi-page clinic-style site) served locally by `scripts/serve_demo_site.py` |
| 4 Website | The same bundled demo site, assessed for structure/navigation/conversion paths |
| 5 Blog | Five demo topics, one containing the failure-injection token to demonstrate failed-only retry |
| 6 Social | Be Well social calendar over the demo campaign dates with the default cadence |

Requirements:
- Mock outputs are generated **from the user's actual inputs**, validated by the **same Pydantic schemas and validators** and passed through the **same pipeline** (parsing, persistence, QA, exports) as real-provider output. Mock output is always labelled; never described as real AI.
- Demonstration executions and outputs are **persisted** and can be reopened; exported demo reports carry a "DEMONSTRATION DATA" banner and the mock/provider label.
- **Repeatable failure injection:** the mock supports (a) tokens in inputs (`[fail]`, `[timeout]`, `[invalid]`) and (b) a test-only deterministic failure plan (e.g., `MOCK_FAIL_PLAN='{"META_ADS": {"fail_attempts": 1}}'`) with resettable per-process counters, so retry/recovery tests are repeatable.
- **Demo-data loading is idempotent** (stable demo keys; loading twice creates no duplicates). **Removing demo data deletes only `is_demo=true` records and their own children** — never real records; a test creates real records, loads and removes demo data, and asserts real records and their versions remain. If the user edits a demo record, it stays labelled demo unless they choose "Keep as my own" (sets `is_demo=false`).
- **No simulated crawling:** SEO/Website demo data comes from a **real crawl** of the bundled demo site through the normal crawl pipeline (the seed script starts the demo server, crawls, and persists). If the crawl cannot run (e.g., port blocked, `ALLOW_DEMO_SITE` unset), no demo audit is created and the UI says so. Never ship pre-fabricated findings presented as observed facts.

### 3.4 Retry budget and provider health checks

- **Layers and budget (no multiplication):** the only automatic retry layer is the provider call. A single stage execution may issue at most `STAGE_AI_CALL_BUDGET` (default 4) provider requests in total, covering up to `PROVIDER_MAX_ATTEMPTS` (default 3) attempts for transient failures (timeouts, 429, 5xx, network) with exponential backoff and jitter (honoring `Retry-After`), **plus at most one repair request** for invalid structured output; the repair request is not itself retried beyond the remaining budget. An execution is additionally capped by `EXECUTION_AI_CALL_BUDGET`. Exhaustion fails the stage with `AI_BUDGET_EXHAUSTED` (retryable by a manual retry that gets a fresh budget). Manual retries (2.3) are capped by `JOB_MAX_ATTEMPTS` per lineage. Crawler fetches use their own `FETCH_MAX_ATTEMPTS` (default 2) per URL.
- `ai_calls_used` is recorded on each execution/stage; the budget is enforced centrally in the provider wrapper (not per-provider) so Mock, Ollama, and Gemini behave identically. **Tests** count provider calls with a counting mock under worst-case failure plans and assert the hard cap.
- **Selection and switching:** the provider is chosen explicitly (global setting); the app never switches silently, and an execution that started on one provider keeps it. Switching providers mid-lineage is a user action recorded in provenance (3.2).
- **Health checks** (`POST /api/settings/test-provider`) never trigger generation: Mock is instant; Ollama calls its model-listing endpoint and checks the configured model is present; Gemini uses a model-metadata/list call. If a provider offers no free metadata call, the check requires explicit user confirmation, uses a minimal-length request, is labelled as such, and is rate-limited (min 10 s between checks). Results are cached for 30 s.
- **Credentials and errors:** invalid configuration yields `PROVIDER_CONFIG_INVALID` with a fix hint; credentials never appear in API responses, logs, exceptions, URLs (some providers accept keys as query parameters — a log/exception redaction filter masks keys and `key=` query values), or the frontend. Provider errors are sanitized before storage and display. **Test:** inject a recognizable fake key, force every provider error path, and assert the key appears nowhere in responses, logs, or the database.

### 3.5 Versioning integrity (extends 3.2; keep it simple — versioned rows, no event sourcing)

- **Constraints:** `UNIQUE(output_type, output_id, version_number)`; a **partial unique index** `(output_type, output_id) WHERE is_active = 1` so exactly one active version exists; CHECK constraints on `origin`; foreign keys to the parent record and execution; `parent_type/parent_id` stored so every version belongs to the correct parent. `version_number` is assigned inside a `BEGIN IMMEDIATE` transaction as `max + 1`.
- **Optimistic concurrency:** each editable output exposes its active version number as an `ETag`; `PATCH`/`regenerate` requires `If-Match` (or `expected_version` in the body). A mismatch returns 409 `VERSION_CONFLICT` including the current version so the UI can reload or reapply — edits never silently overwrite newer changes.
- **Failed regeneration never destroys the last valid version:** a new version becomes active only after its output has been schema-validated and committed (insert + activate in one transaction); on failure the previously active version is untouched and the failure is recorded on the execution.
- **No-op edits** (normalized content identical to the active version) create no version and invalidate nothing. Dependents are invalidated **only when the active version of an output changes**, per the module's dependency graph.
- **Exports** read a consistent snapshot (2.7) of the selected active versions and record their version ids.
- **Tests:** one-active-version constraint violation is rejected by the database; concurrent edits (one wins, one gets 409); failed regeneration keeps the old active version; restore creates a new version; no-op edit invalidates nothing; export records version ids; orphan versions impossible (FK).

### 3.6 Demo-data integrity and cleanup

- Demo records carry `is_demo=true`; **children of a demo parent are demo and children of a real parent are never demo** (validator + test). Seed keys are stable so reloading is idempotent.
- **Removal** computes the set of demo roots and deletes them **with their own descendants only**, in one transaction, by explicit ID set — never by pattern or by module-wide delete. If any **non-demo** record references a demo record (e.g., a user-created funnel with `source_campaign_id` pointing at the demo campaign, or a website-report context snapshot), removal is refused with 409 listing the dependents, offering "Keep as my own" (sets `is_demo=false` on that demo record and its descendants) or "Detach the reference".
- The UI distinguishes demo from real data everywhere (badge, list filter All/Mine/Demo). Dashboard counts exclude demo records by default with an "Include demo data" toggle that is clearly labelled.
- Demo outputs come from the real workflow (mock provider through the normal pipeline); demo SEO/Website records come from an actual crawl of the bundled synthetic site (3.3). No real patient or personal information exists in any demo data.
- **Tests:** seed twice (no duplicates); remove with real records present (all real records, their versions and exports remain); refusal path with a real dependent; "Keep as my own" path; demo/real parent-child invariant; dashboard exclusion toggle.

---

## 4. SHARED APPLICATION FEATURES

- **Dashboard:** Campaign Intelligence is the first, largest card with the primary call to action ("Create Campaign"); the Funnel Builder is second; the remaining four follow in catalogue order. Cards show **real** data only (database counts, recent actual executions). Empty states guide the user to the first action. No fabricated metrics.
- Sidebar in the same order; active-route highlight; collapses on mobile.
- Shared components: `StatusBadge`, `StageTimeline`, `EmptyState`, `ErrorBanner`, `Spinner`, `DataTable`, `ConfirmDialog`, `Toast`, `ProviderBadge`, `DownloadButton`, `DemoBadge`, `ContentStatusControl`.
- **Execution history:** a generic `WorkflowRun` log written by each module for real operations (module, parent id, status, provider, timestamps); filterable list on the dashboard.
- **Draft saving, editing, validation** are generic capabilities used by all modules.
- **Demo data:** per Section 3.3 — idempotent seeding via `scripts/seed_demo_data.py` and Settings buttons; all demo records `is_demo=true` with a visible badge; exports labelled; removal touches only demo records; synthetic data only, no real patient or personal information.
- Accessible (labels, keyboard operable, contrast) and responsive (360 px to 1440 px).
- No notification service exists unless a feature genuinely needs one; transient feedback uses toasts.

### 4.1 Shared content status model
Used by social items, blog drafts, campaign social items, and funnel node content. These are **content states, not an approval system** (single-user; "review" means the user's own review).

States: `DRAFT`, `READY_FOR_REVIEW`, `NEEDS_REVISION`, `READY_TO_EXPORT`.

Allowed transitions (anything else → 409 `INVALID_STATUS_TRANSITION`; implement in one module and unit-test every allowed and disallowed pair):

| From | To |
|---|---|
| `DRAFT` | `READY_FOR_REVIEW` |
| `READY_FOR_REVIEW` | `NEEDS_REVISION`, `READY_TO_EXPORT`, `DRAFT` |
| `NEEDS_REVISION` | `DRAFT`, `READY_FOR_REVIEW` |
| `READY_TO_EXPORT` | `NEEDS_REVISION`, `DRAFT` |

Editing content in `READY_FOR_REVIEW` or `READY_TO_EXPORT` resets it to `DRAFT` (recorded in history). Generation/execution status is a **separate field** (`PENDING`, `RUNNING`, `COMPLETED`, `FAILED`) and staleness is a separate boolean `is_outdated`. Exports include the content status; items not `READY_TO_EXPORT` produce a non-blocking QA warning. No status means "published" or "scheduled".

---

## 5. PRIORITY 1 — AI MARKETING CAMPAIGN INTELLIGENCE ENGINE (FLAGSHIP)

**Objective:** transform a campaign brief into a structured, reviewable, validated, downloadable campaign pack through an orchestrated, observable, multi-stage workflow. Not a single text-generation call. Own data model, logic, API, UI, validation, tests, and deliverables.

### 5.1 Demonstration scenario and demo brief
Business **Be Well Hospitals**; objective **generate orthopaedic consultation leads**; location **Selaiyur, Chennai, Tamil Nadu, India**; **total proposed paid-media budget ₹15,000**; **14 days**; paid channels **Google Ads** and **Meta Ads**; organic: **social media**. Synthetic only: no campaign launched, no patient contacted.

The "Load demo brief" button and the test fixture populate **every required field** (Section 5.2). Real-world details that are not known are filled with clearly labelled `DEMO ASSUMPTION` values, never presented as facts about the business:

| Field | Demo value |
|---|---|
| Business name | Be Well Hospitals |
| Industry | Healthcare — hospital / orthopaedics |
| Business description | `DEMO ASSUMPTION:` Multi-speciality hospital offering orthopaedic consultations in Selaiyur, Chennai |
| Location | Selaiyur, Chennai, Tamil Nadu, India |
| Primary service | Orthopaedic consultation |
| Value proposition | `DEMO ASSUMPTION:` Convenient local access to orthopaedic consultation and clear next steps |
| Campaign name | Be Well Orthopaedic Consultation — Demo |
| Objective | Generate orthopaedic consultation leads |
| Primary conversion goal | Consultation enquiry (form submission or phone call) |
| Start / end date | Fixed in tests: 2026-11-02 → 2026-11-15 (inclusive, 14 days). UI button: next Monday from today → +13 days |
| Duration | 14 days (consistent with dates) |
| Total paid-media budget / currency | 15000 / INR |
| Ad channels | Google Ads, Meta Ads |
| Organic channels | Instagram, Facebook (social) |
| Language / tone | English; professional and reassuring |
| Target geography | Selaiyur and surrounding Chennai areas |
| Audience description | Adults seeking information about joint pain, orthopaedic consultation, or mobility problems |
| Offer / service details | `DEMO ASSUMPTION:` Orthopaedic consultation enquiry; availability and fees to be confirmed by the hospital |
| Call to action | Book a consultation |
| Contact / conversion method | `DEMO ASSUMPTION:` Enquiry form or phone call |
| Landing page | `https://example.com/orthopaedic-consultation` (`DEMO PLACEHOLDER`, reserved example domain) |
| Approved claims | `DEMO ASSUMPTION:` "Orthopaedic consultations available in Selaiyur, Chennai" |
| Prohibited claims | Guaranteed relief or cure; "best"/"No.1" superlatives; before/after promises; invented doctors, credentials, prices, testimonials |
| Posting cadence | `every_n_days` n=2 (demo default) |

Every output record created from this brief carries `is_demo=true` and the demonstration label. The user can substitute any business/brief with **no source changes**.

**Healthcare responsibility rules** (when industry is healthcare/medical — detected by a configurable keyword list with a user-visible, user-overridable `is_healthcare` flag — enforced by prompt constraints **and** a deterministic scanner): no guaranteed outcomes or cure claims; no unsupported medical claims; no fear-based targeting; no invented doctor names/credentials, prices, testimonials, awards, or statistics; no "suitable for everyone" claims; no before/after promises; do not request or process patient health information. Risky phrases come from a configurable list and produce review findings. Always show: platform healthcare-advertising policies and local regulations must be reviewed by the user; generated ads are never described as compliant. The same scanner is reused by the Funnel Builder, Blog, and Social modules.

### 5.2 Campaign brief form
Required fields are marked `*`. Optional fields never block.

- **Business:** name*, industry*, description*, website URL, location*, service areas, primary service/product*, secondary services, value proposition, existing brand messaging.
- **Campaign:** name*, objective*, primary conversion goal*, secondary goals, **start date***, end date **or** duration* (see 5.7), **total paid-media budget***, currency* (default INR), paid channels* (`google_ads`, `meta_ads`), organic channels, language*, tone, competitors, existing campaign info, **social posting cadence** (Section 10; default provided).
- **Audience:** target geography*, age range, description*, needs/interests, problems, intent, exclusions/restrictions, existing research.
- **Offer & landing page:** offer/service details*, landing page URL, call to action*, contact/conversion method*, booking/enquiry method, approved claims, prohibited claims, brand guidelines, additional instructions.

Behavior: field-level hints; Save Draft and reopen later; edit before generation; changes after generation mark only the **affected** stages outdated (5.5). Missing critical info → blocking validation error; missing non-critical info → proceed with **labelled assumptions** recorded in the brief's assumptions list. Never silently invent facts about a real business.

### 5.3 Workflow stages (12, fixed keys and order)

| # | Stage key |
|---|---|
| 1 | `INPUT_VALIDATION` |
| 2 | `BRIEF_NORMALIZATION` |
| 3 | `OBJECTIVE_ANALYSIS` |
| 4 | `STRATEGY` |
| 5 | `CONCEPTS` |
| 6 | `GOOGLE_ADS` |
| 7 | `META_ADS` |
| 8 | `SOCIAL_PLAN` |
| 9 | `TRACKING_PLAN` |
| 10 | `BUDGET_ALLOCATION` |
| 11 | `QUALITY_ASSURANCE` |
| 12 | `PACK_GENERATION` |

Stage states (within an execution): `PENDING`, `RUNNING`, `COMPLETED`, `FAILED`, `SKIPPED`, `CANCELLED`, `CARRIED_FORWARD`. Execution (job) states: `PENDING`, `RUNNING`, `COMPLETED`, `COMPLETED_WITH_WARNINGS`, `FAILED`, `CANCELLED` — the campaign's own status (`DRAFT`, `READY`, then a mirror of its latest execution) is separate (2.3). Allowed transitions are defined once in `jobs/state_machine.py` and unit-tested exhaustively (illegal transitions raise). **Outdated** is a flag on the campaign's *current stage state*, not a job state. Each stage persists: input snapshot, validated JSON output, status, started/finished timestamps, duration, provider/model/is_mock, sanitized error code/message, attempt count.

**Stage 1 — `INPUT_VALIDATION` (deterministic).** Required fields; budget is a positive decimal within currency precision; duration/date consistency (5.7); dates parse; supported channels only; geography present; URLs well-formed (http/https); conversion goal present; contradictions flagged (e.g., channel selected with zero budget). Field-specific errors returned and rendered per field. **No later stage runs if blocking validation fails.**

**Stage 2 — `BRIEF_NORMALIZATION` (deterministic).** Normalized brief: ISO dates, derived `duration_days`, `Decimal` budget with currency code, channel identifiers, structured location (best-effort city/state/country; original preserved), trimmed/deduplicated lists. Original input preserved unchanged and viewable beside the normalized brief.

**Stage 3 — `OBJECTIVE_ANALYSIS`.** Primary business objective, marketing objective, desired conversion action, target service, geographic scope, audience characteristics/needs, main messaging opportunity, constraints, missing information, assumptions needing review. Every item tagged `source`: `user_provided` | `generated_suggestion` | `assumption`.

**Stage 4 — `STRATEGY`.** Campaign summary, primary/secondary objectives, positioning, core value proposition, messaging pillars, audience segments (with intent and needs), approach, **channel roles**, funnel stages, conversion journey, landing-page considerations, risks/constraints, measurement approach, key assumptions, next actions. Insights are labelled "proposed strategy based on supplied brief", never "verified research".

**Stage 5 — `CONCEPTS`.** Configurable count (default 3, range 1–6). Each concept: name, rationale, target segment, main message, value proposition, headline, supporting copy, CTA, creative direction, suggested visual composition, image/video format, landing-page message alignment, review notes. A deterministic similarity check flags near-duplicates (token-overlap threshold). Users can edit, keep, regenerate, or discard individual concepts.

**Stage 6 — `GOOGLE_ADS`.** Campaign naming, ad-group/theme suggestions, keyword themes with search intent, headlines, descriptions, display paths, CTAs, landing-page recommendations, negative keyword ideas, conversion-tracking requirements, policy/review warnings. **Configurable character limits** (defaults: headline ≤ 30, description ≤ 90, display path ≤ 15 per segment; docs state these must be re-verified against current Google Ads documentation). Over-limit assets are `INVALID` and cannot be marked ready. **Never invent** keyword volumes, CPCs, competition scores, or performance; keyword output is labelled "generated proposal, not platform research".

**Stage 7 — `META_ADS`.** Objective recommendation, audience strategy, primary text/headline/description variations, CTAs, creative concepts, image/video formats, creative brief, landing-page alignment, tracking requirements, review warnings. Distinct schema from Google (no reused copy). Configurable limits (documented as recommended lengths; verify against current Meta documentation). No claim of upload to Meta Ads Manager. No sensitive/personal-attribute targeting; copy must not imply knowledge of a person's health condition.

**Stage 8 — `SOCIAL_PLAN`.** Generated by the **shared social-content service** (Section 10) using the brief's cadence. Items per schedule slot: date/campaign day, platform, objective, theme, audience segment, format, caption, hook, CTA, hashtags, creative direction, campaign message, funnel stage, content status (4.1). The calendar **spans the full campaign period** according to the cadence; it does not require a post every day.

**Stage 9 — `TRACKING_PLAN`.** Primary/secondary conversions, conversion events, **UTM parameters** (campaign, source, medium, content, term where relevant) generated deterministically (lowercase slug, consistent separators, values percent-encoded via `urllib.parse`), full tagged URLs per channel/asset group from the landing-page URL (preserve existing query params; handle fragments), landing-page/form/call/booking tracking requirements, analytics events, tools, attribution considerations, data-quality checks, reporting cadence, implementation checklist. Labelled "generated plan — not verified or installed".

**Stage 10 — `BUDGET_ALLOCATION`.** Deterministic arithmetic (5.8); AI only drafts the rationale. Shows amount, percentage, rationale, assumptions, and daily figures per channel. Manual edit with immediate backend-validated recalculation. **Proposed allocation is not actual spend.** No invented leads, CPL, conversion rates, revenue, or forecasts; any illustrative estimate requires an explicit, labelled estimation model with stated assumptions, and is **off by default**.

**Stage 11 — `QUALITY_ASSURANCE`.** Deterministic checks (code, not AI): required sections present; objective consistency across channels; budget sum equals total; dates/duration consistency; CTA present; URL format; UTM correctness (re-parse and compare); calendar dates within period and consistent with cadence; duplicate content; required fields populated; character limits; unverified business facts presented as verified (compare against `approved_claims`/prohibited list); missing info flagged; health-claim scan (5.1); assumptions documented; content-status warnings (items not `READY_TO_EXPORT`); **no stale outputs** (5.5); export reflects latest edits. Optional AI semantic suggestions are labelled and never replace a deterministic rule.
Finding fields: `severity` (`BLOCKER` | `WARNING` | `INFO`), `category`, `description`, `evidence/field`, `recommended_correction`, `blocks_completion`. Export is blocked **only** by a blocking finding or stale outputs (5.5); otherwise the execution is `COMPLETED_WITH_WARNINGS`.

**Stage 12 — `PACK_GENERATION`.** Pack sections: 1 Executive summary, 2 Original brief, 3 Normalized brief, 4 Objectives, 5 Strategy & positioning, 6 Audience segments, 7 Messaging pillars, 8 Concepts, 9 Google Ads proposals, 10 Meta Ads proposals, 11 Social calendar, 12 Tracking & measurement plan, 13 Budget allocation, 14 Assumptions & limitations, 15 QA results, 16 Outstanding actions, 17 Recommended implementation sequence.
Exports: **PDF** (title page with campaign ID/date/provider/mock + demo labels, budget chart, tables, QA summary), **Excel** (sheets: Summary, Brief, Strategy, Concepts, Google Ads, Meta Ads, Social Calendar, Tracking & UTMs, Budget, QA Findings, Assumptions), **CSV** (per dataset via `dataset` param or a ZIP). All content comes from stored, latest-edited data. Each export stores a `CampaignExport` row (format, timestamp, content hash, campaign `content_version`, file path). Consistent campaign identifier on every output.

### 5.4 Campaign page and live-demo UX
Dedicated `/campaigns`: history list (status, provider, updated), "Create Campaign" primary action, brief form (Save Draft, Load demo brief, Validate, **Run Campaign Intelligence**), per-field validation, **stage timeline** driven by real stage states, current-stage detail, output preview per stage, sanitized errors, retry for a failed stage, cancel for a running execution, editable outputs (concepts, ad assets, calendar items, budget), per-output regenerate, QA summary, Download Pack (PDF/Excel/CSV), reopen saved campaigns. Progress = count of actually completed stages — no timers or fake percentages. Failed stage → completed stages keep outputs; retry re-runs only that stage; dependents become `OUTDATED` with an explanation. Provider/mock/demo badges on the execution.

### 5.5 Dependency graph and invalidation (explicit, not blanket)
`OUTDATED` below means `is_outdated=true` (with `outdated_reason`) on the campaign's **current stage-state record**; historical execution rows are immutable and never touched (2.3). Regeneration or retry creates a new execution whose `CARRIED_FORWARD` stages reference the still-current outputs.

Stage dependencies (a stage is *directly* affected by changes to its inputs; **transitive** staleness follows only these edges):

- `BRIEF_NORMALIZATION` ← all brief fields (deterministic; re-run automatically on save)
- `OBJECTIVE_ANALYSIS` ← business, industry, offer, audience, language, tone, claims, brand, competitors, existing info
- `STRATEGY` ← `OBJECTIVE_ANALYSIS`, **paid/organic channels**, geography
- `CONCEPTS` ← `STRATEGY`, CTA, contact method, approved/prohibited claims
- `GOOGLE_ADS` ← `CONCEPTS`, `STRATEGY`, landing URL, language
- `META_ADS` ← `CONCEPTS`, `STRATEGY`, landing URL, language
- `SOCIAL_PLAN` ← `STRATEGY`, `CONCEPTS`, **start date, end date/duration, cadence**, organic channels
- `TRACKING_PLAN` ← `GOOGLE_ADS`, `META_ADS`, landing URL, campaign name, channels
- `BUDGET_ALLOCATION` ← **budget, currency, duration, paid channels**, `STRATEGY` (channel roles)
- `QUALITY_ASSURANCE` ← every output stage (always re-run after any change)
- `PACK_GENERATION` ← `QUALITY_ASSURANCE` and all outputs (always regenerated after any change)

Examples (must be tested): changing **budget only** → `BUDGET_ALLOCATION`, `QUALITY_ASSURANCE`, `PACK_GENERATION` outdated; strategy, concepts, ads, social, tracking stay `COMPLETED`. Changing **duration/dates** → `BRIEF_NORMALIZATION` (auto), `SOCIAL_PLAN`, `BUDGET_ALLOCATION`, QA, pack. Changing **landing URL** → `GOOGLE_ADS`, `META_ADS`, `TRACKING_PLAN`, QA, pack. Editing a **concept** → `GOOGLE_ADS`, `META_ADS`, `SOCIAL_PLAN` (and via them `TRACKING_PLAN`), QA, pack. Editing a **social item** or **budget** by hand → QA, pack only.

Rules: record an `outdated_reason` (which input/output changed, when) on each affected stage and show it in the UI; unaffected outputs are preserved; outdated outputs stay visible with an "Outdated" badge but are **never presented as current**; eligible stages can be regenerated individually (the backend re-runs only requested stages and refuses a stage whose upstream stages are not current, with a clear 409); QA is re-run automatically after regeneration; the final pack always reflects the latest saved outputs; **export is blocked (409 `STALE_OUTPUTS`) while any output stage is `OUTDATED`**, unless the request passes `allow_stale=true`, in which case the export carries a visible STALE banner. Implement the graph as testable data, with a function `affected_stages(change)` covered by unit tests.

### 5.6 Data model (SQLAlchemy; consolidate or split if justified and documented)
`Campaign` (identifier UUID, status, `content_version` incremented on every saved change, `is_demo`), `CampaignBrief` (original JSON, normalized JSON, assumptions), `CampaignStrategy`, `CampaignConcept`, `ChannelAsset` (channel, asset_type, fields JSON, limit-validity), `SocialContentItem` (shared table/service model, Section 10), `TrackingPlan` (+ UTM rows), `BudgetAllocation` (+ per-channel rows), `CampaignExecution`, `CampaignExecutionStage` (incl. `outdated_reason`), `CampaignValidationFinding`, `CampaignExport`. For each: PK, FKs with cascade rules, typed fields, nullability, validation, `created_at`/`updated_at`, relationships, indexes (campaign_id, execution_id, status, stage_key), persistence behavior. Document the ER diagram in `docs/ARCHITECTURE.md`. All generated/editable outputs use the shared `OutputVersion` mechanism (3.2). Schema changes ship as Alembic revisions (2.4) and must work on a fresh DB and an existing one.

### 5.7 Date and duration semantics
- Start and end dates are **inclusive**. `duration_days = (end_date − start_date).days + 1`. A same-day campaign has `duration_days = 1`.
- Start date is required. The user supplies end date **or** duration (or both). If only one is supplied, the other is derived. Dates must be valid ISO calendar dates.
- **End before start** → field-level `END_BEFORE_START` on `end_date`. **Explicitly supplied dates and duration that conflict** → field-level `DURATION_DATE_MISMATCH` on both fields; the backend never silently changes submitted data.
- The form UI recomputes duration live when either date changes (user-visible), but the backend always revalidates and treats the submitted values as authoritative inputs to validate.
- "Today" (e.g., for the demo-button dates: next Monday from today, end = start + 13 days) uses `APP_TIMEZONE`; tests use a frozen clock and fixed dates.
- `duration_days` is the single source of truth used in normalization, social calendar generation, daily budget math, dependency invalidation, reports, and tests. Bounded (default max 365).
- Tests: same-day campaign, month boundary (e.g., Jan 30 → Feb 2), leap year (2028-02-28 → 2028-03-01 = 4 days; 2028-02-29 valid; 2027-02-29 invalid), year boundary, campaigns spanning different months, mismatch rejection, end-before-start rejection, invalid dates (e.g., 2027-02-30, non-ISO strings), derived end date, derived duration, and demo-button date computation with a frozen clock in `APP_TIMEZONE`.

### 5.8 Budget semantics and arithmetic
- The user-entered budget is **authoritative** and is the available paid-media budget: it is never altered by AI or by rounding, and allocations are constrained to it. The campaign budget is the **total proposed paid-media budget across the selected paid channels**. Organic social work is not budgeted. For the demo: **₹15,000** total; **Google Ads allocation + Meta Ads allocation must equal exactly ₹15,000**.
- Use `Decimal` (or integer minor units) everywhere; **no floats** in any financial path, including JSON serialization (serialize as strings or integers of minor units).
- Precision: currency exponent from a small table (INR 2 dp, JPY 0, USD 2). **Allocation unit is whole major currency units** by default.
- Allocation method (largest-remainder): `raw_i = total × weight_i`; floor to whole units; distribute the leftover units one at a time to the channels with the largest fractional remainder, ties broken by channel order (`google_ads`, `meta_ads`). The allocation sum is then exactly the total. Percentages are displayed with 2 dp and may not sum to exactly 100.00; daily figures (`amount / duration_days`) are displayed rounded half-up to 2 dp and noted as derived (they may not sum exactly).
- **Default weights** are a documented, editable, deterministic rule (default for two-channel lead generation: Google Ads 60%, Meta Ads 40% → ₹9,000 + ₹6,000) and are labelled "default rule, not a proven optimum". AI may only draft rationale text; it never sets numbers.
- Manual edits: the backend recomputes and validates after every edit. Sum > total → blocking finding and rejected save of the "final" state; sum < total → saved with a `WARNING` ("unallocated ₹X"). Negative or non-numeric values are rejected.
- **Only channels in the brief's `paid_channels` receive allocation rows** (validator + database constraint); organic channels never do. Stored amounts are exact decimals (strings or integer minor units); **exports read the stored values and never recompute them**, and a test compares every exported amount to the database row. The AI provider never sets, adjusts, or overrides a number.
- Tests: exact sums for ₹15,000 and for awkward totals (e.g., ₹10,001 across 3 channels), single channel, zero-budget rejection, large values, rounding remainder placement, edit-recalculation, no float usage (static check/grep test on the budget module).

### 5.9 Campaign API (all real, validated, consistent errors)
- `POST /api/campaigns`, `GET /api/campaigns`, `GET /api/campaigns/{id}`
- `PATCH /api/campaigns/{id}/brief` (applies 5.5 invalidation), `POST /api/campaigns/{id}/validate`
- `POST /api/campaigns/{id}/executions` (202; duplicate active start → 409), `GET /api/campaigns/{id}/executions/{exec_id}`
- `GET /api/campaigns/{id}/stages/{stage_key}`
- `PATCH /api/campaigns/{id}/outputs/{output_type}/{output_id}` (validated; applies 5.5), `POST .../regenerate`
- `POST /api/campaigns/{id}/executions/{exec_id}/stages/{stage_key}/retry` (202; creates a **new** execution, the original stays immutable), `POST .../executions/{exec_id}/cancel`
- `GET /api/campaigns/{id}/findings`
- `GET /api/campaigns/{id}/export.{pdf|xlsx|csv}` (409 on blocking findings or stale outputs)
- `DELETE /api/campaigns/{id}` (blocked while RUNNING)
Proper status codes (201, 202, 404, 409, remapped 422), response schemas (never raw ORM objects), every contract in `docs/API_REFERENCE.md`.

---

## 6. PRIORITY 2 — AI MARKETING FUNNEL BUILDER

A complete implementation: configuration, journey design, a validated connected graph, per-stage content recommendations, an **interactive diagram**, persistence, execution status, and reports. It is neither a static picture nor a renamed Campaign Intelligence run.

### 6.1 Funnel configuration (`FunnelConfig`)
Required `*`: funnel name*, business/brand*, industry*, offer/product*, primary goal* (`lead`, `booking`, `purchase`, `signup`), audience description*, template* (`lead_generation`, `consultation_booking`, `ecommerce_purchase`, `webinar_signup`, `custom`), language*. Optional: tone, supported channels (`google_ads`, `meta_ads`, `organic_social`, `website`, `email`, `phone_call` — content is *recommended*, nothing is sent), constraints, approved/prohibited claims, timeline, notes, `source_campaign_id` (Section 12), maximum node count (default 12, hard max 20). Save Draft, reopen, edit. Healthcare rules (5.1) apply when `is_healthcare`.

### 6.2 Funnel graph model
- **Nodes** (`FunnelNode`): `id`, stable `key`, `name`, `stage_type` ∈ {`AWARENESS`, `INTEREST`, `CONSIDERATION`, `INTENT`, `CONVERSION`, `RETENTION`, `NURTURE`, `RETARGETING`, `DROP_OFF`}, rank (derived from stage_type), saved `x`/`y` position, `objective`, `audience_state`, `channels`, `touchpoints`, `entry_criteria`, `exit_criteria`, `success_metric` (metric *names* only — no invented values), `cta`, `risks`, `content_recommendations` (list of {asset_type, brief, key_message, channel}), `content_status` (4.1), `generation_status`, `is_outdated`, provider/is_mock.
- **Edges** (`FunnelEdge`): `id`, `from_node`, `to_node`, `transition_type` ∈ {`PROGRESSION`, `NURTURE_LOOP`, `RETARGET`, `DROP_OFF`}, `trigger/condition` text, `recommended_action`, `is_outdated`.
- Content recommendations are briefs and key messages, **not** final ad-copy sets (those belong to the Campaign Engine).

### 6.3 Deterministic graph validation (`graph_validation.py`)
Rules (each returns a finding with `rule_id`, severity, affected node/edge ids, message, fix hint):
`V01` unique node keys; `V02` exactly one entry node (no incoming edges, excluding loop/retarget edges); `V03` at least one `CONVERSION` node; `V04` every node reachable from the entry; `V05` every non-terminal node has ≥ 1 outgoing edge (`CONVERSION`, `RETENTION`, `DROP_OFF` may be terminal); `V06` a `CONVERSION` node is reachable from every node except `DROP_OFF`; `V07` `PROGRESSION` edges are acyclic (cycles are legal only through `NURTURE_LOOP`/`RETARGET` edges, and every cycle must contain at least one such edge); `V08` no duplicate edges and no self-loops (except loop types to a different `NURTURE`/`RETARGETING` node); `V09` `PROGRESSION` edges must not move backward in stage rank; `V10` channels ∈ supported set; `V11` required node fields non-empty; `V12` `CONVERSION` nodes have a CTA and a success metric; `V13` node/edge counts within limits; `V14` edges reference existing nodes. Manual editing may **save an invalid graph as a draft** (findings shown inline and highlighted in the diagram), but **final export/finalize requires zero blocking findings**.

### 6.4 Funnel workflow (own execution model)
Stage keys: 1 `FUNNEL_CONFIG_VALIDATION` (deterministic), 2 `JOURNEY_DESIGN` (template skeleton + AI enrichment; mock is deterministic), 3 `GRAPH_VALIDATION` (deterministic), 4 `NODE_CONTENT` (one independent, retryable unit per node), 5 `TRANSITION_PLAN` (per-edge triggers/actions), 6 `FUNNEL_QA` (deterministic checks + warnings: health-claim scan, missing fields, content-status warnings, staleness), 7 `FUNNEL_REPORT`. States as in 5.3 plus per-node/per-edge generation states. Failure of one node's content preserves all others; retry re-runs only the failed node. Progress shows real states. Same job-lifecycle rules (2.3).

### 6.5 Dependency behavior
- Config `goal`/`template` change → `JOURNEY_DESIGN` outdated (and, since the graph may change, all dependents). Audience/offer/tone/claims change → `NODE_CONTENT` for all nodes (graph and structure preserved). Channel change → only nodes using those channels. Language change → `NODE_CONTENT`.
- Editing a node → that node's adjacent edges' `TRANSITION_PLAN` items, `FUNNEL_QA`, `FUNNEL_REPORT`. Adding/removing nodes or edges → `GRAPH_VALIDATION` re-run, `TRANSITION_PLAN` for affected edges, new nodes get `NODE_CONTENT` `PENDING`, QA, report.
- Outdated items show an explanation, can be regenerated individually, and are never presented as current; export is blocked on stale items unless `allow_stale=true` (STALE banner), same as 5.5.

### 6.6 Interactive diagram and UI (`/funnels`)
- Funnel list/history; "Create Funnel" (with "Load demo funnel"); config form; Run; stage timeline; diagram + side panel.
- **Diagram:** React SVG diagram — either `@xyflow/react` (MIT, pinned, only if it installs cleanly) or a custom SVG implementation; record the choice. Features: render nodes/edges with type styling and direction arrows; select node/edge; **drag nodes** (positions persisted); add node; delete node/edge (with confirmation); connect nodes; inline validation highlighting; status/outdated/provider badges; pan/zoom; "Auto-layout" button.
- **Accessibility:** a keyboard-operable **list/table view of nodes and edges** offers every editing action available in the diagram.
- **Layout:** a deterministic layered auto-layout (rank columns by stage_type, stable ordering) implemented server-side (Python) so the **PDF and SVG exports match the UI**; saved positions override computed ones.
- Side panel edits all node fields; saving validates and re-runs `GRAPH_VALIDATION`; per-node regenerate; content status control.
- Exports: PDF (diagram + per-node pages + transition table + validation/QA), Excel (Nodes, Edges, Content Recommendations, Validation), CSV (nodes, edges), **SVG** of the diagram. All from stored data; demo labels preserved.

### 6.7 Funnel data model and API
Models: `Funnel`, `FunnelConfig` (may merge), `FunnelNode`, `FunnelEdge`, `FunnelExecution`, `FunnelExecutionStage`, `FunnelValidationFinding`, `FunnelExport`, plus `context_snapshot` JSON on `Funnel`. Endpoints: `POST/GET /api/funnels`, `GET/PATCH/DELETE /api/funnels/{id}`, `POST /api/funnels/{id}/validate`, `POST /api/funnels/{id}/executions`, `GET .../executions/{eid}`, `POST .../stages/{stage_key}/retry`, `POST .../cancel`, `POST/PATCH/DELETE /api/funnels/{id}/nodes[/{nid}]`, `POST/PATCH/DELETE /api/funnels/{id}/edges[/{eid}]`, `PATCH /api/funnels/{id}/layout`, `POST /api/funnels/{id}/nodes/{nid}/regenerate`, `GET /api/funnels/{id}/findings`, `PATCH .../nodes/{nid}/status`, `GET /api/funnels/{id}/export.{pdf|xlsx|csv|svg}`. Same conventions as 5.9.

### 6.8 Graph integrity rules (resolved)

- **Identity and structure:** nodes/edges have stable IDs; edges must reference existing nodes (FK + validator); duplicate edges are rejected; self-connections follow `V08`. **Default templates generate acyclic graphs**; cycles exist only when the user (or a template that explicitly includes retargeting) adds `NURTURE_LOOP`/`RETARGET` edges.
- **Backend validation is authoritative.** The backend computes and stores `validation_state` (`VALID` | `INVALID_DRAFT`) on every save; the client can never set it. An invalid graph may be saved only as `INVALID_DRAFT` with findings; finalize/export requires `VALID`.
- **Semantic vs layout edits:** `PATCH …/layout` changes only `x`/`y` — no `graph_version` bump, no invalidation, no revalidation. Any semantic change (nodes, edges, types, content fields) bumps `graph_version`, revalidates, and applies 6.5 invalidation. Semantic edits require `If-Match: <graph_version>`; a mismatch → 409 `VERSION_CONFLICT` (concurrent edits never silently overwrite).
- **Deleting a node** deletes its incident edges inside one transaction after a confirmation dialog that lists exactly what will be removed; the previous graph is retained as a `FunnelGraphVersion`.
- **Regeneration never silently discards user edits:** re-running `JOURNEY_DESIGN` on a funnel containing manually edited nodes/edges requires explicit confirmation "Replace graph (discard my edits)", stores the prior graph as a restorable `FunnelGraphVersion`, and is otherwise refused. Per-node content regeneration skips nodes whose active version is `MANUALLY_EDITED` unless the user chooses "overwrite my edits" (the old version is kept, 3.5). A failed regeneration keeps the last valid version.
- **Reports** correspond to the saved graph: each export records `graph_version` and node/edge version ids and reads a consistent snapshot (2.7).
- **Tests:** concurrent semantic edits, layout-only edits do not invalidate, node deletion removes edges and keeps a restorable version, regenerate-with-edits refusal and confirmed replace, `validation_state` cannot be client-set, export `graph_version` matches the saved graph.

---

## 7. PRIORITY 3 — WEBSITE SEO AUDIT & SEO REPORT GENERATOR

**Scope: SEO-specific, verifiable analysis only.**

**Crawler/rule engine (modular):** URL input (normalize scheme; strip fragments), page limit (default 50, hard max from env), per-request timeout (10 s), total time budget (120 s), max response size (2 MB), max redirects (5), HTML-only content-type checks, small controlled concurrency (default 4), delay, clear User-Agent, same-site only (`www`/bare treated alike), bounded queue and visited-set with a **depth limit** (`SEO_MAX_DEPTH`, default 5) so recursion is never unbounded, `robots.txt` honoured and reported, graceful handling of 403/429/timeouts/malformed HTML/encoding errors. Network unavailable → actionable error; incomplete crawl never reported as a successful audit (3.1).

**SSRF protection (mandatory, tested):** http/https only; resolve DNS and block loopback, private (10/8, 172.16/12, 192.168/16), link-local (169.254.0.0/16 incl. 169.254.169.254), reserved, multicast, unspecified, IPv6 equivalents, IPv4-mapped IPv6, and metadata hostnames; **re-validate every redirect hop and the resolved IP at connect time** (pin the validated IP where practical against DNS rebinding; document residual risk); reject credentials in URLs; ports 80/443 only by default. `ALLOW_PRIVATE_TARGETS=true` exists solely for local fixtures/tests, defaults to false, and is never exposed in the UI. A separate, narrower `ALLOW_DEMO_SITE=true` allowlists **only** the exact bundled demo server (`127.0.0.1:DEMO_SITE_PORT`) for demonstrations; it does not relax any other rule, and tests assert that other loopback ports and private ranges remain blocked while it is enabled.

**Checks:** status codes; redirects/chains; titles (missing/long/short/duplicate); meta descriptions (missing/long/short/duplicate); H1 presence/count; heading hierarchy; image alt; internal and broken internal links; canonical tags; robots meta/X-Robots-Tag; `robots.txt`; XML sitemap availability and parsing (index, bounded); response times; basic accessibility signals **only where actually detected** (`lang`, form labels, empty links); crawl errors; indexability signals; internal-linking opportunities (e.g., sitemap-only pages).

### 7.1 Evidence model and coverage reporting (shared by Sections 7 and 8; one implementation)

Every finding/observation/recommendation preserves: **title**, **description**, **category**, **severity**, **affected URL**, **supporting evidence** (extracted snippet, header, measured value), **detection method** (`HTTP_FETCH` | `HTML_PARSE` | `ROBOTS_PARSE` | `SITEMAP_PARSE` | `RULE_ENGINE` | `HEURISTIC` | `AI_ASSESSMENT`), **crawl timestamp**, **kind** (`OBSERVATION` = verified, deterministic; `RECOMMENDATION` = suggested action; `ASSESSMENT` = interpretive hypothesis), **confidence** (`HIGH` | `MEDIUM` | `LOW`) with **known limitations** text, **suggested corrective action**, plus finding ID, rule ID (where applicable), and `based_on_finding_ids` linking recommendations/assessments to the observations they derive from. Document the severity rule table (e.g., missing H1 = Medium, 5xx = High).

Rules:
- **Crawl actual accessible pages before reporting findings.** A page is never listed as crawled unless it was actually fetched; a finding without stored evidence is invalid (a database/schema constraint and a validator reject it).
- Never invent a missing H1, missing image alt, broken link, metadata issue, or any technical finding. Deterministic checks produce `OBSERVATION`s with `HIGH` confidence (limitations stated, e.g., "JavaScript-rendered content not evaluated"). AI-generated items are `RECOMMENDATION`/`ASSESSMENT`, never `HIGH` confidence, and never displayed as verified observations.
- **External metrics are never invented** (traffic, rankings, backlinks, search volumes, advertising costs, conversions). A metric that cannot be retrieved is stored and shown as `UNAVAILABLE` with the reason (e.g., "requires Search Console — not configured").
- **Coverage panel (UI, report, and API):** seed URL; scope rules and limits used; pages discovered; pages crawled successfully; **failed pages with reasons** (timeout, DNS, HTTP status, SSRF-blocked, too large); **excluded pages with reasons** (robots disallow, out of scope, non-HTML, over page cap, duplicate URL); redirects followed; crawl start/end timestamps; "pages analysed X of Y discovered".
- **Completeness state:** `COMPLETE` (queue exhausted within limits), `PARTIAL` (page cap, time budget, or cancellation reached — stated plainly), `FAILED` (seed unreachable, network unavailable, or crawl aborted). Never present `PARTIAL` or `FAILED` as a complete audit; the exact scope actually analysed is recorded.
- robots.txt, timeouts, HTTP errors, redirects, and inaccessible pages are reported accurately (never silently dropped).
- Crawled page text is **untrusted data, never instructions** (Section 3); prompt-injection fixtures are tested.
- **Audits are immutable snapshots.** A completed audit/report is never overwritten; "retry failed pages" and "re-audit" create **new linked runs** (`retry_of_audit_id` / `previous_audit_id`) that carry forward successfully fetched pages by reference (2.3). Findings and evidence rows are never edited. **User triage** (status `OPEN`/`ACKNOWLEDGED`/`DISMISSED` with a note) is stored in a **separate mutable `FindingTriage` table** keyed by finding ID, so evidence immutability and editability do not conflict; triage on a carried-forward finding follows it into the new run only by explicit user action.
- The demo-site allowlist (`ALLOW_DEMO_SITE`) is re-evaluated on **every redirect hop**: a hop to any other host or port (including other loopback ports) is blocked even when the allowlist is on; startup logs a warning when it is enabled.


**Report:** executive summary, summary cards, severity and category charts, detailed URL-level findings, prioritized recommendations (P1/P2/P3 + checklist), scope and **limitations**, verified observations separated from recommendations. PDF/XLSX/CSV from stored findings only. Audit history list/detail.

**Do not claim** rankings, traffic, backlinks, impressions, or Search Console data unless obtained from a configured authorized source. Search Console/PageSpeed are optional future modules, never required.

Endpoints: `POST/GET /api/seo-audits`, `GET /api/seo-audits/{id}`, `GET /api/seo-audits/{id}/report.{pdf|xlsx|csv}`.

---

## 8. PRIORITY 4 — WEBSITE INTELLIGENCE & WEBSITE REPORT GENERATOR

**Scope: broader website assessment — distinct from SEO.** Each page's header states its scope and links to the other.

| | SEO report | Website report |
|---|---|---|
| Question | "Is the site technically and on-page sound for search?" | "How clear, navigable, and conversion-oriented is the site for visitors?" |
| Evidence | Metadata, status codes, canonicals, robots, sitemaps, headings, links, alt text | Structure, page inventory, service/product coverage, navigation, CTAs, contact paths, trust information, content clarity |
| Output | Rule-based findings by severity | Evidence-backed observations, strengths, opportunities, roadmap |

Shared: the **fetch/crawl service and SSRF guard** (one implementation). Separate rule engines, outputs, and UI.

**Analysis (fetched pages only):** inferred purpose; services/products presented; page inventory and structure; navigation clarity (menu items, depth); content organisation; value-proposition presence; contact/enquiry pathways (`tel:`/`mailto:`/forms/links detected); calls to action (detected button/link patterns); landing-page messaging; service-page coverage; publicly visible trust information; conversion-path consistency; missing/confusing information; content opportunities; improvement recommendations. Heuristic detections are deterministic. Interpretive assessments may use the AI provider, are labelled **"assessment/hypothesis"**, and cite supporting page URLs and extracted snippets. Mock mode uses deterministic heuristics only and says so. Fetched page text is untrusted data (Section 3). The evidence model, coverage panel, completeness states, and `UNAVAILABLE`-metric rules of Section 7.1 apply here too: deterministic detections are `OBSERVATION`s with evidence; AI interpretations are `ASSESSMENT`/`RECOMMENDATION`s with `based_on_finding_ids`, labelled hypotheses, and never `HIGH` confidence. Failed pages and analysis limitations are always displayed.

**Do not claim** user behavior, conversion rates, bounce rates, recordings, or analytics performance without an authorized configured source.

**Deliverables:** overview; analysed-page inventory; evidence-backed observations; strengths; opportunities; prioritized recommendations; implementation roadmap; limitations; PDF and Excel (CSV for inventory/observations). History list/detail. Endpoints: `POST/GET /api/website-reports`, `GET /api/website-reports/{id}`, `GET .../export.{pdf|xlsx|csv}`.

---

## 9. PRIORITY 5 — AI BULK BLOG & CONTENT GENERATOR

- Batch input (one topic per line or structured rows): trim, drop blanks, dedupe case-insensitively, cap (default 50), per-topic length limit.
- Per-topic fields: topic, audience, search intent, primary keyword, supporting keywords, language, tone, target length, content type, brand instructions, reference material (pasted text only in v1; if file upload is added: validate size/type/content, safe paths, no execution).
- Per-draft output: title, introduction, structured headings, body, conclusion, meta title (~≤60), meta description (~≤160), URL slug (deterministic, unique within batch), keywords, internal-link suggestions, image suggestions + alt-text drafts, editorial review notes.
- Each topic is an independent task with `generation_status`, result, error, provider, `is_mock`, attempts, timestamps, and a **content status** (4.1). Batch progress from real states.
- **Retry failed only:** re-runs `FAILED` items; `COMPLETED` items stay unchanged (verify with content hash). Retrying with no failures returns a clear message.
- Edit (resets content status to `DRAFT` per 4.1), save, copy (clipboard fallback), export (Markdown/TXT per draft; batch CSV; batch ZIP with sanitized unique file names).
- Content validation with visible warnings (meta length, missing headings, keyword absent, too short, duplicates, health-claim scan when relevant). No guarantees about rankings, originality, accuracy, or performance. Mock output labelled; never described as real AI.
- Endpoints: `POST/GET /api/blog-batches`, `GET /api/blog-batches/{id}`, `POST .../retry-failed`, `PATCH /api/blog-items/{id}`, `PATCH /api/blog-items/{id}/status`, `GET .../export.{csv|zip}`.

---

## 10. PRIORITY 6 — AI SOCIAL MEDIA CAMPAIGN & CONTENT CALENDAR GENERATOR

One **shared social-content service** (`services/social_content.py`) serves both this standalone module and the Campaign Engine's `SOCIAL_PLAN` stage. Single implementation; different entry points; no duplicated logic.

- Inputs: campaign theme/brief, platforms (Instagram, Facebook, LinkedIn), campaign period (start/end inclusive, same semantics as 5.7), tone, audience, optional brand voice, **posting cadence**.
- Outputs (platform-specific schemas): theme, content pillars, captions, headlines, hooks, CTAs, hashtags, **reel scripts, carousel outlines**, creative briefs, format suggestions, suggested dates, campaign alignment.

### 10.1 Posting cadence and calendar rules
- Cadence options: `daily`; `every_n_days` (n ≥ 1); `weekdays` (selected weekdays); `times_per_week` (k, spread evenly); `custom` (explicit list of dated slots). Configurable per platform or global; default `every_n_days`, n=2.
- The generator creates **schedule slots** from the cadence within `[start, end]` inclusive, then fills each slot with content. The calendar must **cover the complete period** (the schedule spans start to end) but does **not** need a post every day. QA warns if the gap between consecutive slots exceeds `max_gap_days` (default 3), or the first/last slot is more than `max_gap_days` from the start/end.
- Dates always fall within the period; no unnecessary duplicate content (deterministic similarity check); each item has a theme/format sequence that avoids repetition.
- **Editing:** edit content; **add, remove, and reschedule** items (move date/platform); every change **revalidates the schedule** (dates in range, no duplicate platform+date+format collisions unless allowed, gap rule, cadence deviation noted as `INFO`); changes persist; reopening shows the saved state. Changing campaign dates/duration or cadence re-plans: items outside the new window are flagged `is_outdated` (not silently deleted) and the user can regenerate or reschedule them.
- **Dates are suggestions.** The UI and exports label them "Suggested date" and never "scheduled" or "published". There is no `PUBLISHED`/`SCHEDULED` state in v1; publishing integrations are optional future modules (documented only).
- Item content status uses 4.1. Per-item regenerate, edit, copy, retry on failure; CSV export (and Excel for the standalone module).
- Endpoints: `POST/GET /api/social-campaigns`, `GET /api/social-campaigns/{id}`, `POST .../items`, `PATCH/DELETE /api/social-items/{id}`, `POST /api/social-items/{id}/regenerate`, `PATCH /api/social-items/{id}/status`, `POST /api/social-campaigns/{id}/validate-schedule`, `GET .../export.{csv|xlsx}`.
- Tests: cadence generation for each option, date boundaries (first/last day, same-day campaign), duration change re-planning, add/remove/reschedule with revalidation, gap-rule warnings, persistence across reload, shared-service parity (the campaign stage and standalone module produce the same schedule for the same inputs).

---

## 11. FRONTEND REQUIREMENTS

React + Vite + TypeScript (strict), reusable components, typed API contracts in a `types/` module mirroring backend schemas. Professional, consistent, usable design favoring function over decoration. Loading, empty, error, and success states (success only after real backend confirmation). Accessible labelled forms with field-level messages; keyboard usability; confirmation dialogs for destructive actions; download controls with per-button loading/error states; demo data always labelled; all buttons wired to the real backend; no console errors on page load. Additional rules in 11.1.

### 11.1 UX consistency and behavior rules

- Consistent navigation, page layouts, typography, spacing, buttons, forms, and status badges (shared components and design tokens; no per-page one-offs).
- Clear loading, empty (with a useful next action), success, warning, and error states; **no unexplained blank screens**; an error boundary shows a recoverable message instead of a white page.
- **No dead links or nonfunctional buttons;** unimplemented controls are visibly disabled with an explanation.
- **Confirm destructive actions** (delete, discard version, remove demo data) with an explicit dialog naming what will be deleted.
- **Prevent accidental duplicate submissions** (disable while pending + `Idempotency-Key`, 2.2).
- **Preserve user inputs when validation fails;** show **field-level validation errors** tied to the field with an accessible description.
- **Warn about unsaved changes** before navigating away (router blocker + `beforeunload`).
- Display **actual background-job states** (pending/running/completed/failed/cancelled/outdated) from the backend; **actionable failure messages** (what happened, whether retry is possible, what to change); retry/cancel/recovery controls wherever supported.
- **Search, filtering, and pagination** on list views (campaigns, funnels, audits, reports, batches, social items).
- Keyboard accessibility (visible focus, logical tab order, dialogs trap focus, diagram has the list-view alternative), readable contrast, and responsive layouts at 360 px and 1440 px.
- No unnecessary animation or visual complexity at the expense of reliability.
- **Do not claim manual browser verification unless it was actually performed**; record automated UI test results separately from manual checks in `docs/BUILD_STATE.md`.

---

## 12. CROSS-MODULE DATA CONTRACTS (all optional; every module works alone)

1. **SEO → Website report:** a website report may reference an SEO audit's findings (read-only summary by `audit_id`) in its roadmap.
2. **Website report → Campaign:** a campaign brief may attach a website-report summary as labelled context (copied as a snapshot with the report id and timestamp).
3. **Campaign → Funnel:** `POST /api/funnels` with `source_campaign_id` copies a **read-only snapshot** (audience segments, messaging pillars, concept summaries, landing URL, channels, language, campaign `content_version`) into `funnel.context_snapshot`. If the campaign later changes, the funnel shows an informational `CONTEXT_STALE` badge; "Refresh context" updates the snapshot and marks `NODE_CONTENT` outdated. The funnel never triggers Campaign Engine stages.
4. **Campaign → Social:** via the shared social-content service (Section 10).
5. **Shared exports:** common PDF/Excel/CSV utilities give all modules consistent styling, labels (demo/mock/provider), and file handling.
6. **Execution history:** `WorkflowRun` lists real completed operations across modules.

When source data changes, dependents are flagged outdated with a reason. Never scrape the frontend; never create hidden dependencies.

---

## 13. BACKEND ARCHITECTURE

```
backend/alembic.ini  backend/alembic/ (env.py, versions/)
backend/app/
  main.py config.py database.py
  models/  schemas/            (per module)
  api/     health dashboard settings campaigns funnels seo website_reports blogs social
  services/
    campaign/  orchestrator.py stages/ (one file per stage) dependency_graph.py qa_rules.py
               budget.py utm.py dates.py exports.py
    funnel/    orchestrator.py graph_validation.py layout.py dependency.py templates.py exports.py
    content/   health_claims.py content_status.py similarity.py social_content.py versioning.py
    crawl/     fetcher.py url_safety.py robots.py sitemap.py
    seo/       rules.py seo_service.py seo_reports.py
    website/   analyzer.py website_service.py website_reports.py
    blog_service.py
    reporting/ pdf.py excel.py csv_export.py charts.py fonts/   (shared)
    jobs/      worker.py claims.py recovery.py
  ai/        base.py mock_provider.py ollama_provider.py gemini_provider.py factory.py schemas.py
  utils/     errors.py files.py
backend/tests/ (unit/, integration/, e2e/, fixtures/site/)
```
Separate routes, schemas, models, business logic, orchestration, providers, crawling, reporting, exports, validation, config, tests. Proper transaction handling; indexes where justified; DB and filesystem errors handled; environment config out of source.

---

## 14. SECURITY AND RELIABILITY

Server-side validation of all input with length limits; URL validation and SSRF prevention (Section 7); upload validation if uploads exist (size, type, content sniffing, safe filenames, path-traversal prevention, no execution of uploaded content); parameterized ORM queries only; XSS prevention (no `dangerouslySetInnerHTML` with user/AI content; SVG diagram text escaped); prompt-injection handling (Section 3); secret management; error sanitization; request timeouts; resource limits (crawl, job concurrency, payload size, graph size); background-job lifecycle and cleanup; export-path restrictions (2.2); safe deletion behavior; dependency hygiene (pinned versions; run `pip-audit`/`npm audit` if available and report results, else mark NOT RUN). **Bind to loopback (`127.0.0.1`) by default; do not expose the app to the LAN unless the user explicitly sets `ALLOW_LAN=true` (and `HOST`), in which case print a warning that v1 has no authentication.** **Concrete limits and local-API protections:** `MAX_BODY_BYTES` (default 2 MB) enforced before parsing, per-field length caps (e.g., reference text ≤ 100k characters), a global cap on queued jobs and bounded worker concurrency (2.3), crawl page/depth/timeout/response-size limits (Section 7). Because the API is local but reachable from any web page the user visits, enforce **`Host` header validation** (allow only `127.0.0.1`/`localhost` with the configured ports, mitigating DNS rebinding), **`Origin` checks on all state-changing requests** (reject unknown origins), `application/json` content-type enforcement on JSON endpoints, and CORS restricted to the dev/production origins. When the backend serves the built frontend, send `Content-Security-Policy` (`default-src 'self'`), `X-Content-Type-Options: nosniff`, and `frame-ancestors 'none'`. Generated SVG/HTML-adjacent exports escape all user text. Prefer these simple protections to heavier machinery.
Never execute AI output as code or commands. The application is single-user and local; document that no real authentication or multi-user authorization exists.

---

## 15. TESTING REQUIREMENTS (MANDATORY, covering all six automations)

Tests run without network access, real ad accounts, or paid providers. Use deterministic fixtures. A frontend build alone, polished screens alone, or a few unit tests alone are **not** sufficient. Never mark a feature verified because its source code exists.

### 15.0 Test organization and diagnosability

- **Separate layers**, each runnable on its own: `tests/unit/` (pure logic: budget, dates, UTM, state machines, graph validation, scanners), `tests/integration/` (services + real temporary SQLite built via migrations), `tests/api/` (HTTP routes via TestClient/httpx, status codes, schemas, persistence), frontend tests (Vitest + React Testing Library), and `tests/e2e/` (real backend process + HTTP, and browser-level only if a free tool installs). `scripts/test unit|integration|api|frontend|e2e|all` selects layers; pytest markers: `unit`, `integration`, `api`, `e2e`, `slow`, `optional_network`.
- **Independently diagnosable journeys:** each module's journey (1.2) is split into one small test per capability (e.g., `test_m1_j05_observe_real_stage_status`, `test_m1_j11_reopen_after_restart`, `test_m1_j16_work_preserved_after_cancel`). Tests **never depend on each other's state**; each builds its starting state through factory fixtures/API calls. Add only a thin end-to-end smoke chain (15.8) on top. A failing test must point at one capability.
- Assert **state, not just responses**: database rows, stage transitions and timestamps, output versions/provenance, and **exported file contents compared with stored values**. Test failures and recovery paths, not only success.
- **Determinism:** frozen clock, fake timers for backoff/heartbeat tests, seeded randomness, fixed fixtures, no sleeping on real time where a fake clock works.
- **No external dependencies by default:** no real AI APIs, no public websites; only the mock provider and local fixture/demo servers. Tests needing real Ollama/Gemini/public sites are classified `optional_network`, live in `tests/optional/`, are excluded from default runs and gates, and are reported separately.
- Never weaken, skip, or loosen a test to obtain a pass; a skipped/xfail test counts as NOT VERIFIED in the traceability report.

### 15.1 Campaign Intelligence
- **Demo-brief validation test:** (1) load the demo brief (5.1); (2) validate every required field is populated; (3) confirm **no blocking validation errors** remain; (4) start the workflow with the mock provider; (5) verify it reaches a valid terminal state (`COMPLETED` or `COMPLETED_WITH_WARNINGS`); (6) confirm outputs and exports retain the **demonstration-data label** (`is_demo=true`, DEMONSTRATION DATA banner). A required-fields guard test fails if a new required field is added without a demo value.
- **Non-healthcare brief test:** a different business (e.g., a bakery or software consultancy) completes the workflow; assert no Be Well text, no healthcare warnings unless flagged, and correct currency/dates.
- **Twelve-stage execution:** all 12 stage keys run in order with persisted inputs/outputs/timestamps; state-machine transition tests.
- **Budget arithmetic:** per 5.8, including exact ₹15,000 split, awkward totals, edits, over/under-allocation, no floats.
- **Date semantics:** per 5.7 (same-day, month boundary, leap year, year boundary, mismatch, derived values).
- **UTM generation:** spaces, unicode, existing query strings, fragments, encoding round-trip.
- **Quality findings:** each QA rule triggered by a purpose-built defect fixture (over-limit headline, budget sum mismatch, out-of-range date, duplicate content, prohibited health claim, unsupported claim, stale output).
- **Dependency invalidation:** per 5.5 — budget-only, dates-only, landing-URL, concept edit, social edit; unaffected stages stay `COMPLETED`; `outdated_reason` recorded; regeneration of only requested stages; refusal when upstream is stale; QA auto-rerun; **final-pack freshness** (pack reflects the latest edits; export blocked on stale unless `allow_stale`).
- **Failure and retry:** injected failure at `META_ADS`; earlier outputs preserved; retry completes only that stage; cancellation; restart recovery of `RUNNING` executions; duplicate concurrent start → 409; provider timeout; **invalid structured AI response** (repair then fail).
- **Exports:** PDF/XLSX/CSV generated and **re-opened and parsed** (PDF begins with `%PDF`, has pages, `₹` text or "INR" fallback present; XLSX loads with openpyxl and expected sheets; CSV parses); blocked export on blockers.
- The 25-step end-to-end flow: create, validate, save, start, stage transitions, each stage output, QA, save, complete, retrieve, edit, regenerate, preserve-on-failure, retry, export ×3, reopen with latest data.

### 15.2 Funnel Builder
Funnel creation (including from the demo funnel); stage generation per node with provider/mock labelling; **graph validation** — one test per rule `V01`–`V14` with minimal invalid graphs plus a valid graph (including a legal nurture loop and an illegal progression cycle); node and edge create/update/delete with revalidation; **layout** determinism (same input → identical coordinates; saved positions override); persistence across restart; editing resets content status; **dependency behavior** (6.5: audience change → all node content outdated while structure preserved; channel change → only matching nodes; node edit → adjacent edges + QA + report); partial failure (one node fails, others preserved; retry only that node); campaign context snapshot, `CONTEXT_STALE`, and refresh; exports (PDF/XLSX/CSV/SVG generated and parsed — SVG is well-formed XML containing every node); stale export blocking; confirm it never invokes Campaign Engine stages (assert via spy/test).

### 15.3 SEO Report Generator
Local fixture site (static HTML on a random localhost port, `ALLOW_PRIVATE_TARGETS=true` **only inside tests**): valid metadata, missing title/description/H1, multiple H1, duplicate metadata, missing alt, broken internal links, redirects/chains, canonicals, robots directives, `robots.txt`, sitemap and sitemap index parsing, malformed HTML, timeouts, HTTP errors, unexpected content types, oversized responses; assert exact expected findings. **SSRF tests:** localhost, 127.0.0.1, 10.x, 172.16.x, 192.168.x, 169.254.169.254, IPv6 loopback, IPv4-mapped IPv6, non-HTTP schemes, credentials in URL, redirect to a prohibited destination, hostname resolving to a private IP. Crawl-limit and bounded-recursion tests. Network-unavailable test (simulated) → actionable error and no "successful" audit. Report generation and export parsing.

### 15.4 Website Report Generator
Assessment of the fixture site: extracted evidence (CTAs, contact paths, nav items, service pages) matches the fixture; each observation cites URL/snippet; interpretive items labelled "assessment/hypothesis"; **separation from SEO findings** (no SEO rule IDs appear in website findings and vice versa); prompt-injection fixture page does not alter outputs; persistence; PDF/XLSX/CSV validation.

### 15.5 Bulk Blog Generator
Multiple topics, per-item status, partial failures via failure injection, **failed-only retry leaves completed items byte-identical** (hash check), editing resets content status and persists, dedupe/cap behavior, slug uniqueness, export file-name sanitization, ZIP integrity.

### 15.6 Social Media Module
Platform-specific schemas differ per platform; cadence generation for every option; date boundaries; duration change re-planning with `is_outdated` flags; add/remove/reschedule with revalidation; gap warnings; content-status transitions (every allowed/disallowed pair); persistence; CSV/Excel exports; no `PUBLISHED`/`SCHEDULED` value anywhere; shared-service parity with the campaign stage.

### 15.7 Application-wide tests
Database initialization (fresh and upgrade); API integration against a temporary DB (status codes, validation, missing records, persistence, parent–child association, pagination); frontend interactions (dashboard order and navigation — Campaign first, Funnel second; campaign form validation, execution controls, stage failure display, retry, output edit, budget-edit recalculation; funnel diagram interactions via list view and diagram, validation highlighting; SEO and website forms; blog batch submission; social calendar editing/rescheduling; loading/error/empty states; **no success message after a failed operation**); provider failures (timeout, 401, 429, missing key, Ollama down, invalid structure); error-format consistency; regression suite; `tsc --noEmit`; lint if configured; frontend tests; **production build**; backend startup; `/api/health`; **PDF/Excel/CSV validation**; **local offline demonstration mode** (run with network blocked/unavailable, mock provider, seeded demo data: campaign, funnel, blog, social complete; SEO/website against the local fixture only); no console errors; no unhandled backend exceptions during the smoke test.

### 15.8 End-to-end smoke test (`scripts/smoke_test`)
Start the real backend (temporary DB) and over HTTP: health → full Campaign Intelligence run (mock) → injected failure → retry → export three formats and re-open/parse → edit budget → verify outdated markers → regenerate → fresh export → Funnel Builder run from the demo funnel with campaign context → validate graph → export four formats → SEO audit of the fixture site → website report of the fixture → blog batch with an injected failure and failed-only retry → social calendar with reschedule → dashboard counts match → execution history lists these runs. Print a per-step PASS/FAIL table. If a free browser-automation tool (e.g., Playwright) installs locally, add UI-level tests for the campaign demo and funnel diagram; otherwise record "UI-level E2E: NOT RUN".

### 15.9 Build, runtime, and reporting
Run and report exact commands and results for: environment verification, backend install, backend tests, frontend install, lint (if configured), type checks, frontend tests, production build, backend startup, health check, DB initialization, key workflow runs, export generation. Anything not run → **NOT RUN** with reason. Don't ignore failures; fix causes and rerun affected tests plus regression tests for impacted modules.

### 15.10 Acceptance gate (before declaring completion)
All tests above **and all six module acceptance gates (15.12)** pass; production build passes; types pass; DB persistence verified (restart backend, confirm data remains); exports opened and validated; every primary navigation item leads to a working module; clean-clone setup verified (Section 16); `scripts/check` fully green with output quoted; offline demo mode verified.

### 15.11 Manual checklist
Generate `docs/MANUAL_TEST_CHECKLIST.md` with browser steps and expected results for every module, led by the Campaign demo script (load demo brief → run → watch stages → edit budget → see recalculation and outdated markers → regenerate → export pack), then the Funnel demo (load demo funnel → run → drag a node → introduce an invalid edge → see validation → fix → export).

### 15.12 Module acceptance gates

A module cannot be declared COMPLETE because its pages exist. It is COMPLETE only when **every** criterion below maps to at least one passing automated test (mapped in the traceability matrix, 17.1) **and** its journey suite (15.0) passes. A failing or unexecutable test is reported with its real status (FAILING / NOT RUN); never claim a module is fully verified in that case. "Restart" tests stop the backend process, start it again on the same database file, and re-fetch records (helper `tests/e2e/helpers/restart.py`). Test files follow `tests/e2e/test_mN_journey.py` and `tests/integration/test_mN_*.py`.

**Module 1 — Campaign Intelligence**
- M1-AC01 The brief is validated (field-level errors; the demo brief passes with zero blocking errors).
- M1-AC02 All 12 stages (5.3) exist in order with persisted state.
- M1-AC03 The actual backend workflow executes (asserted via database rows, stage timestamps, and provider provenance — not just HTTP responses).
- M1-AC04 Stage outputs are schema-validated and persisted.
- M1-AC05 Budget allocations sum exactly to the specified budget (₹15,000 demo and awkward totals).
- M1-AC06 Editing inputs invalidates only the affected downstream stages (5.5).
- M1-AC07 Editing outputs works, creates versions, and invalidates correctly.
- M1-AC08 Retry and failure recovery work (earlier outputs preserved; only the failed stage re-runs).
- M1-AC09 The complete campaign pack is generated from the latest stored data.
- M1-AC10 PDF, Excel, and CSV exports contain the correct stored data (compared to database values, not merely parseable).
- M1-AC11 Saved campaigns reopen after an application restart.
- M1-AC12 Cancellation preserves completed stages; duplicate starts are rejected; the non-healthcare brief also passes.

**Module 2 — Funnel Builder**
- M2-AC01 A funnel is created from user inputs. M2-AC02 Stages and connections are generated and persisted.
- M2-AC03 The diagram renders actual backend data (frontend test: rendered nodes/edges equal the API payload; server SVG contains every node).
- M2-AC04 Nodes and connections are editable through supported controls (diagram and list view).
- M2-AC05 Invalid graphs produce meaningful validation errors (rule ID, affected node/edge IDs, fix hint).
- M2-AC06 Changes save and reopen, including after restart.
- M2-AC07 Outdated dependent outputs are handled per 6.5. M2-AC08 Reports and exports (PDF, XLSX, CSV, SVG) work with correct stored data.
- M2-AC09 Failed node retry; cancellation preserves completed nodes; the funnel never invokes Campaign Engine stages.

**Module 3 — SEO Audit**
- M3-AC01 A valid website is submitted and crawled. M3-AC02 The crawler retrieves actual accessible pages (asserted against the fixture server's request log).
- M3-AC03 Findings are based on observed evidence (every finding has stored evidence matching the fixture HTML; none without evidence).
- M3-AC04 Failed and excluded pages are reported accurately with reasons. M3-AC05 Coverage, scope, and limitations are visible (API, UI, report).
- M3-AC06 An incomplete or failed crawl is never reported as complete (`PARTIAL`/`FAILED` states). M3-AC07 Results persist, including after restart.
- M3-AC08 The SEO report is generated and exported (PDF, XLSX, CSV) with correct data. M3-AC09 SSRF protections hold. M3-AC10 Prompt-injection pages do not alter behavior.
- M3-AC11 Triage status/notes are editable and persisted without altering observed evidence. M3-AC12 Cancellation preserves pages crawled so far, marked `PARTIAL`.

**Module 4 — Website Intelligence**
- M4-AC01 Website structure and accessible content are analyzed from collected evidence.
- M4-AC02 Navigation, page organization, and conversion paths are assessed with cited evidence.
- M4-AC03 Recommendations/assessments are distinguished from verified observations. M4-AC04 Failed pages and analysis limitations are displayed.
- M4-AC05 Reports contain the correct stored data. M4-AC06 Results persist (including after restart) and export (PDF, XLSX, CSV).
- M4-AC07 No SEO-rule findings appear here and vice versa. M4-AC08 Prompt-injection content is treated as data. M4-AC09 Retry of failed pages and cancellation preserve completed work.

**Module 5 — Bulk Blog**
- M5-AC01 Multiple items are generated in one batch. M5-AC02 Each item has an independent status.
- M5-AC03 Successful items are preserved when others fail. M5-AC04 Failed-only retry leaves successful items byte-identical (hash check).
- M5-AC05 Content is inspectable and editable (versions recorded). M5-AC06 Results persist, including after restart. M5-AC07 Supported exports work.
- M5-AC08 Cancellation preserves completed items. M5-AC09 Input dedupe/caps enforced.

**Module 6 — Social Calendar**
- M6-AC01 Platform-specific content is generated (schemas differ per platform).
- M6-AC02 The calendar respects the requested date range and posting cadence (every cadence option).
- M6-AC03 Content is editable and saved. M6-AC04 Items have accurate statuses (all allowed/disallowed transitions tested).
- M6-AC05 Invalid or inconsistent content is flagged (out-of-range dates, gap rule, duplicates). M6-AC06 The calendar persists after restart.
- M6-AC07 Supported exports work. M6-AC08 Shared-service parity with the campaign `SOCIAL_PLAN` stage. M6-AC09 No item is ever labelled scheduled or published. M6-AC10 Failed-item retry and cancellation preserve completed items.

### 15.13 Job engine, idempotency, and process-model tests
- **State machine:** exhaustive (from, to) matrix for execution and stage states; terminal rows never mutate (assert via guarded-update rejection); retry creates a new execution with `CARRIED_FORWARD` stages that reference original outputs and writes nothing to unrelated records; staleness flags live only on current-state records.
- **Claiming and concurrency:** parallel start requests → exactly one `202`, others `409`; two workers racing for one job → exactly one runs; a worker with a lost `claim_token` cannot write; queue cap → 429.
- **Heartbeat/stale detection (fake clock):** a stalled worker is marked `FAILED/STALE_HEARTBEAT` exactly once and its later writes are rejected; max-duration timeout.
- **Cancellation races:** cancel before claim, mid-stage (in-flight result discarded, committed outputs preserved), and after the final commit (409, job stays completed); never leaves `RUNNING`.
- **Commit boundaries:** fault-injected commit failure never yields `COMPLETED`; worker exception → `FAILED` with earlier stages intact.
- **Retry budget:** worst-case failure plans never exceed `STAGE_AI_CALL_BUDGET`/`EXECUTION_AI_CALL_BUDGET`; exhaustion → `AI_BUDGET_EXHAUSTED`, retryable manually with a fresh budget; `JOB_MAX_ATTEMPTS` lineage cap.
- **SQLite contention:** a second connection holding a write lock → bounded retry, then a retryable error; no write transaction across a provider call.
- **Restart and recovery:** backend restart while jobs are running → `RUNNING`→`FAILED/INTERRUPTED` (retryable), `PENDING` jobs remain `PENDING` and are claimed after startup succeeds, completed stages intact, in-flight AI request not resumed; no worker starts before migration/initialization succeed.
- **Process model:** second-instance refusal, lock release after clean exit and after kill, stale lock file reacquired, controlled-shutdown sequencing with WAL checkpoint.
- **Idempotency:** the full test list in 2.5. **Exports:** the test list in 2.7.

### 15.14 Migration tests
Exactly the tests listed in 2.4, run in every schema-changing phase gate, using committed per-phase DB snapshots; plus a data-integrity check after each upgrade (row counts, key-column checksums, FK check, integrity check, required indexes/constraints present).

### 15.15 Provenance and versioning tests
Generation records provider/model/is_mock/timestamp/execution/stage-or-item/source-input version; manual edit creates a `MANUALLY_EDITED` version that retains the original generation provenance and sets content status to `DRAFT`; the UI/export labels edited content correctly (never "raw AI output"); regeneration preserves prior versions, switches the active version, and records the new provider; restore creates a new version; per-stage provenance stays correct when providers differ between stages; retention never deletes the original or active version; edits mark dependents outdated per the relevant graph. Add the integrity tests in 3.5 (one-active-version constraint, optimistic-concurrency conflicts, failed regeneration keeps the old version, no-op edits, export version ids).

### 15.16 Offline/demo-mode tests
Every module's demo scenario completes with the mock provider and **no network** (SEO/Website against the local demo site with `ALLOW_DEMO_SITE=true`); mock output passes the same schemas/pipeline as real-provider output; all demo outputs and exports are labelled; seeding twice creates no duplicates; removing demo data leaves real records untouched; deterministic failure plans are repeatable; with `ALLOW_DEMO_SITE` unset the SEO/Website demo is not created and the UI says why; no pre-fabricated findings exist anywhere in seed data. Demo cleanup integrity tests per 3.6.

---

## 16. LOCAL STARTUP AND OPERATION

Provide **root-level** scripts (Windows `.ps1` and `.bat`, macOS/Linux `.sh`) and document equivalent manual commands:

- `scripts/setup` — checks Python/Node versions and disk; creates `backend/.venv`; installs backend and frontend dependencies; creates `backend/.env` from `.env.example` if missing; initializes the DB; idempotent; no undocumented manual DB steps.
- `scripts/start` — checks dependencies are installed; **checks ports 8000 and 5173 are free** and prints a clear message with how to change them when occupied; initializes the DB if needed; starts backend and frontend bound to `127.0.0.1`; waits for `/api/health` and for the frontend to respond; verifies the frontend can reach `/api/health` through the proxy; prints URLs (`http://127.0.0.1:5173`, API docs `http://127.0.0.1:8000/docs`); on Ctrl+C or window close, **shuts down both processes including child process trees** (Windows included) and confirms ports are released.
- `scripts/check` — runs backend tests, frontend type-check + tests + build, a **start/health/stop cycle**, and the smoke test; exits non-zero on failure; prints a PASS/FAIL summary.
- `scripts/seed_demo_data.py`, `scripts/serve_demo_site.py` (serves the bundled synthetic demo site on `127.0.0.1:DEMO_SITE_PORT` for demos and manual SEO/website audits; requires `ALLOW_DEMO_SITE=true`, which allowlists only that exact host and port — documented).

**Startup/shutdown safety rules (verify each):** environment checks run *before* any installation or execution (Python ≥ 3.10, Node ≥ 18, `pip check`, lockfile present); missing or too-old dependencies stop the procedure with exact install instructions; **port checks** distinguish "occupied by a FlowSynapse instance" (via the health identity payload) from "occupied by an unrelated service" and never connect the UI to an unrelated service; the script waits for a valid backend health response, then for the frontend, then verifies `/api/health` through the proxy; **any startup failure stops everything it started** (including child process trees) and exits non-zero; shutdown follows 2.6 so the database is never corrupted (WAL checkpoint, lock released, ports released — verified); unsupported OS/architecture is reported honestly rather than attempted silently.
**Do not claim one-command startup works unless it has actually been run.** Record in `docs/BUILD_STATE.md` exactly which OS(es) the scripts were run on; never claim Windows/macOS/Linux support for a platform on which they were not run (mark those NOT VERIFIED). Verify from a clean state (delete `.venv`, `node_modules`, DB) and record the result in `docs/BUILD_STATE.md`. If a platform's script cannot be run in your environment, mark it NOT RUN and say which platform was verified.

README troubleshooting: port in use, Python/Node versions, PowerShell execution policy, pip/npm failures, CORS/proxy errors, "backend unreachable", Ollama not running/model missing, network-required operations failing offline, PDF font/`₹` issues, resetting the database, stopping orphaned processes.

---

## 17. DOCUMENTATION AND RESUMPTION

Deliver: `README.md` (overview, quick start per OS, no-API-key mode, provider choice, the local-mode table from 3.1, troubleshooting, "How to explain FlowSynapse"), `docs/ZERO_COST_SETUP.md` (Ollama install and model choice with disk/RAM caveats; optional Gemini key — verify current quota/terms; `.env`), `docs/ARCHITECTURE.md` (stack, ER diagrams, state machines, dependency graphs, severity tables, decisions/defaults, module boundaries, SEO-vs-Website and Campaign-vs-Funnel distinctions), `docs/API_REFERENCE.md`, `docs/TEST_PLAN.md`, `docs/BUILD_STATE.md` (completed, remaining, unverified, deviations, resolved versions, commands run + results, platform verification), `docs/MANUAL_TEST_CHECKLIST.md`, `IMPLEMENTATION_CHECKLIST.md` (ordered per Section 1 and Section 18, and containing the traceability matrix of 17.1). Do not create additional documentation files that duplicate the checklist or `BUILD_STATE.md`.

**Resumption:** at the start of every session read `IMPLEMENTATION_CHECKLIST.md` and `docs/BUILD_STATE.md`, inspect actual files, identify the first incomplete task, and continue without recreating completed features. Before stopping, update both files with exact state, including partially completed work and failing tests.

**`docs/BUILD_STATE.md` structure (single source of truth for progress; keep it short and current):** (1) Current phase and next explicit step; (2) Last verified run (commit hash, date, command, counts); (3) Completed (phase → gate result); (4) Failed (with failing tests and suspected cause); (5) Blocked (with the blocker); (6) Pending; (7) Deviations from this prompt; (8) Environment (OS, Python/Node versions, resolved package versions) and the OSes on which scripts were verified; (9) Known defects. **No duplicated documentation:** configuration is documented once in `backend/.env.example` (commented) with a README table; `scripts/check_docs.py` fails if a variable read in `config.py` is missing from `.env.example` or the README table, or if a command in the README does not exist in `scripts/`, `package.json`, or the CLI. Docs must work from a fresh clone (verified by the clean-clone test).

**Known limitations section:** mock ≠ real AI; campaign assets and funnel recommendations are proposals, not platform research or live-account data; no ad-platform upload or social publishing; tracking plan is not an installed configuration; basic crawler ≠ commercial SEO suite; website report is an evidence-based assessment, not analytics; single-user local app without authentication; hosted free tiers can change; local AI quality/speed depends on hardware; network-dependent operations fail offline; healthcare outputs require human and platform-policy review.

### 17.1 Requirements traceability (generated from real test results)

Requirements live in a compact table inside `IMPLEMENTATION_CHECKLIST.md` with columns: **Requirement ID** (`FS-M1-001`…; `FS-SYS-###` for shared), description, owning module, implementation files, API endpoint(s), database model(s), **required test kinds** (e.g., `unit+api`, `e2e`, `negative-path`), acceptance criteria (e.g., M1-AC05), **verification status (generated)**, known defects.

**Tests declare what they verify:** pytest marker `@pytest.mark.req("FS-M1-005", kind="unit")` and Vitest titles prefixed `[FS-M1-005]`. `scripts/run_traceability` runs the suites with JUnit XML output, then **generates** `reports/traceability.json` and updates the status column; statuses are computed, not typed:
- `VERIFIED` only if every test mapped to the requirement **ran and passed** in the latest recorded run, **all declared test kinds are present** (including a negative-path test where required), and the run's commit hash equals the current `HEAD` (otherwise `STALE — re-run`).
- `FAILING` (any mapped test failed), `NOT RUN` (skipped/xfail/not executed), `TESTING GAP` (no mapped test), `INSUFFICIENT COVERAGE` (a declared kind or negative path is missing — say which), `IMPLEMENTED (UNVERIFIED)`, `IN PROGRESS`, `NOT STARTED`; `MANUAL (NOT PERFORMED)` for items that can only be checked by hand.
- The script **fails** (non-zero) if: a marker references a nonexistent requirement ID; the matrix references a test that is not collected; a requirement is hand-marked `VERIFIED`; a module is marked COMPLETE while any of its acceptance criteria (15.12) is not `VERIFIED`; a mapped test contains no assertion (static AST scan; warning for frontend); or any generated status disagrees with the recorded results. It prints all `TESTING GAP`, `INSUFFICIENT COVERAGE`, and `STALE` rows.
- A test file existing, or a test existing, is never evidence by itself; the existence of a passing, correctly-scoped, current test is. Whether a test is *adequate* is judged by the declared kinds and acceptance criteria and noted in the defects column when doubtful.
- Keep it maintainable: one row per requirement (not per test); `reports/` is generated and git-ignored, and `BUILD_STATE.md` records the last run summary. Run it from `scripts/check`.

---

## 18. PHASES AND GATES

**Sizing rules:** each phase is one small, independently verifiable vertical increment that an AI coding agent can implement, test, and debug in a local environment. If a phase proves too large for one working session, split it and record the split in `BUILD_STATE.md`. Shared infrastructure precedes dependent modules; a **working vertical slice (Phase 6) exists early**; integration checks run in every phase, not at the end. Module priority order is preserved (Campaign → Funnel → SEO → Website → Blog → Social) and no functionality is dropped to make phases easier.

**Every phase ends with:** (1) the phase-specific tests; (2) `scripts/check --fast` (unit + integration + API tests for everything implemented so far, type-check/build for the frontend if touched); (3) an Alembic revision + upgrade test if the schema changed; (4) `scripts/run_traceability` and an updated matrix; (5) updates to `IMPLEMENTATION_CHECKLIST.md` and `docs/BUILD_STATE.md`; (6) a Git commit. A dependent phase may not start while its prerequisite gate fails. Phases that complete a module also run that module's acceptance gate (15.12); the final phase re-runs **all** module gates, so module gates are a subset of, never a substitute for, phase gates.

| Phase | Scope (one vertical increment) | Depends on | Gate |
|---|---|---|---|
| 1 | Foundation: toolchain check, repo structure, `.gitignore`, `.env.example`, backend + frontend skeletons, `/api/health` identity payload, Vite proxy + CORS, Alembic baseline, minimal `setup`/`start` scripts with port checks | — | Fresh setup works; UI shows backend connected; migration fresh-create/re-run tests pass |
| 2 | Core platform: standard error format, logging + redaction, `Host`/`Origin`/body-size protections, idempotency (2.5), process lock + startup order + controlled shutdown (2.6) | 1 | Idempotency and process-model tests pass |
| 3 | Job engine: state machine, claiming, heartbeats/watchdog, cancellation, recovery, retry-as-new-execution (2.3), `WorkflowRun` log | 2 | Full 15.13 job-engine tests pass |
| 4 | AI layer: provider abstraction, MockProvider + failure plans, structured-output validation, retry budget (3.4), `OutputVersion` provenance/versioning (3.2, 3.5), provider health checks, settings API | 3 | Provider, budget, secret-redaction, versioning-integrity tests pass |
| 5 | Frontend shell + shared services: layout/nav in catalogue order, API client, shared components, dashboard shell, settings page; content-status module, health-claims scanner, shared reporting utilities + `₹` font + export lifecycle (2.7), demo-data framework (3.6) | 4 | `tsc` + build + frontend tests; export-reliability tests pass |
| 6 | **Campaign vertical slice:** models + migration, brief form + demo brief, validation, normalization, date semantics, stages 1–3 through the real job engine, stage timeline UI, persistence across restart, one CSV export | 5 | Demo-brief validation test; slice journey tests (open→validate→run→observe→reopen after restart) pass |
| 7 | Campaign stages 4–5, output editing with versions, dependency graph + invalidation | 6 | Dependency/invalidation, versioning, edit tests pass |
| 8 | Campaign stages 6–7 (Google/Meta proposals, character-limit validation) | 7 | Stage tests + limit tests pass |
| 9 | Shared social-content service + campaign stages 8–10 (social plan, UTM/tracking, budget allocation) | 8 | Budget, date, UTM, cadence tests pass |
| 10 | Campaign stages 11–12: QA rules, pack, PDF/XLSX/CSV exports, history, retry/cancel UI | 9 | **Module 1 gate (M1-AC01–AC12)** passes |
| 11 | Funnel: models + migration, config, graph model, validation rules, deterministic layout, graph integrity (6.8) | 5 | Rules V01–V14 and integrity tests pass |
| 12 | Funnel: execution (7 stages), node content, dependency behavior, campaign context contract, exports | 10, 11 | Funnel execution/export tests pass |
| 13 | Funnel: interactive diagram + list view + editing UI | 12 | **Module 2 gate (M2-AC01–AC09)** passes |
| 14 | Crawl infrastructure: fetcher, SSRF guard, robots/sitemap parsing, bundled demo site + narrow allowlist, evidence model + coverage (7.1) | 5 | SSRF, crawl-limit, allowlist tests pass |
| 15 | SEO audit rules, report, exports, triage, linked retry runs | 14 | **Module 3 gate (M3-AC01–AC12)** passes |
| 16 | Website intelligence analyzer, report, exports | 14 | **Module 4 gate (M4-AC01–AC09)** passes |
| 17 | Bulk blog generator | 5 | **Module 5 gate (M5-AC01–AC09)** passes |
| 18 | Social module UI: cadence, calendar editing/rescheduling, exports | 9 | **Module 6 gate (M6-AC01–AC10)** passes |
| 19 | Optional Ollama + Gemini providers (mocked-HTTP tests; clear errors) | 4 | Core works without them; provider error tests pass |
| 20 | Integration: dashboard with real data, cross-module contracts, offline demo mode (15.16), responsive + accessibility pass, docs and `check_docs` | 10, 13, 15–18 | Smoke test (15.8) passes |
| 21 | Full verification: `scripts/check` all green, clean-clone test, OS verification record, traceability clean, packaging (clean ZIP: no `.venv`, `node_modules`, `.env`, DB, backups, exports, caches, secrets) | 20 | Acceptance gate 15.10 and **all six module gates (15.12)** green; migration upgrade tests green; traceability has no unexplained `TESTING GAP`/`INSUFFICIENT COVERAGE`/`STALE` rows |

---

## 19. DEFINITION OF DONE

Fresh clone → setup → start → all six modules work in the browser with real stored data and each passes its acceptance gate (15.12); the Campaign Intelligence and Funnel Builder demos run end to end with the mock provider and export valid files; core local workflows complete with no paid API key and no internet when the mock provider and local data are used (network-dependent operations are clearly identified and fail with actionable errors); `scripts/check` is green with output quoted; optional integrations (Ollama, Gemini, Search Console, PageSpeed, Meta, LinkedIn, ad-platform APIs) are separate, documented, and never required; progress files are current and honest.

## 20. SECURITY AND PRIVACY NOTES FOR DOCS
Local data stays on the machine; briefs, crawled content, and exports are stored unencrypted in the local DB/export directory (document this); hosted providers receive the prompt contents you send them (document this).

## 21. FINAL REPORT FORMAT

(1) Exact start commands; (2) table of every verification with command + PASS/FAIL/NOT RUN, plus the traceability summary (commit hash of the verifying run; `TESTING GAP`/`INSUFFICIENT COVERAGE`/`STALE` rows) and the OSes on which scripts were actually run; (3) unverified items and why; (4) deviations from this prompt; (5) known limitations; (6) assumptions made; (7) recommended next steps.

## 22. ARCHITECTURAL DECISIONS AND RESOLVED CONTRADICTIONS (v6)

| # | Potential conflict | Decision |
|---|---|---|
| 1 | Terminal-state immutability vs retry | Terminal execution rows never change; retry creates a **new linked execution** with `CARRIED_FORWARD` stages referencing prior outputs (2.3). Applies to all modules, including linked audit runs and blog retry batches. |
| 2 | "Outdated" stage state vs immutable executions | `is_outdated` is a flag on mutable **current-state records**, not a job state; historical rows are never touched (2.3, 5.5). |
| 3 | Campaign `DRAFT`/`READY` vs job states | Record lifecycle status is a derived mirror; job states are `PENDING`…`CANCELLED` (2.3, 5.3). |
| 4 | Idempotency vs manual retries and one-active-execution | A retry is a distinct operation with its own key; the active-execution rule always wins; same key replays, new key during an active run → 409 (2.5). |
| 5 | Automatic provider retries vs stage/job retries | Automatic retries only at the provider-call layer under one per-stage and per-execution call budget; manual retries get fresh budgets with a lineage cap (3.4). |
| 6 | Cancellation vs stage commit | Point of no return = commit of the last required output; earlier cancel discards in-flight results, preserves committed ones (2.3). |
| 7 | Migrations vs startup lock | Lock first, migrate under the lock, workers start only afterward (2.6, 2.4). |
| 8 | Backup/restore vs failed migration | Migrate a verified **copy** then swap atomically; failure leaves the original byte-identical, proven by tests (2.4). |
| 9 | Restart recovery vs `PENDING` jobs | `PENDING` stays claimable; `RUNNING`/stale → `FAILED/INTERRUPTED` retryable; in-flight AI requests never assumed complete (2.6). |
| 10 | Versioning vs downstream invalidation | Invalidate only when the active version changes; no-op edits do nothing; failed regeneration keeps the last valid version (3.5). |
| 11 | Funnel layout vs semantic edits | Layout patches never bump `graph_version` or invalidate; semantic edits do, with optimistic concurrency (6.8). |
| 12 | SEO evidence immutability vs triage | Evidence rows immutable; triage in a separate mutable table (7.1). |
| 13 | Demo-site allowlist vs SSRF | Exact `127.0.0.1:DEMO_SITE_PORT` only, re-checked on every redirect hop, all other rules intact and tested (7.1). |
| 14 | Demo cleanup vs relationships | Delete by explicit demo ID set with own descendants; refuse (409) if real records reference demo ones (3.6). |
| 15 | Module gates vs phase gates | Module gates are subsets of phase gates; the last phase re-runs all (18). |
| 16 | `COMPLETE` vs traceability script | Statuses are **generated** from real test results at the current commit; hand-set `VERIFIED` fails the script (17.1). |
| 17 | Report generation vs concurrent DB changes | Exports read one consistent snapshot and record source versions; UI shows export vs current version (2.7, 3.5, 6.8). |

**Unresolved ambiguities to record in `docs/ARCHITECTURE.md` if encountered (do not guess silently):** exact numeric defaults for `STALE_AFTER_SECONDS`/`JOB_MAX_DURATION_SECONDS` on slow hardware (defaults are starting points — tune and record); choice of the OS-lock library (pinned pure-Python vs stdlib); whether `@xyflow/react` installs cleanly (else custom SVG, 6.6).

---

**BEGIN NOW.** Inspect the working directory and detect the toolchain. If empty, write the plan and `IMPLEMENTATION_CHECKLIST.md`, then start Phase 1. If files exist, resume at the first incomplete task. Work phase by phase in small increments (Section 18). Do not stop until the Phase 21 gate passes or you hit a blocker you must report.
