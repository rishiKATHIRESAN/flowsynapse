"""Create a committed per-phase DB snapshot with seeded rows (for upgrade tests).

Usage (from backend/): .venv/Scripts/python -m tests.fixtures.make_snapshot <name> <revision>
Seeds use raw SQL so they stay valid for the schema at that revision.
"""
import sqlite3
import sys
from pathlib import Path

from alembic import command

from app.migrations import alembic_config

SEEDS: dict[str, list[str]] = {
    "app_settings": [
        "INSERT INTO app_settings(key,value,created_at,updated_at) VALUES ('ai_provider','mock','2026-10-21 00:00:00','2026-10-21 00:00:00')",
        "INSERT INTO app_settings(key,value,created_at,updated_at) VALUES ('seed_marker','snapshot','2026-10-21 00:00:00','2026-10-21 00:00:00')",
    ],
    "idempotency_keys": [
        "INSERT INTO idempotency_keys(id,key,scope,operation,request_fingerprint,state,response_status,response_body,created_at,expires_at) "
        "VALUES ('k1','key-1','POST /api/x {}','create','fp','COMPLETED',201,'{}','2026-10-21 00:00:00','2026-10-22 00:00:00')",
    ],
    "executions": [
        "INSERT INTO executions(id,parent_type,parent_id,scope,status,attempt_number,params,cancel_requested,ai_calls_used,"
        "is_mock,is_demo,warnings_count,created_at,row_version,provider) VALUES "
        "('e1','testjob','p1','FULL','COMPLETED',1,'{}',0,2,1,0,0,'2026-10-21 00:00:00',3,'mock')",
        "INSERT INTO executions(id,parent_type,parent_id,scope,status,attempt_number,params,cancel_requested,ai_calls_used,"
        "is_mock,is_demo,warnings_count,created_at,row_version,provider) VALUES "
        "('e2','testjob','p2','FULL','PENDING',1,'{}',0,0,1,0,0,'2026-10-21 00:00:01',1,'mock')",
    ],
    "execution_stages": [
        "INSERT INTO execution_stages(id,execution_id,stage_key,item_id,position,status,required,attempt_count,ai_calls_used,output_ref) "
        "VALUES ('s1','e1','S1','',0,'COMPLETED',1,1,1,'{\"x\":1}')",
        "INSERT INTO execution_stages(id,execution_id,stage_key,item_id,position,status,required,attempt_count,ai_calls_used) "
        "VALUES ('s2','e2','S1','',0,'PENDING',1,1,0)",
    ],
    "workflow_runs": [
        "INSERT INTO workflow_runs(id,module,parent_type,parent_id,execution_id,title,status,scope,is_mock,is_demo,created_at) "
        "VALUES ('w1','test','testjob','p1','e1','t','COMPLETED','FULL',1,0,'2026-10-21 00:00:00')",
    ],
    "outputs": [
        "INSERT INTO outputs(id,parent_type,parent_id,output_type,item_key,position,content,active_version_id,version_number,"
        "generation_status,is_outdated,validity,is_discarded,is_demo,created_at,updated_at) VALUES "
        "('o1','campaign','c1','objective_analysis','',0,'{\"a\":1}','v1',1,'COMPLETED',0,'VALID',0,0,'2026-10-21 00:00:00','2026-10-21 00:00:00')",
    ],
    "output_versions": [
        "INSERT INTO output_versions(id,output_id,output_type,parent_type,parent_id,version_number,is_active,content,content_hash,"
        "origin,provider,is_mock,created_at) VALUES ('v1','o1','objective_analysis','campaign','c1',1,1,'{\"a\":1}','h',"
        "'MOCK_GENERATED','mock',1,'2026-10-21 00:00:00')",
    ],
    "file_exports": [
        "INSERT INTO file_exports(id,module,parent_type,parent_id,format,status,is_demo,is_stale,created_at) VALUES "
        "('f1','campaigns','campaign','c1','csv','FAILED',0,0,'2026-10-21 00:00:00')",
    ],
    "campaigns": [
        "INSERT INTO campaigns(id,identifier,name,brief_original,brief_valid,content_version,brief_version,is_demo,created_at,updated_at) "
        "VALUES ('c1','CMP-SNAP-1','Snapshot campaign','{}',0,1,1,0,'2026-10-21 00:00:00','2026-10-21 00:00:00')",
    ],
    "campaign_stage_states": [
        "INSERT INTO campaign_stage_states(campaign_id,stage_key,is_outdated) VALUES ('c1','STRATEGY',1)",
    ],
}
EXTRA: dict[str, list[str]] = {}


def main() -> None:
    name, rev = sys.argv[1], sys.argv[2]
    p = Path(__file__).parent / "db_snapshots" / f"{name}.db"
    if p.exists():
        p.unlink()
    command.upgrade(alembic_config("sqlite:///" + p.resolve().as_posix()), rev)
    con = sqlite3.connect(p)
    con.execute("PRAGMA foreign_keys=ON")
    tables = {r[0] for r in con.execute("select name from sqlite_master where type='table'")}
    for table, stmts in {**SEEDS, **EXTRA}.items():
        if table in tables:
            for s in stmts:
                con.execute(s)
    con.commit()
    con.execute("PRAGMA journal_mode=DELETE")
    con.close()
    print(p)


if __name__ == "__main__":
    main()
