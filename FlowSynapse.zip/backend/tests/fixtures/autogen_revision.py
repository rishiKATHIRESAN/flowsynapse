"""Autogenerate a revision against a temp DB at current head: autogen.py <rev_id> <message>"""
import sys, tempfile, pathlib
from alembic import command
from app.migrations import alembic_config
d = pathlib.Path(tempfile.mkdtemp()) / "ag.db"
url = "sqlite:///" + d.as_posix()
command.upgrade(alembic_config(url), "head")
command.revision(alembic_config(url), message=sys.argv[2], autogenerate=True, rev_id=sys.argv[1])
