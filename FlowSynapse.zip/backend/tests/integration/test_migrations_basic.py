import sqlite3

import pytest

from app.migrations import check_drift, code_head, code_heads, db_revision, safe_migrate


@pytest.mark.req("FS-SYS-010", kind="integration")
def test_fresh_create_reaches_head(settings):
    res = safe_migrate(settings)
    assert res.action == "fresh"
    assert db_revision(settings.db_path) == code_head()
    con = sqlite3.connect(settings.db_path)
    tables = {r[0] for r in con.execute("select name from sqlite_master where type='table'")}
    con.close()
    assert "app_settings" in tables and "alembic_version" in tables


@pytest.mark.req("FS-SYS-010", kind="integration")
def test_rerun_is_idempotent(settings):
    safe_migrate(settings)
    res = safe_migrate(settings)
    assert res.action == "up_to_date"
    assert db_revision(settings.db_path) == code_head()


@pytest.mark.req("FS-SYS-010", kind="unit")
def test_single_alembic_head():
    assert len(code_heads()) == 1


@pytest.mark.req("FS-SYS-010", kind="integration")
def test_no_schema_drift_after_fresh_create(settings):
    safe_migrate(settings)
    assert check_drift(settings.db_path) == []
