"""Process lock, startup order and controlled shutdown (master prompt 2.6)."""
from __future__ import annotations

import json
import sqlite3
import subprocess
import sys
import time
from pathlib import Path

import pytest

from app.process_lock import LockHeldError, ProcessLock, read_lock_info
from app.runtime import Runtime, StartupError

BACKEND = Path(__file__).resolve().parents[2]


@pytest.mark.req("FS-SYS-007", kind="integration+negative")
def test_second_instance_is_refused(tmp_path):
    p = tmp_path / "flowsynapse.lock"
    a = ProcessLock(p)
    a.acquire(port=8000)
    try:
        with pytest.raises(LockHeldError) as ei:
            ProcessLock(p).acquire()
        assert "Another FlowSynapse backend" in str(ei.value)
        assert str(read_lock_info(p)["pid"]) in str(ei.value)
    finally:
        a.release()


@pytest.mark.req("FS-SYS-007", kind="integration")
def test_lock_released_after_clean_exit(tmp_path):
    p = tmp_path / "flowsynapse.lock"
    with ProcessLock(p):
        pass
    b = ProcessLock(p)
    b.acquire()
    assert b.held
    b.release()


@pytest.mark.req("FS-SYS-007", kind="integration")
def test_lock_released_after_process_is_killed(tmp_path):
    p = tmp_path / "flowsynapse.lock"
    code = (
        "import sys,time; sys.path.insert(0, r'%s');"
        "from pathlib import Path; from app.process_lock import ProcessLock;"
        "l=ProcessLock(Path(r'%s')); l.acquire(); print('LOCKED', flush=True); time.sleep(60)"
    ) % (BACKEND, p)
    proc = subprocess.Popen([sys.executable, "-c", code], stdout=subprocess.PIPE, text=True)
    try:
        assert proc.stdout is not None
        assert proc.stdout.readline().strip() == "LOCKED"
        with pytest.raises(LockHeldError):
            ProcessLock(p).acquire()
    finally:
        proc.kill()
        proc.wait(timeout=10)
    deadline = time.monotonic() + 5
    while True:
        try:
            lk = ProcessLock(p)
            lk.acquire()
            lk.release()
            break
        except LockHeldError:
            if time.monotonic() > deadline:
                raise
            time.sleep(0.1)


@pytest.mark.req("FS-SYS-007", kind="integration")
def test_stale_lock_file_without_held_lock_is_acquired(tmp_path):
    p = tmp_path / "flowsynapse.lock"
    p.write_text(json.dumps({"pid": 999999, "started_at": "2020-01-01"}))
    lk = ProcessLock(p)
    lk.acquire()
    assert read_lock_info(p)["pid"] != 999999
    lk.release()


class _Svc:
    def __init__(self, log: list[str], name: str) -> None:
        self.log, self.name = log, name

    def start(self) -> None:
        self.log.append(f"start:{self.name}")

    def stop(self, grace: float) -> None:
        self.log.append(f"stop:{self.name}")


@pytest.mark.req("FS-SYS-007", kind="integration+negative")
def test_startup_aborts_without_starting_workers_if_migration_refused(settings):
    settings.db_path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(settings.db_path)
    con.execute("create table alembic_version (version_num varchar(32) not null)")
    con.execute("insert into alembic_version values ('9999_future')")
    con.commit()
    con.close()
    events: list[str] = []
    rt = Runtime(settings)
    rt.service_factories.append(lambda _rt: _Svc(events, "workers"))
    rt.recovery_hooks.append(lambda: events.append("recovery"))
    with pytest.raises(StartupError):
        rt.startup()
    assert events == []
    assert rt.status == "error"
    assert not rt.lock.held
    # the lock is free again for a later start
    ProcessLock(settings.lock_path).acquire()


@pytest.mark.req("FS-SYS-007", kind="integration")
def test_startup_order_and_controlled_shutdown(settings):
    events: list[str] = []
    rt = Runtime(settings)
    rt.recovery_hooks.append(lambda: events.append("recovery"))
    rt.service_factories.append(lambda _rt: _Svc(events, "workers"))
    rt.service_factories.append(lambda _rt: _Svc(events, "maintenance"))
    rt.startup()
    assert rt.status == "ok" and rt.lock.held
    assert events == ["recovery", "start:workers", "start:maintenance"]
    # write something so the WAL has content
    from app.database import session_scope
    from app.models.settings import AppSetting

    with session_scope() as db:
        db.add(AppSetting(key="k", value="v"))
    rt.shutdown()
    assert events[-2:] == ["stop:maintenance", "stop:workers"]
    assert rt.status == "stopped" and not rt.lock.held
    wal = Path(str(settings.db_path) + "-wal")
    assert not wal.exists() or wal.stat().st_size == 0
    con = sqlite3.connect(settings.db_path)
    assert con.execute("select value from app_settings where key='k'").fetchone() == ("v",)
    con.close()


@pytest.mark.req("FS-SYS-007", kind="integration+negative")
def test_pending_migrations_with_auto_migrate_off_refuses(tmp_path):
    from tests.conftest import make_settings

    s = make_settings(tmp_path, AUTO_MIGRATE=False)
    rt = Runtime(s)
    with pytest.raises(Exception) as ei:
        rt.startup()
    assert "AUTO_MIGRATE=false" in str(ei.value)
    assert not rt.lock.held
