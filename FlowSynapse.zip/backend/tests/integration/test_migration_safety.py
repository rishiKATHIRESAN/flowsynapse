"""Safe migration procedure (master prompt 2.4 / 15.14)."""
from __future__ import annotations

import shutil
import sqlite3
from pathlib import Path

import pytest

from app import migrations as mig
from app.migrations import (
    MigrationError,
    NewerDatabaseError,
    code_head,
    db_revision,
    row_counts,
    safe_migrate,
    sha256_file,
)

SNAPSHOTS = Path(__file__).resolve().parent.parent / "fixtures" / "db_snapshots"


def _all_snapshots() -> list[Path]:
    return sorted(SNAPSHOTS.glob("phase*.db"))


def _install(snapshot: Path, settings) -> Path:
    settings.db_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(snapshot, settings.db_path)
    return settings.db_path


@pytest.fixture(autouse=True)
def _clear_hooks():
    yield
    mig.TEST_HOOKS.clear()


def _key_checksums(path: Path) -> dict[str, str]:
    con = sqlite3.connect(path)
    out = {}
    for (t,) in con.execute("select name from sqlite_master where type='table' and name not like 'sqlite_%' and name!='alembic_version'"):
        rows = con.execute(f'select * from "{t}" order by 1').fetchall()
        out[t] = str(hash(tuple(map(tuple, rows))))
    con.close()
    return out


@pytest.mark.req("FS-SYS-011", kind="integration")
@pytest.mark.parametrize("snapshot", _all_snapshots(), ids=lambda p: p.stem)
def test_upgrade_from_each_snapshot_preserves_rows(settings, snapshot):
    db = _install(snapshot, settings)
    before_counts = row_counts(db)
    before_sums = _key_checksums(db)
    res = safe_migrate(settings)
    if db_revision(snapshot) == code_head():
        assert res.action == "up_to_date"
    else:
        assert res.action == "upgraded" and res.backup is not None and res.backup.exists()
    assert db_revision(db) == code_head()
    after = row_counts(db)
    for t, n in before_counts.items():
        if t != "alembic_version":
            assert after[t] == n
    after_sums = _key_checksums(db)
    for t, s in before_sums.items():
        assert after_sums[t] == s, f"data changed in {t}"
    assert mig.fk_violations(db) == []
    assert mig.integrity_ok(db)
    assert mig.required_index_names() <= mig.existing_index_names(db)
    assert res.drift == []


@pytest.mark.req("FS-SYS-011", kind="integration+negative")
def test_injected_migration_failure_leaves_original_byte_identical(settings):
    db = _install(SNAPSHOTS / "phase01_0001_baseline.db", settings)
    checksum = sha256_file(db)

    def boom():
        raise RuntimeError("injected failure")

    mig.TEST_HOOKS["migrate"] = boom
    with pytest.raises(MigrationError) as ei:
        safe_migrate(settings)
    assert ei.value.step == "migrate"
    assert ei.value.backup is not None and ei.value.backup.exists()
    assert "restore-backup" in str(ei.value)
    assert sha256_file(db) == checksum
    assert not list(db.parent.glob("*.migrating*"))


@pytest.mark.req("FS-SYS-011", kind="integration+negative")
def test_failure_after_migration_before_swap_leaves_original(settings):
    db = _install(SNAPSHOTS / "phase01_0001_baseline.db", settings)
    checksum = sha256_file(db)
    mig.TEST_HOOKS["verify_migrated"] = lambda: (_ for _ in ()).throw(RuntimeError("verify failed"))
    with pytest.raises(MigrationError):
        safe_migrate(settings)
    assert sha256_file(db) == checksum
    assert not list(db.parent.glob("*.migrating*"))


@pytest.mark.req("FS-SYS-011", kind="integration+negative")
def test_backup_verification_failure_means_no_migration(settings):
    db = _install(SNAPSHOTS / "phase01_0001_baseline.db", settings)
    checksum = sha256_file(db)
    called = []
    mig.TEST_HOOKS["verify_backup"] = lambda: (_ for _ in ()).throw(RuntimeError("bad backup"))
    mig.TEST_HOOKS["migrate"] = lambda: called.append(1)
    with pytest.raises(MigrationError) as ei:
        safe_migrate(settings)
    assert ei.value.step == "verify_backup"
    assert called == []
    assert sha256_file(db) == checksum
    assert db_revision(db) == "0001_baseline"


@pytest.mark.req("FS-SYS-011", kind="integration+negative")
def test_insufficient_disk_aborts_without_change(settings, monkeypatch):
    db = _install(SNAPSHOTS / "phase01_0001_baseline.db", settings)
    checksum = sha256_file(db)
    monkeypatch.setattr(mig, "free_disk_bytes", lambda _p: 1024)
    with pytest.raises(MigrationError) as ei:
        safe_migrate(settings)
    assert ei.value.step == "disk_check"
    assert "insufficient free disk space" in str(ei.value)
    assert sha256_file(db) == checksum
    assert not settings.backups_dir.exists() or not list(settings.backups_dir.glob("*.db"))


@pytest.mark.req("FS-SYS-011", kind="integration+negative")
def test_newer_revision_database_is_refused_unchanged(settings):
    db = _install(SNAPSHOTS / "phase01_0001_baseline.db", settings)
    con = sqlite3.connect(db)
    con.execute("update alembic_version set version_num='9999_future'")
    con.commit()
    con.close()
    checksum = sha256_file(db)
    with pytest.raises(NewerDatabaseError):
        safe_migrate(settings)
    assert sha256_file(db) == checksum


@pytest.mark.req("FS-SYS-011", kind="integration")
def test_leftover_migrating_file_is_cleaned_up(settings):
    safe_migrate(settings)
    leftover = settings.db_path.with_name(settings.db_path.name + ".migrating")
    leftover.write_bytes(b"partial")
    res = safe_migrate(settings)
    assert res.action == "up_to_date"
    assert not leftover.exists()


@pytest.mark.req("FS-SYS-011", kind="integration")
def test_backup_retention_keeps_five_newest(settings):
    import os
    import time

    settings.backups_dir.mkdir(parents=True)
    for i in range(7):
        p = settings.backups_dir / f"flowsynapse_2026010{i}_x.db"
        p.write_bytes(b"x")
        os.utime(p, (time.time() - (10 - i) * 100, time.time() - (10 - i) * 100))
    removed = mig.prune_backups(settings)
    assert len(removed) == 2
    left = sorted(p.name for p in settings.backups_dir.glob("*.db"))
    assert left == [f"flowsynapse_2026010{i}_x.db" for i in range(2, 7)]


@pytest.mark.req("FS-SYS-012", kind="integration")
def test_restore_backup_round_trip(settings):
    db = _install(SNAPSHOTS / "phase01_0001_baseline.db", settings)
    res = safe_migrate(settings)
    backup = res.backup
    assert backup is not None
    con = sqlite3.connect(db)
    con.execute("insert into app_settings(key,value,created_at,updated_at) values ('after','1','2026-01-01','2026-01-01')")
    con.commit()
    con.close()
    safety = mig.restore_backup(backup, settings)
    assert safety.exists() and safety != db
    assert db_revision(db) == "0001_baseline"
    con = sqlite3.connect(db)
    keys = {r[0] for r in con.execute("select key from app_settings")}
    con.close()
    assert "after" not in keys and "seed_marker" in keys
    # and the restored DB upgrades again cleanly
    assert safe_migrate(settings).action == "upgraded"


@pytest.mark.req("FS-SYS-012", kind="integration+negative")
def test_restore_rejects_corrupt_backup(settings, tmp_path):
    safe_migrate(settings)
    bad = tmp_path / "bad.db"
    bad.write_bytes(b"not a database at all" * 100)
    with pytest.raises(Exception):
        mig.restore_backup(bad, settings)
    assert db_revision(settings.db_path) == code_head()
