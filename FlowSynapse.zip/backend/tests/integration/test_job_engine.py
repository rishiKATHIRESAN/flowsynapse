"""Job engine behaviour with real SQLite (master prompt 2.3, 2.6, 15.13)."""
from __future__ import annotations

import itertools
import json
import sqlite3
import threading

import pytest
from sqlalchemy import select

from app.database import DatabaseBusyError, init_engine, new_session, session_scope, with_lock_retry
from app.models.jobs import Execution, ExecutionStage, WorkflowRun
from app.models.settings import AppSetting
from app.services.jobs import engine, recovery, worker
from app.services.jobs import state_machine as sm
from app.services.jobs.worker import ExecutionRunner, WorkerPool, try_claim, watchdog_tick
from app.utils.clock import clock, utcnow
from app.utils.errors import AppError
from tests import jobs_helpers as jh


@pytest.fixture
def handler(migrated_db):
    return jh.install()


@pytest.fixture
def pool(handler):
    p = WorkerPool(concurrency=2, watchdog_interval=3600)
    p.start()
    yield p
    handler.gate.set()
    p.stop(2)
    assert p.join(5)


def _run_inline(ex_id: str) -> None:
    claim = try_claim(ex_id, "inline")
    assert claim is not None
    ExecutionRunner(claim, threading.Event()).run()


# --------------------------------------------------------------------------
# state machine against the database
# --------------------------------------------------------------------------

@pytest.mark.req("FS-SYS-020", kind="integration")
def test_illegal_transitions_are_never_applied(handler):
    ex_id = jh.create()
    for frm, to in itertools.product(sm.EXECUTION_STATES, sm.EXECUTION_STATES):
        if sm.is_legal_execution(frm, to):
            continue
        with pytest.raises(sm.IllegalTransition):
            with session_scope(immediate=True) as db:
                sm.transition_execution(db, ex_id, frm, to)
    ex, _ = jh.get(ex_id)
    assert ex.status == "PENDING" and ex.row_version == 1


@pytest.mark.req("FS-SYS-024", kind="integration")
def test_terminal_execution_rows_never_mutate(handler):
    ex_id = jh.create()
    _run_inline(ex_id)
    before, stages_before = jh.get(ex_id)
    assert before.status == "COMPLETED"
    for to in sm.EXECUTION_STATES:
        with pytest.raises(sm.IllegalTransition):
            with session_scope(immediate=True) as db:
                sm.transition_execution(db, ex_id, "COMPLETED", to)
    with session_scope(immediate=True) as db:
        assert not sm.update_running_execution(db, ex_id, before.claim_token or "", error_code="X")
    after, stages_after = jh.get(ex_id)
    assert after.row_version == before.row_version and after.finished_at == before.finished_at
    assert [s.status for s in stages_after] == [s.status for s in stages_before]


# --------------------------------------------------------------------------
# full runs, ordering, persistence
# --------------------------------------------------------------------------

@pytest.mark.req("FS-SYS-021", kind="integration")
def test_pool_runs_stages_in_order_with_timestamps(handler, pool):
    ex_id = jh.create()
    ex = jh.wait_terminal(ex_id)
    assert ex.status == "COMPLETED"
    _, stages = jh.get(ex_id)
    assert [s.stage_key for s in stages] == jh.STAGES
    assert all(s.status == "COMPLETED" and s.started_at and s.finished_at for s in stages)
    assert stages[0].finished_at <= stages[1].started_at <= stages[2].started_at
    assert handler.calls == jh.STAGES
    with new_session() as db:
        run = db.execute(select(WorkflowRun).where(WorkflowRun.execution_id == ex_id)).scalar_one()
        assert run.status == "COMPLETED" and run.finished_at is not None
        outputs = db.execute(select(AppSetting.key)).scalars().all()
    assert len(outputs) == 3


@pytest.mark.req("FS-SYS-021", kind="integration+negative")
def test_one_active_execution_per_parent(handler):
    jh.create("same")
    with pytest.raises(AppError) as ei:
        jh.create("same")
    assert ei.value.status_code == 409 and ei.value.code == "EXECUTION_ALREADY_ACTIVE"


@pytest.mark.req("FS-SYS-021", kind="integration+negative")
def test_partial_unique_index_enforced_by_database(handler, migrated_db):
    jh.create("dbguard")
    con = sqlite3.connect(migrated_db.db_path)
    with pytest.raises(sqlite3.IntegrityError):
        con.execute(
            "insert into executions(id,parent_type,parent_id,scope,status,attempt_number,params,cancel_requested,"
            "ai_calls_used,is_mock,is_demo,warnings_count,created_at,row_version) values "
            "('x','testjob','dbguard','FULL','RUNNING',1,'{}',0,0,0,0,0,'2026-01-01',1)"
        )
    con.close()


@pytest.mark.req("FS-SYS-021", kind="integration")
def test_parallel_starts_exactly_one_succeeds(handler):
    results: list[str] = []
    barrier = threading.Barrier(6)

    def go() -> None:
        barrier.wait()
        try:
            jh.create("race")
            results.append("ok")
        except AppError as e:
            results.append(e.code)

    ts = [threading.Thread(target=go) for _ in range(6)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    assert results.count("ok") == 1
    assert set(results) - {"ok"} == {"EXECUTION_ALREADY_ACTIVE"}


@pytest.mark.req("FS-SYS-021", kind="integration+negative")
def test_queue_cap_returns_429(handler, settings):
    settings.MAX_QUEUED_JOBS = 2
    jh.create("q1")
    jh.create("q2")
    with pytest.raises(AppError) as ei:
        jh.create("q3")
    assert ei.value.status_code == 429 and ei.value.code == "QUEUE_FULL"


@pytest.mark.req("FS-SYS-021", kind="integration")
def test_two_workers_racing_claim_exactly_one(handler):
    ex_id = jh.create()
    claims: list[object] = []
    barrier = threading.Barrier(4)

    def go(i: int) -> None:
        barrier.wait()
        claims.append(try_claim(ex_id, f"w{i}"))

    ts = [threading.Thread(target=go, args=(i,)) for i in range(4)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    winners = [c for c in claims if c is not None]
    assert len(winners) == 1


@pytest.mark.req("FS-SYS-021", kind="integration+negative")
def test_lost_claim_token_cannot_write(handler):
    ex_id = jh.create()
    claim = try_claim(ex_id, "w")
    assert claim is not None
    with session_scope(immediate=True) as db:
        assert not sm.update_running_execution(db, ex_id, "wrong-token", error_code="HACK")
    with pytest.raises(sm.IllegalTransition):
        with session_scope(immediate=True) as db:
            sm.transition_execution(db, ex_id, "RUNNING", "COMPLETED", claim_token="wrong-token")
    ex, _ = jh.get(ex_id)
    assert ex.status == "RUNNING" and ex.error_code is None


# --------------------------------------------------------------------------
# failures, retry lineage
# --------------------------------------------------------------------------

@pytest.mark.req("FS-SYS-025", kind="integration+negative")
def test_stage_failure_preserves_earlier_outputs(handler):
    handler.behaviour["S2"] = "fail"
    ex_id = jh.create()
    _run_inline(ex_id)
    ex, stages = jh.get(ex_id)
    assert ex.status == "FAILED" and ex.error_code == "TEST_FAILURE" and ex.retryable
    assert [s.status for s in stages] == ["COMPLETED", "FAILED", "SKIPPED"]
    assert stages[0].output_ref
    with new_session() as db:
        assert len(db.execute(select(AppSetting)).scalars().all()) == 1


@pytest.mark.req("FS-SYS-024", kind="integration")
def test_retry_creates_new_execution_with_carried_forward_stages(handler):
    handler.behaviour["S2"] = "fail"
    first = jh.create()
    _run_inline(first)
    before, before_stages = jh.get(first)
    handler.behaviour.clear()
    handler.calls.clear()
    with session_scope(immediate=True) as db:
        prev = db.get(Execution, first)
        created = engine.create_retry_execution(db, prev, rerun={("S2", "")}, scope="STAGE_RETRY")
        retry_id = created.execution.id
    retry, rstages = jh.get(retry_id)
    assert retry.retry_of_execution_id == first and retry.attempt_number == 2 and retry.scope == "STAGE_RETRY"
    assert [s.status for s in rstages] == ["CARRIED_FORWARD", "PENDING", "PENDING"]
    assert rstages[0].carried_from_stage_id == before_stages[0].id
    assert rstages[0].output_ref == before_stages[0].output_ref
    _run_inline(retry_id)
    retry, rstages = jh.get(retry_id)
    assert retry.status == "COMPLETED"
    assert handler.calls == ["S2", "S3"]  # S1 not recomputed
    assert rstages[1].attempt_count == 2
    after, after_stages = jh.get(first)
    assert after.row_version == before.row_version and after.status == "FAILED"
    assert [(s.status, s.output_ref) for s in after_stages] == [(s.status, s.output_ref) for s in before_stages]


@pytest.mark.req("FS-SYS-024", kind="integration+negative")
def test_retry_lineage_cap(handler, settings):
    settings.JOB_MAX_ATTEMPTS = 2
    handler.behaviour["S1"] = "fail"
    first = jh.create()
    _run_inline(first)
    with session_scope(immediate=True) as db:
        r = engine.create_retry_execution(db, db.get(Execution, first), rerun=set(), scope="STAGE_RETRY")
        second = r.execution.id
    _run_inline(second)
    with pytest.raises(AppError) as ei:
        with session_scope(immediate=True) as db:
            engine.create_retry_execution(db, db.get(Execution, second), rerun=set(), scope="STAGE_RETRY")
    assert ei.value.code == "RETRY_LIMIT_REACHED"


@pytest.mark.req("FS-SYS-025", kind="integration+negative")
def test_commit_failure_never_yields_completed(handler):
    def boom(ctx):
        if ctx.stage_key == "S2":
            raise RuntimeError("disk full during commit")

    worker.TEST_HOOKS["before_commit"] = boom
    ex_id = jh.create()
    _run_inline(ex_id)
    ex, stages = jh.get(ex_id)
    assert ex.status == "FAILED"
    assert [s.status for s in stages] == ["COMPLETED", "FAILED", "SKIPPED"]
    with new_session() as db:
        keys = db.execute(select(AppSetting.key)).scalars().all()
    assert len(keys) == 1  # S2's output rolled back with its transition


@pytest.mark.req("FS-SYS-025", kind="integration+negative")
def test_worker_exception_marks_failed_non_retryable(handler):
    handler.behaviour["S3"] = "crash"
    ex_id = jh.create()
    _run_inline(ex_id)
    ex, stages = jh.get(ex_id)
    assert ex.status == "FAILED" and ex.error_code == "INTERNAL_ERROR" and ex.retryable is False
    assert "ZeroDivisionError" in (ex.error_message or "") and "boom" not in (ex.error_message or "")
    assert [s.status for s in stages] == ["COMPLETED", "COMPLETED", "FAILED"]


@pytest.mark.req("FS-SYS-025", kind="integration")
def test_independent_items_continue_after_failure(handler):
    handler.continue_items = True
    handler.behaviour["ITEM/b"] = "fail"
    ex_id = jh.create(stages=[], items=["a", "b", "c"])
    _run_inline(ex_id)
    ex, stages = jh.get(ex_id)
    assert [s.status for s in stages] == ["COMPLETED", "FAILED", "COMPLETED"]
    assert ex.status == "COMPLETED_WITH_WARNINGS" and ex.error_code == "PARTIAL_FAILURE"


# --------------------------------------------------------------------------
# cancellation races
# --------------------------------------------------------------------------

@pytest.mark.req("FS-SYS-023", kind="integration")
def test_cancel_before_claim(handler):
    ex_id = jh.create()
    with session_scope(immediate=True) as db:
        engine.request_cancel(db, ex_id)
    ex, stages = jh.get(ex_id)
    assert ex.status == "CANCELLED" and all(s.status == "CANCELLED" for s in stages)
    assert try_claim(ex_id, "w") is None


@pytest.mark.req("FS-SYS-023", kind="integration")
def test_cancel_mid_stage_discards_in_flight_and_preserves_committed(handler, pool):
    handler.behaviour["S2"] = "block"
    ex_id = jh.create()
    assert handler.entered.wait(5)
    with session_scope(immediate=True) as db:
        engine.request_cancel(db, ex_id)
    handler.gate.set()
    ex = jh.wait_terminal(ex_id)
    _, stages = jh.get(ex_id)
    assert ex.status == "CANCELLED"
    assert [s.status for s in stages] == ["COMPLETED", "CANCELLED", "CANCELLED"]
    with new_session() as db:
        keys = db.execute(select(AppSetting.key)).scalars().all()
    assert len(keys) == 1 and keys[0].endswith(":S1:")


@pytest.mark.req("FS-SYS-023", kind="integration+negative")
def test_cancel_after_final_commit_is_409(handler):
    ex_id = jh.create()
    _run_inline(ex_id)
    with pytest.raises(AppError) as ei:
        with session_scope(immediate=True) as db:
            engine.request_cancel(db, ex_id)
    assert ei.value.status_code == 409 and ei.value.code == "ALREADY_COMPLETED"
    assert jh.get(ex_id)[0].status == "COMPLETED"


@pytest.mark.req("FS-SYS-023", kind="integration")
def test_cancel_racing_last_stage_commit_is_deterministic(handler):
    """Cancel arriving while the last stage computes: cancel wins, never RUNNING."""

    def cancel_now(ctx):
        if ctx.stage_key == "S3":
            with session_scope(immediate=True) as db:
                engine.request_cancel(db, ctx.execution_id)

    worker.TEST_HOOKS["after_stage_returns"] = cancel_now
    ex_id = jh.create()
    _run_inline(ex_id)
    ex, stages = jh.get(ex_id)
    assert ex.status == "CANCELLED"
    assert [s.status for s in stages] == ["COMPLETED", "COMPLETED", "CANCELLED"]


# --------------------------------------------------------------------------
# heartbeat / watchdog (fake clock)
# --------------------------------------------------------------------------

@pytest.mark.req("FS-SYS-022", kind="integration")
def test_stale_heartbeat_marked_failed_exactly_once(handler, settings):
    clock.freeze(utcnow())
    ex_id = jh.create()
    claim = try_claim(ex_id, "stalled")
    assert claim is not None
    clock.advance(settings.STALE_AFTER_SECONDS - 1)
    assert watchdog_tick() == []
    clock.advance(2)
    assert watchdog_tick() == [(ex_id, "STALE_HEARTBEAT")]
    assert watchdog_tick() == []
    ex, stages = jh.get(ex_id)
    assert ex.status == "FAILED" and ex.error_code == "STALE_HEARTBEAT" and ex.retryable
    # the stalled worker wakes up: its writes are rejected and it abandons
    ExecutionRunner(claim, threading.Event()).run()
    assert jh.get(ex_id)[0].row_version == ex.row_version
    assert all(s.status in ("SKIPPED",) for s in stages)


@pytest.mark.req("FS-SYS-022", kind="integration")
def test_heartbeat_keeps_job_alive(handler, settings):
    clock.freeze(utcnow())
    ex_id = jh.create()
    claim = try_claim(ex_id, "w")
    assert claim is not None
    clock.advance(settings.STALE_AFTER_SECONDS - 5)
    assert worker.heartbeat(claim)
    clock.advance(10)
    assert watchdog_tick() == []


@pytest.mark.req("FS-SYS-022", kind="integration")
def test_max_duration_timeout(handler, settings):
    clock.freeze(utcnow())
    settings.JOB_MAX_DURATION_SECONDS = 100
    ex_id = jh.create()
    claim = try_claim(ex_id, "w")
    assert claim is not None
    for _ in range(4):
        clock.advance(30)
        worker.heartbeat(claim)
    assert watchdog_tick() == [(ex_id, "TIMEOUT")]
    assert jh.get(ex_id)[0].error_code == "TIMEOUT"


# --------------------------------------------------------------------------
# recovery and shutdown
# --------------------------------------------------------------------------

@pytest.mark.req("FS-SYS-008", kind="integration")
def test_restart_recovery_running_failed_pending_untouched(handler):
    running = jh.create("r1")
    pending = jh.create("r2")
    claim = try_claim(running, "old-process")
    assert claim is not None
    # stage S1 completed before the "crash"
    with session_scope(immediate=True) as db:
        st = db.execute(select(ExecutionStage).where(ExecutionStage.execution_id == running, ExecutionStage.stage_key == "S1")).scalar_one()
        sm.transition_stage(db, st.id, "PENDING", "RUNNING", started_at=utcnow())
        sm.transition_stage(db, st.id, "RUNNING", "COMPLETED", finished_at=utcnow(), output_ref='{"x":1}')
        st2 = db.execute(select(ExecutionStage).where(ExecutionStage.execution_id == running, ExecutionStage.stage_key == "S2")).scalar_one()
        sm.transition_stage(db, st2.id, "PENDING", "RUNNING", started_at=utcnow())
    changed = recovery.recover_on_startup()
    assert changed == [running]
    ex, stages = jh.get(running)
    assert ex.status == "FAILED" and ex.error_code == "INTERRUPTED" and ex.retryable
    assert [s.status for s in stages] == ["COMPLETED", "FAILED", "SKIPPED"]
    assert stages[0].output_ref == '{"x":1}'
    assert jh.get(pending)[0].status == "PENDING"
    # the interrupted AI request is not resumed: the old claim cannot write
    ExecutionRunner(claim, threading.Event()).run()
    assert handler.calls == []
    # PENDING work is claimed normally once workers start
    p = WorkerPool(concurrency=1, watchdog_interval=3600)
    p.start()
    try:
        assert jh.wait_terminal(pending).status == "COMPLETED"
    finally:
        p.stop(2)
        assert p.join(5)


@pytest.mark.req("FS-SYS-007", kind="integration")
def test_controlled_shutdown_interrupts_running_work(handler):
    handler.behaviour["S2"] = "block"
    p = WorkerPool(concurrency=1, watchdog_interval=3600)
    p.start()
    ex_id = jh.create()
    assert handler.entered.wait(5)
    p.stop(0.2)
    ex, stages = jh.get(ex_id)
    assert ex.status == "FAILED" and ex.error_code == "INTERRUPTED" and ex.retryable
    assert stages[0].status == "COMPLETED"
    handler.gate.set()
    assert p.join(5)


# --------------------------------------------------------------------------
# SQLite contention
# --------------------------------------------------------------------------

@pytest.mark.req("FS-SYS-026", kind="integration")
def test_persistent_lock_surfaces_retryable_error(migrated_db, monkeypatch):
    from app import database

    monkeypatch.setattr(database, "BUSY_TIMEOUT_MS", 50)
    init_engine(migrated_db.database_url)
    blocker = sqlite3.connect(migrated_db.db_path, timeout=0.05)
    blocker.isolation_level = None
    blocker.execute("BEGIN IMMEDIATE")
    try:
        def write() -> None:
            with session_scope(immediate=True) as db:
                db.add(AppSetting(key="x", value="y"))

        with pytest.raises(DatabaseBusyError):
            with_lock_retry(write, attempts=3, base_delay=0.01)
    finally:
        blocker.execute("ROLLBACK")
        blocker.close()
    with_lock_retry(lambda: None)


@pytest.mark.req("FS-SYS-026", kind="integration")
def test_no_write_transaction_held_during_stage_compute(handler, migrated_db, monkeypatch):
    from app import database

    monkeypatch.setattr(database, "BUSY_TIMEOUT_MS", 100)
    init_engine(migrated_db.database_url)
    outcome: dict[str, object] = {}

    def second_connection_write(ctx):
        if ctx.stage_key != "S2":
            return
        con = sqlite3.connect(migrated_db.db_path, timeout=0.1)
        try:
            con.execute("insert into app_settings(key,value,created_at,updated_at) values ('concurrent','1','2026-01-01','2026-01-01')")
            con.commit()
            outcome["ok"] = True
        except sqlite3.OperationalError as e:
            outcome["ok"] = str(e)
        finally:
            con.close()

    handler.during = second_connection_write
    ex_id = jh.create()
    _run_inline(ex_id)
    assert outcome["ok"] is True
    assert jh.get(ex_id)[0].status == "COMPLETED"


@pytest.mark.req("FS-SYS-027", kind="integration")
def test_workflow_run_lists_each_execution(handler):
    a = jh.create("h1")
    _run_inline(a)
    handler.behaviour["S1"] = "fail"
    b = jh.create("h2")
    _run_inline(b)
    with new_session() as db:
        runs = {r.execution_id: r.status for r in db.execute(select(WorkflowRun)).scalars()}
    assert runs == {a: "COMPLETED", b: "FAILED"}
    _ = json  # keep import used in helpers
