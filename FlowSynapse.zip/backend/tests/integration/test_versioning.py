"""OutputVersion provenance and integrity (3.2, 3.5, 15.15)."""
from __future__ import annotations

import sqlite3
import threading

import pytest
from sqlalchemy import select

from app.database import new_session, session_scope
from app.models.outputs import Output, OutputVersion
from app.services.content import versioning as ver
from app.utils.errors import AppError

PROV_MOCK = ver.Provenance("mock", "mock-v1", True, None, "CONCEPTS", None, "cv-3")
PROV_AI = ver.Provenance("gemini", "g-1", False, None, "CONCEPTS", None, "cv-4")


def _create(content=None) -> str:
    with session_scope(immediate=True) as db:
        out, _ = ver.create_output(db, parent_type="campaign", parent_id="c1", output_type="concept",
                                   item_key="1", content=content or {"headline": "A"}, prov=PROV_MOCK,
                                   content_status="READY_TO_EXPORT")
        return out.id


def _versions(oid: str) -> list[OutputVersion]:
    with new_session() as db:
        return list(db.execute(select(OutputVersion).where(OutputVersion.output_id == oid)
                               .order_by(OutputVersion.version_number)).scalars())


@pytest.mark.req("FS-SYS-035", kind="integration")
def test_generation_records_full_provenance(migrated_db):
    oid = _create()
    (v,) = _versions(oid)
    assert (v.version_number, v.is_active, v.origin) == (1, True, "MOCK_GENERATED")
    assert (v.provider, v.model, v.is_mock, v.stage_key, v.source_input_version) == ("mock", "mock-v1", True, "CONCEPTS", "cv-3")
    assert v.generated_at is not None and v.original_generation_version_id == v.id


@pytest.mark.req("FS-SYS-035", kind="integration")
def test_manual_edit_keeps_original_provenance_and_resets_status(migrated_db):
    oid = _create()
    with session_scope(immediate=True) as db:
        out = db.get(Output, oid)
        v = ver.edit_output(db, out, {"headline": "B"}, 1, "tweak")
        assert v is not None
        assert ver.provenance_label(v, db) == "Mock-generated, edited by you"
        assert out.content_status == "DRAFT"
    v1, v2 = _versions(oid)
    assert v2.origin == "MANUALLY_EDITED" and v2.original_generation_version_id == v1.id and v2.is_active
    assert not v1.is_active and v2.previous_version_id == v1.id and v2.edit_summary == "tweak"


@pytest.mark.req("FS-SYS-035", kind="integration")
def test_noop_edit_creates_nothing(migrated_db):
    oid = _create({"headline": "A", "b": 1})
    with session_scope(immediate=True) as db:
        assert ver.edit_output(db, db.get(Output, oid), {"b": 1, "headline": "A"}, 1) is None
    assert len(_versions(oid)) == 1


@pytest.mark.req("FS-SYS-035", kind="integration")
def test_regeneration_keeps_history_and_records_new_provider(migrated_db):
    oid = _create()
    with session_scope(immediate=True) as db:
        ver.upsert_generated(db, parent_type="campaign", parent_id="c1", output_type="concept", item_key="1",
                             content={"headline": "C"}, prov=PROV_AI)
    v1, v2 = _versions(oid)
    assert v2.origin == "REGENERATED" and v2.provider == "gemini" and not v2.is_mock and v2.is_active
    assert v1.provider == "mock" and not v1.is_active


@pytest.mark.req("FS-SYS-035", kind="integration")
def test_regeneration_skips_manual_edits_unless_overwrite(migrated_db):
    oid = _create()
    with session_scope(immediate=True) as db:
        ver.edit_output(db, db.get(Output, oid), {"headline": "mine"}, 1)
    with session_scope(immediate=True) as db:
        _, v = ver.upsert_generated(db, parent_type="campaign", parent_id="c1", output_type="concept", item_key="1",
                                    content={"headline": "C"}, prov=PROV_AI, overwrite_edits=False)
        assert v is None
    assert len(_versions(oid)) == 2


@pytest.mark.req("FS-SYS-035", kind="integration")
def test_restore_creates_new_version(migrated_db):
    oid = _create()
    with session_scope(immediate=True) as db:
        out = db.get(Output, oid)
        ver.edit_output(db, out, {"headline": "B"}, 1)
        first = _versions(oid)[0]
        r = ver.restore_version(db, out, first.id, 2)
        assert r.version_number == 3 and r.origin == "MOCK_GENERATED" and "Restored from version 1" in r.edit_summary
    assert [v.version_number for v in _versions(oid)] == [1, 2, 3]
    with new_session() as db:
        assert db.get(Output, oid).content == first.content


@pytest.mark.req("FS-SYS-035", kind="integration+negative")
def test_failed_regeneration_keeps_previous_active_version(migrated_db):
    oid = _create()
    with pytest.raises(RuntimeError):
        with session_scope(immediate=True) as db:
            ver.upsert_generated(db, parent_type="campaign", parent_id="c1", output_type="concept", item_key="1",
                                 content={"headline": "new"}, prov=PROV_AI)
            raise RuntimeError("validation failed after insert")
    (v,) = _versions(oid)
    assert v.is_active and v.version_number == 1


@pytest.mark.req("FS-SYS-035", kind="integration+negative")
def test_database_rejects_two_active_versions(migrated_db):
    oid = _create()
    con = sqlite3.connect(migrated_db.db_path, isolation_level=None)
    con.execute("PRAGMA foreign_keys=ON")
    with pytest.raises(sqlite3.IntegrityError):
        con.execute(
            "insert into output_versions(id,output_id,output_type,parent_type,parent_id,version_number,is_active,content,"
            "content_hash,origin,is_mock,created_at) values ('x',?,'concept','campaign','c1',9,1,'{}','h','MOCK_GENERATED',1,'2026-01-01')",
            (oid,),
        )
    with pytest.raises(sqlite3.IntegrityError):
        con.execute(
            "insert into output_versions(id,output_id,output_type,parent_type,parent_id,version_number,is_active,content,"
            "content_hash,origin,is_mock,created_at) values ('y',?,'concept','campaign','c1',8,0,'{}','h','BOGUS',1,'2026-01-01')",
            (oid,),
        )
    with pytest.raises(sqlite3.IntegrityError):
        con.execute(
            "insert into output_versions(id,output_id,output_type,parent_type,parent_id,version_number,is_active,content,"
            "content_hash,origin,is_mock,created_at) values ('z','no-such-output','concept','campaign','c1',1,0,'{}','h','MOCK_GENERATED',1,'2026-01-01')"
        )
    con.close()


@pytest.mark.req("FS-SYS-036", kind="integration+negative")
def test_concurrent_edits_one_wins_one_conflicts(migrated_db):
    oid = _create()
    results: list[str] = []
    barrier = threading.Barrier(2)

    def edit(text: str) -> None:
        barrier.wait()
        try:
            with session_scope(immediate=True) as db:
                ver.edit_output(db, db.get(Output, oid), {"headline": text}, 1)
            results.append("ok")
        except AppError as e:
            results.append(e.code)

    ts = [threading.Thread(target=edit, args=(t,)) for t in ("X", "Y")]
    [t.start() for t in ts]
    [t.join() for t in ts]
    assert sorted(results) == ["VERSION_CONFLICT", "ok"]
    assert len(_versions(oid)) == 2


@pytest.mark.req("FS-SYS-035", kind="integration")
def test_retention_never_deletes_original_or_active(migrated_db, settings):
    settings.OUTPUT_VERSIONS_KEEP = 3
    oid = _create()
    for i in range(6):
        with session_scope(immediate=True) as db:
            out = db.get(Output, oid)
            ver.edit_output(db, out, {"headline": f"e{i}"}, out.version_number)
    vs = _versions(oid)
    nums = [v.version_number for v in vs]
    assert 1 in nums and 7 in nums and len(vs) == 4  # original + last 3
    assert sum(v.is_active for v in vs) == 1
