"""Export reliability (master prompt 2.7)."""
from __future__ import annotations

import csv
import io
import threading
import zipfile
from datetime import timedelta
from decimal import Decimal

import pytest
from openpyxl import load_workbook
from pypdf import PdfReader
from sqlalchemy import select

from app.database import new_session, session_scope
from app.models.exports import FileExport
from app.models.settings import AppSetting
from app.services.reporting import fonts, lifecycle
from app.services.reporting.document import (
    DEMO_BANNER,
    Chart,
    Dataset,
    ExportData,
    KeyValue,
    Paragraph,
    ReportDoc,
    Section,
    Table,
)
from app.services.reporting.lifecycle import (
    cleanup_exports,
    content_disposition,
    generate_export,
    safe_path,
    sanitize_download_name,
)
from app.utils.clock import clock, utcnow
from app.utils.errors import AppError

LONG_URL = "https://example.com/" + "very-long-path-segment-" * 20 + "?utm_source=x"


def _collect(rows=None, chart_fails=False, demo=True):
    def collect(db):
        amount = fonts.format_money(Decimal("15000"), "INR")
        doc = ReportDoc(
            title="Test Pack <script>alert(1)</script>",
            identifier="CMP-1",
            labels=[DEMO_BANNER] if demo else [],
            sections=[
                Section("Budget", [KeyValue([("Total", amount)]), Paragraph(LONG_URL),
                                   Table(["Channel", "Amount"], rows if rows is not None else [["google_ads", "₹9,000"]])]),
                Section("Chart", [Chart("Budget chart", (lambda: (_ for _ in ()).throw(RuntimeError("x"))) if chart_fails
                                         else (lambda: __import__("app.services.reporting.charts", fromlist=["x"]).bar_chart(["a"], [1], "t")))]),
                Section("Empty", []),
            ],
        )
        ds = [Dataset("Budget", ["channel", "amount", "note"],
                      rows if rows is not None else [["google_ads", "9000", "=HYPERLINK(\"http://evil\")"], ["meta_ads", "6000", "+cmd"]])]
        return ExportData(doc=doc, datasets=ds, download_base="be well/pack:demo?", source_version="7",
                          source_versions={"budget": "v1"}, is_demo=demo, labels=[DEMO_BANNER] if demo else [])

    return collect


def _gen(fmt, **kw):
    return generate_export(module="test", parent_type="t", parent_id="p1", fmt=fmt, collect=_collect(**kw))


@pytest.fixture(autouse=True)
def _fonts():
    fonts.reset_fonts_state()
    yield
    fonts.reset_fonts_state()
    lifecycle.TEST_HOOKS.clear()


@pytest.mark.req("FS-SYS-043", kind="integration")
def test_pdf_has_rupee_text_banner_and_escaped_text(migrated_db):
    row = _gen("pdf")
    assert row.status == "COMPLETED" and row.source_version == "7"
    path = safe_path(row.file_name)
    assert path.read_bytes().startswith(b"%PDF")
    text = "\n".join(p.extract_text() for p in PdfReader(str(path)).pages)
    assert "₹15,000" in text
    assert "DEMONSTRATION DATA" in text
    assert "<script>" in text  # rendered literally (escaped), not interpreted
    assert row.download_name == "be_well_pack_demo_.pdf"


@pytest.mark.req("FS-SYS-043", kind="integration")
def test_pdf_falls_back_to_inr_when_font_fails(migrated_db):
    fonts.register_fonts(force_fail=True)
    row = _gen("pdf")
    text = "\n".join(p.extract_text() for p in PdfReader(str(safe_path(row.file_name))).pages)
    assert "INR" in text and "15,000" in text


@pytest.mark.req("FS-SYS-043", kind="integration")
def test_chart_failure_gives_warning_not_silent_partial(migrated_db):
    row = _gen("pdf", chart_fails=True)
    assert row.status == "COMPLETED_WITH_WARNINGS"
    text = "\n".join(p.extract_text() for p in PdfReader(str(safe_path(row.file_name))).pages)
    assert "Section unavailable" in text


@pytest.mark.req("FS-SYS-043", kind="integration+negative")
def test_failed_export_leaves_no_file_and_failed_row(migrated_db):
    lifecycle.TEST_HOOKS["render"] = lambda fmt: (_ for _ in ()).throw(RuntimeError("disk"))
    with pytest.raises(AppError) as ei:
        _gen("xlsx")
    assert ei.value.code == "EXPORT_FAILED"
    with new_session() as db:
        rows = db.execute(select(FileExport)).scalars().all()
    assert [r.status for r in rows] == ["FAILED"]
    assert list(lifecycle.exports_dir().iterdir()) == []


@pytest.mark.req("FS-SYS-043", kind="integration")
def test_xlsx_and_csv_neutralize_formulas_and_keep_data(migrated_db):
    x = _gen("xlsx")
    wb = load_workbook(safe_path(x.file_name))
    assert "Summary" in wb.sheetnames and "Budget" in wb.sheetnames
    ws = wb["Budget"]
    vals = [[c.value for c in r] for r in ws.iter_rows()]
    assert vals[1][:2] == ["google_ads", "9000"]
    assert vals[1][2].startswith("'=") and vals[2][2] == "'+cmd"
    c = _gen("csv")
    raw = safe_path(c.file_name).read_bytes()
    assert raw.startswith(b"\xef\xbb\xbf")
    rows = list(csv.reader(io.StringIO(raw.decode("utf-8-sig"))))
    assert rows[0] == ["channel", "amount", "note"] and rows[1][2].startswith("'=")
    assert any(DEMO_BANNER in r[0] for r in rows)


@pytest.mark.req("FS-SYS-043", kind="integration")
def test_empty_dataset_and_zip(migrated_db):
    row = _gen("pdf", rows=[])
    assert row.status == "COMPLETED"
    z = _gen("zip")
    with zipfile.ZipFile(safe_path(z.file_name)) as zf:
        assert zf.testzip() is None and "budget.csv" in zf.namelist() and "README.txt" in zf.namelist()


@pytest.mark.req("FS-SYS-043", kind="unit+negative")
def test_path_traversal_and_name_sanitization(migrated_db):
    for bad in ("../../etc/passwd", "..\\..\\win.ini", "/abs/path"):
        with pytest.raises(AppError):
            safe_path(bad)
    assert sanitize_download_name('a<b>:"c|d?*.pdf') == "a_b_c_d_.pdf"
    assert sanitize_download_name("CON.pdf").startswith("export")
    assert len(sanitize_download_name("x" * 400 + ".pdf")) <= 120
    cd = content_disposition("रिपोर्ट ₹.pdf")
    assert "filename*=UTF-8''" in cd and "\n" not in cd


@pytest.mark.req("FS-SYS-043", kind="integration")
def test_concurrent_exports_get_unique_files(migrated_db):
    rows: list[FileExport] = []

    def go():
        rows.append(_gen("csv"))

    ts = [threading.Thread(target=go) for _ in range(4)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    names = {r.file_name for r in rows}
    assert len(names) == 4 and all(safe_path(n).exists() for n in names)


@pytest.mark.req("FS-SYS-043", kind="integration+negative")
def test_retention_skips_recently_accessed_and_purged_download_is_410(migrated_db):
    clock.freeze(utcnow())
    old = _gen("csv")
    fresh = _gen("csv")
    clock.advance(8 * 86400)
    with session_scope() as db:
        db.get(FileExport, fresh.id).last_accessed_at = utcnow() - timedelta(minutes=2)
    assert cleanup_exports() == 1
    assert not safe_path(old.file_name).exists() and safe_path(fresh.file_name).exists()
    with new_session() as db:
        r = db.get(FileExport, old.id)
        db.expunge(r)
    with pytest.raises(AppError) as ei:
        lifecycle.file_response(r)
    assert ei.value.status_code == 410 and ei.value.details == {"action": "regenerate"}


@pytest.mark.req("FS-SYS-043", kind="integration")
def test_snapshot_consistency_with_concurrent_edit(migrated_db):
    with session_scope() as db:
        db.add(AppSetting(key="budget", value="15000"))
    seen: list[str] = []

    def collect(db):
        seen.append(db.get(AppSetting, "budget").value)
        # a concurrent edit commits while the export is reading
        with session_scope(immediate=True) as other:
            other.get(AppSetting, "budget").value = "99999"
        db.expire_all()
        seen.append(db.execute(select(AppSetting.value).where(AppSetting.key == "budget")).scalar_one())
        return ExportData(doc=None, datasets=[Dataset("x", ["v"], [[seen[-1]]])], download_base="x")

    generate_export(module="test", parent_type="t", parent_id="p", fmt="csv", collect=collect)
    assert seen == ["15000", "15000"]
