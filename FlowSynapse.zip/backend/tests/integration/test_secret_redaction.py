"""A recognisable fake key never appears in responses, logs or the database (3.4)."""
from __future__ import annotations

import logging
import threading

import pytest
import requests
from pydantic import BaseModel

from app.ai import gemini_provider
from app.database import session_scope
from app.services.jobs import engine
from app.services.jobs.registry import BaseHandler, register, unregister
from app.services.jobs.worker import ExecutionRunner, try_claim

FAKE_KEY = "AIzaSyFAKEKEYforTESTING-0123456789abcd"


class Out(BaseModel):
    x: int


class AIHandler(BaseHandler):
    parent_type = "secrettest"
    module = "test"

    def run_stage(self, ctx):
        return ctx.ai.generate("T", Out, {"q": 1}, "do it")


def _resp(status, text):
    r = requests.Response()
    r.status_code = status
    r._content = text.encode()
    r.headers["Content-Type"] = "application/json"
    return r


SCENARIOS = {
    "401": lambda *a, **k: _resp(401, f'{{"error":"API key {FAKE_KEY} invalid"}}'),
    "429": lambda *a, **k: _resp(429, f'{{"error":"quota for key={FAKE_KEY}"}}'),
    "500": lambda *a, **k: _resp(500, f"internal {FAKE_KEY}"),
    "timeout": lambda *a, **k: (_ for _ in ()).throw(requests.Timeout(f"timeout ?key={FAKE_KEY}")),
    "network": lambda *a, **k: (_ for _ in ()).throw(requests.ConnectionError(f"https://x/?key={FAKE_KEY}")),
    "badshape": lambda *a, **k: _resp(200, f'{{"weird": "{FAKE_KEY}"}}'),
}


@pytest.mark.req("FS-SYS-034", kind="integration+negative")
@pytest.mark.parametrize("scenario", list(SCENARIOS))
def test_fake_key_never_leaks(scenario, migrated_db, monkeypatch, caplog, client=None):
    migrated_db.GEMINI_API_KEY = FAKE_KEY
    migrated_db.GEMINI_MODEL = "gemini-test"
    monkeypatch.setattr(requests.Session, "post", SCENARIOS[scenario])
    monkeypatch.setattr(requests.Session, "get", SCENARIOS[scenario])
    register(AIHandler())
    try:
        with session_scope(immediate=True) as db:
            ex = engine.create_execution(db, parent_type="secrettest", parent_id="p", stages=[engine.StageSpec("S1")],
                                         provider=engine.ProviderInfo("gemini", "gemini-test", False)).execution
            ex_id = ex.id
        with caplog.at_level(logging.DEBUG):
            claim = try_claim(ex_id, "w")
            ExecutionRunner(claim, threading.Event()).run()
            # also the health check path
            h = gemini_provider.GeminiProvider(FAKE_KEY, "gemini-test", 1).health_check()
        assert FAKE_KEY not in h.message and FAKE_KEY not in str(h.details)
        from app.services.jobs.engine import execution_to_dict
        from app.database import new_session

        with new_session() as db:
            payload = execution_to_dict(engine.load_execution(db, ex_id))
        assert payload["status"] == "FAILED"
        assert FAKE_KEY not in str(payload)
        assert FAKE_KEY not in caplog.text
        dump = "\n".join(__import__("sqlite3").connect(migrated_db.db_path).iterdump())
        assert FAKE_KEY not in dump
    finally:
        unregister("secrettest")
