"""Idempotency-Key behaviour (master prompt 2.5), service level with real SQLite."""
from __future__ import annotations

import threading
from datetime import timedelta

import pytest
from sqlalchemy import func, select

from app.database import new_session
from app.models.idempotency import IdempotencyKey
from app.models.settings import AppSetting
from app.services.idempotency import cleanup_expired, execute, fingerprint, validate_key
from app.utils.clock import clock, utcnow
from app.utils.errors import AppError

SCOPE = "POST /api/things {}"


def _create_op(name: str):
    def op(db):
        db.add(AppSetting(key=name, value="v"))
        db.flush()
        return 201, {"id": name}, "setting", name

    return op


def _count_settings() -> int:
    with new_session() as db:
        return db.execute(select(func.count()).select_from(AppSetting)).scalar_one()


@pytest.mark.req("FS-SYS-006", kind="integration")
def test_replay_returns_identical_response_and_creates_nothing(migrated_db):
    fp = fingerprint({"a": 1}, {})
    s1, b1, r1 = execute(SCOPE, "k1", "create", fp, _create_op("x1"))
    s2, b2, r2 = execute(SCOPE, "k1", "create", fp, _create_op("x2"))
    assert (s1, b1, r1) == (201, {"id": "x1"}, False)
    assert (s2, b2, r2) == (201, {"id": "x1"}, True)
    assert _count_settings() == 1


@pytest.mark.req("FS-SYS-006", kind="integration+negative")
def test_same_key_different_payload_is_rejected(migrated_db):
    execute(SCOPE, "k2", "create", fingerprint({"a": 1}, {}), _create_op("y1"))
    with pytest.raises(AppError) as ei:
        execute(SCOPE, "k2", "create", fingerprint({"a": 2}, {}), _create_op("y2"))
    assert ei.value.status_code == 422 and ei.value.code == "IDEMPOTENCY_KEY_REUSED"
    assert _count_settings() == 1


@pytest.mark.req("FS-SYS-006", kind="integration+negative")
def test_failed_request_frees_the_key(migrated_db):
    fp = fingerprint({"a": 1}, {})

    def failing(db):
        db.add(AppSetting(key="z", value="v"))
        db.flush()
        raise AppError(422, "VALIDATION_ERROR", "bad")

    with pytest.raises(AppError):
        execute(SCOPE, "k3", "create", fp, failing)
    assert _count_settings() == 0
    with new_session() as db:
        assert db.execute(select(func.count()).select_from(IdempotencyKey)).scalar_one() == 0
    s, b, replayed = execute(SCOPE, "k3", "create", fp, _create_op("z"))
    assert s == 201 and not replayed


@pytest.mark.req("FS-SYS-006", kind="integration")
def test_non_2xx_outcome_is_not_stored(migrated_db):
    fp = fingerprint({}, {})
    s, _, _ = execute(SCOPE, "k4", "create", fp, lambda db: (409, {"error": {}}, None, None))
    assert s == 409
    with new_session() as db:
        assert db.execute(select(func.count()).select_from(IdempotencyKey)).scalar_one() == 0


@pytest.mark.req("FS-SYS-006", kind="integration")
def test_concurrent_same_key_one_success_rest_replay(migrated_db):
    fp = fingerprint({"a": 1}, {})
    results: list[tuple[int, object, bool]] = []
    errors: list[BaseException] = []
    barrier = threading.Barrier(5)

    def worker(i: int) -> None:
        barrier.wait()
        try:
            results.append(execute(SCOPE, "same", "create", fp, _create_op(f"c{i}")))
        except AppError as e:
            errors.append(e)

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(5)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert _count_settings() == 1
    fresh = [r for r in results if not r[2]]
    assert len(fresh) == 1
    assert all(r[2] for r in results if r is not fresh[0])
    assert all(getattr(e, "code", "") == "IDEMPOTENCY_IN_PROGRESS" for e in errors)
    assert len(results) + len(errors) == 5


@pytest.mark.req("FS-SYS-006", kind="integration")
def test_key_scopes_are_independent(migrated_db):
    fp = fingerprint({}, {})
    execute("POST /a {}", "shared", "create", fp, _create_op("s1"))
    s, b, replayed = execute("POST /b {}", "shared", "create", fp, _create_op("s2"))
    assert not replayed and b == {"id": "s2"}
    assert _count_settings() == 2


@pytest.mark.req("FS-SYS-006", kind="integration")
def test_expiry_and_cleanup_with_fake_clock(migrated_db):
    clock.freeze(utcnow())
    fp = fingerprint({}, {})
    execute(SCOPE, "old", "create", fp, _create_op("e1"))
    clock.advance(25 * 3600)
    # expired key is treated as absent -> new work happens
    s, b, replayed = execute(SCOPE, "old", "create", fp, _create_op("e2"))
    assert not replayed and b == {"id": "e2"}
    clock.advance(25 * 3600)
    # a young IN_PROGRESS row must never be removed by cleanup
    with new_session() as db:
        db.add(IdempotencyKey(key="busy", scope=SCOPE, operation="x", request_fingerprint=fp,
                              state="IN_PROGRESS", created_at=utcnow(), expires_at=utcnow() - timedelta(seconds=1)))
        db.commit()
    removed = cleanup_expired(batch=1)
    assert removed == 1
    with new_session() as db:
        keys = db.execute(select(IdempotencyKey.key)).scalars().all()
    assert keys == ["busy"]


@pytest.mark.req("FS-SYS-006", kind="integration")
def test_stale_in_progress_row_is_reclaimable(migrated_db):
    clock.freeze(utcnow())
    fp = fingerprint({}, {})
    with new_session() as db:
        db.add(IdempotencyKey(key="crashed", scope=SCOPE, operation="x", request_fingerprint=fp,
                              state="IN_PROGRESS", created_at=utcnow(), expires_at=utcnow() + timedelta(hours=24)))
        db.commit()
    with pytest.raises(AppError) as ei:
        execute(SCOPE, "crashed", "create", fp, _create_op("r1"))
    assert ei.value.code == "IDEMPOTENCY_IN_PROGRESS" and ei.value.headers["Retry-After"] == "1"
    clock.advance(6 * 60)
    s, _, replayed = execute(SCOPE, "crashed", "create", fp, _create_op("r1"))
    assert s == 201 and not replayed


@pytest.mark.req("FS-SYS-006", kind="unit+negative")
def test_key_format_validation():
    assert validate_key("abc-123_x.y:z") == "abc-123_x.y:z"
    assert validate_key(None) is None
    for bad in ("", "a" * 129, "has space", "emoji☃"):
        with pytest.raises(AppError):
            validate_key(bad)


@pytest.mark.req("FS-SYS-006", kind="unit")
def test_fingerprint_canonicalisation():
    assert fingerprint({"b": 1, "a": "x "}, {"id": "1"}) == fingerprint({"a": "x", "b": 1.0}, {"id": "1"})
    assert fingerprint({"a": 1}, {}) != fingerprint({"a": 2}, {})
    assert fingerprint({"a": 1, "client_timestamp": 5}, {}) == fingerprint({"a": 1}, {})
