import pytest


@pytest.mark.req("FS-SYS-001", kind="api")
def test_health_identity_payload(client):
    r = client.get("/api/health")
    assert r.status_code == 200
    body = r.json()
    assert body["app"] == "flowsynapse"
    assert body["status"] == "ok"
    assert body["db_revision"]
    assert len(body["instance_id"]) == 32
    assert body["version"]


@pytest.mark.req("FS-SYS-001", kind="api")
def test_cors_allows_dev_origins_only(client):
    ok = client.options(
        "/api/health",
        headers={"Origin": "http://127.0.0.1:5173", "Access-Control-Request-Method": "GET"},
    )
    assert ok.headers.get("access-control-allow-origin") == "http://127.0.0.1:5173"
    ok2 = client.get("/api/health", headers={"Origin": "http://localhost:5173"})
    assert ok2.headers.get("access-control-allow-origin") == "http://localhost:5173"
    bad = client.get("/api/health", headers={"Origin": "http://evil.example"})
    assert "access-control-allow-origin" not in bad.headers


@pytest.mark.req("FS-SYS-003", kind="api")
def test_unknown_api_route_uses_standard_error(client):
    r = client.get("/api/does-not-exist")
    assert r.status_code == 404
    assert r.json()["error"]["code"] == "NOT_FOUND"
