"""Campaign API: create, validate, brief edits, runs, idempotency, lists (5.9)."""
from __future__ import annotations

import sqlite3
import threading

import pytest

from app.services.campaign.brief import demo_brief
from tests import campaign_helpers as ch


@pytest.mark.req("FS-M1-001", kind="api+negative")
def test_validation_errors_are_field_level_and_inputs_preserved(client):
    brief = {"business_name": "Half filled", "start_date": "2026-11-15", "end_date": "2026-11-02", "total_budget": "abc"}
    r = client.post("/api/campaigns/validate-brief", json={"brief": brief})
    assert r.status_code == 200
    errs = {(e["field"], e["code"]) for e in r.json()["errors"]}
    assert ("end_date", "END_BEFORE_START") in errs and ("total_budget", "INVALID_AMOUNT") in errs
    # Save Draft works with an invalid brief; the stored brief is exactly what was sent
    c = ch.create(client, brief)
    assert c["status"] == "DRAFT" and c["brief"]["business_name"] == "Half filled" and c["brief"]["total_budget"] == "abc"
    v = client.post(f"/api/campaigns/{c['id']}/validate").json()
    assert not v["valid"]
    bad = client.post("/api/campaigns", json={"brief": {"unknown_field": 1}})
    assert bad.status_code == 422 and bad.json()["error"]["details"]["fields"][0]["field"].startswith("brief")


@pytest.mark.req("FS-M1-002", kind="integration")
def test_demo_brief_endpoint_and_demo_label(client):
    b = client.get("/api/campaigns/demo-brief").json()
    assert b["is_demo"] and b["brief"]["business_name"] == "Be Well Hospitals"
    c = ch.create(client, b["brief"], is_demo=True)
    assert c["is_demo"] and c["status"] == "READY" and c["validation"]["valid"]


@pytest.mark.req("FS-SYS-006", kind="api")
def test_create_idempotency_replay_and_reuse(client):
    h = {"Idempotency-Key": "create-1"}
    r1 = client.post("/api/campaigns", json={"brief": demo_brief(fixed=True)}, headers=h)
    r2 = client.post("/api/campaigns", json={"brief": demo_brief(fixed=True)}, headers=h)
    assert r1.status_code == r2.status_code == 201
    assert r2.headers["Idempotent-Replayed"] == "true" and r1.json()["id"] == r2.json()["id"]
    assert client.get("/api/campaigns").json()["total"] == 1
    other = demo_brief(fixed=True)
    other["campaign_name"] = "Different"
    r3 = client.post("/api/campaigns", json={"brief": other}, headers=h)
    assert r3.status_code == 422 and r3.json()["error"]["code"] == "IDEMPOTENCY_KEY_REUSED"
    bad = client.post("/api/campaigns", json={"brief": {}}, headers={"Idempotency-Key": "bad key!"})
    assert bad.status_code == 422


@pytest.mark.req("FS-SYS-021", kind="api+negative")
def test_duplicate_start_returns_409_and_parallel_starts_one_wins(client):
    c = ch.create(client)
    results = []
    barrier = threading.Barrier(4)

    def go():
        barrier.wait()
        results.append(client.post(f"/api/campaigns/{c['id']}/executions").status_code)

    ts = [threading.Thread(target=go) for _ in range(4)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    assert sorted(results).count(202) == 1 and set(results) <= {202, 409}


@pytest.mark.req("FS-M1-005", kind="integration")
def test_slice_runs_stages_in_order_with_persisted_state(client, settings):
    c, ex = ch.run(client)
    assert ex["status"] in ("COMPLETED", "COMPLETED_WITH_WARNINGS")
    keys = [s["stage_key"] for s in ex["stages"]]
    assert keys[:3] == ["INPUT_VALIDATION", "BRIEF_NORMALIZATION", "OBJECTIVE_ANALYSIS"]
    assert all(s["status"] == "COMPLETED" and s["started_at"] and s["finished_at"] for s in ex["stages"])
    con = sqlite3.connect(settings.db_path)
    rows = con.execute("select stage_key, status, started_at, finished_at, provider, is_mock, output_ref from execution_stages "
                       "where execution_id=? order by position", (ex["id"],)).fetchall()
    assert [r[0] for r in rows] == keys
    obj = [r for r in rows if r[0] == "OBJECTIVE_ANALYSIS"][0]
    assert obj[4] == "mock" and obj[5] == 1 and "output_versions" in obj[6]
    ver = con.execute("select origin, provider, is_mock, stage_key, execution_id from output_versions where stage_key='OBJECTIVE_ANALYSIS'").fetchone()
    assert ver == ("MOCK_GENERATED", "mock", 1, "OBJECTIVE_ANALYSIS", ex["id"])
    con.close()


@pytest.mark.req("FS-M1-006", kind="integration")
def test_objective_output_is_schema_valid_and_tagged(client):
    c, _ = ch.run(client)
    st = client.get(f"/api/campaigns/{c['id']}/stages/OBJECTIVE_ANALYSIS").json()
    content = st["outputs"][0]["content"]
    for key in ("primary_business_objective", "marketing_objective", "desired_conversion_action", "target_service",
                "geographic_scope", "main_messaging_opportunity"):
        assert content[key]["source"] in ("user_provided", "generated_suggestion", "assumption")
    assert content["primary_business_objective"] == {"text": "Generate orthopaedic consultation leads", "source": "user_provided"}
    assert st["outputs"][0]["provenance_label"] == "Mock-generated (not real AI)"


@pytest.mark.req("FS-M1-005", kind="integration")
def test_invalid_brief_stops_at_stage_one(client):
    b = demo_brief(fixed=True)
    b["total_budget"] = "0"
    c = ch.create(client, b)
    ex = ch.wait(client, c["id"], ch.start(client, c["id"])["id"])
    assert ex["status"] == "FAILED" and ex["error_code"] == "BRIEF_INVALID" and ex["retryable"] is False
    assert [s["status"] for s in ex["stages"]][:3] == ["FAILED", "SKIPPED", "SKIPPED"]


@pytest.mark.req("FS-M1-021", kind="integration")
def test_non_healthcare_brief_has_no_be_well_text(client):
    c, ex = ch.run(client, ch.bakery_brief())
    assert ex["status"] in ("COMPLETED", "COMPLETED_WITH_WARNINGS")
    d = client.get(f"/api/campaigns/{c['id']}").json()
    assert d["normalized_brief"]["is_healthcare"] is False and d["healthcare_disclaimer"] is None
    text = str(client.get(f"/api/campaigns/{c['id']}/outputs").json())
    assert "Be Well" not in text and "orthopaedic" not in text.lower()
    assert d["normalized_brief"]["campaign"]["budget"]["amount"] == "10001.00"


@pytest.mark.req("FS-SYS-036", kind="api+negative")
def test_brief_patch_requires_matching_version(client):
    c = ch.create(client)
    b = c["brief"]
    b["tone"] = "Calm"
    assert client.patch(f"/api/campaigns/{c['id']}/brief", json={"brief": b}).status_code == 428
    ok = client.patch(f"/api/campaigns/{c['id']}/brief", json={"brief": b}, headers={"If-Match": str(c["brief_version"])})
    assert ok.status_code == 200 and ok.json()["changed_fields"] == ["tone"]
    stale = client.patch(f"/api/campaigns/{c['id']}/brief", json={"brief": b}, headers={"If-Match": str(c["brief_version"])})
    assert stale.status_code == 409 and stale.json()["error"]["code"] == "VERSION_CONFLICT"


@pytest.mark.req("FS-SYS-045", kind="api")
def test_list_pagination_search_and_demo_filter(client):
    for i in range(3):
        b = demo_brief(fixed=True)
        b["campaign_name"] = f"Campaign {i}"
        ch.create(client, b, is_demo=(i == 0))
    page = client.get("/api/campaigns", params={"limit": 2, "offset": 0}).json()
    assert page["total"] == 3 and len(page["items"]) == 2
    assert client.get("/api/campaigns", params={"limit": 2, "offset": 2}).json()["items"][0]
    assert client.get("/api/campaigns", params={"q": "Campaign 2"}).json()["total"] == 1
    assert client.get("/api/campaigns", params={"demo": "mine"}).json()["total"] == 2
    assert client.get("/api/campaigns", params={"demo": "demo"}).json()["total"] == 1
    assert client.get("/api/campaigns", params={"limit": 500}).status_code == 422


@pytest.mark.req("FS-SYS-027", kind="api")
def test_runs_history_lists_executions(client):
    c, ex = ch.run(client)
    runs = client.get("/api/runs", params={"module": "campaigns"}).json()
    assert runs["total"] == 1 and runs["items"][0]["execution_id"] == ex["id"]
    assert runs["items"][0]["status"] == ex["status"] and runs["items"][0]["title"] == c["name"]


@pytest.mark.req("FS-SYS-051", kind="api")
def test_dashboard_counts_real_records_and_excludes_demo(client):
    ch.create(client)
    ch.create(client, is_demo=True)
    d = client.get("/api/dashboard").json()
    assert [m["key"] for m in d["modules"]][:2] == ["campaigns", "funnels"]
    assert d["modules"][0]["total"] == 1
    assert client.get("/api/dashboard", params={"include_demo": True}).json()["modules"][0]["total"] == 2


@pytest.mark.req("FS-M1-018", kind="api")
def test_csv_export_of_stored_objectives(client):
    c, _ = ch.run(client)
    r = client.get(f"/api/campaigns/{c['id']}/export.csv", params={"dataset": "Objectives"})
    assert r.status_code == 200 and r.content.startswith(b"\xef\xbb\xbf")
    assert "filename*=UTF-8''" in r.headers["content-disposition"]
    text = r.content.decode("utf-8-sig")
    assert "Generate orthopaedic consultation leads,user_provided" in text
    assert "DEMONSTRATION DATA" not in text  # not created as demo
    assert client.get(f"/api/campaigns/{c['id']}/export.csv", params={"dataset": "Nope"}).status_code == 422


@pytest.mark.req("FS-M1-021", kind="api+negative")
def test_delete_and_brief_edit_blocked_while_active_then_allowed(idle_client):
    client = idle_client
    c = ch.create(client)
    ex = ch.start(client, c["id"])  # stays PENDING: no workers
    r = client.delete(f"/api/campaigns/{c['id']}")
    assert r.status_code == 409 and r.json()["error"]["code"] == "EXECUTION_ACTIVE"
    b = c["brief"]
    b["tone"] = "x"
    e = client.patch(f"/api/campaigns/{c['id']}/brief", json={"brief": b}, headers={"If-Match": str(c["brief_version"])})
    assert e.status_code == 409 and e.json()["error"]["code"] == "EXECUTION_ACTIVE"
    cancelled = client.post(f"/api/campaigns/{c['id']}/executions/{ex['id']}/cancel")
    assert cancelled.json()["status"] == "CANCELLED"
    again = client.post(f"/api/campaigns/{c['id']}/executions/{ex['id']}/cancel")
    assert again.status_code == 409 and again.json()["error"]["code"] == "ALREADY_FINISHED"
    assert client.delete(f"/api/campaigns/{c['id']}").status_code == 200
    assert client.get(f"/api/campaigns/{c['id']}").status_code == 404
