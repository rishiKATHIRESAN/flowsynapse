import pytest

from app.api import settings as settings_api


@pytest.fixture(autouse=True)
def _reset():
    settings_api.reset_cache()
    yield
    settings_api.reset_cache()


@pytest.mark.req("FS-SYS-033", kind="api")
def test_get_settings_defaults_to_mock_and_hides_secrets(client, settings):
    r = client.get("/api/settings")
    assert r.status_code == 200
    body = r.json()
    assert body["active_provider"] == "mock" and body["is_mock"] is True
    gem = next(p for p in body["providers"] if p["name"] == "gemini")
    assert gem["configured"] is False and "GEMINI_API_KEY" in gem["config_error"]
    assert body["gemini_key_configured"] is False
    settings.GEMINI_API_KEY = "AIzaSECRETVALUEnotToLeak123456"
    r2 = client.get("/api/settings")
    assert r2.json()["gemini_key_configured"] is True
    assert "AIzaSECRETVALUEnotToLeak123456" not in r2.text


@pytest.mark.req("FS-SYS-033", kind="api")
def test_switch_provider_persists_and_reports_config_error(client):
    r = client.put("/api/settings", json={"ai_provider": "gemini"})
    assert r.status_code == 200 and r.json()["active_provider"] == "gemini"
    assert r.json()["config_error"]
    assert client.get("/api/settings").json()["active_provider"] == "gemini"
    bad = client.put("/api/settings", json={"ai_provider": "openai"})
    assert bad.status_code == 422


@pytest.mark.req("FS-SYS-033", kind="api")
def test_test_provider_mock_ok_and_cached(client):
    r = client.post("/api/settings/test-provider", json={})
    assert r.status_code == 200 and r.json()["ok"] is True and r.json()["cached"] is False
    r2 = client.post("/api/settings/test-provider", json={})
    assert r2.json()["cached"] is True


@pytest.mark.req("FS-SYS-033", kind="api")
def test_test_provider_misconfigured_reports_without_crash(client):
    r = client.post("/api/settings/test-provider", json={"provider": "gemini"})
    assert r.status_code == 200
    body = r.json()
    assert body["ok"] is False and body["details"]["code"] == "PROVIDER_CONFIG_INVALID"
    # rate-limited: a second non-mock check within 10 s (cache returns the same result instead)
    assert client.post("/api/settings/test-provider", json={"provider": "gemini"}).json()["cached"] is True
