"""Error format, Host/Origin/content-type/body-size protections (2.2, 14)."""
from __future__ import annotations

import pytest
from fastapi import APIRouter, Body

from pydantic import BaseModel, Field

from app.utils.errors import AppError


class Thing(BaseModel):
    name: str = Field(min_length=1, max_length=10)
    count: int


@pytest.fixture
def guarded_client(settings):
    """App with a tiny test-only router exercising validation and errors."""
    from fastapi.testclient import TestClient

    from app.main import create_app

    router = APIRouter(prefix="/api/test-only")

    @router.post("/things")
    def create(thing: Thing) -> dict:
        return {"ok": True, "name": thing.name}

    @router.post("/boom")
    def boom(_: dict = Body(default={})) -> dict:
        raise RuntimeError("secret internal detail AIzaFAKEKEY1234567890123456")

    @router.post("/conflict")
    def conflict() -> dict:
        raise AppError(409, "SOMETHING_CONFLICTS", "conflict", {"x": 1})

    app = create_app(settings)
    app.router.routes.insert(0, router.routes[0])
    app.router.routes.insert(0, router.routes[1])
    app.router.routes.insert(0, router.routes[2])
    with TestClient(app, base_url="http://127.0.0.1:8000", raise_server_exceptions=False) as c:
        yield c


@pytest.mark.req("FS-SYS-003", kind="api+negative")
def test_422_is_remapped_with_field_details(guarded_client):
    r = guarded_client.post("/api/test-only/things", json={"name": "", "count": "nope"})
    assert r.status_code == 422
    err = r.json()["error"]
    assert err["code"] == "VALIDATION_ERROR"
    fields = {f["field"] for f in err["details"]["fields"]}
    assert fields == {"name", "count"}


@pytest.mark.req("FS-SYS-003", kind="api+negative")
def test_unhandled_error_has_no_stack_trace(guarded_client):
    r = guarded_client.post("/api/test-only/boom", json={})
    assert r.status_code == 500
    body = r.json()
    assert body["error"]["code"] == "INTERNAL_ERROR"
    text = r.text
    assert "Traceback" not in text and "secret internal detail" not in text and "AIza" not in text


@pytest.mark.req("FS-SYS-003", kind="api")
def test_app_error_format(guarded_client):
    r = guarded_client.post("/api/test-only/conflict", json={})
    assert r.status_code == 409
    assert r.json() == {"error": {"code": "SOMETHING_CONFLICTS", "message": "conflict", "details": {"x": 1}}}


@pytest.mark.req("FS-SYS-005", kind="api+negative")
def test_foreign_host_header_rejected(guarded_client):
    r = guarded_client.get("/api/health", headers={"Host": "evil.example.com"})
    assert r.status_code == 400
    assert r.json()["error"]["code"] == "INVALID_HOST"
    ok = guarded_client.get("/api/health", headers={"Host": "localhost:8000"})
    assert ok.status_code == 200


@pytest.mark.req("FS-SYS-005", kind="api+negative")
def test_unknown_origin_rejected_on_state_change(guarded_client):
    r = guarded_client.post("/api/test-only/things", json={"name": "a", "count": 1},
                            headers={"Origin": "http://evil.example"})
    assert r.status_code == 403 and r.json()["error"]["code"] == "ORIGIN_REJECTED"
    ok = guarded_client.post("/api/test-only/things", json={"name": "a", "count": 1},
                             headers={"Origin": "http://127.0.0.1:5173"})
    assert ok.status_code == 200
    # GET from any origin is allowed by the guard (CORS still restricts reading)
    assert guarded_client.get("/api/health", headers={"Origin": "http://evil.example"}).status_code == 200


@pytest.mark.req("FS-SYS-005", kind="api+negative")
def test_non_json_content_type_rejected(guarded_client):
    r = guarded_client.post("/api/test-only/things", content=b"name=a", headers={"Content-Type": "application/x-www-form-urlencoded"})
    assert r.status_code == 415 and r.json()["error"]["code"] == "UNSUPPORTED_MEDIA_TYPE"


@pytest.mark.req("FS-SYS-005", kind="api+negative")
def test_body_size_limit_enforced(guarded_client, settings):
    big = b'{"name":"' + b"a" * (settings.MAX_BODY_BYTES + 10) + b'","count":1}'
    r = guarded_client.post("/api/test-only/things", content=big, headers={"Content-Type": "application/json"})
    assert r.status_code == 413 and r.json()["error"]["code"] == "PAYLOAD_TOO_LARGE"


@pytest.mark.req("FS-SYS-004", kind="unit")
def test_request_id_header_is_returned(guarded_client):
    r = guarded_client.get("/api/health", headers={"X-Request-ID": "abc123"})
    assert r.headers["X-Request-ID"] == "abc123"
    r2 = guarded_client.get("/api/health")
    assert len(r2.headers["X-Request-ID"]) >= 8
