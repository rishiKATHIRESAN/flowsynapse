"""Helpers for campaign tests (TestClient based)."""
from __future__ import annotations

import time
from typing import Any

from app.services.campaign.brief import demo_brief

TERMINAL = ("COMPLETED", "COMPLETED_WITH_WARNINGS", "FAILED", "CANCELLED")


def bakery_brief() -> dict[str, Any]:
    b = demo_brief(fixed=True)
    b.update(
        business_name="Crust & Crumb Bakery",
        industry="Food & beverage - artisan bakery",
        business_description="Neighbourhood bakery selling sourdough and celebration cakes",
        location="Koramangala, Bengaluru, Karnataka, India",
        service_areas=["Koramangala", "HSR Layout"],
        primary_service="Custom celebration cakes",
        value_proposition="Freshly baked cakes made to order within 48 hours",
        campaign_name="Crust & Crumb Cake Orders",
        objective="Increase custom cake orders",
        primary_conversion_goal="Cake order enquiry",
        total_budget="10001",
        currency="INR",
        target_geography="Koramangala and HSR Layout, Bengaluru",
        audience_description="Families and office teams planning celebrations",
        offer_details="Custom cakes with 48-hour lead time",
        landing_page_url="https://crustandcrumb.example.in/cakes?ref=ads#order",
        call_to_action="Order a cake",
        contact_method="WhatsApp or web order form",
        approved_claims=["Made to order"],
        prohibited_claims=["Cheapest in town"],
        tone="Warm and cheerful",
    )
    return b


def create(client, brief: dict[str, Any] | None = None, is_demo: bool = False, **headers: str) -> dict[str, Any]:
    r = client.post("/api/campaigns", json={"brief": brief or demo_brief(fixed=True), "is_demo": is_demo}, headers=headers)
    assert r.status_code == 201, r.text
    return r.json()


def start(client, cid: str) -> dict[str, Any]:
    r = client.post(f"/api/campaigns/{cid}/executions")
    assert r.status_code == 202, r.text
    return r.json()


def wait(client, cid: str, eid: str, timeout: float = 30.0) -> dict[str, Any]:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        x = client.get(f"/api/campaigns/{cid}/executions/{eid}").json()
        if x["status"] in TERMINAL:
            return x
        time.sleep(0.05)
    raise AssertionError(f"execution {eid} did not finish")


def run(client, brief: dict[str, Any] | None = None, is_demo: bool = False) -> tuple[dict[str, Any], dict[str, Any]]:
    c = create(client, brief, is_demo)
    ex = start(client, c["id"])
    return c, wait(client, c["id"], ex["id"])
