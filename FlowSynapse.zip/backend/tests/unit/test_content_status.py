import itertools

import pytest

from app.services.content import content_status as cs
from app.utils.errors import AppError

ALLOWED = {
    ("DRAFT", "READY_FOR_REVIEW"),
    ("READY_FOR_REVIEW", "NEEDS_REVISION"),
    ("READY_FOR_REVIEW", "READY_TO_EXPORT"),
    ("READY_FOR_REVIEW", "DRAFT"),
    ("NEEDS_REVISION", "DRAFT"),
    ("NEEDS_REVISION", "READY_FOR_REVIEW"),
    ("READY_TO_EXPORT", "NEEDS_REVISION"),
    ("READY_TO_EXPORT", "DRAFT"),
}


@pytest.mark.req("FS-SYS-040", kind="unit+negative")
def test_every_pair_allowed_or_rejected():
    for frm, to in itertools.product(cs.STATES, cs.STATES):
        if (frm, to) in ALLOWED:
            cs.check_transition(frm, to)
        else:
            with pytest.raises(AppError) as ei:
                cs.check_transition(frm, to)
            assert ei.value.status_code == 409 and ei.value.code == "INVALID_STATUS_TRANSITION"


@pytest.mark.req("FS-SYS-040", kind="unit+negative")
def test_unknown_and_publishing_states_rejected():
    for bad in ("PUBLISHED", "SCHEDULED", "APPROVED"):
        with pytest.raises(AppError) as ei:
            cs.check_transition("DRAFT", bad)
        assert ei.value.status_code == 422
    assert "PUBLISHED" not in cs.STATES and "SCHEDULED" not in cs.STATES
