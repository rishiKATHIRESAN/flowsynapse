import logging

import pytest

from app.utils.redact import RedactingFilter, redact, register_secret


@pytest.mark.req("FS-SYS-004", kind="unit")
def test_redacts_query_keys_headers_and_registered_secrets():
    register_secret("sk-test-SECRET-VALUE-123")
    s = redact("GET https://x/models?key=AIzaSyA1234567890123456789012345&alt=json token sk-test-SECRET-VALUE-123")
    assert "AIzaSy" not in s and "sk-test-SECRET" not in s
    assert "key=***REDACTED***" in s
    assert "x-goog-api-key: ***REDACTED***" in redact("x-goog-api-key: abcdef123456")
    assert "Authorization: ***REDACTED***" in redact("Authorization: Bearer abc.def.ghi")


@pytest.mark.req("FS-SYS-004", kind="unit")
def test_logging_filter_masks_messages(caplog):
    logger = logging.getLogger("test.redact")
    logger.addFilter(RedactingFilter())
    with caplog.at_level(logging.INFO, logger="test.redact"):
        logger.info("calling %s", "https://api/x?key=SUPERSECRETKEY99")
    assert "SUPERSECRETKEY99" not in caplog.text
    assert "***REDACTED***" in caplog.text
