"""Exhaustive (from, to) matrices for execution and stage states (2.3, 15.13)."""
import itertools

import pytest

from app.services.jobs import state_machine as sm

EXEC_LEGAL = {
    (None, "PENDING"),
    ("PENDING", "RUNNING"),
    ("PENDING", "CANCELLED"),
    ("RUNNING", "COMPLETED"),
    ("RUNNING", "COMPLETED_WITH_WARNINGS"),
    ("RUNNING", "FAILED"),
    ("RUNNING", "CANCELLED"),
}
STAGE_LEGAL = {
    (None, "PENDING"),
    (None, "CARRIED_FORWARD"),
    ("PENDING", "RUNNING"),
    ("PENDING", "SKIPPED"),
    ("PENDING", "CANCELLED"),
    ("RUNNING", "COMPLETED"),
    ("RUNNING", "FAILED"),
    ("RUNNING", "CANCELLED"),
}


@pytest.mark.req("FS-SYS-020", kind="unit")
def test_execution_transition_matrix_is_exhaustive():
    states = [None, *sm.EXECUTION_STATES]
    for frm, to in itertools.product(states, sm.EXECUTION_STATES):
        assert sm.is_legal_execution(frm, to) == ((frm, to) in EXEC_LEGAL), (frm, to)


@pytest.mark.req("FS-SYS-020", kind="unit")
def test_stage_transition_matrix_is_exhaustive():
    states = [None, *sm.STAGE_STATES]
    for frm, to in itertools.product(states, sm.STAGE_STATES):
        assert sm.is_legal_stage(frm, to) == ((frm, to) in STAGE_LEGAL), (frm, to)


@pytest.mark.req("FS-SYS-020", kind="unit")
def test_terminal_states_have_no_exits():
    for t in sm.TERMINAL_EXECUTION_STATES:
        assert sm.EXECUTION_TRANSITIONS[t] == frozenset()
    for t in ("COMPLETED", "FAILED", "CANCELLED", "SKIPPED", "CARRIED_FORWARD"):
        assert sm.STAGE_TRANSITIONS[t] == frozenset()
