"""Ollama and Gemini providers with mocked HTTP (no network)."""
from __future__ import annotations

import pytest
import requests

from app.ai.base import AIRequest, ProviderError
from app.ai.gemini_provider import GeminiProvider
from app.ai.ollama_provider import OllamaProvider

FAKE_KEY = "AIzaFAKE-test-key-0123456789abcdefXYZ"


class Resp:
    def __init__(self, status=200, payload=None, headers=None):
        self.status_code = status
        self._payload = payload
        self.headers = headers or {}

    def json(self):
        if self._payload is None:
            raise ValueError("no json")
        return self._payload

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError(str(self.status_code))


class FakeSession:
    def __init__(self, result):
        self.result = result
        self.calls = []

    def _do(self, *a, **k):
        self.calls.append((a, k))
        if isinstance(self.result, Exception):
            raise self.result
        return self.result

    post = get = _do


REQ = AIRequest("T", "sys", "prompt", {"type": "object"})


@pytest.mark.req("FS-SYS-037", kind="unit")
def test_gemini_success_parses_text_and_uses_header_not_url():
    s = FakeSession(Resp(200, {"candidates": [{"content": {"parts": [{"text": '{"a":1}'}]}}]}))
    p = GeminiProvider(FAKE_KEY, "gemini-test", 5, s)
    assert p.generate(REQ) == '{"a":1}'
    (url,), kw = s.calls[0]
    assert FAKE_KEY not in url and kw["headers"]["x-goog-api-key"] == FAKE_KEY
    assert url.endswith("models/gemini-test:generateContent")
    assert kw["json"]["generationConfig"]["response_mime_type"] == "application/json"


@pytest.mark.req("FS-SYS-037", kind="unit+negative")
@pytest.mark.parametrize(
    "status,code,retryable",
    [(401, "PROVIDER_AUTH_FAILED", False), (403, "PROVIDER_AUTH_FAILED", False), (404, "PROVIDER_MODEL_MISSING", False),
     (429, "PROVIDER_RATE_LIMITED", True), (500, "PROVIDER_UNAVAILABLE", True), (503, "PROVIDER_UNAVAILABLE", True)],
)
def test_gemini_error_classification(status, code, retryable):
    p = GeminiProvider(FAKE_KEY, "g", 5, FakeSession(Resp(status, {"error": {"message": f"bad key {FAKE_KEY}"}})))
    with pytest.raises(ProviderError) as ei:
        p.generate(REQ)
    assert ei.value.code == code and ei.value.retryable is retryable
    assert FAKE_KEY not in str(ei.value)


@pytest.mark.req("FS-SYS-037", kind="unit+negative")
def test_gemini_timeout_and_network():
    with pytest.raises(ProviderError) as ei:
        GeminiProvider(FAKE_KEY, "g", 5, FakeSession(requests.Timeout())).generate(REQ)
    assert ei.value.code == "PROVIDER_TIMEOUT" and ei.value.retryable
    with pytest.raises(ProviderError) as ei2:
        GeminiProvider(FAKE_KEY, "g", 5, FakeSession(requests.ConnectionError(f"x?key={FAKE_KEY}"))).generate(REQ)
    assert ei2.value.code == "NETWORK_ERROR" and FAKE_KEY not in ei2.value.message


@pytest.mark.req("FS-SYS-037", kind="unit")
def test_gemini_health_check_uses_metadata_only():
    s = FakeSession(Resp(200, {"name": "models/g"}))
    h = GeminiProvider(FAKE_KEY, "g", 5, s).health_check()
    assert h.ok and "no generation" in h.message
    (url,), _ = s.calls[0]
    assert ":generateContent" not in url
    bad = GeminiProvider(FAKE_KEY, "g", 5, FakeSession(Resp(401))).health_check()
    assert not bad.ok and bad.details["code"] == "PROVIDER_AUTH_FAILED"


@pytest.mark.req("FS-SYS-037", kind="unit+negative")
def test_ollama_not_running_model_missing_timeout():
    with pytest.raises(ProviderError) as ei:
        OllamaProvider("http://localhost:11434", "llama3", 5, FakeSession(requests.ConnectionError())).generate(REQ)
    assert ei.value.code == "PROVIDER_UNAVAILABLE" and "ollama serve" in (ei.value.hint or "")
    with pytest.raises(ProviderError) as ei2:
        OllamaProvider("http://localhost:11434", "llama3", 5, FakeSession(Resp(404, {}))).generate(REQ)
    assert ei2.value.code == "PROVIDER_MODEL_MISSING" and "ollama pull llama3" in (ei2.value.hint or "")
    with pytest.raises(ProviderError) as ei3:
        OllamaProvider("http://localhost:11434", "llama3", 5, FakeSession(requests.Timeout())).generate(REQ)
    assert ei3.value.code == "PROVIDER_TIMEOUT"


@pytest.mark.req("FS-SYS-037", kind="unit")
def test_ollama_success_and_health():
    ok = OllamaProvider("http://h", "llama3", 5, FakeSession(Resp(200, {"message": {"content": '{"x":1}'}})))
    assert ok.generate(REQ) == '{"x":1}'
    h = OllamaProvider("http://h", "llama3", 5, FakeSession(Resp(200, {"models": [{"name": "llama3:latest"}]}))).health_check()
    assert h.ok
    missing = OllamaProvider("http://h", "phi3", 5, FakeSession(Resp(200, {"models": [{"name": "llama3:latest"}]}))).health_check()
    assert not missing.ok and "ollama pull phi3" in missing.details["hint"]
    down = OllamaProvider("http://h", "phi3", 5, FakeSession(requests.ConnectionError())).health_check()
    assert not down.ok
