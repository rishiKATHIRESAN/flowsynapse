import pytest

from app.services.content import health_claims as hc
from app.services.content.similarity import jaccard, near_duplicates


@pytest.mark.req("FS-SYS-041", kind="unit")
def test_detects_healthcare_industries():
    assert hc.detect_healthcare("Healthcare - hospital / orthopaedics")
    assert hc.detect_healthcare("Dental clinic in Pune")
    assert not hc.detect_healthcare("Artisan bakery", "Sourdough and cakes")
    assert not hc.detect_healthcare("Software consultancy")


@pytest.mark.req("FS-SYS-041", kind="unit")
def test_flags_risky_phrases_with_field_paths():
    content = {"headline": "Guaranteed relief - the best hospital in Chennai", "body": ["Cure knee pain 100% before and after"]}
    cats = {(f.category, f.field) for f in hc.scan_content(content)}
    assert ("GUARANTEED_OUTCOME", "headline") in cats
    assert ("SUPERLATIVE", "headline") in cats
    assert ("CURE_CLAIM", "body[0]") in cats
    assert ("BEFORE_AFTER", "body[0]") in cats
    assert any(f.severity == "BLOCKER" for f in hc.scan_content(content))


@pytest.mark.req("FS-SYS-041", kind="unit")
def test_clean_copy_and_approved_claims_not_flagged():
    assert hc.scan_text("Book an orthopaedic consultation in Selaiyur, Chennai.") == []
    assert hc.scan_text("Securely guarantee your slot", allowed=["securely guarantee your slot"]) == []
    assert hc.scan_text("Meet Dr. Kumar", "x")[0].category == "INVENTED_CREDENTIAL"
    assert "never describes generated content as compliant" in hc.disclaimer()


@pytest.mark.req("FS-SYS-042", kind="unit")
def test_similarity():
    assert jaccard("Book a knee consultation today", "Book your knee consultation today") == 1.0
    assert jaccard("Fresh sourdough bread", "Orthopaedic consultation") == 0.0
    pairs = near_duplicates(["Book a knee consult now", "Book knee consult now please", "Totally different message here"])
    assert [(i, j) for i, j, _ in pairs] == [(0, 1)]
