"""Campaign date semantics, brief validation and normalization (5.2, 5.3, 5.7)."""
from __future__ import annotations

from datetime import date, datetime, timezone

import pytest

from app.services.campaign.brief import REQUIRED_FIELDS, BriefInput, demo_brief
from app.services.campaign.dates import demo_period, next_monday, resolve_period
from app.services.campaign.normalization import normalize, structure_location
from app.services.campaign.validation import validate_brief
from app.utils.clock import clock


def codes(p):
    return {(e["field"], e["code"]) for e in p.errors}


@pytest.mark.req("FS-M1-003", kind="unit")
@pytest.mark.parametrize(
    "start,end,days",
    [
        ("2026-11-02", "2026-11-02", 1),  # same-day
        ("2027-01-30", "2027-02-02", 4),  # month boundary
        ("2028-02-28", "2028-03-01", 3),  # leap year: 28, 29, 1
        ("2026-12-30", "2027-01-02", 4),  # year boundary
        ("2026-11-02", "2026-11-15", 14),  # demo
        ("2026-10-25", "2026-12-05", 42),  # spans months
    ],
)
def test_inclusive_duration(start, end, days):
    p = resolve_period(start, end)
    assert p.ok and p.duration_days == days


@pytest.mark.req("FS-M1-003", kind="unit")
def test_leap_day_valid_and_invalid():
    assert resolve_period("2028-02-29", None, 1).ok
    assert ("start_date", "INVALID_DATE") in codes(resolve_period("2027-02-29", None, 1))
    assert ("start_date", "INVALID_DATE") in codes(resolve_period("2027-02-30", None, 1))


@pytest.mark.req("FS-M1-003", kind="unit")
def test_leap_year_span_follows_inclusive_formula():
    # The prompt's example says "= 4 days" but its own formula (end - start).days + 1 gives 3
    # (Feb 28, Feb 29, Mar 1). The formula wins; recorded as decision D9 in docs/ARCHITECTURE.md.
    p = resolve_period("2028-02-28", "2028-03-01")
    assert p.duration_days == 3
    assert resolve_period("2027-02-28", "2027-03-01").duration_days == 2


@pytest.mark.req("FS-M1-003", kind="unit")
def test_derived_end_and_derived_duration():
    p = resolve_period("2026-11-02", None, 14)
    assert p.end == date(2026, 11, 15)
    q = resolve_period("2026-11-02", "2026-11-15", None)
    assert q.duration_days == 14


@pytest.mark.req("FS-M1-003", kind="unit+negative")
def test_mismatch_end_before_start_and_bad_input():
    m = codes(resolve_period("2026-11-02", "2026-11-15", 10))
    assert {("end_date", "DURATION_DATE_MISMATCH"), ("duration_days", "DURATION_DATE_MISMATCH")} <= m
    assert ("end_date", "END_BEFORE_START") in codes(resolve_period("2026-11-15", "2026-11-02"))
    assert ("start_date", "INVALID_DATE") in codes(resolve_period("02/11/2026", None, 3))
    assert ("start_date", "INVALID_DATE") in codes(resolve_period("2026-1-2", None, 3))
    assert ("duration_days", "INVALID_DURATION") in codes(resolve_period("2026-11-02", None, 0))
    assert ("duration_days", "DURATION_TOO_LONG") in codes(resolve_period("2026-11-02", None, 400))
    r = codes(resolve_period("2026-11-02"))
    assert ("end_date", "REQUIRED") in r and ("duration_days", "REQUIRED") in r


@pytest.mark.req("FS-M1-003", kind="unit")
def test_demo_button_dates_with_frozen_clock_in_app_timezone(settings):
    # 2026-10-21 20:00 UTC is already Thursday 22 Oct 01:30 in Asia/Kolkata
    clock.freeze(datetime(2026, 10, 21, 20, 0, tzinfo=timezone.utc))
    start, end = demo_period()
    assert start == date(2026, 10, 26) and start.weekday() == 0
    assert end == date(2026, 11, 8)
    assert next_monday(date(2026, 10, 26)) == date(2026, 11, 2)  # strictly after a Monday


@pytest.mark.req("FS-M1-002", kind="integration")
def test_demo_brief_populates_every_required_field_and_passes():
    b = BriefInput.model_validate(demo_brief(fixed=True))
    data = b.model_dump()
    for f in REQUIRED_FIELDS:  # guard: a new required field without a demo value fails here
        assert data[f] not in (None, "", []), f
    res = validate_brief(b)
    assert res.ok, res.errors
    assert b.start_date == "2026-11-02" and b.end_date == "2026-11-15" and b.duration_days == 14


@pytest.mark.req("FS-M1-001", kind="unit+negative")
def test_validation_reports_field_level_errors():
    res = validate_brief(BriefInput())
    fields = {e["field"] for e in res.errors}
    assert set(REQUIRED_FIELDS) - {"currency"} <= fields  # currency defaults to INR
    bad = demo_brief(fixed=True)
    bad.update(total_budget="-5", paid_channels=["tiktok"], landing_page_url="notaurl", currency="XYZ",
               approved_claims=["Same"], prohibited_claims=["same"])
    errs = {(e["field"], e["code"]) for e in validate_brief(BriefInput.model_validate(bad)).errors}
    assert ("total_budget", "NON_POSITIVE_AMOUNT") in errs
    assert ("paid_channels", "UNSUPPORTED_CHANNEL") in errs
    assert ("landing_page_url", "INVALID_URL") in errs
    assert ("currency", "UNSUPPORTED_CURRENCY") in errs
    assert ("approved_claims", "CONTRADICTION") in errs


@pytest.mark.req("FS-M1-001", kind="unit+negative")
def test_budget_precision_and_cadence_rules():
    b = demo_brief(fixed=True)
    b["total_budget"] = "100.005"
    errs = {(e["field"], e["code"]) for e in validate_brief(BriefInput.model_validate(b)).errors}
    assert ("total_budget", "TOO_PRECISE") in errs
    b = demo_brief(fixed=True)
    b["posting_cadence"] = {"type": "custom", "custom_dates": ["2026-12-25"]}
    errs = {(e["field"], e["code"]) for e in validate_brief(BriefInput.model_validate(b)).errors}
    assert ("posting_cadence", "DATE_OUT_OF_RANGE") in errs


@pytest.mark.req("FS-M1-004", kind="unit")
def test_normalization_preserves_original_and_derives_values():
    raw = demo_brief(fixed=True)
    raw["end_date"] = None
    raw["service_areas"] = [" Selaiyur ", "selaiyur", "Tambaram"]
    b = BriefInput.model_validate(raw)
    n = normalize(b)
    assert n["campaign"]["end_date"] == "2026-11-15" and n["campaign"]["duration_days"] == 14
    assert n["campaign"]["budget"] == {"amount": "15000.00", "currency": "INR", "exponent": 2, "minor_units": 1500000}
    assert n["business"]["service_areas"] == ["Selaiyur", "Tambaram"]
    assert n["is_healthcare"] is True
    assert any(a["source"] == "demo_assumption" for a in n["assumptions"])
    assert any(a["source"] == "demo_placeholder" for a in n["assumptions"])
    assert b.end_date is None  # original untouched
    loc = structure_location("Selaiyur, Chennai, Tamil Nadu, India")
    assert (loc["locality"], loc["city"], loc["state"], loc["country"]) == ("Selaiyur", "Chennai", "Tamil Nadu", "India")


@pytest.mark.req("FS-M1-004", kind="unit")
def test_healthcare_override():
    raw = demo_brief(fixed=True)
    raw["is_healthcare"] = False
    n = normalize(BriefInput.model_validate(raw))
    assert n["is_healthcare"] is False and n["is_healthcare_detected"] is True and n["is_healthcare_overridden"]
