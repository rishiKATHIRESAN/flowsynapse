"""Run the real backend as a subprocess on a temporary data directory and
restart it on the same database file (master prompt 15.12)."""
from __future__ import annotations

import os
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import httpx

BACKEND = Path(__file__).resolve().parents[3]


def free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


class BackendProcess:
    def __init__(self, data_dir: Path, port: int | None = None, env: dict[str, str] | None = None) -> None:
        self.data_dir = data_dir
        self.port = port or free_port()
        self.extra_env = env or {}
        self.proc: subprocess.Popen[bytes] | None = None
        self.log = data_dir / f"backend-{self.port}.log"

    @property
    def base(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    def client(self) -> httpx.Client:
        return httpx.Client(base_url=self.base, timeout=30)

    def start(self, timeout: float = 60) -> dict[str, Any]:
        env = dict(os.environ)
        env.update({
            "DATA_DIR": str(self.data_dir), "PORT": str(self.port), "AI_PROVIDER": "mock", "GEMINI_API_KEY": "",
            "LOG_LEVEL": "WARNING", "PYTHONUNBUFFERED": "1", "HEARTBEAT_INTERVAL_SECONDS": "1",
            "STALE_AFTER_SECONDS": "10", "MOCK_FAIL_PLAN": "",
        })
        env.update(self.extra_env)
        kwargs: dict[str, Any] = {}
        if sys.platform == "win32":
            kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP  # type: ignore[attr-defined]
        else:
            kwargs["start_new_session"] = True
        fh = open(self.log, "ab")
        self.proc = subprocess.Popen(
            [sys.executable, "-m", "app.cli", "serve", "--port", str(self.port)],
            cwd=str(BACKEND), env=env, stdout=fh, stderr=subprocess.STDOUT, **kwargs,
        )
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self.proc.poll() is not None:
                raise RuntimeError(f"backend exited early (code {self.proc.returncode}); log: {self.log.read_text(errors='replace')[-2000:]}")
            try:
                h = httpx.get(self.base + "/api/health", timeout=2).json()
                if h.get("app") == "flowsynapse" and h.get("status") == "ok":
                    return h
            except (httpx.HTTPError, ValueError):
                pass
            time.sleep(0.2)
        self.kill()
        raise RuntimeError("backend did not become healthy")

    def stop(self, timeout: float = 30) -> int:
        """Graceful stop (Ctrl+Break / SIGTERM) - runs the controlled shutdown."""
        assert self.proc is not None
        if self.proc.poll() is None:
            if sys.platform == "win32":
                self.proc.send_signal(signal.CTRL_BREAK_EVENT)  # type: ignore[attr-defined]
            else:
                self.proc.send_signal(signal.SIGTERM)
            try:
                self.proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                self.kill()
        return int(self.proc.returncode or 0)

    def kill(self) -> None:
        """Hard kill (simulates a crash); next start runs recovery."""
        if self.proc is not None and self.proc.poll() is None:
            self.proc.kill()
            self.proc.wait(timeout=15)

    def restart(self) -> dict[str, Any]:
        self.stop()
        return self.start()
