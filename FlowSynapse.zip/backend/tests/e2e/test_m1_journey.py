"""Module 1 journey suite against a real backend process (1.2, 15.0).

One small, independent test per capability; each builds its own state.
"""
from __future__ import annotations

import time
from typing import Any

import httpx
import pytest

from app.services.campaign.brief import demo_brief

TERMINAL = ("COMPLETED", "COMPLETED_WITH_WARNINGS", "FAILED", "CANCELLED")


def _create(c: httpx.Client, brief: dict[str, Any] | None = None, demo: bool = True) -> dict[str, Any]:
    r = c.post("/api/campaigns", json={"brief": brief or demo_brief(fixed=True), "is_demo": demo})
    assert r.status_code == 201, r.text
    return r.json()


def _run(c: httpx.Client, cid: str, timeout: float = 60) -> tuple[dict[str, Any], list[str]]:
    r = c.post(f"/api/campaigns/{cid}/executions")
    assert r.status_code == 202, r.text
    eid = r.json()["id"]
    seen = [r.json()["status"]]
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        x = c.get(f"/api/campaigns/{cid}/executions/{eid}").json()
        if x["status"] != seen[-1]:
            seen.append(x["status"])
        if x["status"] in TERMINAL:
            return x, seen
        time.sleep(0.05)
    raise AssertionError("execution did not finish")


@pytest.mark.req("FS-M1-024", kind="e2e")
def test_m1_j01_open_module(backend):
    with backend.client() as c:
        assert c.get("/api/campaigns").json()["items"] == []
        assert c.get("/api/campaigns/demo-brief").status_code == 200


@pytest.mark.req("FS-M1-002", kind="e2e")
@pytest.mark.req("FS-M1-024", kind="e2e")
def test_m1_j02_load_demo_and_validate(backend):
    with backend.client() as c:
        brief = c.get("/api/campaigns/demo-brief").json()["brief"]
        v = c.post("/api/campaigns/validate-brief", json={"brief": brief}).json()
        assert v["valid"] and v["errors"] == []


@pytest.mark.req("FS-M1-024", kind="e2e")
def test_m1_j03_field_level_validation_preserves_input(backend):
    with backend.client() as c:
        brief = demo_brief(fixed=True)
        brief["landing_page_url"] = "not a url"
        created = _create(c, brief)
        assert created["brief"]["landing_page_url"] == "not a url"
        errs = c.post(f"/api/campaigns/{created['id']}/validate").json()["errors"]
        assert errs == [{"field": "landing_page_url", "code": "INVALID_URL", "message": errs[0]["message"]}]


@pytest.mark.req("FS-M1-005", kind="e2e")
@pytest.mark.req("FS-M1-024", kind="e2e")
def test_m1_j04_j05_start_and_observe_real_status(backend):
    with backend.client() as c:
        cid = _create(c)["id"]
        ex, seen = _run(c, cid)
        assert seen[0] == "PENDING" and seen[-1] in ("COMPLETED", "COMPLETED_WITH_WARNINGS")
        assert ex["progress"]["completed"] == ex["progress"]["total"]
        assert all(s["finished_at"] for s in ex["stages"])


@pytest.mark.req("FS-M1-024", kind="e2e")
def test_m1_j06_j07_view_results_with_provenance(backend):
    with backend.client() as c:
        cid = _create(c)["id"]
        _run(c, cid)
        st = c.get(f"/api/campaigns/{cid}/stages/OBJECTIVE_ANALYSIS").json()
        assert st["outputs"] and st["outputs"][0]["is_mock"] is True and st["outputs"][0]["is_demo"] is True
        norm = c.get(f"/api/campaigns/{cid}/stages/BRIEF_NORMALIZATION").json()
        assert norm["original_brief"]["end_date"] == "2026-11-15" and norm["normalized_brief"]["campaign"]["duration_days"] == 14


@pytest.mark.req("FS-M1-020", kind="e2e")
@pytest.mark.req("FS-M1-024", kind="e2e")
def test_m1_j10_j11_reopen_after_restart(backend):
    with backend.client() as c:
        created = _create(c)
        ex, _ = _run(c, created["id"])
        before = c.get(f"/api/campaigns/{created['id']}").json()
        outputs_before = c.get(f"/api/campaigns/{created['id']}/outputs").json()
    backend.restart()
    with backend.client() as c:
        after = c.get(f"/api/campaigns/{created['id']}").json()
        assert after["identifier"] == before["identifier"] and after["brief"] == before["brief"]
        assert after["latest_execution"]["id"] == ex["id"] and after["latest_execution"]["status"] == ex["status"]
        assert [s["status"] for s in after["latest_execution"]["stages"]] == [s["status"] for s in ex["stages"]]
        assert c.get(f"/api/campaigns/{created['id']}/outputs").json() == outputs_before


@pytest.mark.req("FS-M1-024", kind="e2e")
def test_m1_j13_actionable_error_on_failure(backend):
    with backend.client() as c:
        brief = demo_brief(fixed=True)
        brief["start_date"] = "2026-13-40"
        cid = _create(c, brief)["id"]
        ex, _ = _run(c, cid)
        assert ex["status"] == "FAILED" and ex["retryable"] is False
        assert "Fix the highlighted fields" in ex["stages"][0]["error_message"]


@pytest.mark.req("FS-M1-024", kind="e2e")
def test_m1_j12_csv_export(backend):
    with backend.client() as c:
        cid = _create(c)["id"]
        _run(c, cid)
        r = c.get(f"/api/campaigns/{cid}/export.csv", params={"dataset": "Normalized Brief"})
        assert r.status_code == 200
        text = r.content.decode("utf-8-sig")
        assert "duration_days,14" in text and "DEMONSTRATION DATA" in text
