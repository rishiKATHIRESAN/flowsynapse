from __future__ import annotations

from pathlib import Path
from typing import Iterator

import pytest

from tests.e2e.helpers.restart import BackendProcess


@pytest.fixture
def backend(tmp_path: Path) -> Iterator[BackendProcess]:
    b = BackendProcess(tmp_path)
    b.start()
    yield b
    if b.proc is not None and b.proc.poll() is None:
        b.stop()
