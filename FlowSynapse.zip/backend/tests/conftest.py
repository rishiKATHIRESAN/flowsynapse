"""Shared fixtures. Every test gets an isolated data directory and settings."""
from __future__ import annotations

from pathlib import Path
from typing import Iterator

import pytest

from app.config import Settings, set_settings_override
from app.utils.clock import clock

LAYERS = ("unit", "integration", "api", "e2e")


def pytest_collection_modifyitems(config, items):  # type: ignore[no-untyped-def]
    for item in items:
        parts = Path(str(item.fspath)).parts
        for layer in LAYERS:
            if layer in parts:
                item.add_marker(getattr(pytest.mark, layer))
        for m in item.iter_markers(name="req"):
            kind = m.kwargs.get("kind", "unit")
            for rid in m.args:
                item.user_properties.append(("req", f"{rid}|{kind}"))


def make_settings(tmp: Path, **overrides: object) -> Settings:
    base = dict(
        DATA_DIR=str(tmp),
        AI_PROVIDER="mock",
        GEMINI_API_KEY="",
        HEARTBEAT_INTERVAL_SECONDS=0.2,
        STALE_AFTER_SECONDS=60,
        LOG_LEVEL="WARNING",
        ALLOW_PRIVATE_TARGETS=False,
        ALLOW_DEMO_SITE=False,
        MOCK_FAIL_PLAN="",
    )
    base.update(overrides)
    s = Settings(_env_file=None, **base)  # type: ignore[call-arg]
    return s


@pytest.fixture
def settings(tmp_path: Path) -> Iterator[Settings]:
    s = make_settings(tmp_path)
    set_settings_override(s)
    yield s
    set_settings_override(None)


@pytest.fixture(autouse=True)
def _reset_clock() -> Iterator[None]:
    yield
    clock.unfreeze()


@pytest.fixture
def migrated_db(settings: Settings) -> Iterator[Settings]:
    """A fresh database built through Alembic migrations, engine initialised."""
    from app.database import dispose_engine, init_engine
    from app.migrations import safe_migrate

    safe_migrate(settings)
    init_engine(settings.database_url)
    yield settings
    dispose_engine()


@pytest.fixture
def client(settings: Settings) -> Iterator["object"]:
    """TestClient with the full startup sequence (lock, migrate, workers)."""
    from fastapi.testclient import TestClient

    from app.main import create_app

    app = create_app(settings)
    with TestClient(app, base_url="http://127.0.0.1:8000") as c:
        yield c


@pytest.fixture(autouse=True)
def _fast_ai_and_clean_hooks() -> Iterator[None]:
    from app.ai import mock_provider, runner
    from app.services.jobs import worker

    old = runner.BACKOFF_BASE_SECONDS
    runner.BACKOFF_BASE_SECONDS = 0.001
    mock_provider.reset_fail_counters()
    runner._exec_budgets.clear()
    yield
    runner.BACKOFF_BASE_SECONDS = old
    worker.TEST_HOOKS.clear()
    mock_provider.reset_fail_counters()


@pytest.fixture
def idle_client(tmp_path: Path) -> Iterator["object"]:
    """Full app but with zero workers: executions stay PENDING (deterministic)."""
    from fastapi.testclient import TestClient

    from app.main import create_app

    s = make_settings(tmp_path, WORKER_CONCURRENCY=0)
    set_settings_override(s)
    with TestClient(create_app(s), base_url="http://127.0.0.1:8000") as c:
        yield c
    set_settings_override(None)
