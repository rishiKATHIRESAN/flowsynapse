"""A test-only job handler with scriptable stage behaviour."""
from __future__ import annotations

import threading
import time
from typing import Any

from sqlalchemy.orm import Session

from app.database import new_session, session_scope
from app.models.jobs import Execution, ExecutionStage
from app.models.settings import AppSetting
from app.services.jobs import engine
from app.services.jobs.errors import StageError
from app.services.jobs.registry import BaseHandler, StageContext, StageOutcome, register

STAGES = ["S1", "S2", "S3"]


class ScriptedHandler(BaseHandler):
    parent_type = "testjob"
    module = "test"

    def __init__(self) -> None:
        self.behaviour: dict[str, str] = {}
        self.calls: list[str] = []
        self.gate = threading.Event()
        self.entered = threading.Event()
        self.continue_items = False
        self.during: Any = None

    def run_stage(self, ctx: StageContext) -> Any:
        key = ctx.stage_key + (f"/{ctx.item_id}" if ctx.item_id else "")
        self.calls.append(key)
        b = self.behaviour.get(key, "ok")
        if self.during:
            self.during(ctx)
        if b == "fail":
            raise StageError("TEST_FAILURE", f"{key} failed", True)
        if b == "fail_hard":
            raise StageError("TEST_INVALID", f"{key} invalid", False)
        if b == "crash":
            raise ZeroDivisionError("boom")
        if b == "block":
            self.entered.set()
            self.gate.wait(10)
        if b == "sleep":
            time.sleep(0.3)
        return {"value": key, "attempt": ctx.attempt_number}

    def commit_stage(self, db: Session, ctx: StageContext, result: Any) -> StageOutcome:
        key = f"{ctx.execution_id}:{ctx.stage_key}:{ctx.item_id}"
        db.add(AppSetting(key=key[:64], value=str(result["value"])))
        return StageOutcome(output_ref={"setting": key[:64]}, warnings=["w"] if self.behaviour.get(ctx.stage_key) == "warn" else [])

    def continue_on_failure(self, stage_key: str) -> bool:
        return self.continue_items


def install() -> ScriptedHandler:
    h = ScriptedHandler()
    register(h)
    return h


def create(parent_id: str = "p1", stages: list[str] | None = None, items: list[str] | None = None) -> str:
    specs = [engine.StageSpec(s) for s in (STAGES if stages is None else stages)]
    for it in items or []:
        specs.append(engine.StageSpec("ITEM", item_id=it))
    with session_scope(immediate=True) as db:
        c = engine.create_execution(db, parent_type="testjob", parent_id=parent_id, stages=specs,
                                    provider=engine.ProviderInfo("mock", "m", True))
        return c.execution.id


def get(ex_id: str) -> tuple[Execution, list[ExecutionStage]]:
    with new_session() as db:
        ex = db.get(Execution, ex_id)
        assert ex is not None
        stages = list(ex.stages)
        db.expunge_all()
        return ex, stages


def wait_terminal(ex_id: str, timeout: float = 10.0) -> Execution:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        ex, _ = get(ex_id)
        if ex.status in ("COMPLETED", "COMPLETED_WITH_WARNINGS", "FAILED", "CANCELLED"):
            return ex
        time.sleep(0.02)
    raise AssertionError(f"execution {ex_id} did not finish: {get(ex_id)[0].status}")


def wait_for(pred, timeout: float = 5.0) -> None:  # type: ignore[no-untyped-def]
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if pred():
            return
        time.sleep(0.02)
    raise AssertionError("condition not met in time")
