"""Provider selection. The active provider is a global setting; the app never
switches providers on its own, and each execution keeps the provider it
started with (recorded on the execution row)."""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass

from ..config import get_settings
from .base import Provider, ProviderError

log = logging.getLogger("flowsynapse.ai")

PROVIDERS = ("mock", "ollama", "gemini")


@dataclass
class ProviderSelection:
    provider: str
    model: str | None
    is_mock: bool
    config_error: str | None = None


def _setting(key: str) -> str | None:
    try:
        from ..database import new_session
        from ..models.settings import AppSetting

        with new_session() as db:
            row = db.get(AppSetting, key)
            return row.value if row else None
    except Exception:
        return None


def active_provider_name() -> str:
    name = (_setting("ai_provider") or get_settings().AI_PROVIDER or "mock").strip().lower()
    return name if name in PROVIDERS else "mock"


def config_error(name: str) -> str | None:
    s = get_settings()
    if name == "gemini":
        if not s.GEMINI_API_KEY or not s.GEMINI_MODEL:
            return "Gemini requires GEMINI_API_KEY and GEMINI_MODEL in backend/.env."
    if name == "ollama":
        if not s.OLLAMA_MODEL:
            return "Ollama requires OLLAMA_MODEL in backend/.env (and the model pulled locally)."
    return None


def selection(name: str | None = None) -> ProviderSelection:
    name = name or active_provider_name()
    s = get_settings()
    model = {"mock": "mock-deterministic-v1", "ollama": s.OLLAMA_MODEL or None, "gemini": s.GEMINI_MODEL or None}[name]
    return ProviderSelection(name, model, name == "mock", config_error(name))


def build_provider(name: str) -> Provider:
    s = get_settings()
    if name == "mock":
        from .mock_provider import MockProvider

        plan = {}
        if s.MOCK_FAIL_PLAN.strip():
            try:
                plan = json.loads(s.MOCK_FAIL_PLAN)
            except ValueError:
                log.error("MOCK_FAIL_PLAN is not valid JSON; ignoring")
        return MockProvider(plan)
    err = config_error(name)
    if err:
        raise ProviderError("PROVIDER_CONFIG_INVALID", err, False, hint="Fix backend/.env or switch to the mock provider in Settings.")
    if name == "ollama":
        from .ollama_provider import OllamaProvider

        return OllamaProvider(s.OLLAMA_BASE_URL, s.OLLAMA_MODEL, s.AI_TIMEOUT_SECONDS)
    if name == "gemini":
        from .gemini_provider import GeminiProvider

        return GeminiProvider(s.GEMINI_API_KEY, s.GEMINI_MODEL, s.AI_TIMEOUT_SECONDS)
    raise ProviderError("PROVIDER_CONFIG_INVALID", f"Unknown provider {name}", False)
