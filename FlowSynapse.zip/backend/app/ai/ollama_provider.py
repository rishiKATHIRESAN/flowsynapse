"""Ollama provider (local; no key). Works offline only if the model is already
pulled and Ollama is running. Uses ``POST /api/chat`` with ``format: "json"``
and ``GET /api/tags`` for the health check."""
from __future__ import annotations

import requests

from .base import AIRequest, HealthResult, Provider, ProviderError


class OllamaProvider(Provider):
    name = "ollama"
    is_mock = False

    def __init__(self, base_url: str, model: str, timeout: float, session: requests.Session | None = None) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout
        self.session = session or requests.Session()

    def _not_running(self) -> ProviderError:
        return ProviderError(
            "PROVIDER_UNAVAILABLE",
            f"Ollama is not running at {self.base_url}.",
            True,
            hint="Start Ollama (ollama serve) or switch to the mock provider in Settings.",
        )

    def generate(self, req: AIRequest) -> str:
        body = {
            "model": self.model,
            "format": "json",
            "stream": False,
            "messages": [
                {"role": "system", "content": req.system},
                {"role": "user", "content": req.prompt + "\n\nJSON schema:\n" + str(req.schema_json)},
            ],
        }
        try:
            resp = self.session.post(f"{self.base_url}/api/chat", json=body, timeout=self.timeout)
        except requests.Timeout:
            raise ProviderError("PROVIDER_TIMEOUT", "Ollama did not answer in time (local model may be slow).", True,
                                hint="Increase AI_TIMEOUT_SECONDS or use a smaller model.") from None
        except requests.ConnectionError:
            raise self._not_running() from None
        if resp.status_code == 404:
            raise ProviderError("PROVIDER_MODEL_MISSING", f"Ollama model '{self.model}' is not installed.", False,
                                hint=f"Run: ollama pull {self.model}")
        if resp.status_code >= 500:
            raise ProviderError("PROVIDER_UNAVAILABLE", f"Ollama error (HTTP {resp.status_code}).", True)
        if resp.status_code >= 400:
            raise ProviderError("PROVIDER_REQUEST_REJECTED", f"Ollama rejected the request (HTTP {resp.status_code}).", False)
        try:
            return str(resp.json()["message"]["content"])
        except (ValueError, KeyError, TypeError):
            raise ProviderError("PROVIDER_BAD_RESPONSE", "Ollama returned an unexpected response shape.", True) from None

    def health_check(self) -> HealthResult:
        try:
            resp = self.session.get(f"{self.base_url}/api/tags", timeout=5)
            resp.raise_for_status()
            names = [m.get("name", "") for m in resp.json().get("models", [])]
        except requests.RequestException:
            e = self._not_running()
            return HealthResult(False, self.name, self.model, e.message, {"hint": e.hint})
        except ValueError:
            return HealthResult(False, self.name, self.model, "Unexpected response from Ollama.")
        present = any(n == self.model or n.split(":")[0] == self.model for n in names)
        if not present:
            return HealthResult(False, self.name, self.model, f"Model '{self.model}' is not installed in Ollama.",
                                {"hint": f"Run: ollama pull {self.model}", "installed": names[:20]})
        return HealthResult(True, self.name, self.model, "Ollama is running and the model is installed.")
