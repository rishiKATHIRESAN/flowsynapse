"""Deterministic, offline MockProvider (master prompt 3, 3.3).

Outputs are built from the request's actual input data by per-task template
functions registered by each module (parameterised templates, never hard-coded
to the demo business). All output is labelled mock by provenance.

Failure injection:
* input tokens: ``[fail]`` / ``[timeout]`` fail every call of the *first*
  execution attempt (so a manual retry succeeds); ``[invalid]`` always returns
  an invalid structure (the repair attempt also fails).
* ``MOCK_FAIL_PLAN`` (test-only), e.g. ``{"META_ADS": {"fail_attempts": 1}}``:
  the first N stage runs of that task fail entirely. Optional keys:
  ``"mode"``: error|timeout|invalid|auth|rate_limit; ``"fail_calls"``: fail
  only the first N provider calls (absorbed by automatic retries).
  Counters are per process and resettable via :func:`reset_fail_counters`.
"""
from __future__ import annotations

import json
import threading
from typing import Any, Callable

from .base import AIRequest, HealthResult, Provider, ProviderError

MockTemplate = Callable[[dict[str, Any]], dict[str, Any]]
_TEMPLATES: dict[str, MockTemplate] = {}

_lock = threading.Lock()
_stage_runs: dict[str, list[str]] = {}
_call_counts: dict[str, int] = {}


def register_mock(task: str) -> Callable[[MockTemplate], MockTemplate]:
    def deco(fn: MockTemplate) -> MockTemplate:
        _TEMPLATES[task] = fn
        return fn

    return deco


def reset_fail_counters() -> None:
    with _lock:
        _stage_runs.clear()
        _call_counts.clear()


def _contains(data: Any, token: str) -> bool:
    if isinstance(data, str):
        return token in data.lower()
    if isinstance(data, dict):
        return any(_contains(v, token) for v in data.values())
    if isinstance(data, (list, tuple)):
        return any(_contains(v, token) for v in data)
    return False


def _raise_mode(mode: str, task: str) -> str:
    if mode == "timeout":
        raise ProviderError("PROVIDER_TIMEOUT", f"Mock provider timed out on {task} (injected).", True)
    if mode == "invalid":
        return json.dumps({"unexpected": "structure"})
    if mode == "auth":
        raise ProviderError("PROVIDER_AUTH_FAILED", "Mock provider rejected credentials (injected).", False,
                            hint="Check the API key in backend/.env.")
    if mode == "rate_limit":
        raise ProviderError("PROVIDER_RATE_LIMITED", "Mock provider rate limited (injected).", True, retry_after=0.0)
    raise ProviderError("MOCK_INJECTED_FAILURE", f"Mock provider failure on {task} (injected).", True)


class MockProvider(Provider):
    name = "mock"
    model = "mock-deterministic-v1"
    is_mock = True

    def __init__(self, fail_plan: dict[str, Any] | None = None) -> None:
        self.fail_plan = fail_plan or {}

    def generate(self, req: AIRequest) -> str:
        plan = self.fail_plan.get(req.task)
        if plan:
            mode = str(plan.get("mode", "error"))
            with _lock:
                runs = _stage_runs.setdefault(req.task, [])
                if req.stage_run_id and req.stage_run_id not in runs:
                    runs.append(req.stage_run_id)
                run_index = runs.index(req.stage_run_id) + 1 if req.stage_run_id in runs else 1
                _call_counts[req.task] = _call_counts.get(req.task, 0) + 1
                calls = _call_counts[req.task]
            if "fail_calls" in plan:
                if calls <= int(plan["fail_calls"]):
                    out = _raise_mode(mode, req.task)
                    if req.repair_error is None:
                        return out
            elif run_index <= int(plan.get("fail_attempts", 0)):
                out = _raise_mode(mode, req.task)
                return out
        if _contains(req.data, "[invalid]"):
            return json.dumps({"invalid": True, "note": "injected invalid structure"})
        if req.attempt_number == 1 and _contains(req.data, "[timeout]"):
            raise ProviderError("PROVIDER_TIMEOUT", "Mock provider timed out (injected via [timeout]).", True)
        if req.attempt_number == 1 and _contains(req.data, "[fail]"):
            raise ProviderError("MOCK_INJECTED_FAILURE", "Mock provider failure (injected via [fail]). Retry to succeed.", True)
        tmpl = _TEMPLATES.get(req.task)
        if tmpl is None:
            raise ProviderError("MOCK_TEMPLATE_MISSING", f"No mock template for task {req.task}.", False)
        return json.dumps(tmpl(req.data), default=str)

    def health_check(self) -> HealthResult:
        return HealthResult(True, self.name, self.model, "Mock provider ready (deterministic, offline, not real AI).")
