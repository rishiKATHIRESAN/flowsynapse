"""Provider abstraction (master prompt 3)."""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class AIRequest:
    task: str
    system: str
    prompt: str
    schema_json: dict[str, Any]
    data: dict[str, Any] = field(default_factory=dict)
    stage_run_id: str = ""
    attempt_number: int = 1
    repair_error: str | None = None


class ProviderError(Exception):
    """Sanitized provider failure."""

    def __init__(
        self,
        code: str,
        message: str,
        retryable: bool,
        retry_after: float | None = None,
        hint: str | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.retryable = retryable
        self.retry_after = retry_after
        self.hint = hint


@dataclass
class HealthResult:
    ok: bool
    provider: str
    model: str | None
    message: str
    details: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "provider": self.provider,
            "model": self.model,
            "message": self.message,
            "details": self.details,
        }


class Provider(ABC):
    name: str = ""
    model: str | None = None
    is_mock: bool = False

    @abstractmethod
    def generate(self, req: AIRequest) -> str:
        """Return the raw model text (expected to be JSON)."""

    @abstractmethod
    def health_check(self) -> HealthResult:
        """Never triggers generation."""
