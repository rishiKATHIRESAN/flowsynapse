"""Gemini provider (hosted; requires network, may incur charges).

Interface verified 2026-10-21 against https://ai.google.dev/api/generate-content:
``POST /v1beta/models/{model}:generateContent`` with ``contents[].parts[].text``
and ``generationConfig.response_mime_type = application/json``; text is in
``candidates[].content.parts[].text``. The key is sent in the
``x-goog-api-key`` header (never in the URL) and is never logged.
Health check: ``GET /v1beta/models/{model}`` (metadata only, no generation).
"""
from __future__ import annotations

import requests

from ..utils.redact import redact, register_secret
from .base import AIRequest, HealthResult, Provider, ProviderError

BASE_URL = "https://generativelanguage.googleapis.com/v1beta"


def _model_path(model: str) -> str:
    return model if model.startswith("models/") else f"models/{model}"


class GeminiProvider(Provider):
    name = "gemini"
    is_mock = False

    def __init__(self, api_key: str, model: str, timeout: float, session: requests.Session | None = None) -> None:
        self._key = api_key
        register_secret(api_key)
        self.model = model
        self.timeout = timeout
        self.session = session or requests.Session()

    def _headers(self) -> dict[str, str]:
        return {"x-goog-api-key": self._key, "Content-Type": "application/json"}

    def _raise_for(self, resp: requests.Response) -> None:
        code = resp.status_code
        if code in (401, 403):
            raise ProviderError("PROVIDER_AUTH_FAILED", f"Gemini rejected the API key (HTTP {code}).", False,
                                hint="Check GEMINI_API_KEY in backend/.env.")
        if code == 404:
            raise ProviderError("PROVIDER_MODEL_MISSING", f"Gemini model '{self.model}' was not found.", False,
                                hint="Check GEMINI_MODEL in backend/.env.")
        if code == 429:
            ra = resp.headers.get("Retry-After")
            raise ProviderError("PROVIDER_RATE_LIMITED", "Gemini rate limit or quota reached (HTTP 429).", True,
                                retry_after=float(ra) if ra and ra.replace(".", "", 1).isdigit() else None,
                                hint="Wait, check your quota, or switch to the mock provider.")
        if code >= 500:
            raise ProviderError("PROVIDER_UNAVAILABLE", f"Gemini service error (HTTP {code}).", True)
        if code >= 400:
            raise ProviderError("PROVIDER_REQUEST_REJECTED", f"Gemini rejected the request (HTTP {code}).", False)

    def generate(self, req: AIRequest) -> str:
        body = {
            "systemInstruction": {"parts": [{"text": req.system}]},
            "contents": [{"role": "user", "parts": [{"text": req.prompt + "\n\nJSON schema:\n" + str(req.schema_json)}]}],
            "generationConfig": {"response_mime_type": "application/json", "temperature": 0.4},
        }
        try:
            resp = self.session.post(
                f"{BASE_URL}/{_model_path(self.model or '')}:generateContent",
                json=body, headers=self._headers(), timeout=self.timeout,
            )
        except requests.Timeout:
            raise ProviderError("PROVIDER_TIMEOUT", "Gemini request timed out.", True) from None
        except requests.RequestException as exc:
            raise ProviderError("NETWORK_ERROR", "Could not reach Gemini (network unavailable?): " + redact(type(exc).__name__),
                                True, hint="Check your internet connection or switch to the mock provider.") from None
        self._raise_for(resp)
        try:
            data = resp.json()
            parts = data["candidates"][0]["content"]["parts"]
            return "".join(p.get("text", "") for p in parts)
        except (ValueError, KeyError, IndexError, TypeError):
            raise ProviderError("PROVIDER_BAD_RESPONSE", "Gemini returned an unexpected response shape.", True) from None

    def health_check(self) -> HealthResult:
        try:
            resp = self.session.get(f"{BASE_URL}/{_model_path(self.model or '')}", headers=self._headers(), timeout=min(self.timeout, 15))
        except requests.RequestException as exc:
            return HealthResult(False, self.name, self.model, "Could not reach Gemini: " + redact(type(exc).__name__),
                                {"hint": "Requires network access."})
        try:
            self._raise_for(resp)
        except ProviderError as exc:
            return HealthResult(False, self.name, self.model, exc.message, {"code": exc.code, "hint": exc.hint})
        return HealthResult(True, self.name, self.model, "Gemini model metadata retrieved (no generation performed).")
