from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, CheckConstraint, Index, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from ..database import Base
from ..utils.clock import utcnow
from .base import UTCDateTime, id_column


class FileExport(Base):
    """Every generated report/export file (master prompt 2.7)."""

    __tablename__ = "file_exports"
    __table_args__ = (
        CheckConstraint(
            "status IN ('PENDING','COMPLETED','COMPLETED_WITH_WARNINGS','FAILED')", name="status_valid"
        ),
        Index("ix_file_exports_parent", "parent_type", "parent_id", "created_at"),
    )

    id: Mapped[str] = id_column()
    module: Mapped[str] = mapped_column(String(32), nullable=False)
    parent_type: Mapped[str] = mapped_column(String(32), nullable=False)
    parent_id: Mapped[str] = mapped_column(String(32), nullable=False)
    format: Mapped[str] = mapped_column(String(8), nullable=False)
    dataset: Mapped[str | None] = mapped_column(String(48), nullable=True)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="PENDING")
    file_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    download_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    content_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)
    size_bytes: Mapped[int | None] = mapped_column(nullable=True)
    source_version: Mapped[str | None] = mapped_column(String(64), nullable=True)
    source_versions: Mapped[str | None] = mapped_column(Text, nullable=True)
    warnings: Mapped[str | None] = mapped_column(Text, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_demo: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    is_stale: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, nullable=False)
    finished_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    last_accessed_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    purged_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
