"""Generic generated/editable outputs and their versions (master prompt 3.2, 3.5).

Every generated or editable output in every module is an ``outputs`` row
(e.g. a campaign concept, an ad asset, a social item, a blog draft, a funnel
node's content recommendations). Its versions live in ``output_versions``
with a foreign key to the output, so orphan versions are impossible.
Decision D8 in docs/ARCHITECTURE.md.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    text,
)
from sqlalchemy.orm import Mapped, mapped_column

from ..database import Base
from ..utils.clock import utcnow
from .base import TimestampMixin, UTCDateTime, id_column

ORIGINS = ("AI_GENERATED", "MOCK_GENERATED", "MANUALLY_EDITED", "REGENERATED")
CONTENT_STATUSES = ("DRAFT", "READY_FOR_REVIEW", "NEEDS_REVISION", "READY_TO_EXPORT")
GENERATION_STATUSES = ("PENDING", "RUNNING", "COMPLETED", "FAILED")


class Output(TimestampMixin, Base):
    __tablename__ = "outputs"
    __table_args__ = (
        UniqueConstraint("parent_type", "parent_id", "output_type", "item_key", name="uq_outputs_identity"),
        Index("ix_outputs_parent", "parent_type", "parent_id", "output_type"),
        CheckConstraint(
            "content_status IS NULL OR content_status IN ('DRAFT','READY_FOR_REVIEW','NEEDS_REVISION','READY_TO_EXPORT')",
            name="content_status_valid",
        ),
        CheckConstraint(
            "generation_status IN ('PENDING','RUNNING','COMPLETED','FAILED')", name="generation_status_valid"
        ),
    )

    id: Mapped[str] = id_column()
    parent_type: Mapped[str] = mapped_column(String(32), nullable=False)
    parent_id: Mapped[str] = mapped_column(String(32), nullable=False)
    output_type: Mapped[str] = mapped_column(String(48), nullable=False)
    item_key: Mapped[str] = mapped_column(String(64), nullable=False, default="")
    position: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    # Inputs that produced this item (e.g. a blog topic row); not versioned.
    inputs: Mapped[str | None] = mapped_column(Text, nullable=True)
    # Denormalised copy of the active version's content for queries.
    content: Mapped[str | None] = mapped_column(Text, nullable=True)
    active_version_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    version_number: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    content_status: Mapped[str | None] = mapped_column(String(24), nullable=True)
    generation_status: Mapped[str] = mapped_column(String(16), nullable=False, default="COMPLETED")
    generation_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_outdated: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    outdated_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    validity: Mapped[str] = mapped_column(String(16), nullable=False, default="VALID")
    validity_details: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_discarded: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    is_demo: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    status_history: Mapped[str | None] = mapped_column(Text, nullable=True)


class OutputVersion(Base):
    __tablename__ = "output_versions"
    __table_args__ = (
        UniqueConstraint("output_id", "version_number", name="uq_output_versions_number"),
        Index(
            "uq_output_versions_one_active",
            "output_id",
            unique=True,
            sqlite_where=text("is_active = 1"),
        ),
        CheckConstraint(
            "origin IN ('AI_GENERATED','MOCK_GENERATED','MANUALLY_EDITED','REGENERATED')", name="origin_valid"
        ),
        Index("ix_output_versions_output", "output_id", "version_number"),
        Index("ix_output_versions_execution", "execution_id"),
    )

    id: Mapped[str] = id_column()
    output_id: Mapped[str] = mapped_column(ForeignKey("outputs.id", ondelete="CASCADE"), nullable=False)
    output_type: Mapped[str] = mapped_column(String(48), nullable=False)
    parent_type: Mapped[str] = mapped_column(String(32), nullable=False)
    parent_id: Mapped[str] = mapped_column(String(32), nullable=False)
    version_number: Mapped[int] = mapped_column(Integer, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    content_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    origin: Mapped[str] = mapped_column(String(24), nullable=False)
    provider: Mapped[str | None] = mapped_column(String(32), nullable=True)
    model: Mapped[str | None] = mapped_column(String(128), nullable=True)
    is_mock: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    generated_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    execution_id: Mapped[str | None] = mapped_column(
        ForeignKey("executions.id", ondelete="SET NULL"), nullable=True
    )
    stage_key: Mapped[str | None] = mapped_column(String(48), nullable=True)
    item_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    source_input_version: Mapped[str | None] = mapped_column(String(64), nullable=True)
    previous_version_id: Mapped[str | None] = mapped_column(
        ForeignKey("output_versions.id", ondelete="SET NULL"), nullable=True
    )
    original_generation_version_id: Mapped[str | None] = mapped_column(
        ForeignKey("output_versions.id", ondelete="SET NULL"), nullable=True
    )
    edit_summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, nullable=False)
