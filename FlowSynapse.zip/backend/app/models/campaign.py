"""Campaign Intelligence data model (master prompt 5.6).

Consolidation (decision D8): generated/editable outputs (objective analysis,
strategy, concepts, ad assets, social items, tracking plan, budget, pack) are
generic ``outputs`` rows with ``parent_type='campaign'`` and versioned via
``output_versions``. Executions use the shared ``executions`` tables.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, CheckConstraint, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from ..database import Base
from ..utils.clock import utcnow
from .base import TimestampMixin, UTCDateTime, id_column


class Campaign(TimestampMixin, Base):
    __tablename__ = "campaigns"
    __table_args__ = (
        Index("ix_campaigns_updated", "updated_at"),
        Index("ix_campaigns_demo_key", "demo_key", unique=True),
    )

    id: Mapped[str] = id_column()
    identifier: Mapped[str] = mapped_column(String(32), nullable=False, unique=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False, default="Untitled campaign")
    brief_original: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
    brief_normalized: Mapped[str | None] = mapped_column(Text, nullable=True)
    assumptions: Mapped[str | None] = mapped_column(Text, nullable=True)
    brief_valid: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    validation: Mapped[str | None] = mapped_column(Text, nullable=True)
    content_version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    brief_version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    is_demo: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    demo_key: Mapped[str | None] = mapped_column(String(64), nullable=True)
    website_context: Mapped[str | None] = mapped_column(Text, nullable=True)


class CampaignStageState(Base):
    """Mutable current state per stage (outdated flag lives here, never on
    immutable execution rows)."""

    __tablename__ = "campaign_stage_states"

    campaign_id: Mapped[str] = mapped_column(ForeignKey("campaigns.id", ondelete="CASCADE"), primary_key=True)
    stage_key: Mapped[str] = mapped_column(String(48), primary_key=True)
    is_outdated: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    outdated_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    outdated_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    current_stage_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)


class CampaignFinding(Base):
    __tablename__ = "campaign_findings"
    __table_args__ = (
        CheckConstraint("severity IN ('BLOCKER','WARNING','INFO')", name="severity_valid"),
        Index("ix_campaign_findings_campaign", "campaign_id"),
    )

    id: Mapped[str] = id_column()
    campaign_id: Mapped[str] = mapped_column(ForeignKey("campaigns.id", ondelete="CASCADE"), nullable=False)
    execution_id: Mapped[str | None] = mapped_column(ForeignKey("executions.id", ondelete="SET NULL"), nullable=True)
    rule_id: Mapped[str] = mapped_column(String(48), nullable=False)
    severity: Mapped[str] = mapped_column(String(16), nullable=False)
    category: Mapped[str] = mapped_column(String(48), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    evidence: Mapped[str | None] = mapped_column(Text, nullable=True)
    field: Mapped[str | None] = mapped_column(String(200), nullable=True)
    recommended_correction: Mapped[str | None] = mapped_column(Text, nullable=True)
    blocks_completion: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    source: Mapped[str] = mapped_column(String(16), nullable=False, default="RULE")
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, nullable=False)
