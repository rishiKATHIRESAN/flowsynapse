"""Shared execution (job) records for every module (master prompt 2.3).

One ``executions`` table with ``parent_type``/``parent_id`` serves all six
modules (identical semantics; documented decision D7). Stage/item rows live in
``execution_stages``; ``item_id`` distinguishes per-item units (blog topics,
funnel nodes, social items).
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..database import Base
from ..utils.clock import utcnow
from .base import UTCDateTime, id_column

EXECUTION_STATES = ("PENDING", "RUNNING", "COMPLETED", "COMPLETED_WITH_WARNINGS", "FAILED", "CANCELLED")
STAGE_STATES = ("PENDING", "RUNNING", "COMPLETED", "FAILED", "CANCELLED", "SKIPPED", "CARRIED_FORWARD")
SCOPES = ("FULL", "STAGE_RETRY", "STAGE_REGENERATE", "OUTPUT_REGENERATE", "ITEM_RETRY")


def _in(col: str, values: tuple[str, ...]) -> str:
    return f"{col} IN (" + ",".join(f"'{v}'" for v in values) + ")"


class Execution(Base):
    __tablename__ = "executions"
    __table_args__ = (
        CheckConstraint(_in("status", EXECUTION_STATES), name="status_valid"),
        CheckConstraint(_in("scope", SCOPES), name="scope_valid"),
        Index(
            "uq_executions_one_active",
            "parent_type",
            "parent_id",
            unique=True,
            sqlite_where=text("status IN ('PENDING','RUNNING')"),
        ),
        Index("ix_executions_parent", "parent_type", "parent_id", "created_at"),
        Index("ix_executions_status", "status"),
    )

    id: Mapped[str] = id_column()
    parent_type: Mapped[str] = mapped_column(String(32), nullable=False)
    parent_id: Mapped[str] = mapped_column(String(32), nullable=False)
    scope: Mapped[str] = mapped_column(String(24), nullable=False, default="FULL")
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="PENDING")
    retry_of_execution_id: Mapped[str | None] = mapped_column(
        ForeignKey("executions.id", ondelete="SET NULL"), nullable=True
    )
    attempt_number: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    params: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
    claimed_by: Mapped[str | None] = mapped_column(String(64), nullable=True)
    claim_token: Mapped[str | None] = mapped_column(String(32), nullable=True)
    claimed_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    heartbeat_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    cancel_requested: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    error_code: Mapped[str | None] = mapped_column(String(64), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    retryable: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    ai_calls_used: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    provider: Mapped[str | None] = mapped_column(String(32), nullable=True)
    model: Mapped[str | None] = mapped_column(String(128), nullable=True)
    is_mock: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    is_demo: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    max_duration_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)
    warnings_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, nullable=False)
    started_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    row_version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)

    stages: Mapped[list["ExecutionStage"]] = relationship(
        back_populates="execution",
        cascade="all, delete-orphan",
        order_by="ExecutionStage.position",
        passive_deletes=True,
    )


class ExecutionStage(Base):
    __tablename__ = "execution_stages"
    __table_args__ = (
        CheckConstraint(_in("status", STAGE_STATES), name="status_valid"),
        UniqueConstraint("execution_id", "stage_key", "item_id", name="uq_execution_stages_key"),
        Index("ix_execution_stages_execution", "execution_id", "position"),
        Index("ix_execution_stages_stage_key", "stage_key"),
    )

    id: Mapped[str] = id_column()
    execution_id: Mapped[str] = mapped_column(
        ForeignKey("executions.id", ondelete="CASCADE"), nullable=False
    )
    stage_key: Mapped[str] = mapped_column(String(48), nullable=False)
    item_id: Mapped[str] = mapped_column(String(64), nullable=False, default="")
    position: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[str] = mapped_column(String(24), nullable=False, default="PENDING")
    required: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    carried_from_stage_id: Mapped[str | None] = mapped_column(
        ForeignKey("execution_stages.id", ondelete="SET NULL"), nullable=True
    )
    output_ref: Mapped[str | None] = mapped_column(Text, nullable=True)
    input_snapshot: Mapped[str | None] = mapped_column(Text, nullable=True)
    error_code: Mapped[str | None] = mapped_column(String(64), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    retryable: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    attempt_count: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    ai_calls_used: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    provider: Mapped[str | None] = mapped_column(String(32), nullable=True)
    model: Mapped[str | None] = mapped_column(String(128), nullable=True)
    is_mock: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    warnings: Mapped[str | None] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)

    execution: Mapped[Execution] = relationship(back_populates="stages")


class WorkflowRun(Base):
    """Generic execution-history log across modules (master prompt 4)."""

    __tablename__ = "workflow_runs"
    __table_args__ = (
        Index("ix_workflow_runs_created", "created_at"),
        Index("ix_workflow_runs_module", "module"),
    )

    id: Mapped[str] = id_column()
    module: Mapped[str] = mapped_column(String(32), nullable=False)
    parent_type: Mapped[str] = mapped_column(String(32), nullable=False)
    parent_id: Mapped[str] = mapped_column(String(32), nullable=False)
    execution_id: Mapped[str] = mapped_column(
        ForeignKey("executions.id", ondelete="CASCADE"), nullable=False, unique=True
    )
    title: Mapped[str] = mapped_column(String(200), nullable=False, default="")
    status: Mapped[str] = mapped_column(String(32), nullable=False)
    scope: Mapped[str] = mapped_column(String(24), nullable=False)
    provider: Mapped[str | None] = mapped_column(String(32), nullable=True)
    is_mock: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    is_demo: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, nullable=False)
    started_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
