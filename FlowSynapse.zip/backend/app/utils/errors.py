"""Standard error format: {"error": {"code", "message", "details"}}."""
from __future__ import annotations

import logging
from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from .redact import redact

log = logging.getLogger("flowsynapse.errors")


class AppError(Exception):
    """Raise anywhere in request handling to return a standard error."""

    def __init__(
        self,
        status_code: int,
        code: str,
        message: str,
        details: Any = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.message = message
        self.details = details
        self.headers = headers or {}


def not_found(what: str, ident: Any = None) -> AppError:
    msg = f"{what} not found" if ident is None else f"{what} {ident} not found"
    return AppError(404, "NOT_FOUND", msg)


def conflict(code: str, message: str, details: Any = None) -> AppError:
    return AppError(409, code, message, details)


def field_error(field: str, code: str, message: str) -> dict[str, str]:
    return {"field": field, "code": code, "message": message}


def validation_failed(errors: list[dict[str, str]], message: str = "Validation failed") -> AppError:
    return AppError(422, "VALIDATION_ERROR", message, {"fields": errors})


def error_body(code: str, message: str, details: Any = None) -> dict[str, Any]:
    return {"error": {"code": code, "message": message, "details": details}}


def _loc_to_field(loc: tuple[Any, ...] | list[Any]) -> str:
    parts = [str(p) for p in loc if p not in ("body", "query", "path", "header")]
    return ".".join(parts) if parts else "body"


def install_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(AppError)
    async def _app_error(_req: Request, exc: AppError) -> JSONResponse:
        return JSONResponse(
            status_code=exc.status_code,
            content=error_body(exc.code, exc.message, exc.details),
            headers=exc.headers,
        )

    @app.exception_handler(RequestValidationError)
    async def _validation(_req: Request, exc: RequestValidationError) -> JSONResponse:
        fields = []
        for e in exc.errors():
            fields.append(
                {
                    "field": _loc_to_field(e.get("loc", ())),
                    "code": str(e.get("type", "invalid")).upper(),
                    "message": str(e.get("msg", "Invalid value")),
                }
            )
        return JSONResponse(
            status_code=422,
            content=error_body("VALIDATION_ERROR", "Request validation failed", {"fields": fields}),
        )

    @app.exception_handler(StarletteHTTPException)
    async def _http(_req: Request, exc: StarletteHTTPException) -> JSONResponse:
        code = {404: "NOT_FOUND", 405: "METHOD_NOT_ALLOWED", 413: "PAYLOAD_TOO_LARGE"}.get(
            exc.status_code, "HTTP_ERROR"
        )
        return JSONResponse(
            status_code=exc.status_code,
            content=error_body(code, str(exc.detail)),
            headers=getattr(exc, "headers", None) or {},
        )

    @app.exception_handler(Exception)
    async def _unhandled(req: Request, exc: Exception) -> JSONResponse:
        rid = getattr(req.state, "request_id", "-")
        log.error("unhandled error request_id=%s: %s", rid, redact(repr(exc)), exc_info=exc)
        from ..database import DatabaseBusyError

        if isinstance(exc, DatabaseBusyError):
            return JSONResponse(
                status_code=503,
                content=error_body("DATABASE_BUSY", str(exc), {"retryable": True}),
                headers={"Retry-After": "1"},
            )
        return JSONResponse(
            status_code=500,
            content=error_body(
                "INTERNAL_ERROR",
                "An unexpected error occurred. See server logs for request " + str(rid),
            ),
        )
