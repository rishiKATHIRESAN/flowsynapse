"""Injectable clock so tests can freeze or advance time deterministically."""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from ..config import get_settings


class Clock:
    def __init__(self) -> None:
        self._frozen: datetime | None = None

    def now(self) -> datetime:
        if self._frozen is not None:
            return self._frozen
        return datetime.now(timezone.utc)

    def freeze(self, at: datetime) -> None:
        if at.tzinfo is None:
            at = at.replace(tzinfo=timezone.utc)
        self._frozen = at.astimezone(timezone.utc)

    def advance(self, seconds: float) -> None:
        if self._frozen is None:
            self._frozen = datetime.now(timezone.utc)
        self._frozen = self._frozen + timedelta(seconds=seconds)

    def unfreeze(self) -> None:
        self._frozen = None

    @property
    def frozen(self) -> bool:
        return self._frozen is not None


clock = Clock()


def utcnow() -> datetime:
    return clock.now()


def local_today() -> date:
    """'Today' in APP_TIMEZONE (master prompt 2.2 / 5.7)."""
    tz = ZoneInfo(get_settings().APP_TIMEZONE)
    return utcnow().astimezone(tz).date()


def ensure_aware(dt: datetime | None) -> datetime | None:
    """SQLite returns naive datetimes; we always store UTC."""
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def iso(dt: datetime | None) -> str | None:
    dt = ensure_aware(dt)
    return dt.isoformat().replace("+00:00", "Z") if dt else None
