"""Secret redaction for logs, exceptions and stored error messages (3.4)."""
from __future__ import annotations

import logging
import re

_PATTERNS = [
    re.compile(r"(?i)([?&](?:key|api_key|apikey|token|access_token)=)[^&\s'\"]+"),
    re.compile(r"(?i)((?:x-goog-api-key|authorization|api[-_]?key)\s*[:=]\s*)(?:Bearer\s+)?[^\s,'\"}]+"),
    re.compile(r"AIza[0-9A-Za-z_\-]{20,}"),
]

_extra_secrets: set[str] = set()


def register_secret(value: str | None) -> None:
    """Exact secret values (e.g. the configured API key) are always masked."""
    if value and len(value) >= 6:
        _extra_secrets.add(value)


def redact(text: str | None) -> str:
    if not text:
        return text or ""
    out = text
    for s in _extra_secrets:
        out = out.replace(s, "***REDACTED***")
    out = _PATTERNS[0].sub(r"\1***REDACTED***", out)
    out = _PATTERNS[1].sub(r"\1***REDACTED***", out)
    out = _PATTERNS[2].sub("***REDACTED***", out)
    return out


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
        except Exception:  # pragma: no cover - malformed log call
            return True
        red = redact(msg)
        if red != msg:
            record.msg = red
            record.args = ()
        if record.exc_text:
            record.exc_text = redact(record.exc_text)
        return True
