"""Process model: startup order, lock, recovery and controlled shutdown (2.6)."""
from __future__ import annotations

import logging
import shutil
import uuid
from typing import Callable, Protocol

from .config import Settings, get_settings
from .database import dispose_engine, init_engine
from .migrations import (
    NewerDatabaseError,
    PendingMigrationsError,
    checkpoint,
    cleanup_leftovers,
    db_revision,
    pending,
    safe_migrate,
)
from .process_lock import ProcessLock

log = logging.getLogger("flowsynapse.runtime")


class Service(Protocol):
    def start(self) -> None: ...
    def stop(self, grace_seconds: float) -> None: ...


class StartupError(Exception):
    pass


class Runtime:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()
        self.instance_id = uuid.uuid4().hex
        self.status = "starting"
        self.error: str | None = None
        self.lock = ProcessLock(self.settings.lock_path)
        self.services: list[Service] = []
        self.db_revision: str | None = None
        self.shutdown_requested = False
        # Hooks registered by later phases (recovery, workers, cleanup tasks).
        self.recovery_hooks: list[Callable[[], None]] = []
        self.service_factories: list[Callable[["Runtime"], Service]] = []

    # ------------------------------------------------------------------
    def startup(self) -> None:
        s = self.settings
        try:
            # 1. configuration is loaded (invalid provider config is non-fatal)
            s.data_dir.mkdir(parents=True, exist_ok=True)
            # 2. exclusive process lock
            self.lock.acquire(port=s.PORT)
            # 3. disk check + safe migrations under the lock
            free_mb = shutil.disk_usage(str(s.data_dir)).free // (1024 * 1024)
            if free_mb < s.MIN_FREE_DISK_MB:
                raise StartupError(
                    f"Only {free_mb} MB free disk space; at least {s.MIN_FREE_DISK_MB} MB is required."
                )
            cleanup_leftovers(s.db_path)
            if not s.AUTO_MIGRATE and pending(s.db_path):
                raise PendingMigrationsError(
                    "Pending database migrations and AUTO_MIGRATE=false. Run: python -m app.cli migrate"
                )
            result = safe_migrate(s)
            if result.drift:
                log.warning("schema drift detected: %s", result.drift)
            self.db_revision = db_revision(s.db_path)
            # 4. database engine
            init_engine(s.database_url)
            # 5. recovery of interrupted work
            for hook in self.recovery_hooks:
                hook()
            # 6. workers, watchdog and cleanup tasks
            for factory in self.service_factories:
                svc = factory(self)
                svc.start()
                self.services.append(svc)
            self.status = "ok"
            log.info("FlowSynapse started (instance %s, revision %s)", self.instance_id, self.db_revision)
        except NewerDatabaseError as exc:
            self._abort(str(exc))
            raise StartupError(str(exc)) from exc
        except Exception as exc:
            self._abort(str(exc))
            raise

    def _abort(self, message: str) -> None:
        self.status = "error"
        self.error = message
        log.error("startup aborted: %s", message)
        for svc in reversed(self.services):
            try:
                svc.stop(0)
            except Exception:  # pragma: no cover
                log.exception("service stop failed during abort")
        self.services.clear()
        dispose_engine()
        self.lock.release()

    def shutdown(self) -> None:
        if self.status == "stopped":
            return
        self.shutdown_requested = True
        self.status = "stopping"
        for svc in reversed(self.services):
            try:
                svc.stop(self.settings.SHUTDOWN_GRACE_SECONDS)
            except Exception:
                log.exception("service stop failed")
        self.services.clear()
        dispose_engine()
        try:
            checkpoint(self.settings.db_path)
        except Exception:  # pragma: no cover
            log.exception("WAL checkpoint failed")
        self.lock.release()
        self.status = "stopped"
        log.info("FlowSynapse stopped cleanly")
