"""Application configuration.

Every variable read here must be documented in ``backend/.env.example`` and the
README configuration table (enforced by ``scripts/check_docs.py``).
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Optional

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BACKEND_DIR / "data"
APP_VERSION = "0.1.0"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=str(BACKEND_DIR / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # AI providers
    AI_PROVIDER: str = "mock"
    GEMINI_API_KEY: str = ""
    GEMINI_MODEL: str = ""
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = ""
    AI_TIMEOUT_SECONDS: float = 60.0
    MOCK_FAIL_PLAN: str = ""

    # Storage / network
    DATABASE_URL: str = ""
    DATA_DIR: str = ""
    CORS_ORIGINS: str = "http://127.0.0.1:5173,http://localhost:5173"
    HOST: str = "127.0.0.1"
    PORT: int = 8000
    FRONTEND_PORT: int = 5173
    ALLOW_LAN: bool = False
    APP_TIMEZONE: str = "Asia/Kolkata"
    LOG_LEVEL: str = "INFO"

    # Crawl
    ALLOW_PRIVATE_TARGETS: bool = False
    ALLOW_DEMO_SITE: bool = False
    DEMO_SITE_PORT: int = 8765
    SEO_MAX_DEPTH: int = 5
    SEO_MAX_PAGES_LIMIT: int = 200
    FETCH_MAX_ATTEMPTS: int = 2

    # Provider budgets
    PROVIDER_MAX_ATTEMPTS: int = 3
    STAGE_AI_CALL_BUDGET: int = 4
    EXECUTION_AI_CALL_BUDGET: Optional[int] = None

    # Jobs
    JOB_MAX_ATTEMPTS: int = 5
    WORKER_CONCURRENCY: int = 2
    MAX_QUEUED_JOBS: int = 20
    HEARTBEAT_INTERVAL_SECONDS: float = 5.0
    STALE_AFTER_SECONDS: float = 60.0
    JOB_MAX_DURATION_SECONDS: float = 1800.0
    SHUTDOWN_GRACE_SECONDS: float = 15.0

    # Limits / retention
    MAX_BODY_BYTES: int = 2_000_000
    EXPORT_RETENTION_DAYS: int = 7
    OUTPUT_VERSIONS_KEEP: int = 20
    MIN_FREE_DISK_MB: int = 200
    AUTO_MIGRATE: bool = True

    @field_validator("EXECUTION_AI_CALL_BUDGET", mode="before")
    @classmethod
    def _blank_is_none(cls, v):  # type: ignore[no-untyped-def]
        if v is None or (isinstance(v, str) and not v.strip()):
            return None
        return v

    # ---- derived helpers -------------------------------------------------
    @property
    def data_dir(self) -> Path:
        return Path(self.DATA_DIR).resolve() if self.DATA_DIR else DATA_DIR

    @property
    def db_path(self) -> Path:
        if self.DATABASE_URL:
            prefix = "sqlite:///"
            if not self.DATABASE_URL.startswith(prefix):
                raise ValueError("Only sqlite:/// DATABASE_URL values are supported")
            return Path(self.DATABASE_URL[len(prefix):]).resolve()
        return self.data_dir / "flowsynapse.db"

    @property
    def database_url(self) -> str:
        return "sqlite:///" + self.db_path.as_posix()

    @property
    def exports_dir(self) -> Path:
        return self.data_dir / "exports"

    @property
    def backups_dir(self) -> Path:
        return self.data_dir / "backups"

    @property
    def lock_path(self) -> Path:
        return self.db_path.parent / "flowsynapse.lock"

    @property
    def cors_origins(self) -> list[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]

    def execution_call_budget(self, stage_count: int) -> int:
        if self.EXECUTION_AI_CALL_BUDGET:
            return int(self.EXECUTION_AI_CALL_BUDGET)
        return 6 * max(stage_count, 1)

    def allowed_hosts(self) -> set[str]:
        hosts = {"127.0.0.1", "localhost", "testserver"}
        out: set[str] = set()
        for h in hosts:
            out.add(h)
            for p in (self.PORT, self.FRONTEND_PORT):
                out.add(f"{h}:{p}")
        if self.ALLOW_LAN and self.HOST not in ("127.0.0.1", "localhost"):
            out.add(self.HOST)
            out.add(f"{self.HOST}:{self.PORT}")
        return out


_override: Settings | None = None


@lru_cache(maxsize=1)
def _load() -> Settings:
    return Settings()


def get_settings() -> Settings:
    return _override if _override is not None else _load()


def set_settings_override(s: Settings | None) -> None:
    """Used by tests and the CLI to inject explicit settings."""
    global _override
    _override = s
    _load.cache_clear()


# Expose field names for docs checks
CONFIG_FIELDS = list(Settings.model_fields.keys())
