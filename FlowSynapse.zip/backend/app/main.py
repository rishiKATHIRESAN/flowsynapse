"""FlowSynapse FastAPI application factory."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncIterator

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .config import APP_VERSION, BACKEND_DIR, Settings, get_settings
from .logging_setup import setup_logging
from .middleware import GuardMiddleware, RequestIdMiddleware, SecurityHeadersMiddleware
from .runtime import Runtime
from .utils.errors import error_body, install_error_handlers
from .utils.redact import register_secret

log = logging.getLogger("flowsynapse")

FRONTEND_DIST = BACKEND_DIR.parent / "frontend" / "dist"


def _register_routers(app: FastAPI) -> None:
    from .api import routers

    for r in routers():
        app.include_router(r)


def create_app(settings: Settings | None = None, runtime: Runtime | None = None) -> FastAPI:
    settings = settings or get_settings()
    setup_logging(settings.LOG_LEVEL, settings.data_dir / "logs")
    register_secret(settings.GEMINI_API_KEY)
    rt = runtime or Runtime(settings)
    from .bootstrap import configure_runtime

    configure_runtime(rt)

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        if settings.ALLOW_LAN and settings.HOST not in ("127.0.0.1", "localhost"):
            log.warning("ALLOW_LAN=true: FlowSynapse v1 has NO authentication; anyone on the network can use it.")
        if settings.ALLOW_DEMO_SITE:
            log.warning("ALLOW_DEMO_SITE=true: crawler allows 127.0.0.1:%s (bundled demo site only).", settings.DEMO_SITE_PORT)
        rt.startup()
        try:
            yield
        finally:
            rt.shutdown()

    app = FastAPI(
        title="FlowSynapse API",
        version=APP_VERSION,
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url=None,
    )
    app.state.runtime = rt
    app.state.settings = settings

    install_error_handlers(app)
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=False,
        allow_methods=["GET", "POST", "PATCH", "PUT", "DELETE", "OPTIONS"],
        allow_headers=["Content-Type", "Idempotency-Key", "If-Match", "X-Request-ID"],
        expose_headers=["Content-Disposition", "ETag", "Idempotent-Replayed", "X-Request-ID", "Retry-After"],
    )
    app.add_middleware(GuardMiddleware)
    app.add_middleware(RequestIdMiddleware)

    _register_routers(app)

    @app.api_route("/api/{rest:path}", methods=["GET", "POST", "PATCH", "PUT", "DELETE"], include_in_schema=False)
    def _api_404(rest: str) -> JSONResponse:
        return JSONResponse(status_code=404, content=error_body("NOT_FOUND", f"No API route /api/{rest}"))

    _mount_frontend(app, FRONTEND_DIST)
    return app


def _mount_frontend(app: FastAPI, dist: Path) -> None:
    """Serve the built SPA when present (single-process alternative to Vite)."""
    index = dist / "index.html"
    if not index.exists():
        return
    assets = dist / "assets"
    if assets.exists():
        app.mount("/assets", StaticFiles(directory=str(assets)), name="assets")

    @app.get("/{path:path}", include_in_schema=False)
    def _spa(path: str) -> FileResponse:
        candidate = (dist / path).resolve()
        if path and candidate.is_file() and dist.resolve() in candidate.parents:
            return FileResponse(candidate)
        return FileResponse(index)
