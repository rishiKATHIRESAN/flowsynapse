"""Command-line entry points: ``python -m app.cli <command>``.

Commands: serve, migrate, restore-backup, check-drift, cleanup-exports.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path


def _serve(args: argparse.Namespace) -> int:
    import uvicorn

    from .config import get_settings
    from .main import create_app

    s = get_settings()
    host = args.host or s.HOST
    if host not in ("127.0.0.1", "localhost") and not s.ALLOW_LAN:
        print("Refusing to bind to a non-loopback address without ALLOW_LAN=true.", file=sys.stderr)
        return 2
    port = args.port or s.PORT
    try:
        uvicorn.run(create_app(s), host=host, port=port, log_level=s.LOG_LEVEL.lower(), timeout_graceful_shutdown=int(s.SHUTDOWN_GRACE_SECONDS))
    except SystemExit as exc:  # startup failure -> non-zero
        return int(exc.code or 1)
    return 0


def _migrate(_args: argparse.Namespace) -> int:
    from .config import get_settings
    from .migrations import MigrationError, NewerDatabaseError, safe_migrate
    from .process_lock import LockHeldError, ProcessLock

    s = get_settings()
    lock = ProcessLock(s.lock_path)
    try:
        lock.acquire()
    except LockHeldError as exc:
        print(str(exc), file=sys.stderr)
        return 3
    try:
        res = safe_migrate(s)
        print(f"Migration: {res.action} ({res.from_revision} -> {res.to_revision})")
        if res.backup:
            print(f"Backup: {res.backup}")
        if res.drift:
            print(f"WARNING schema drift: {res.drift}")
        return 0
    except (MigrationError, NewerDatabaseError) as exc:
        print(str(exc), file=sys.stderr)
        return 1
    finally:
        lock.release()


def _restore(args: argparse.Namespace) -> int:
    from .config import get_settings
    from .migrations import restore_backup
    from .process_lock import LockHeldError, ProcessLock

    s = get_settings()
    lock = ProcessLock(s.lock_path)
    try:
        lock.acquire()
    except LockHeldError as exc:
        print(str(exc) + " Stop it before restoring.", file=sys.stderr)
        return 3
    try:
        safety = restore_backup(Path(args.file), s)
        print(f"Restored {args.file}. Safety backup of previous database: {safety}")
        return 0
    except Exception as exc:
        print(f"Restore failed: {exc}", file=sys.stderr)
        return 1
    finally:
        lock.release()


def _drift(_args: argparse.Namespace) -> int:
    from .config import get_settings
    from .migrations import check_drift

    diffs = check_drift(get_settings().db_path)
    print("No schema drift." if not diffs else "\n".join(diffs))
    return 0 if not diffs else 1


def _cleanup_exports(_args: argparse.Namespace) -> int:
    from .config import get_settings
    from .database import init_engine

    s = get_settings()
    init_engine(s.database_url)
    try:
        from .services.reporting.lifecycle import cleanup_exports
    except ImportError:
        print("Export cleanup not available yet.")
        return 0
    n = cleanup_exports()
    print(f"Removed {n} expired export file(s).")
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m app.cli")
    sub = p.add_subparsers(dest="cmd", required=True)
    sp = sub.add_parser("serve", help="Run the backend")
    sp.add_argument("--host")
    sp.add_argument("--port", type=int)
    sp.set_defaults(fn=_serve)
    sub.add_parser("migrate", help="Run the safe migration procedure").set_defaults(fn=_migrate)
    rp = sub.add_parser("restore-backup", help="Restore a verified backup")
    rp.add_argument("file")
    rp.set_defaults(fn=_restore)
    sub.add_parser("check-drift", help="Compare models with the database schema").set_defaults(fn=_drift)
    sub.add_parser("cleanup-exports", help="Delete expired export files").set_defaults(fn=_cleanup_exports)
    args = p.parse_args(argv)
    return int(args.fn(args))


if __name__ == "__main__":
    sys.exit(main())
