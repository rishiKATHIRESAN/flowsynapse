"""Campaign Intelligence API (master prompt 5.9)."""
from __future__ import annotations

from typing import Any, Literal

from fastapi import APIRouter, Depends, Header, Query, Request
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from ..database import get_db, session_scope
from ..services.campaign import service as svc
from ..services.campaign.brief import BriefInput, demo_brief
from ..services.campaign.constants import PARENT_TYPE
from ..services.campaign.context import get_campaign
from ..services.campaign.validation import validate_brief
from ..services.idempotency import run_idempotent
from ..services.jobs import engine
from ..services.records import remove_files
from ..utils.errors import AppError

router = APIRouter(prefix="/api/campaigns", tags=["campaigns"])


class CampaignCreate(BaseModel):
    brief: BriefInput = Field(default_factory=BriefInput)
    is_demo: bool = False


class BriefUpdate(BaseModel):
    brief: BriefInput
    expected_version: int | None = None


def _if_match(value: str | None) -> int | None:
    if value is None:
        return None
    v = value.strip().strip('"').removeprefix("W/").strip('"')
    try:
        return int(v)
    except ValueError:
        raise AppError(422, "VALIDATION_ERROR", "If-Match must be a version number") from None


@router.get("/demo-brief")
def get_demo_brief() -> dict[str, Any]:
    """Demo brief with dates computed from today in APP_TIMEZONE (next Monday -> +13 days)."""
    return {"brief": demo_brief(), "is_demo": True,
            "note": "Synthetic demonstration brief. Values marked DEMO ASSUMPTION are not facts about a real business."}


@router.post("", status_code=201)
def create(body: CampaignCreate, request: Request) -> JSONResponse:
    def op(db: Session) -> tuple[int, Any, str, str]:
        c = svc.create_campaign(db, body.brief.model_dump(), is_demo=body.is_demo)
        return 201, svc.detail(db, c), "campaign", c.id

    return run_idempotent(request, "create_campaign", body.model_dump(mode="json"), op)


@router.get("")
def list_(
    db: Session = Depends(get_db),
    limit: int = Query(25, ge=1, le=100),
    offset: int = Query(0, ge=0),
    q: str | None = Query(None, max_length=200),
    status: str | None = Query(None, max_length=32),
    demo: Literal["all", "mine", "demo"] = "all",
) -> dict[str, Any]:
    return svc.list_campaigns(db, limit=limit, offset=offset, q=q, status=status, demo=demo)


@router.get("/{campaign_id}")
def get(campaign_id: str, db: Session = Depends(get_db)) -> JSONResponse:
    c = get_campaign(db, campaign_id)
    return JSONResponse(svc.detail(db, c), headers={"ETag": str(c.brief_version)})


@router.patch("/{campaign_id}/brief")
def patch_brief(campaign_id: str, body: BriefUpdate, if_match: str | None = Header(None)) -> dict[str, Any]:
    expected = _if_match(if_match) if if_match is not None else body.expected_version
    with session_scope(immediate=True) as db:
        c = get_campaign(db, campaign_id)
        result = svc.update_brief(db, c, body.brief.model_dump(), expected)
        db.flush()
        return {**result, "campaign": svc.detail(db, c)}


@router.post("/{campaign_id}/validate")
def validate(campaign_id: str, db: Session = Depends(get_db)) -> dict[str, Any]:
    c = get_campaign(db, campaign_id)
    brief = BriefInput.model_validate_json(c.brief_original)
    return validate_brief(brief).as_dict()


@router.post("/validate-brief")
def validate_unsaved(body: CampaignCreate) -> dict[str, Any]:
    """Validate a brief without saving (form 'Validate' before first save)."""
    return validate_brief(body.brief).as_dict()


@router.post("/{campaign_id}/executions", status_code=202)
def start(campaign_id: str, request: Request) -> JSONResponse:
    def op(db: Session) -> tuple[int, Any, str, str]:
        c = get_campaign(db, campaign_id)
        ex = svc.start_execution(db, c)
        db.flush()
        db.refresh(ex)
        return 202, engine.execution_to_dict(ex), "execution", ex.id

    return run_idempotent(request, "start_campaign", {}, op)


@router.get("/{campaign_id}/executions")
def list_executions(campaign_id: str, db: Session = Depends(get_db), limit: int = Query(25, ge=1, le=100), offset: int = Query(0, ge=0)) -> dict[str, Any]:
    from sqlalchemy import func, select

    from ..models.jobs import Execution

    get_campaign(db, campaign_id)
    q = select(Execution).where(Execution.parent_type == PARENT_TYPE, Execution.parent_id == campaign_id)
    total = db.execute(select(func.count()).select_from(q.subquery())).scalar_one()
    rows = db.execute(q.order_by(Execution.created_at.desc()).limit(limit).offset(offset)).scalars().all()
    items = []
    for ex in rows:
        d = engine.execution_to_dict(ex)
        d.pop("stages")
        items.append(d)
    return {"items": items, "total": total, "limit": limit, "offset": offset}


@router.get("/{campaign_id}/executions/{execution_id}")
def get_execution(campaign_id: str, execution_id: str, db: Session = Depends(get_db)) -> dict[str, Any]:
    return engine.execution_to_dict(engine.load_execution(db, execution_id, PARENT_TYPE, campaign_id))


@router.post("/{campaign_id}/executions/{execution_id}/cancel")
def cancel(campaign_id: str, execution_id: str) -> dict[str, Any]:
    with session_scope(immediate=True) as db:
        engine.load_execution(db, execution_id, PARENT_TYPE, campaign_id)
        ex = engine.request_cancel(db, execution_id)
        return engine.execution_to_dict(ex)


@router.post("/{campaign_id}/executions/{execution_id}/stages/{stage_key}/retry", status_code=202)
def retry(campaign_id: str, execution_id: str, stage_key: str, request: Request) -> JSONResponse:
    def op(db: Session) -> tuple[int, Any, str, str]:
        c = get_campaign(db, campaign_id)
        ex = svc.retry_stage(db, c, execution_id, stage_key)
        db.flush()
        db.refresh(ex)
        return 202, engine.execution_to_dict(ex), "execution", ex.id

    return run_idempotent(request, "retry_stage", {}, op)


@router.post("/{campaign_id}/stages/{stage_key}/regenerate", status_code=202)
def regenerate_stage(campaign_id: str, stage_key: str, request: Request) -> JSONResponse:
    def op(db: Session) -> tuple[int, Any, str, str]:
        c = get_campaign(db, campaign_id)
        ex = svc.regenerate_stage(db, c, stage_key)
        db.flush()
        db.refresh(ex)
        return 202, engine.execution_to_dict(ex), "execution", ex.id

    return run_idempotent(request, "regenerate_stage", {}, op)


@router.get("/{campaign_id}/stages/{stage_key}")
def stage(campaign_id: str, stage_key: str, db: Session = Depends(get_db)) -> dict[str, Any]:
    return svc.stage_detail(db, get_campaign(db, campaign_id), stage_key)


@router.get("/{campaign_id}/outputs")
def outputs(campaign_id: str, output_type: str | None = Query(None, max_length=48), versions: bool = False,
            db: Session = Depends(get_db)) -> dict[str, Any]:
    return {"items": svc.outputs_payload(db, get_campaign(db, campaign_id), output_type, versions)}


@router.get("/{campaign_id}/findings")
def findings(campaign_id: str, db: Session = Depends(get_db)) -> dict[str, Any]:
    return {"items": svc.findings_payload(db, get_campaign(db, campaign_id))}


@router.delete("/{campaign_id}")
def delete(campaign_id: str) -> dict[str, Any]:
    with session_scope(immediate=True) as db:
        c = get_campaign(db, campaign_id)
        files = svc.delete_campaign(db, c)
    remove_files(files)
    return {"deleted": campaign_id}


@router.get("/{campaign_id}/export.{fmt}")
def export(campaign_id: str, fmt: Literal["pdf", "xlsx", "csv", "zip"], dataset: str | None = Query(None, max_length=48),
           allow_stale: bool = False) -> FileResponse:
    from ..services.campaign.exports import export_campaign
    from ..services.reporting.lifecycle import file_response

    row = export_campaign(campaign_id, fmt, dataset=dataset, allow_stale=allow_stale)
    return file_response(row)
