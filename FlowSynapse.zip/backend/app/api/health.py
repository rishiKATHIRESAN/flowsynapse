from __future__ import annotations

from fastapi import APIRouter, Request

from ..config import APP_VERSION

router = APIRouter(prefix="/api", tags=["health"])


@router.get("/health")
def health(request: Request) -> dict[str, object]:
    """Identity payload. Clients treat a service as FlowSynapse only if
    ``app == "flowsynapse"``; ``status`` is ``ok`` only after startup step 6."""
    rt = request.app.state.runtime
    return {
        "app": "flowsynapse",
        "version": APP_VERSION,
        "db_revision": rt.db_revision,
        "instance_id": rt.instance_id,
        "status": rt.status,
    }
