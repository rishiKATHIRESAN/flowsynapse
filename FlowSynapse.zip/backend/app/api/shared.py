"""Shared endpoints: exports listing/download and demo-data management."""
from __future__ import annotations

from typing import Any, Literal

from fastapi import APIRouter, Depends, Query
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models.exports import FileExport
from ..services import demo
from ..services.reporting.lifecycle import export_to_dict, file_response
from ..utils.errors import not_found

router = APIRouter(prefix="/api", tags=["shared"])


@router.get("/exports")
def list_exports(
    parent_type: str = Query(..., max_length=32),
    parent_id: str = Query(..., max_length=32),
    limit: int = Query(25, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
) -> dict[str, Any]:
    q = select(FileExport).where(FileExport.parent_type == parent_type, FileExport.parent_id == parent_id)
    rows = db.execute(q.order_by(FileExport.created_at.desc()).limit(limit).offset(offset)).scalars().all()
    return {"items": [export_to_dict(r) for r in rows], "limit": limit, "offset": offset}


@router.get("/exports/{export_id}/download")
def download_export(export_id: str, db: Session = Depends(get_db)) -> FileResponse:
    row = db.get(FileExport, export_id)
    if row is None:
        raise not_found("Export", export_id)
    db.expunge(row)
    return file_response(row)


class DemoLoad(BaseModel):
    modules: list[str] | None = None


class KeepAsOwn(BaseModel):
    module: Literal["campaigns", "funnels", "seo", "website", "blogs", "social"]
    record_id: str


@router.get("/demo-data")
def demo_status() -> dict[str, Any]:
    return {"modules": demo.status()}


@router.post("/demo-data", status_code=202)
def demo_load(body: DemoLoad | None = None) -> dict[str, Any]:
    return {"results": demo.load(body.modules if body else None)}


@router.delete("/demo-data")
def demo_remove() -> dict[str, Any]:
    return demo.remove_all()


@router.post("/demo-data/keep-as-own")
def demo_keep(body: KeepAsOwn) -> dict[str, Any]:
    demo.keep_as_own(body.module, body.record_id)
    return {"ok": True}
