from __future__ import annotations

from fastapi import APIRouter


def routers() -> list[APIRouter]:
    from . import campaigns, dashboard, executions, health, settings, shared

    return [health.router, settings.router, executions.router, shared.router, dashboard.router, campaigns.router]
