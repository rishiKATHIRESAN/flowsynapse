"""Dashboard: real database counts and recent executions only (no fabricated metrics)."""
from __future__ import annotations

from typing import Any, Callable

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models.jobs import WorkflowRun
from ..utils.clock import iso

router = APIRouter(prefix="/api", tags=["dashboard"])

# module key -> counter(db, include_demo) -> {"total": n, "by_status": {...}}
COUNTERS: dict[str, Callable[[Session, bool], dict[str, Any]]] = {}

MODULES = [
    ("campaigns", "AI Marketing Campaign Intelligence Engine", "/campaigns"),
    ("funnels", "AI Marketing Funnel Builder", "/funnels"),
    ("seo", "Website SEO Audit & SEO Report Generator", "/seo"),
    ("website", "Website Intelligence & Website Report Generator", "/website-reports"),
    ("blogs", "AI Bulk Blog & Content Generator", "/blogs"),
    ("social", "AI Social Media Campaign & Content Calendar Generator", "/social"),
]


def register_counter(module: str, fn: Callable[[Session, bool], dict[str, Any]]) -> None:
    COUNTERS[module] = fn


@router.get("/dashboard")
def dashboard(include_demo: bool = False, db: Session = Depends(get_db)) -> dict[str, Any]:
    modules = []
    for key, title, route in MODULES:
        counter = COUNTERS.get(key)
        stats = counter(db, include_demo) if counter else {"total": 0, "by_status": {}, "available": False}
        stats.setdefault("available", True)
        q = select(WorkflowRun).where(WorkflowRun.module == key)
        if not include_demo:
            q = q.where(WorkflowRun.is_demo.is_(False))
        last = db.execute(q.order_by(WorkflowRun.created_at.desc()).limit(1)).scalar_one_or_none()
        modules.append({
            "key": key, "title": title, "route": route, **stats,
            "last_run": None if last is None else {
                "status": last.status, "title": last.title, "created_at": iso(last.created_at),
                "parent_id": last.parent_id, "is_mock": last.is_mock,
            },
        })
    rq = select(WorkflowRun)
    if not include_demo:
        rq = rq.where(WorkflowRun.is_demo.is_(False))
    recent = db.execute(rq.order_by(WorkflowRun.created_at.desc()).limit(10)).scalars().all()
    return {
        "include_demo": include_demo,
        "modules": modules,
        "recent_runs": [
            {"module": r.module, "title": r.title, "status": r.status, "scope": r.scope, "provider": r.provider,
             "is_mock": r.is_mock, "is_demo": r.is_demo, "parent_id": r.parent_id, "execution_id": r.execution_id,
             "created_at": iso(r.created_at), "finished_at": iso(r.finished_at)}
            for r in recent
        ],
    }
