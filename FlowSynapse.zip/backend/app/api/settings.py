"""Settings API: active AI provider and provider health checks (3, 3.4)."""
from __future__ import annotations

import threading
import time
from typing import Any, Literal

from fastapi import APIRouter
from pydantic import BaseModel

from ..ai.base import ProviderError
from ..ai.factory import PROVIDERS, active_provider_name, build_provider, config_error, selection
from ..config import get_settings
from ..database import session_scope
from ..models.settings import AppSetting
from ..utils.errors import AppError
from ..utils.redact import redact

router = APIRouter(prefix="/api/settings", tags=["settings"])

_cache: dict[str, tuple[float, dict[str, Any]]] = {}
_last_paid_check: dict[str, float] = {}
_lock = threading.Lock()
CACHE_SECONDS = 30.0
MIN_INTERVAL_SECONDS = 10.0


class SettingsUpdate(BaseModel):
    ai_provider: Literal["mock", "ollama", "gemini"]


class TestProviderRequest(BaseModel):
    provider: Literal["mock", "ollama", "gemini"] | None = None


def _payload() -> dict[str, Any]:
    s = get_settings()
    active = active_provider_name()
    sel = selection(active)
    return {
        "active_provider": active,
        "active_model": sel.model,
        "is_mock": sel.is_mock,
        "config_error": sel.config_error,
        "providers": [
            {
                "name": name,
                "configured": config_error(name) is None,
                "config_error": config_error(name),
                "model": selection(name).model,
                "requires_network": name == "gemini",
                "may_incur_charges": name == "gemini",
            }
            for name in PROVIDERS
        ],
        "gemini_key_configured": bool(s.GEMINI_API_KEY),
        "ollama_base_url": s.OLLAMA_BASE_URL,
        "app_timezone": s.APP_TIMEZONE,
        "allow_demo_site": s.ALLOW_DEMO_SITE,
        "demo_site_port": s.DEMO_SITE_PORT,
    }


@router.get("")
def get_settings_api() -> dict[str, Any]:
    return _payload()


@router.put("")
def update_settings(body: SettingsUpdate) -> dict[str, Any]:
    with session_scope(immediate=True) as db:
        row = db.get(AppSetting, "ai_provider")
        if row is None:
            db.add(AppSetting(key="ai_provider", value=body.ai_provider))
        else:
            row.value = body.ai_provider
    return _payload()


@router.post("/test-provider")
def test_provider(body: TestProviderRequest | None = None) -> dict[str, Any]:
    """Real health check that never triggers generation. Cached for 30 s."""
    name = (body.provider if body and body.provider else None) or active_provider_name()
    if name not in PROVIDERS:
        raise AppError(422, "VALIDATION_ERROR", "Unknown provider")
    now = time.monotonic()
    with _lock:
        cached = _cache.get(name)
        if cached and now - cached[0] < CACHE_SECONDS:
            return {**cached[1], "cached": True}
        if name != "mock":
            last = _last_paid_check.get(name, 0.0)
            if now - last < MIN_INTERVAL_SECONDS:
                raise AppError(429, "RATE_LIMITED", "Provider checks are limited to one every 10 seconds.",
                               headers={"Retry-After": str(int(MIN_INTERVAL_SECONDS - (now - last)) + 1)})
            _last_paid_check[name] = now
    try:
        provider = build_provider(name)
        result = provider.health_check().as_dict()
    except ProviderError as exc:
        result = {"ok": False, "provider": name, "model": selection(name).model,
                  "message": redact(exc.message), "details": {"code": exc.code, "hint": exc.hint}}
    result["message"] = redact(str(result.get("message", "")))
    with _lock:
        _cache[name] = (now, result)
    return {**result, "cached": False}


def reset_cache() -> None:
    with _lock:
        _cache.clear()
        _last_paid_check.clear()
