"""Generic read access to executions and the cross-module run history."""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models.jobs import WorkflowRun
from ..services.jobs.engine import execution_to_dict, load_execution
from ..utils.clock import iso

router = APIRouter(prefix="/api", tags=["executions"])


@router.get("/executions/{execution_id}")
def get_execution(execution_id: str, db: Session = Depends(get_db)) -> dict[str, Any]:
    return execution_to_dict(load_execution(db, execution_id))


@router.get("/runs")
def list_runs(
    db: Session = Depends(get_db),
    limit: int = Query(25, ge=1, le=100),
    offset: int = Query(0, ge=0),
    module: str | None = Query(None, max_length=32),
    status: str | None = Query(None, max_length=32),
    include_demo: bool = False,
) -> dict[str, Any]:
    q = select(WorkflowRun)
    if module:
        q = q.where(WorkflowRun.module == module)
    if status:
        q = q.where(WorkflowRun.status == status)
    if not include_demo:
        q = q.where(WorkflowRun.is_demo.is_(False))
    total = db.execute(select(func.count()).select_from(q.subquery())).scalar_one()
    rows = db.execute(q.order_by(WorkflowRun.created_at.desc()).limit(limit).offset(offset)).scalars().all()
    return {
        "items": [
            {
                "id": r.id, "module": r.module, "parent_type": r.parent_type, "parent_id": r.parent_id,
                "execution_id": r.execution_id, "title": r.title, "status": r.status, "scope": r.scope,
                "provider": r.provider, "is_mock": r.is_mock, "is_demo": r.is_demo,
                "created_at": iso(r.created_at), "started_at": iso(r.started_at), "finished_at": iso(r.finished_at),
            }
            for r in rows
        ],
        "total": total, "limit": limit, "offset": offset,
    }
