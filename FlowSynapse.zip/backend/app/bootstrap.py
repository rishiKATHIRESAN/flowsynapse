"""Wires recovery hooks and background services into the runtime.

Kept separate from ``runtime.py`` so each phase can register its services
without changing the startup order logic.
"""
from __future__ import annotations

from .runtime import Runtime


def _maintenance(_rt: Runtime):  # type: ignore[no-untyped-def]
    from .services.idempotency import cleanup_expired
    from .services.maintenance import MaintenanceService, Task

    from .services.reporting.lifecycle import cleanup_exports

    tasks = [Task("idempotency_cleanup", 3600, cleanup_expired), Task("export_retention", 86400, cleanup_exports)]
    return MaintenanceService(tasks)


def _workers(_rt: Runtime):  # type: ignore[no-untyped-def]
    from .services.jobs.worker import WorkerPool

    return WorkerPool()


def _recovery() -> None:
    from .services.jobs.recovery import recover_on_startup

    recover_on_startup()


def register_handlers() -> None:
    """Import module handlers so they register with the job registry."""
    from .services import handlers  # noqa: F401


def configure_runtime(rt: Runtime) -> None:
    register_handlers()
    rt.recovery_hooks.clear()
    rt.service_factories.clear()
    rt.recovery_hooks.append(_recovery)
    rt.service_factories.append(_workers)
    rt.service_factories.append(_maintenance)
