"""Local-API protections (master prompt 14) and request ids.

* Host header allow-list (mitigates DNS rebinding).
* Origin check on state-changing requests.
* ``application/json`` enforcement on JSON bodies.
* ``MAX_BODY_BYTES`` enforced before parsing.
"""
from __future__ import annotations

import uuid

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from .config import get_settings
from .logging_setup import request_id_var
from .utils.errors import error_body

STATE_CHANGING = {"POST", "PUT", "PATCH", "DELETE"}


class RequestIdMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        rid = request.headers.get("x-request-id") or uuid.uuid4().hex[:12]
        if not rid.replace("-", "").isalnum() or len(rid) > 64:
            rid = uuid.uuid4().hex[:12]
        request.state.request_id = rid
        token = request_id_var.set(rid)
        try:
            response = await call_next(request)
        finally:
            request_id_var.reset(token)
        response.headers["X-Request-ID"] = rid
        return response


class GuardMiddleware:
    """Pure ASGI middleware so the body limit applies before parsing."""

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        s = get_settings()
        headers = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope.get("headers", [])}
        method = scope.get("method", "GET")
        path: str = scope.get("path", "")

        host = headers.get("host", "")
        if host and host not in s.allowed_hosts():
            await _reject(send, 400, "INVALID_HOST", "Host header not allowed")
            return

        is_api = path.startswith("/api/")
        if is_api and method in STATE_CHANGING:
            origin = headers.get("origin")
            if origin and origin not in s.cors_origins and origin not in _self_origins(s):
                await _reject(send, 403, "ORIGIN_REJECTED", "Request origin is not allowed")
                return
            length = headers.get("content-length")
            if length and length.isdigit() and int(length) > s.MAX_BODY_BYTES:
                await _reject(send, 413, "PAYLOAD_TOO_LARGE", f"Request body exceeds {s.MAX_BODY_BYTES} bytes")
                return
            ctype = headers.get("content-type", "")
            has_body = (length and length != "0") or "transfer-encoding" in headers
            if has_body and not ctype.startswith("application/json"):
                await _reject(send, 415, "UNSUPPORTED_MEDIA_TYPE", "Content-Type must be application/json")
                return

        limit = s.MAX_BODY_BYTES
        received = 0

        async def limited_receive() -> Message:
            nonlocal received
            msg = await receive()
            if msg["type"] == "http.request":
                received += len(msg.get("body", b""))
                if received > limit:
                    raise _BodyTooLarge()
            return msg

        try:
            await self.app(scope, limited_receive, send)
        except _BodyTooLarge:
            await _reject(send, 413, "PAYLOAD_TOO_LARGE", f"Request body exceeds {limit} bytes")


class _BodyTooLarge(Exception):
    pass


def _self_origins(s) -> set[str]:  # type: ignore[no-untyped-def]
    return {f"http://127.0.0.1:{s.PORT}", f"http://localhost:{s.PORT}"}


async def _reject(send: Send, status: int, code: str, message: str) -> None:
    resp = JSONResponse(status_code=status, content=error_body(code, message))
    await resp({"type": "http"}, _empty_receive, send)


async def _empty_receive() -> Message:  # pragma: no cover
    return {"type": "http.request", "body": b"", "more_body": False}


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        p = request.url.path
        if not p.startswith(("/api/", "/docs", "/redoc", "/openapi.json")):
            response.headers.setdefault(
                "Content-Security-Policy",
                "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'",
            )
        return response
