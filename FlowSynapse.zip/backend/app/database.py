"""SQLite engine/session management.

Two engines share the same database file:

* ``engine`` – deferred ``BEGIN`` (used for request sessions and reads).
* ``immediate_engine`` – ``BEGIN IMMEDIATE`` (used for job-engine decision
  points so SQLite serialises them, see master prompt 2.3).

Both apply ``foreign_keys=ON``, WAL journal mode and ``busy_timeout=5000``.
"""
from __future__ import annotations

import logging
import time
from contextlib import contextmanager
from typing import Callable, Iterator, TypeVar

from sqlalchemy import Engine, MetaData, create_engine, event
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from .config import get_settings

log = logging.getLogger("flowsynapse.db")

NAMING_CONVENTION = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_N_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


# Overridable in tests to exercise lock contention quickly.
BUSY_TIMEOUT_MS = 5000


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=NAMING_CONVENTION)


class _State:
    engine: Engine | None = None
    immediate_engine: Engine | None = None
    SessionLocal: sessionmaker[Session] | None = None
    ImmediateSession: sessionmaker[Session] | None = None
    url: str | None = None


state = _State()


def _make_engine(url: str, begin_sql: str) -> Engine:
    eng = create_engine(
        url,
        connect_args={"check_same_thread": False, "timeout": BUSY_TIMEOUT_MS / 1000},
        future=True,
    )

    @event.listens_for(eng, "connect")
    def _on_connect(dbapi_conn, _rec):  # type: ignore[no-untyped-def]
        # Let SQLAlchemy emit BEGIN itself (pysqlite recipe).
        dbapi_conn.isolation_level = None
        cur = dbapi_conn.cursor()
        cur.execute(f"PRAGMA busy_timeout={int(BUSY_TIMEOUT_MS)}")
        cur.execute("PRAGMA foreign_keys=ON")
        # WAL is persistent in the file; switching mode needs an exclusive lock
        # and can fail with "database is locked" while others write, so only
        # switch when the database is not already in WAL mode.
        mode = cur.execute("PRAGMA journal_mode").fetchone()[0]
        if str(mode).lower() != "wal":
            for attempt in range(20):
                try:
                    cur.execute("PRAGMA journal_mode=WAL")
                    break
                except Exception:
                    if attempt == 19:
                        raise
                    time.sleep(0.05)
        cur.execute("PRAGMA synchronous=NORMAL")
        cur.close()

    @event.listens_for(eng, "begin")
    def _on_begin(conn):  # type: ignore[no-untyped-def]
        conn.exec_driver_sql(begin_sql)

    return eng


def init_engine(url: str | None = None) -> None:
    """(Re)initialise engines. Safe to call repeatedly (tests)."""
    dispose_engine()
    url = url or get_settings().database_url
    state.url = url
    state.engine = _make_engine(url, "BEGIN")
    state.immediate_engine = _make_engine(url, "BEGIN IMMEDIATE")
    state.SessionLocal = sessionmaker(bind=state.engine, expire_on_commit=False, future=True)
    state.ImmediateSession = sessionmaker(
        bind=state.immediate_engine, expire_on_commit=False, future=True
    )
    # Switch the file to WAL now, before any worker thread connects.
    with state.engine.connect():
        pass


def dispose_engine() -> None:
    for eng in (state.engine, state.immediate_engine):
        if eng is not None:
            eng.dispose()
    state.engine = state.immediate_engine = None
    state.SessionLocal = state.ImmediateSession = None


def _require() -> tuple[sessionmaker[Session], sessionmaker[Session]]:
    if state.SessionLocal is None or state.ImmediateSession is None:
        init_engine()
    assert state.SessionLocal is not None and state.ImmediateSession is not None
    return state.SessionLocal, state.ImmediateSession


def new_session() -> Session:
    return _require()[0]()


def new_immediate_session() -> Session:
    return _require()[1]()


def get_db() -> Iterator[Session]:
    """FastAPI dependency: one session per request."""
    db = new_session()
    try:
        yield db
    finally:
        db.close()


@contextmanager
def session_scope(immediate: bool = False) -> Iterator[Session]:
    """Short transaction: commit on success, roll back on error."""
    db = new_immediate_session() if immediate else new_session()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


T = TypeVar("T")


class DatabaseBusyError(Exception):
    """Persistent SQLite lock: retryable, surfaced to the caller."""


def is_locked_error(exc: BaseException) -> bool:
    msg = str(exc).lower()
    return "database is locked" in msg or "database is busy" in msg


def with_lock_retry(fn: Callable[[], T], attempts: int = 4, base_delay: float = 0.05) -> T:
    """Run ``fn`` retrying a bounded number of times on ``database is locked``."""
    for i in range(attempts):
        try:
            return fn()
        except OperationalError as exc:
            if not is_locked_error(exc):
                raise
            if i == attempts - 1:
                raise DatabaseBusyError("The database is busy; please retry.") from exc
            delay = base_delay * (2**i)
            log.warning("database locked; retrying in %.2fs", delay)
            time.sleep(delay)
    raise DatabaseBusyError("The database is busy; please retry.")  # pragma: no cover
