"""Structured logging with request ids, rotation and secret redaction."""
from __future__ import annotations

import contextvars
import logging
import logging.handlers
from pathlib import Path

from .utils.redact import RedactingFilter

request_id_var: contextvars.ContextVar[str] = contextvars.ContextVar("request_id", default="-")


class _RequestIdFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.request_id = request_id_var.get()
        return True


_FMT = "%(asctime)s %(levelname)s %(name)s rid=%(request_id)s %(message)s"
_configured = False


def setup_logging(level: str = "INFO", log_dir: Path | None = None) -> None:
    global _configured
    root = logging.getLogger()
    root.setLevel(level.upper())
    if _configured:
        return
    fmt = logging.Formatter(_FMT)
    handlers: list[logging.Handler] = [logging.StreamHandler()]
    if log_dir is not None:
        log_dir.mkdir(parents=True, exist_ok=True)
        handlers.append(
            logging.handlers.RotatingFileHandler(
                log_dir / "flowsynapse.log", maxBytes=2_000_000, backupCount=5, encoding="utf-8"
            )
        )
    for h in handlers:
        h.setFormatter(fmt)
        h.addFilter(_RequestIdFilter())
        h.addFilter(RedactingFilter())
        root.addHandler(h)
    for noisy in ("alembic", "httpx", "uvicorn.access"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    _configured = True
