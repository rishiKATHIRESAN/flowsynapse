"""Shared deletion of a parent record's generic children (outputs, versions,
executions, history, export rows/files) inside the caller's transaction."""
from __future__ import annotations

import logging

from sqlalchemy import delete, select, update
from sqlalchemy.orm import Session

from ..models.exports import FileExport
from ..models.jobs import Execution, WorkflowRun
from ..models.outputs import Output, OutputVersion

log = logging.getLogger("flowsynapse.records")


def delete_parent_children(db: Session, parent_type: str, parent_id: str) -> list[str]:
    """Returns export file names to remove after commit."""
    out_ids = db.execute(
        select(Output.id).where(Output.parent_type == parent_type, Output.parent_id == parent_id)
    ).scalars().all()
    if out_ids:
        # versions reference each other (previous/original); clear then delete
        db.execute(update(OutputVersion).where(OutputVersion.output_id.in_(out_ids))
                   .values(previous_version_id=None, original_generation_version_id=None))
        db.execute(delete(OutputVersion).where(OutputVersion.output_id.in_(out_ids)))
        db.execute(delete(Output).where(Output.id.in_(out_ids)))
    ex_ids = db.execute(
        select(Execution.id).where(Execution.parent_type == parent_type, Execution.parent_id == parent_id)
    ).scalars().all()
    if ex_ids:
        db.execute(update(Execution).where(Execution.id.in_(ex_ids)).values(retry_of_execution_id=None))
        db.execute(update(OutputVersion).where(OutputVersion.execution_id.in_(ex_ids)).values(execution_id=None))
        db.execute(delete(WorkflowRun).where(WorkflowRun.execution_id.in_(ex_ids)))
        db.execute(delete(Execution).where(Execution.id.in_(ex_ids)))
    files = db.execute(
        select(FileExport.file_name).where(FileExport.parent_type == parent_type, FileExport.parent_id == parent_id)
    ).scalars().all()
    db.execute(delete(FileExport).where(FileExport.parent_type == parent_type, FileExport.parent_id == parent_id))
    return [f for f in files if f]


def remove_files(names: list[str]) -> None:
    from .reporting.lifecycle import safe_path

    for n in names:
        try:
            p = safe_path(n)
            if p.exists():
                p.unlink()
        except Exception:
            log.warning("could not remove export file %s; retention will retry", n)
