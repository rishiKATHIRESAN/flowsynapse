"""Startup recovery (2.6 step 5) and shutdown clean-up."""
from __future__ import annotations

import logging

from sqlalchemy import select

from ...database import new_immediate_session
from ...models.jobs import Execution
from . import state_machine as sm
from .engine import fail_running_execution

log = logging.getLogger("flowsynapse.recovery")


def interrupt_running(message: str = "Interrupted by restart. Retry to continue.") -> list[str]:
    """RUNNING executions -> FAILED/INTERRUPTED (retryable). PENDING stays PENDING.

    Completed stage outputs are preserved; an in-flight AI request is never
    assumed to have completed (its stage becomes FAILED and needs a retry).
    """
    db = new_immediate_session()
    changed: list[str] = []
    try:
        running = db.execute(select(Execution).where(Execution.status == sm.RUNNING)).scalars().all()
        for ex in running:
            try:
                fail_running_execution(db, ex, "INTERRUPTED", message, True, claim_token=ex.claim_token)
                changed.append(ex.id)
            except sm.IllegalTransition:
                log.warning("execution %s changed during recovery", ex.id)
        db.commit()
    except BaseException:
        db.rollback()
        raise
    finally:
        db.close()
    if changed:
        log.warning("recovered %d interrupted execution(s): %s", len(changed), changed)
    return changed


def recover_on_startup() -> list[str]:
    return interrupt_running("Interrupted by restart. Retry to continue.")
