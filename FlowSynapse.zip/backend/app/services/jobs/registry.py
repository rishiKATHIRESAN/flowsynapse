"""Module job handlers and the per-stage execution context."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable, Protocol

from sqlalchemy.orm import Session

if TYPE_CHECKING:  # pragma: no cover
    from ...ai.runner import AIRunner


@dataclass
class StageOutcome:
    output_ref: Any = None
    warnings: list[str] = field(default_factory=list)


@dataclass
class StageContext:
    execution_id: str
    parent_type: str
    parent_id: str
    scope: str
    params: dict[str, Any]
    stage_id: str
    stage_key: str
    item_id: str
    attempt_number: int
    claim_token: str
    is_demo: bool
    should_stop: Callable[[], bool]
    guarded_write: Callable[[Callable[[Session], Any]], bool]
    ai: "AIRunner | None" = None
    # provenance written onto the stage row at commit
    provider: str | None = None
    model: str | None = None
    is_mock: bool | None = None
    input_snapshot: Any = None
    scratch: dict[str, Any] = field(default_factory=dict)

    def snapshot_json(self) -> str | None:
        return None if self.input_snapshot is None else json.dumps(self.input_snapshot, default=str)


class JobHandler(Protocol):
    parent_type: str
    module: str

    def run_stage(self, ctx: StageContext) -> Any: ...

    def commit_stage(self, db: Session, ctx: StageContext, result: Any) -> StageOutcome: ...

    def continue_on_failure(self, stage_key: str) -> bool: ...

    def finalize(self, db: Session, execution_id: str, final_status: str) -> list[str]: ...

    def title(self, db: Session, parent_id: str) -> str: ...


class BaseHandler:
    """Convenience base with sensible defaults."""

    parent_type = ""
    module = ""

    def run_stage(self, ctx: StageContext) -> Any:  # pragma: no cover - abstract
        raise NotImplementedError

    def commit_stage(self, db: Session, ctx: StageContext, result: Any) -> StageOutcome:
        return StageOutcome(output_ref=result)

    def continue_on_failure(self, stage_key: str) -> bool:
        return False

    def finalize(self, db: Session, execution_id: str, final_status: str) -> list[str]:
        return []

    def title(self, db: Session, parent_id: str) -> str:
        return parent_id


_HANDLERS: dict[str, JobHandler] = {}


def register(handler: JobHandler) -> None:
    _HANDLERS[handler.parent_type] = handler


def get_handler(parent_type: str) -> JobHandler:
    try:
        return _HANDLERS[parent_type]
    except KeyError:
        raise KeyError(f"no job handler registered for {parent_type}") from None


def unregister(parent_type: str) -> None:
    _HANDLERS.pop(parent_type, None)
