"""Execution creation, cancellation, retry lineage and terminal transitions (2.3)."""
from __future__ import annotations

import json
import logging
import threading
from dataclasses import dataclass, field
from typing import Any, Iterable

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ...config import get_settings
from ...models.jobs import Execution, ExecutionStage, WorkflowRun
from ...utils.clock import iso, utcnow
from ...utils.errors import AppError, not_found
from . import state_machine as sm

log = logging.getLogger("flowsynapse.jobs")

# Set by create_execution so idle workers wake promptly.
wake_event = threading.Event()


@dataclass
class StageSpec:
    stage_key: str
    item_id: str = ""
    required: bool = True
    carried_from: ExecutionStage | None = None
    attempt_count: int = 1
    input_snapshot: Any = None


@dataclass
class ProviderInfo:
    provider: str | None = None
    model: str | None = None
    is_mock: bool = False


@dataclass
class CreatedExecution:
    execution: Execution
    stages: list[ExecutionStage] = field(default_factory=list)


def active_execution(db: Session, parent_type: str, parent_id: str) -> Execution | None:
    return db.execute(
        select(Execution).where(
            Execution.parent_type == parent_type,
            Execution.parent_id == parent_id,
            Execution.status.in_(sm.ACTIVE_EXECUTION_STATES),
        )
    ).scalar_one_or_none()


def latest_execution(db: Session, parent_type: str, parent_id: str) -> Execution | None:
    return db.execute(
        select(Execution)
        .where(Execution.parent_type == parent_type, Execution.parent_id == parent_id)
        .order_by(Execution.created_at.desc(), Execution.attempt_number.desc())
        .limit(1)
    ).scalar_one_or_none()


def create_execution(
    db: Session,
    *,
    parent_type: str,
    parent_id: str,
    stages: Iterable[StageSpec],
    scope: str = "FULL",
    params: dict[str, Any] | None = None,
    provider: ProviderInfo | None = None,
    is_demo: bool = False,
    retry_of: Execution | None = None,
    title: str = "",
    module: str = "",
    max_duration_seconds: int | None = None,
) -> CreatedExecution:
    """Create an execution + its stage rows in the caller's transaction.

    Enforces one active execution per parent (409) and the queue cap (429).
    """
    s = get_settings()
    if active_execution(db, parent_type, parent_id) is not None:
        raise AppError(
            409,
            "EXECUTION_ALREADY_ACTIVE",
            "An execution is already pending or running for this record. Wait for it to finish or cancel it.",
        )
    queued = db.execute(select(func.count()).select_from(Execution).where(Execution.status == sm.PENDING)).scalar_one()
    if queued >= s.MAX_QUEUED_JOBS:
        raise AppError(
            429,
            "QUEUE_FULL",
            f"The job queue is full ({queued} pending). Try again when running jobs finish.",
            headers={"Retry-After": "5"},
        )
    p = provider or ProviderInfo()
    ex = Execution(
        parent_type=parent_type,
        parent_id=parent_id,
        scope=scope,
        status=sm.PENDING,
        retry_of_execution_id=retry_of.id if retry_of else None,
        attempt_number=(retry_of.attempt_number + 1) if retry_of else 1,
        params=json.dumps(params or {}, default=str),
        provider=p.provider,
        model=p.model,
        is_mock=p.is_mock,
        is_demo=is_demo,
        max_duration_seconds=max_duration_seconds,
        created_at=utcnow(),
    )
    db.add(ex)
    try:
        db.flush()
    except IntegrityError as exc:
        raise AppError(409, "EXECUTION_ALREADY_ACTIVE", "An execution is already active for this record.") from exc
    rows = []
    for pos, spec in enumerate(stages):
        carried = spec.carried_from
        row = ExecutionStage(
            execution_id=ex.id,
            stage_key=spec.stage_key,
            item_id=spec.item_id,
            position=pos,
            required=spec.required,
            attempt_count=spec.attempt_count,
            input_snapshot=None if spec.input_snapshot is None else json.dumps(spec.input_snapshot, default=str),
        )
        if carried is not None:
            row.status = sm.CARRIED_FORWARD
            row.carried_from_stage_id = carried.carried_from_stage_id or carried.id
            row.output_ref = carried.output_ref
            row.provider, row.model, row.is_mock = carried.provider, carried.model, carried.is_mock
            row.started_at, row.finished_at = carried.started_at, carried.finished_at
            row.warnings = carried.warnings
        else:
            row.status = sm.PENDING
        rows.append(row)
    db.add_all(rows)
    db.add(
        WorkflowRun(
            module=module or parent_type,
            parent_type=parent_type,
            parent_id=parent_id,
            execution_id=ex.id,
            title=title[:200],
            status=sm.PENDING,
            scope=scope,
            provider=p.provider,
            is_mock=p.is_mock,
            is_demo=is_demo,
        )
    )
    db.flush()
    wake_event.set()
    return CreatedExecution(ex, rows)


def create_retry_execution(
    db: Session,
    prev: Execution,
    *,
    rerun: set[tuple[str, str]],
    scope: str,
    params: dict[str, Any] | None = None,
    provider: ProviderInfo | None = None,
    extra_stages: list[StageSpec] | None = None,
    drop: set[tuple[str, str]] | None = None,
    title: str = "",
    module: str = "",
) -> CreatedExecution:
    """New execution in the lineage of ``prev``.

    Stages still current are created as CARRIED_FORWARD (referencing the
    original output); stages in ``rerun`` and anything not done are PENDING.
    The previous (terminal) execution is never modified.
    """
    if prev.status not in sm.TERMINAL_EXECUTION_STATES:
        raise AppError(409, "EXECUTION_ALREADY_ACTIVE", "The execution is still active; wait or cancel it first.")
    s = get_settings()
    prev_stages = db.execute(
        select(ExecutionStage).where(ExecutionStage.execution_id == prev.id).order_by(ExecutionStage.position)
    ).scalars().all()
    drop = drop or set()
    specs: list[StageSpec] = []
    for st in prev_stages:
        key = (st.stage_key, st.item_id)
        if key in drop:
            continue
        if key in rerun or st.status not in sm.DONE_STAGE_STATES:
            attempts = st.attempt_count + 1
            if attempts > s.JOB_MAX_ATTEMPTS:
                raise AppError(
                    409,
                    "RETRY_LIMIT_REACHED",
                    f"Stage {st.stage_key}{'/' + st.item_id if st.item_id else ''} has been attempted "
                    f"{st.attempt_count} times (limit {s.JOB_MAX_ATTEMPTS}). Change the inputs or the AI provider before retrying.",
                )
            specs.append(StageSpec(st.stage_key, st.item_id, st.required, None, attempts))
        else:
            specs.append(StageSpec(st.stage_key, st.item_id, st.required, st, st.attempt_count))
    for extra in extra_stages or []:
        specs.append(extra)
    if not any(sp.carried_from is None for sp in specs):
        raise AppError(409, "NOTHING_TO_RETRY", "Nothing needs to be re-run: every stage is complete and current.")
    params = dict(params or {})
    return create_execution(
        db,
        parent_type=prev.parent_type,
        parent_id=prev.parent_id,
        stages=specs,
        scope=scope,
        params=params,
        provider=provider,
        is_demo=prev.is_demo,
        retry_of=prev,
        title=title,
        module=module,
        max_duration_seconds=prev.max_duration_seconds,
    )


def _update_run(db: Session, execution_id: str, **fields: Any) -> None:
    run = db.execute(select(WorkflowRun).where(WorkflowRun.execution_id == execution_id)).scalar_one_or_none()
    if run is not None:
        for k, v in fields.items():
            setattr(run, k, v)


def mark_started(db: Session, execution_id: str) -> None:
    _update_run(db, execution_id, status=sm.RUNNING, started_at=utcnow())


def finish_execution(
    db: Session,
    execution_id: str,
    new_status: str,
    *,
    expected: str = sm.RUNNING,
    claim_token: str | None = None,
    error_code: str | None = None,
    error_message: str | None = None,
    retryable: bool | None = None,
    warnings_count: int | None = None,
    stage_status_for_running: str | None = None,
    stage_status_for_pending: str | None = None,
) -> None:
    """Terminal transition + stage clean-up + history, in the caller's transaction."""
    now = utcnow()
    fields: dict[str, Any] = {"finished_at": now}
    if error_code is not None:
        fields.update(error_code=error_code, error_message=error_message, retryable=retryable)
    if warnings_count is not None:
        fields["warnings_count"] = warnings_count
    sm.transition_execution(db, execution_id, expected, new_status, claim_token=claim_token, **fields)
    if stage_status_for_running:
        extra: dict[str, Any] = {"finished_at": now}
        if stage_status_for_running == sm.FAILED:
            extra.update(error_code=error_code, error_message=error_message, retryable=retryable)
        sm.bulk_transition_stages(db, execution_id, sm.RUNNING, stage_status_for_running, **extra)
    if stage_status_for_pending:
        sm.bulk_transition_stages(db, execution_id, sm.PENDING, stage_status_for_pending)
    _update_run(db, execution_id, status=new_status, finished_at=now)


def fail_running_execution(
    db: Session, ex: Execution, code: str, message: str, retryable: bool = True, claim_token: str | None = None
) -> None:
    """Used by the watchdog, recovery and shutdown (guarded by observed token)."""
    finish_execution(
        db,
        ex.id,
        sm.FAILED,
        claim_token=claim_token if claim_token is not None else ex.claim_token,
        error_code=code,
        error_message=message,
        retryable=retryable,
        stage_status_for_running=sm.FAILED,
        stage_status_for_pending=sm.SKIPPED,
    )


def request_cancel(db: Session, execution_id: str) -> Execution:
    """Accepted only for PENDING/RUNNING; otherwise 409 with the current state."""
    ex = db.get(Execution, execution_id)
    if ex is None:
        raise not_found("Execution", execution_id)
    if ex.status == sm.PENDING:
        finish_execution(
            db,
            ex.id,
            sm.CANCELLED,
            expected=sm.PENDING,
            error_code="CANCELLED",
            error_message="Cancelled before it started.",
            retryable=True,
            stage_status_for_pending=sm.CANCELLED,
        )
    elif ex.status == sm.RUNNING:
        ok = sm.update_running_execution(db, ex.id, ex.claim_token or "", cancel_requested=True)
        if not ok:
            raise AppError(409, "CANCEL_RACE", "The execution changed state; reload and try again.")
    else:
        code = "ALREADY_COMPLETED" if ex.status in sm.SUCCESS_EXECUTION_STATES else "ALREADY_FINISHED"
        raise AppError(409, code, f"The execution is already {ex.status}; nothing to cancel.", {"status": ex.status})
    db.flush()
    db.refresh(ex)
    return ex


# ---------------------------------------------------------------------------
# Serialisation
# ---------------------------------------------------------------------------

def stage_to_dict(st: ExecutionStage) -> dict[str, Any]:
    dur = None
    if st.started_at and st.finished_at:
        dur = round((st.finished_at - st.started_at).total_seconds(), 3)
    return {
        "id": st.id,
        "stage_key": st.stage_key,
        "item_id": st.item_id or None,
        "position": st.position,
        "status": st.status,
        "required": st.required,
        "carried_from_stage_id": st.carried_from_stage_id,
        "error_code": st.error_code,
        "error_message": st.error_message,
        "retryable": st.retryable,
        "attempt_count": st.attempt_count,
        "ai_calls_used": st.ai_calls_used,
        "provider": st.provider,
        "model": st.model,
        "is_mock": st.is_mock,
        "warnings": json.loads(st.warnings) if st.warnings else [],
        "started_at": iso(st.started_at),
        "finished_at": iso(st.finished_at),
        "duration_seconds": dur,
    }


def execution_to_dict(ex: Execution, stages: list[ExecutionStage] | None = None) -> dict[str, Any]:
    if stages is None:
        stages = list(ex.stages)
    done = sum(1 for s in stages if s.status in sm.DONE_STAGE_STATES)
    return {
        "id": ex.id,
        "parent_type": ex.parent_type,
        "parent_id": ex.parent_id,
        "scope": ex.scope,
        "status": ex.status,
        "retry_of_execution_id": ex.retry_of_execution_id,
        "attempt_number": ex.attempt_number,
        "cancel_requested": ex.cancel_requested,
        "error_code": ex.error_code,
        "error_message": ex.error_message,
        "retryable": ex.retryable,
        "ai_calls_used": ex.ai_calls_used,
        "provider": ex.provider,
        "model": ex.model,
        "is_mock": ex.is_mock,
        "is_demo": ex.is_demo,
        "warnings_count": ex.warnings_count,
        "created_at": iso(ex.created_at),
        "started_at": iso(ex.started_at),
        "finished_at": iso(ex.finished_at),
        "heartbeat_at": iso(ex.heartbeat_at),
        "progress": {"completed": done, "total": len(stages)},
        "stages": [stage_to_dict(s) for s in stages],
    }


def load_execution(db: Session, execution_id: str, parent_type: str | None = None, parent_id: str | None = None) -> Execution:
    ex = db.get(Execution, execution_id)
    if ex is None or (parent_type and ex.parent_type != parent_type) or (parent_id and ex.parent_id != parent_id):
        raise not_found("Execution", execution_id)
    return ex
