"""In-process worker pool, heartbeats, watchdog and the generic stage loop (2.3).

Rules implemented here:
* claim with a guarded UPDATE (exactly one worker wins);
* every later write includes ``claim_token`` and ``status='RUNNING'``;
* decision points (before each stage, after each stage returns, finalization)
  run in ``BEGIN IMMEDIATE`` transactions;
* no write transaction is open while a stage computes (AI call / fetch / file);
* a stage's output and its COMPLETED transition commit in one transaction, and
  the last required stage's commit also finalizes the execution (point of no
  return), so a racing cancel either wins before it or gets 409.
"""
from __future__ import annotations

import json
import logging
import threading
import uuid
from dataclasses import dataclass
from datetime import timedelta
from typing import Any, Callable

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from ...config import get_settings
from ...database import new_immediate_session, new_session, with_lock_retry
from ...models.jobs import Execution, ExecutionStage
from ...utils.clock import utcnow
from . import state_machine as sm
from .engine import fail_running_execution, finish_execution, mark_started, wake_event
from .errors import ClassifiedError, classify
from .registry import StageContext, get_handler

log = logging.getLogger("flowsynapse.worker")

# Test hooks
TEST_HOOKS: dict[str, Callable[..., Any]] = {}


class LostClaim(Exception):
    """The claim on this execution is no longer valid; abandon silently."""


@dataclass
class Claim:
    execution_id: str
    token: str
    worker_id: str


def _immediate(fn: Callable[[Session], Any]) -> Any:
    def attempt() -> Any:
        db = new_immediate_session()
        try:
            out = fn(db)
            db.commit()
            return out
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    return with_lock_retry(attempt)


# ---------------------------------------------------------------------------
# Claiming
# ---------------------------------------------------------------------------

def try_claim(execution_id: str, worker_id: str) -> Claim | None:
    token = uuid.uuid4().hex

    def op(db: Session) -> Claim | None:
        now = utcnow()
        res = db.execute(
            update(Execution)
            .where(Execution.id == execution_id, Execution.status == sm.PENDING)
            .values(
                status=sm.RUNNING,
                claimed_by=worker_id,
                claim_token=token,
                claimed_at=now,
                heartbeat_at=now,
                started_at=now,
                row_version=Execution.row_version + 1,
            )
            .execution_options(synchronize_session=False)
        )
        if res.rowcount != 1:  # type: ignore[attr-defined]
            return None
        mark_started(db, execution_id)
        return Claim(execution_id, token, worker_id)

    return _immediate(op)


def claim_next(worker_id: str) -> Claim | None:
    with new_session() as db:
        candidates = db.execute(
            select(Execution.id).where(Execution.status == sm.PENDING).order_by(Execution.created_at).limit(5)
        ).scalars().all()
    for cid in candidates:
        c = try_claim(cid, worker_id)
        if c is not None:
            return c
    return None


def heartbeat(claim: Claim) -> bool:
    def op(db: Session) -> bool:
        return sm.update_running_execution(db, claim.execution_id, claim.token, heartbeat_at=utcnow())

    return bool(_immediate(op))


# ---------------------------------------------------------------------------
# Watchdog
# ---------------------------------------------------------------------------

def watchdog_tick() -> list[tuple[str, str]]:
    """Fail RUNNING executions with stale heartbeats or exceeded max duration."""
    s = get_settings()
    now = utcnow()
    stale_before = now - timedelta(seconds=s.STALE_AFTER_SECONDS)
    acted: list[tuple[str, str]] = []
    with new_session() as db:
        running = db.execute(select(Execution).where(Execution.status == sm.RUNNING)).scalars().all()
        snapshot = [(e.id, e.claim_token, e.heartbeat_at, e.started_at, e.max_duration_seconds) for e in running]
    for ex_id, token, hb, started, max_dur in snapshot:
        limit = max_dur or s.JOB_MAX_DURATION_SECONDS
        code = None
        if hb is None or hb < stale_before:
            code, msg = "STALE_HEARTBEAT", "The worker stopped responding (stale heartbeat). Retry to run the remaining stages."
        elif started is not None and (now - started).total_seconds() > limit:
            code, msg = "TIMEOUT", f"The execution exceeded the maximum duration of {int(limit)} seconds. Retry or reduce the scope."
        if code is None:
            continue

        def op(db: Session, ex_id: str = ex_id, token: str | None = token, code: str = code, msg: str = msg) -> bool:
            ex = db.get(Execution, ex_id)
            if ex is None or ex.status != sm.RUNNING or ex.claim_token != token:
                return False
            try:
                fail_running_execution(db, ex, code, msg, True, claim_token=token)
            except sm.IllegalTransition:
                return False
            return True

        if _immediate(op):
            log.warning("watchdog marked execution %s FAILED (%s)", ex_id, code)
            acted.append((ex_id, code))
    return acted


# ---------------------------------------------------------------------------
# The generic execution loop
# ---------------------------------------------------------------------------

class ExecutionRunner:
    def __init__(self, claim: Claim, shutdown: threading.Event) -> None:
        self.claim = claim
        self.shutdown = shutdown

    # -- guarded helpers -----------------------------------------------------
    def _load_valid(self, db: Session) -> Execution:
        ex = db.get(Execution, self.claim.execution_id)
        if ex is None or ex.status != sm.RUNNING or ex.claim_token != self.claim.token:
            raise LostClaim()
        return ex

    def should_stop(self) -> bool:
        if self.shutdown.is_set():
            return True
        with new_session() as db:
            ex = db.get(Execution, self.claim.execution_id)
            return ex is None or ex.status != sm.RUNNING or ex.claim_token != self.claim.token or bool(ex.cancel_requested)

    def guarded_write(self, fn: Callable[[Session], Any]) -> bool:
        def op(db: Session) -> bool:
            ex = self._load_valid(db)
            if ex.cancel_requested and not getattr(fn, "allow_when_cancelling", False):
                return False
            fn(db)
            return True

        try:
            return bool(_immediate(op))
        except LostClaim:
            return False

    # -- main loop -------------------------------------------------------------
    def run(self) -> None:
        try:
            self._run()
        except LostClaim:
            log.info("execution %s: claim lost; worker abandoned it", self.claim.execution_id)

    def _run(self) -> None:
        ex_id = self.claim.execution_id
        with new_session() as db:
            ex = db.get(Execution, ex_id)
            assert ex is not None
            handler = get_handler(ex.parent_type)
            meta = dict(
                parent_type=ex.parent_type,
                parent_id=ex.parent_id,
                scope=ex.scope,
                params=json.loads(ex.params or "{}"),
                attempt_number=ex.attempt_number,
                is_demo=ex.is_demo,
            )
            stage_ids = db.execute(
                select(ExecutionStage.id)
                .where(ExecutionStage.execution_id == ex_id, ExecutionStage.status == sm.PENDING)
                .order_by(ExecutionStage.position)
            ).scalars().all()

        if not stage_ids:
            _immediate(lambda db: self._finalize(db, handler))
            return

        for stage_id in stage_ids:
            # Decision point 1: before claiming the stage.
            started = _immediate(lambda db, sid=stage_id: self._before_stage(db, sid))
            if started is None:
                return  # cancelled/interrupted/finished inside _before_stage
            if started == "skip":
                continue
            stage_key, item_id, snapshot = started
            ctx = StageContext(
                execution_id=ex_id,
                stage_id=stage_id,
                stage_key=stage_key,
                item_id=item_id,
                claim_token=self.claim.token,
                should_stop=self.should_stop,
                guarded_write=self.guarded_write,
                input_snapshot=snapshot,
                **meta,
            )
            from ...ai.runner import make_runner_for_stage

            ctx.ai = make_runner_for_stage(ex_id, f"{stage_key}/{item_id}" if item_id else stage_key)
            result: Any = None
            error: ClassifiedError | None = None
            try:
                hook = TEST_HOOKS.get("during_stage")
                if hook:
                    hook(ctx)
                result = handler.run_stage(ctx)
            except Exception as exc:  # classified, never swallowed silently
                log.warning("stage %s/%s failed: %s", stage_key, item_id, type(exc).__name__)
                error = classify(exc)
            hook = TEST_HOOKS.get("after_stage_returns")
            if hook:
                hook(ctx)
            # Decision point 2: after the stage returns.
            outcome = self._after_stage(ctx, handler, result, error)
            if outcome == "stop":
                return

    def _before_stage(self, db: Session, stage_id: str) -> Any:
        ex = self._load_valid(db)
        if ex.cancel_requested:
            self._cancel(db, ex)
            return None
        if self.shutdown.is_set():
            self._interrupt(db, ex)
            return None
        st = db.get(ExecutionStage, stage_id)
        if st is None or st.status != sm.PENDING:
            return "skip"
        sm.transition_stage(db, stage_id, sm.PENDING, sm.RUNNING, started_at=utcnow())
        snapshot = json.loads(st.input_snapshot) if st.input_snapshot else None
        return st.stage_key, st.item_id, snapshot

    def _cancel(self, db: Session, ex: Execution) -> None:
        finish_execution(
            db,
            ex.id,
            sm.CANCELLED,
            claim_token=self.claim.token,
            error_code="CANCELLED",
            error_message="Cancelled by user. Completed stages were preserved.",
            retryable=True,
            stage_status_for_running=sm.CANCELLED,
            stage_status_for_pending=sm.CANCELLED,
        )

    def _interrupt(self, db: Session, ex: Execution) -> None:
        fail_running_execution(
            db, ex, "INTERRUPTED", "Interrupted by application shutdown. Retry to continue.", True, claim_token=self.claim.token
        )

    def _after_stage(self, ctx: StageContext, handler: Any, result: Any, error: ClassifiedError | None) -> str:
        ai_calls = ctx.ai.stage_calls if ctx.ai else 0

        def provenance() -> dict[str, Any]:
            prov = ctx.ai.provenance() if ctx.ai else {}
            return dict(
                ai_calls_used=ai_calls,
                provider=ctx.provider or prov.get("provider"),
                model=ctx.model or prov.get("model"),
                is_mock=ctx.is_mock if ctx.is_mock is not None else prov.get("is_mock"),
                input_snapshot=ctx.snapshot_json(),
            )

        def common(db: Session) -> Execution | None:
            ex = self._load_valid(db)
            if ex.cancel_requested:
                # In-flight result discarded; committed outputs preserved.
                self._cancel(db, ex)
                return None
            if self.shutdown.is_set():
                self._interrupt(db, ex)
                return None
            sm.update_running_execution(db, ex.id, self.claim.token, ai_calls_used=Execution.ai_calls_used + ai_calls)
            return ex

        def on_error(db: Session, err: ClassifiedError) -> str:
            ex = common(db)
            if ex is None:
                return "stop"
            sm.transition_stage(
                db, ctx.stage_id, sm.RUNNING, sm.FAILED,
                finished_at=utcnow(), error_code=err.code, error_message=err.message, retryable=err.retryable,
                **provenance(),
            )
            if handler.continue_on_failure(ctx.stage_key):
                return self._maybe_finalize(db, handler)
            finish_execution(
                db, ex.id, sm.FAILED, claim_token=self.claim.token,
                error_code=err.code, error_message=f"{ctx.stage_key}: {err.message}", retryable=err.retryable,
                stage_status_for_pending=sm.SKIPPED,
            )
            return "stop"

        if error is not None:
            return str(_immediate(lambda db: on_error(db, error)))

        def on_success(db: Session) -> str:
            ex = common(db)
            if ex is None:
                return "stop"
            hook = TEST_HOOKS.get("before_commit")
            if hook:
                hook(ctx)
            outcome = handler.commit_stage(db, ctx, result)
            ref = outcome.output_ref
            sm.transition_stage(
                db, ctx.stage_id, sm.RUNNING, sm.COMPLETED,
                finished_at=utcnow(),
                output_ref=None if ref is None else json.dumps(ref, default=str),
                warnings=json.dumps(outcome.warnings) if outcome.warnings else None,
                **provenance(),
            )
            return self._maybe_finalize(db, handler)

        try:
            return str(_immediate(on_success))
        except LostClaim:
            raise
        except Exception as exc:  # commit failed -> never COMPLETED
            log.warning("commit of stage %s failed: %s", ctx.stage_key, type(exc).__name__)
            return str(_immediate(lambda db: on_error(db, classify(exc))))

    def _maybe_finalize(self, db: Session, handler: Any) -> str:
        remaining = db.execute(
            select(ExecutionStage.id).where(
                ExecutionStage.execution_id == self.claim.execution_id, ExecutionStage.status == sm.PENDING
            ).limit(1)
        ).first()
        if remaining is not None:
            return "continue"
        self._finalize(db, handler)
        return "stop"

    def _finalize(self, db: Session, handler: Any) -> None:
        ex = self._load_valid(db)
        stages = db.execute(select(ExecutionStage).where(ExecutionStage.execution_id == ex.id)).scalars().all()
        failed = [s for s in stages if s.status == sm.FAILED]
        done = [s for s in stages if s.status in sm.DONE_STAGE_STATES]
        stage_warnings = sum(len(json.loads(s.warnings)) for s in stages if s.warnings and s.status == sm.COMPLETED)
        if failed and not done:
            status = sm.FAILED
        elif failed or stage_warnings:
            status = sm.COMPLETED_WITH_WARNINGS
        else:
            status = sm.COMPLETED
        extra = handler.finalize(db, ex.id, status)
        if extra and status == sm.COMPLETED:
            status = sm.COMPLETED_WITH_WARNINGS
        if status == sm.FAILED:
            err = failed[0]
            finish_execution(db, ex.id, status, claim_token=self.claim.token, error_code=err.error_code,
                             error_message=f"All items failed. {err.error_message}", retryable=err.retryable)
        elif failed:
            finish_execution(db, ex.id, status, claim_token=self.claim.token, error_code="PARTIAL_FAILURE",
                             error_message=f"{len(failed)} of {len(stages)} units failed; completed units were preserved. Use 'Retry failed'.",
                             retryable=True, warnings_count=stage_warnings + len(extra or []) + len(failed))
        else:
            finish_execution(db, ex.id, status, claim_token=self.claim.token,
                             warnings_count=stage_warnings + len(extra or []))


# ---------------------------------------------------------------------------
# Pool
# ---------------------------------------------------------------------------

class WorkerPool:
    def __init__(self, concurrency: int | None = None, watchdog_interval: float = 15.0) -> None:
        s = get_settings()
        self.concurrency = s.WORKER_CONCURRENCY if concurrency is None else concurrency
        self.watchdog_interval = watchdog_interval
        self.shutdown = threading.Event()
        self.accepting = True
        self._threads: list[threading.Thread] = []
        self._active: dict[str, Claim] = {}
        self._lock = threading.Lock()
        self._db_url: str | None = None

    def _bound_db_changed(self) -> bool:
        """True if the global engine was re-initialised (tests): stop working."""
        from ...database import state

        return self._db_url is not None and state.url != self._db_url

    def _heartbeat_loop(self, claim: Claim, done: threading.Event) -> None:
        interval = get_settings().HEARTBEAT_INTERVAL_SECONDS
        while not done.wait(interval):
            if TEST_HOOKS.get("pause_heartbeat"):
                continue
            try:
                if not heartbeat(claim):
                    return
            except Exception:
                log.exception("heartbeat failed")

    def run_claim(self, claim: Claim) -> None:
        done = threading.Event()
        hb = threading.Thread(target=self._heartbeat_loop, args=(claim, done), daemon=True, name=f"hb-{claim.worker_id}")
        hb.start()
        with self._lock:
            self._active[claim.execution_id] = claim
        try:
            ExecutionRunner(claim, self.shutdown).run()
        except Exception:
            log.exception("execution %s crashed", claim.execution_id)
            try:
                def op(db: Session) -> None:
                    ex = db.get(Execution, claim.execution_id)
                    if ex is not None and ex.status == sm.RUNNING and ex.claim_token == claim.token:
                        fail_running_execution(db, ex, "INTERNAL_ERROR", "The worker crashed; see server logs.", False, claim.token)

                _immediate(op)
            except Exception:
                log.exception("could not mark crashed execution failed")
        finally:
            done.set()
            hb.join(timeout=2)
            with self._lock:
                self._active.pop(claim.execution_id, None)

    def join(self, timeout: float = 5.0) -> bool:
        for t in self._threads:
            t.join(timeout=timeout)
        return not any(t.is_alive() for t in self._threads)

    def _worker(self, n: int) -> None:
        wid = f"w{n}-{uuid.uuid4().hex[:6]}"
        while not self.shutdown.is_set() and not self._bound_db_changed():
            claim = None
            if self.accepting:
                try:
                    claim = claim_next(wid)
                except Exception:
                    log.exception("claim failed")
            if claim is None:
                wake_event.wait(0.5)
                wake_event.clear()
                continue
            self.run_claim(claim)

    def _watchdog(self) -> None:
        while not self.shutdown.wait(self.watchdog_interval) and not self._bound_db_changed():
            try:
                watchdog_tick()
            except Exception:
                log.exception("watchdog failed")

    def start(self) -> None:
        from ...database import state

        self._db_url = state.url
        for i in range(self.concurrency):
            t = threading.Thread(target=self._worker, args=(i,), daemon=True, name=f"worker-{i}")
            t.start()
            self._threads.append(t)
        wd = threading.Thread(target=self._watchdog, daemon=True, name="watchdog")
        wd.start()
        self._threads.append(wd)

    def stop(self, grace_seconds: float) -> None:
        """Controlled shutdown: stop claiming, let workers reach a boundary,
        then mark anything still RUNNING as FAILED/INTERRUPTED."""
        self.accepting = False
        self.shutdown.set()
        wake_event.set()
        for t in self._threads:
            t.join(timeout=max(grace_seconds, 0.1))
        alive = [t.name for t in self._threads if t.is_alive()]
        if alive:
            log.warning("worker threads still busy after %.1fs grace: %s", grace_seconds, alive)
        from .recovery import interrupt_running

        interrupt_running("Interrupted by application shutdown. Retry to continue.")
