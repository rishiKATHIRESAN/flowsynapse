"""The single definition of legal execution and stage transitions (2.3).

Every status write goes through :func:`transition_execution` /
:func:`transition_stage` as a guarded UPDATE
(``WHERE id=:id AND status=:expected [AND claim_token=:t]``). An illegal or
lost-race transition raises :class:`IllegalTransition` and is never applied.
"""
from __future__ import annotations

import logging
from typing import Any

from sqlalchemy import update
from sqlalchemy.orm import Session

from ...models.jobs import Execution, ExecutionStage

log = logging.getLogger("flowsynapse.jobs")

PENDING, RUNNING = "PENDING", "RUNNING"
COMPLETED, COMPLETED_WITH_WARNINGS = "COMPLETED", "COMPLETED_WITH_WARNINGS"
FAILED, CANCELLED, SKIPPED, CARRIED_FORWARD = "FAILED", "CANCELLED", "SKIPPED", "CARRIED_FORWARD"

EXECUTION_STATES = (PENDING, RUNNING, COMPLETED, COMPLETED_WITH_WARNINGS, FAILED, CANCELLED)
STAGE_STATES = (PENDING, RUNNING, COMPLETED, FAILED, CANCELLED, SKIPPED, CARRIED_FORWARD)

# None = a new row being created.
EXECUTION_TRANSITIONS: dict[str | None, frozenset[str]] = {
    None: frozenset({PENDING}),
    PENDING: frozenset({RUNNING, CANCELLED}),
    RUNNING: frozenset({COMPLETED, COMPLETED_WITH_WARNINGS, FAILED, CANCELLED}),
    COMPLETED: frozenset(),
    COMPLETED_WITH_WARNINGS: frozenset(),
    FAILED: frozenset(),
    CANCELLED: frozenset(),
}

STAGE_TRANSITIONS: dict[str | None, frozenset[str]] = {
    None: frozenset({PENDING, CARRIED_FORWARD}),
    PENDING: frozenset({RUNNING, SKIPPED, CANCELLED}),
    RUNNING: frozenset({COMPLETED, FAILED, CANCELLED}),
    COMPLETED: frozenset(),
    FAILED: frozenset(),
    CANCELLED: frozenset(),
    SKIPPED: frozenset(),
    CARRIED_FORWARD: frozenset(),
}

ACTIVE_EXECUTION_STATES = frozenset({PENDING, RUNNING})
TERMINAL_EXECUTION_STATES = frozenset({COMPLETED, COMPLETED_WITH_WARNINGS, FAILED, CANCELLED})
SUCCESS_EXECUTION_STATES = frozenset({COMPLETED, COMPLETED_WITH_WARNINGS})
DONE_STAGE_STATES = frozenset({COMPLETED, CARRIED_FORWARD})


class IllegalTransition(Exception):
    def __init__(self, kind: str, row_id: str, frm: str | None, to: str, reason: str = "illegal") -> None:
        self.kind, self.row_id, self.frm, self.to, self.reason = kind, row_id, frm, to, reason
        super().__init__(f"{kind} {row_id}: {reason} transition {frm} -> {to}")


def is_legal_execution(frm: str | None, to: str) -> bool:
    return to in EXECUTION_TRANSITIONS.get(frm, frozenset())


def is_legal_stage(frm: str | None, to: str) -> bool:
    return to in STAGE_TRANSITIONS.get(frm, frozenset())


def transition_execution(
    db: Session,
    execution_id: str,
    expected: str,
    new: str,
    *,
    claim_token: str | None = None,
    **fields: Any,
) -> None:
    if not is_legal_execution(expected, new):
        log.error("illegal execution transition %s -> %s for %s", expected, new, execution_id)
        raise IllegalTransition("execution", execution_id, expected, new)
    stmt = (
        update(Execution)
        .where(Execution.id == execution_id, Execution.status == expected)
        .values(status=new, row_version=Execution.row_version + 1, **fields)
        .execution_options(synchronize_session=False)
    )
    if claim_token is not None:
        stmt = stmt.where(Execution.claim_token == claim_token)
    res = db.execute(stmt)
    if res.rowcount != 1:  # type: ignore[attr-defined]
        log.warning("lost race on execution %s (%s -> %s)", execution_id, expected, new)
        raise IllegalTransition("execution", execution_id, expected, new, "lost-race")


def update_running_execution(db: Session, execution_id: str, claim_token: str, **fields: Any) -> bool:
    """Non-status write by the claiming worker (guarded by claim + RUNNING)."""
    res = db.execute(
        update(Execution)
        .where(
            Execution.id == execution_id,
            Execution.status == RUNNING,
            Execution.claim_token == claim_token,
        )
        .values(row_version=Execution.row_version + 1, **fields)
        .execution_options(synchronize_session=False)
    )
    return res.rowcount == 1  # type: ignore[attr-defined]


def transition_stage(db: Session, stage_id: str, expected: str, new: str, **fields: Any) -> None:
    if not is_legal_stage(expected, new):
        log.error("illegal stage transition %s -> %s for %s", expected, new, stage_id)
        raise IllegalTransition("stage", stage_id, expected, new)
    res = db.execute(
        update(ExecutionStage)
        .where(ExecutionStage.id == stage_id, ExecutionStage.status == expected)
        .values(status=new, **fields)
        .execution_options(synchronize_session=False)
    )
    if res.rowcount != 1:  # type: ignore[attr-defined]
        raise IllegalTransition("stage", stage_id, expected, new, "lost-race")


def bulk_transition_stages(db: Session, execution_id: str, expected: str, new: str, **fields: Any) -> int:
    """Move every stage of an execution in ``expected`` to ``new`` (legal pairs only)."""
    if not is_legal_stage(expected, new):
        raise IllegalTransition("stage", f"{execution_id}/*", expected, new)
    res = db.execute(
        update(ExecutionStage)
        .where(ExecutionStage.execution_id == execution_id, ExecutionStage.status == expected)
        .values(status=new, **fields)
        .execution_options(synchronize_session=False)
    )
    return int(res.rowcount)  # type: ignore[attr-defined]
