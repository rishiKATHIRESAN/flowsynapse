"""Failure classification for stages/items (master prompt 2.3)."""
from __future__ import annotations

from dataclasses import dataclass

from ...utils.redact import redact


class StageError(Exception):
    """Raised by stage handlers with a classified, user-safe message."""

    def __init__(self, code: str, message: str, retryable: bool, hint: str | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.retryable = retryable
        self.hint = hint


@dataclass
class ClassifiedError:
    code: str
    message: str
    retryable: bool

    @property
    def display(self) -> str:
        return self.message


RETRYABLE_CODES = {
    "PROVIDER_TIMEOUT",
    "PROVIDER_RATE_LIMITED",
    "PROVIDER_UNAVAILABLE",
    "NETWORK_ERROR",
    "DATABASE_BUSY",
    "FETCH_TIMEOUT",
    "STALE_HEARTBEAT",
    "INTERRUPTED",
    "AI_BUDGET_EXHAUSTED",
    "TIMEOUT",
}


def classify(exc: BaseException) -> ClassifiedError:
    from ...database import DatabaseBusyError

    if isinstance(exc, StageError):
        msg = exc.message + (f" What to change: {exc.hint}" if exc.hint else "")
        return ClassifiedError(exc.code, redact(msg)[:2000], exc.retryable)
    if isinstance(exc, DatabaseBusyError):
        return ClassifiedError("DATABASE_BUSY", "The database was busy; retry the operation.", True)
    if isinstance(exc, TimeoutError):
        return ClassifiedError("PROVIDER_TIMEOUT", "The operation timed out; retry is possible.", True)
    if isinstance(exc, (ConnectionError, OSError)):
        return ClassifiedError("NETWORK_ERROR", "A network error occurred; retry is possible.", True)
    # Programming errors are non-retryable and never leak internals.
    return ClassifiedError(
        "INTERNAL_ERROR",
        f"An internal error occurred ({type(exc).__name__}). See server logs; retrying will not help until it is fixed.",
        False,
    )
