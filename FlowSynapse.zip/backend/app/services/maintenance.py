"""Periodic maintenance tasks (idempotency-key cleanup, export retention)."""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass
from typing import Callable

log = logging.getLogger("flowsynapse.maintenance")


@dataclass
class Task:
    name: str
    interval_seconds: float
    fn: Callable[[], object]
    next_run: float = 0.0


class MaintenanceService:
    def __init__(self, tasks: list[Task]) -> None:
        self.tasks = tasks
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def run_due(self) -> None:
        now = time.monotonic()
        for t in self.tasks:
            if now >= t.next_run:
                try:
                    result = t.fn()
                    log.info("maintenance task %s done: %s", t.name, result)
                except Exception:
                    # Logged and retried at the next interval; never crashes the app.
                    log.exception("maintenance task %s failed", t.name)
                t.next_run = now + t.interval_seconds

    def _loop(self) -> None:
        while not self._stop.is_set():
            self.run_due()
            self._stop.wait(5.0)

    def start(self) -> None:
        self.run_due()  # at startup
        self._thread = threading.Thread(target=self._loop, name="maintenance", daemon=True)
        self._thread.start()

    def stop(self, grace_seconds: float) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=max(grace_seconds, 1.0))
