"""Demo-data framework (master prompt 3.3, 3.6).

Each module registers a :class:`DemoModule`. Loading is idempotent (stable demo
keys). Removal computes the demo roots and deletes them with their own
descendants only, in one transaction, by explicit ID set; it is refused (409)
when any real record references a demo record.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Callable

from sqlalchemy.orm import Session

from ..database import new_immediate_session
from ..utils.errors import AppError
from .records import remove_files

log = logging.getLogger("flowsynapse.demo")


@dataclass
class DemoModule:
    name: str
    order: int
    load: Callable[[], dict[str, Any]]
    roots: Callable[[Session], list[str]]
    delete_root: Callable[[Session, str], list[str]]  # returns export files to remove
    real_dependents: Callable[[Session, set[str]], list[dict[str, Any]]]
    keep_as_own: Callable[[Session, str], None]
    status: Callable[[Session], dict[str, Any]] | None = None


_MODULES: dict[str, DemoModule] = {}


def register(m: DemoModule) -> None:
    _MODULES[m.name] = m


def modules() -> list[DemoModule]:
    return sorted(_MODULES.values(), key=lambda m: m.order)


def status() -> dict[str, Any]:
    from ..database import new_session

    out: dict[str, Any] = {}
    with new_session() as db:
        for m in modules():
            info = {"demo_records": len(m.roots(db))}
            if m.status:
                info.update(m.status(db))
            out[m.name] = info
    return out


def load(names: list[str] | None = None) -> dict[str, Any]:
    results: dict[str, Any] = {}
    for m in modules():
        if names and m.name not in names:
            continue
        try:
            results[m.name] = m.load()
        except AppError as exc:
            results[m.name] = {"created": False, "error": exc.message, "code": exc.code}
    return results


def remove_all() -> dict[str, Any]:
    db = new_immediate_session()
    files: list[str] = []
    try:
        all_roots: dict[str, list[str]] = {m.name: m.roots(db) for m in modules()}
        demo_ids = {i for ids in all_roots.values() for i in ids}
        dependents: list[dict[str, Any]] = []
        for m in modules():
            dependents += m.real_dependents(db, demo_ids)
        if dependents:
            db.rollback()
            raise AppError(
                409,
                "DEMO_DATA_REFERENCED",
                "Some of your own records reference demo records. Choose 'Keep as my own' on the demo record "
                "or detach the reference, then try again.",
                {"dependents": dependents},
            )
        counts = {}
        for m in modules():
            for rid in all_roots[m.name]:
                files += m.delete_root(db, rid)
            counts[m.name] = len(all_roots[m.name])
        db.commit()
    except BaseException:
        db.rollback()
        raise
    finally:
        db.close()
    remove_files(files)
    return {"removed": counts}


def keep_as_own(module: str, record_id: str) -> None:
    m = _MODULES.get(module)
    if m is None:
        raise AppError(404, "NOT_FOUND", f"Unknown module {module}")
    db = new_immediate_session()
    try:
        m.keep_as_own(db, record_id)
        db.commit()
    except BaseException:
        db.rollback()
        raise
    finally:
        db.close()
