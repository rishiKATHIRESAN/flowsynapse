"""Stage 1 - INPUT_VALIDATION (deterministic, master prompt 5.3).

Returns field-level errors (blocking) and warnings (non-blocking). No later
stage runs while blocking errors exist.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from urllib.parse import urlparse

from .brief import CURRENCIES, ORGANIC_CHANNELS, PAID_CHANNELS, REQUIRED_FIELDS, BriefInput
from .budget import BudgetError, parse_amount
from .dates import parse_iso_date, resolve_period


@dataclass
class ValidationResult:
    errors: list[dict[str, str]] = field(default_factory=list)
    warnings: list[dict[str, str]] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors

    def as_dict(self) -> dict[str, Any]:
        return {"valid": self.ok, "errors": self.errors, "warnings": self.warnings}


def _blank(v: Any) -> bool:
    return v is None or (isinstance(v, str) and not v.strip()) or (isinstance(v, (list, tuple)) and len(v) == 0)


def valid_http_url(url: str) -> bool:
    try:
        p = urlparse(url.strip())
    except ValueError:
        return False
    return p.scheme in ("http", "https") and bool(p.netloc) and " " not in url.strip() and "." in (p.hostname or "")


def validate_brief(brief: BriefInput) -> ValidationResult:
    r = ValidationResult()
    data = brief.model_dump()

    def err(f: str, code: str, msg: str) -> None:
        if not any(e["field"] == f and e["code"] == code for e in r.errors):
            r.errors.append({"field": f, "code": code, "message": msg})

    def warn(f: str, code: str, msg: str) -> None:
        r.warnings.append({"field": f, "code": code, "message": msg})

    for f, label in REQUIRED_FIELDS.items():
        if _blank(data.get(f)):
            err(f, "REQUIRED", f"{label} is required")

    # Dates / duration
    period = resolve_period(brief.start_date, brief.end_date, brief.duration_days)
    for e in period.errors:
        if not (e["code"] == "REQUIRED" and e["field"] == "start_date" and any(x["field"] == "start_date" for x in r.errors)):
            err(e["field"], e["code"], e["message"])

    # Currency and budget
    currency = (brief.currency or "").upper()
    if currency and currency not in CURRENCIES:
        err("currency", "UNSUPPORTED_CURRENCY", f"Supported currencies: {', '.join(CURRENCIES)}")
    if not _blank(brief.total_budget):
        try:
            parse_amount(brief.total_budget, currency or "INR")
        except BudgetError as e:
            err("total_budget", e.code, e.message)

    # Channels
    bad_paid = [c for c in brief.paid_channels if c not in PAID_CHANNELS]
    if bad_paid:
        err("paid_channels", "UNSUPPORTED_CHANNEL", f"Unsupported paid channel(s): {', '.join(bad_paid)}. Use google_ads, meta_ads.")
    bad_org = [c for c in brief.organic_channels if c not in ORGANIC_CHANNELS]
    if bad_org:
        err("organic_channels", "UNSUPPORTED_CHANNEL", f"Unsupported organic channel(s): {', '.join(bad_org)}")
    if len(set(brief.paid_channels)) != len(brief.paid_channels):
        warn("paid_channels", "DUPLICATE", "Duplicate paid channels were removed")

    # URLs
    for f in ("landing_page_url", "website_url"):
        v = data.get(f)
        if not _blank(v) and not valid_http_url(v):
            err(f, "INVALID_URL", "Enter a full http(s) URL, e.g. https://example.com/page")

    # Cadence
    cad = brief.posting_cadence
    if cad.type == "every_n_days" and not cad.n:
        err("posting_cadence", "INVALID_CADENCE", "every_n_days needs n >= 1")
    if cad.type == "weekdays" and not cad.weekdays:
        err("posting_cadence", "INVALID_CADENCE", "Choose at least one weekday")
    if cad.type == "weekdays" and cad.weekdays and any(d < 0 or d > 6 for d in cad.weekdays):
        err("posting_cadence", "INVALID_CADENCE", "Weekdays must be 0 (Mon) to 6 (Sun)")
    if cad.type == "times_per_week" and not cad.times_per_week:
        err("posting_cadence", "INVALID_CADENCE", "times_per_week needs a number from 1 to 7")
    if cad.type == "custom":
        if not cad.custom_dates:
            err("posting_cadence", "INVALID_CADENCE", "Add at least one custom date")
        else:
            for d in cad.custom_dates:
                try:
                    dd = parse_iso_date(d)
                    if period.ok and not (period.start <= dd <= period.end):  # type: ignore[operator]
                        err("posting_cadence", "DATE_OUT_OF_RANGE", f"Custom date {d} is outside the campaign period")
                except ValueError:
                    err("posting_cadence", "INVALID_DATE", f"Custom date {d} is not a valid ISO date")

    # Contradictions and gaps (non-blocking where the brief can still proceed)
    if not brief.organic_channels:
        warn("organic_channels", "NO_ORGANIC_CHANNELS", "No organic channels selected: the social plan will be empty")
    if _blank(brief.landing_page_url):
        warn("landing_page_url", "MISSING", "No landing page URL: tracking URLs will be placeholders to complete")
    overlap = {c.strip().lower() for c in brief.approved_claims} & {c.strip().lower() for c in brief.prohibited_claims}
    if overlap:
        err("approved_claims", "CONTRADICTION", "A claim is listed as both approved and prohibited: " + "; ".join(sorted(overlap)))
    for f in ("value_proposition", "tone", "age_range"):
        if _blank(data.get(f)):
            warn(f, "ASSUMPTION_NEEDED", f"{f.replace('_', ' ').capitalize()} not supplied - a labelled assumption will be used")
    return r
