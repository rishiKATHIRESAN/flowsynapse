"""Execution finalization hook for campaigns (QA-derived warnings)."""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...models.campaign import CampaignFinding
from ...models.jobs import Execution


def finalize_campaign(db: Session, execution_id: str, final_status: str) -> list[str]:
    ex = db.get(Execution, execution_id)
    if ex is None:
        return []
    rows = db.execute(
        select(CampaignFinding).where(CampaignFinding.campaign_id == ex.parent_id,
                                      CampaignFinding.execution_id == execution_id,
                                      CampaignFinding.severity.in_(("BLOCKER", "WARNING")))
    ).scalars().all()
    return [f"{r.severity}: {r.description}" for r in rows]
