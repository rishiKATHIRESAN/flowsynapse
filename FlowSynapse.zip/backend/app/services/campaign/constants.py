"""Campaign workflow stage keys (fixed order, master prompt 5.3)."""
from __future__ import annotations

STAGES: list[str] = [
    "INPUT_VALIDATION",
    "BRIEF_NORMALIZATION",
    "OBJECTIVE_ANALYSIS",
    "STRATEGY",
    "CONCEPTS",
    "GOOGLE_ADS",
    "META_ADS",
    "SOCIAL_PLAN",
    "TRACKING_PLAN",
    "BUDGET_ALLOCATION",
    "QUALITY_ASSURANCE",
    "PACK_GENERATION",
]

STAGE_LABELS: dict[str, str] = {
    "INPUT_VALIDATION": "Input validation",
    "BRIEF_NORMALIZATION": "Brief normalization",
    "OBJECTIVE_ANALYSIS": "Objective analysis",
    "STRATEGY": "Strategy",
    "CONCEPTS": "Creative concepts",
    "GOOGLE_ADS": "Google Ads proposals",
    "META_ADS": "Meta Ads proposals",
    "SOCIAL_PLAN": "Social plan",
    "TRACKING_PLAN": "Tracking & UTM plan",
    "BUDGET_ALLOCATION": "Budget allocation",
    "QUALITY_ASSURANCE": "Quality assurance",
    "PACK_GENERATION": "Campaign pack",
}

# Output types produced by each stage (generic outputs table).
STAGE_OUTPUTS: dict[str, list[str]] = {
    "INPUT_VALIDATION": [],
    "BRIEF_NORMALIZATION": [],
    "OBJECTIVE_ANALYSIS": ["objective_analysis"],
    "STRATEGY": ["strategy"],
    "CONCEPTS": ["concept"],
    "GOOGLE_ADS": ["google_ads_plan", "google_ad_group"],
    "META_ADS": ["meta_ads_plan", "meta_ad_variant"],
    "SOCIAL_PLAN": ["social_item"],
    "TRACKING_PLAN": ["tracking_plan"],
    "BUDGET_ALLOCATION": ["budget_allocation"],
    "QUALITY_ASSURANCE": ["qa_summary"],
    "PACK_GENERATION": ["campaign_pack"],
}

OUTPUT_STAGE: dict[str, str] = {o: s for s, outs in STAGE_OUTPUTS.items() for o in outs}

PARENT_TYPE = "campaign"
MODULE = "campaigns"
