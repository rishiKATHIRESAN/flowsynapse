"""Read-side helpers: load a campaign and its current outputs for a stage."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...models.campaign import Campaign
from ...models.outputs import Output
from ...utils.errors import not_found
from .brief import BriefInput
from .constants import PARENT_TYPE


@dataclass
class OutputRef:
    id: str
    item_key: str
    position: int
    content: dict[str, Any]
    version: int
    version_id: str | None
    content_status: str | None
    is_outdated: bool
    validity: str
    is_discarded: bool


@dataclass
class CampaignCtx:
    campaign_id: str
    identifier: str
    name: str
    is_demo: bool
    content_version: int
    brief: BriefInput
    normalized: dict[str, Any] | None
    outputs: dict[str, list[OutputRef]] = field(default_factory=dict)

    def one(self, output_type: str) -> OutputRef | None:
        items = self.outputs.get(output_type) or []
        return items[0] if items else None

    def content(self, output_type: str) -> dict[str, Any] | None:
        o = self.one(output_type)
        return o.content if o else None

    def items(self, output_type: str, include_discarded: bool = False) -> list[OutputRef]:
        return [o for o in self.outputs.get(output_type, []) if include_discarded or not o.is_discarded]

    @property
    def n(self) -> dict[str, Any]:
        if self.normalized is None:
            raise RuntimeError("brief not normalized")
        return self.normalized


def get_campaign(db: Session, campaign_id: str) -> Campaign:
    c = db.get(Campaign, campaign_id)
    if c is None:
        raise not_found("Campaign", campaign_id)
    return c


def campaign_outputs(db: Session, campaign_id: str, output_type: str | None = None) -> list[Output]:
    q = select(Output).where(Output.parent_type == PARENT_TYPE, Output.parent_id == campaign_id)
    if output_type:
        q = q.where(Output.output_type == output_type)
    return list(db.execute(q.order_by(Output.output_type, Output.position, Output.item_key)).scalars())


def load_ctx(db: Session, campaign_id: str) -> CampaignCtx:
    c = get_campaign(db, campaign_id)
    ctx = CampaignCtx(
        campaign_id=c.id,
        identifier=c.identifier,
        name=c.name,
        is_demo=c.is_demo,
        content_version=c.content_version,
        brief=BriefInput.model_validate(json.loads(c.brief_original or "{}")),
        normalized=json.loads(c.brief_normalized) if c.brief_normalized else None,
    )
    for o in campaign_outputs(db, campaign_id):
        ctx.outputs.setdefault(o.output_type, []).append(
            OutputRef(o.id, o.item_key, o.position, json.loads(o.content) if o.content else {}, o.version_number,
                      o.active_version_id, o.content_status, o.is_outdated, o.validity, o.is_discarded)
        )
    return ctx
