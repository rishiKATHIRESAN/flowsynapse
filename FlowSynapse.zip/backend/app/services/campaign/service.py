"""Campaign service: create, brief edits with targeted invalidation, runs,
retries, cancellation, deletion and serialisation."""
from __future__ import annotations

import json
import secrets
from typing import Any

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ...ai.factory import selection
from ...models.campaign import Campaign, CampaignFinding, CampaignStageState
from ...models.jobs import Execution, ExecutionStage
from ...utils.clock import iso, utcnow
from ...utils.errors import AppError
from ..content import versioning
from ..jobs import engine
from ..jobs import state_machine as sm
from ..records import delete_parent_children
from .brief import BriefInput
from .constants import MODULE, PARENT_TYPE, STAGE_LABELS, STAGES
from .context import campaign_outputs, get_campaign
from .dependency_graph import Change, affected_stages, dependents, reason_text, upstream
from .normalization import normalize
from .validation import validate_brief


def _identifier() -> str:
    return f"CMP-{utcnow().strftime('%Y%m%d')}-{secrets.token_hex(3).upper()}"


def _apply_validation(c: Campaign, brief: BriefInput) -> dict[str, Any]:
    res = validate_brief(brief)
    c.validation = json.dumps(res.as_dict())
    c.brief_valid = res.ok
    if res.ok:
        n = normalize(brief)
        c.brief_normalized = json.dumps(n)
        c.assumptions = json.dumps(n["assumptions"])
    return res.as_dict()


def create_campaign(db: Session, brief_data: dict[str, Any], is_demo: bool = False, demo_key: str | None = None) -> Campaign:
    brief = BriefInput.model_validate(brief_data)
    c = Campaign(
        identifier=_identifier(),
        name=(brief.campaign_name or "Untitled campaign")[:200],
        brief_original=brief.model_dump_json(),
        is_demo=is_demo,
        demo_key=demo_key,
    )
    db.add(c)
    db.flush()
    _apply_validation(c, brief)
    for key in STAGES:
        db.add(CampaignStageState(campaign_id=c.id, stage_key=key))
    db.flush()
    return c


def changed_fields(old: BriefInput, new: BriefInput) -> set[str]:
    a, b = old.model_dump(), new.model_dump()
    return {k for k in b if a.get(k) != b.get(k)}


def mark_outdated(db: Session, campaign_id: str, stages: list[str], reason_for: Any) -> list[str]:
    """Flag current-state rows (never execution rows) and their outputs."""
    marked = []
    now = utcnow()
    for s in stages:
        st = db.get(CampaignStageState, (campaign_id, s))
        if st is None:
            st = CampaignStageState(campaign_id=campaign_id, stage_key=s)
            db.add(st)
        if st.current_stage_id is None and not st.is_outdated:
            continue  # never produced; nothing to mark
        st.is_outdated = True
        st.outdated_reason = reason_for(s)
        st.outdated_at = now
        marked.append(s)
        from .constants import STAGE_OUTPUTS

        for ot in STAGE_OUTPUTS.get(s, []):
            for o in campaign_outputs(db, campaign_id, ot):
                o.is_outdated = True
                o.outdated_reason = st.outdated_reason
    return marked


def update_brief(db: Session, c: Campaign, brief_data: dict[str, Any], expected_version: int | None) -> dict[str, Any]:
    if engine.active_execution(db, PARENT_TYPE, c.id):
        raise AppError(409, "EXECUTION_ACTIVE", "The campaign is running. Wait for it to finish or cancel it before editing the brief.")
    if expected_version is None:
        raise AppError(428, "PRECONDITION_REQUIRED", "Send If-Match with the brief_version you edited.",
                       {"current_version": c.brief_version})
    if int(expected_version) != c.brief_version:
        raise AppError(409, "VERSION_CONFLICT", f"The brief changed (now version {c.brief_version}); reload or reapply your edit.",
                       {"current_version": c.brief_version})
    old = BriefInput.model_validate(json.loads(c.brief_original or "{}"))
    new = BriefInput.model_validate(brief_data)
    fields = changed_fields(old, new)
    if not fields:
        return {"changed_fields": [], "outdated_stages": [], "validation": json.loads(c.validation or "{}")}
    c.brief_original = new.model_dump_json()
    c.name = (new.campaign_name or "Untitled campaign")[:200]
    c.brief_version += 1
    c.content_version += 1
    validation = _apply_validation(c, new)
    change = Change(fields=fields)
    outdated = mark_outdated(db, c.id, affected_stages(change), lambda s: reason_text(change, s) + f" ({iso(utcnow())})")
    return {"changed_fields": sorted(fields), "outdated_stages": outdated, "validation": validation,
            "auto_rerun": ["BRIEF_NORMALIZATION"] if validation["valid"] else []}


def stage_states(db: Session, campaign_id: str) -> dict[str, CampaignStageState]:
    rows = db.execute(select(CampaignStageState).where(CampaignStageState.campaign_id == campaign_id)).scalars().all()
    return {r.stage_key: r for r in rows}


def derived_status(db: Session, c: Campaign) -> str:
    latest = engine.latest_execution(db, PARENT_TYPE, c.id)
    if latest is not None:
        return latest.status
    return "READY" if c.brief_valid else "DRAFT"


def any_outdated(db: Session, campaign_id: str) -> list[str]:
    return [k for k, v in stage_states(db, campaign_id).items() if v.is_outdated]


def provider_info() -> engine.ProviderInfo:
    sel = selection()
    if sel.config_error:
        raise AppError(409, "PROVIDER_NOT_CONFIGURED", f"The active AI provider '{sel.provider}' is not configured: {sel.config_error}",
                       {"hint": "Fix backend/.env or choose the mock provider in Settings."})
    return engine.ProviderInfo(sel.provider, sel.model, sel.is_mock)


def start_execution(db: Session, c: Campaign) -> Execution:
    from .orchestrator import implemented_stages

    created = engine.create_execution(
        db, parent_type=PARENT_TYPE, parent_id=c.id,
        stages=[engine.StageSpec(s) for s in implemented_stages()],
        scope="FULL", provider=provider_info(), is_demo=c.is_demo, title=c.name, module=MODULE,
        params={"brief_version": c.brief_version},
    )
    return created.execution


def _latest_terminal(db: Session, c: Campaign) -> Execution | None:
    ex = engine.latest_execution(db, PARENT_TYPE, c.id)
    return ex


def rerun_stages(db: Session, c: Campaign, stages: set[str], scope: str, prev: Execution | None = None) -> Execution:
    """New execution re-running ``stages`` plus their dependents and QA/pack;
    everything still current is carried forward (2.3)."""
    if engine.active_execution(db, PARENT_TYPE, c.id):
        raise AppError(409, "EXECUTION_ALREADY_ACTIVE", "An execution is already active for this campaign.")
    prev = prev or _latest_terminal(db, c)
    if prev is None:
        raise AppError(409, "NO_PREVIOUS_RUN", "Run the campaign first.")
    states = stage_states(db, c.id)
    outdated = {k for k, v in states.items() if v.is_outdated}
    # refuse a stage whose upstream stages are not current (unless they are also being re-run)
    for s in stages:
        stale_up = [u for u in upstream(s) if u in outdated and u not in stages]
        if stale_up:
            raise AppError(409, "UPSTREAM_OUTDATED",
                           f"{STAGE_LABELS[s]} depends on outdated stage(s): {', '.join(STAGE_LABELS[u] for u in stale_up)}. Regenerate those first.",
                           {"stage": s, "outdated_upstream": stale_up})
    rerun: set[str] = set(stages)
    for s in stages:
        rerun |= set(dependents(s))
    rerun |= {"QUALITY_ASSURANCE", "PACK_GENERATION"} & set(STAGES)
    from .orchestrator import implemented_stages

    impl = implemented_stages()
    rerun = {s for s in rerun if s in impl}
    prev_keys = {st.stage_key for st in prev.stages}
    extra = [engine.StageSpec(s) for s in impl if s not in prev_keys]
    created = engine.create_retry_execution(
        db, prev, rerun={(s, "") for s in rerun}, scope=scope, provider=provider_info(),
        extra_stages=extra, title=c.name, module=MODULE, params={"requested_stages": sorted(stages)},
    )
    return created.execution


def retry_stage(db: Session, c: Campaign, execution_id: str, stage_key: str) -> Execution:
    prev = engine.load_execution(db, execution_id, PARENT_TYPE, c.id)
    if prev.status not in sm.TERMINAL_EXECUTION_STATES:
        raise AppError(409, "EXECUTION_ALREADY_ACTIVE", "The execution is still active.")
    st = next((s for s in prev.stages if s.stage_key == stage_key), None)
    if st is None:
        raise AppError(404, "NOT_FOUND", f"Stage {stage_key} is not part of this execution")
    if st.status in sm.DONE_STAGE_STATES and not stage_states(db, c.id).get(stage_key, CampaignStageState()).is_outdated:
        raise AppError(409, "STAGE_NOT_FAILED", f"{STAGE_LABELS[stage_key]} completed and is current; use regenerate to replace its output.")
    if st.status == sm.FAILED and st.retryable is False:
        raise AppError(409, "NOT_RETRYABLE", f"{STAGE_LABELS[stage_key]} failed with a non-retryable error: {st.error_message}",
                       {"hint": "Change the inputs or the provider, then run again."})
    return rerun_stages(db, c, {stage_key}, "STAGE_RETRY", prev)


def regenerate_stage(db: Session, c: Campaign, stage_key: str) -> Execution:
    if stage_key not in STAGES[2:]:
        raise AppError(422, "VALIDATION_ERROR", f"{stage_key} cannot be regenerated individually")
    return rerun_stages(db, c, {stage_key}, "STAGE_REGENERATE")


def delete_campaign(db: Session, c: Campaign) -> list[str]:
    if engine.active_execution(db, PARENT_TYPE, c.id):
        raise AppError(409, "EXECUTION_ACTIVE", "Cancel the running execution before deleting the campaign.")
    files = delete_parent_children(db, PARENT_TYPE, c.id)
    db.delete(c)
    return files


# ---------------------------------------------------------------------------
# Serialisation
# ---------------------------------------------------------------------------

def summary(db: Session, c: Campaign) -> dict[str, Any]:
    latest = engine.latest_execution(db, PARENT_TYPE, c.id)
    brief = json.loads(c.brief_original or "{}")
    return {
        "id": c.id,
        "identifier": c.identifier,
        "name": c.name,
        "status": derived_status(db, c),
        "business_name": brief.get("business_name"),
        "is_demo": c.is_demo,
        "brief_valid": c.brief_valid,
        "content_version": c.content_version,
        "provider": latest.provider if latest else None,
        "is_mock": latest.is_mock if latest else None,
        "latest_execution_id": latest.id if latest else None,
        "outdated_stages": any_outdated(db, c.id),
        "created_at": iso(c.created_at),
        "updated_at": iso(c.updated_at),
    }


def detail(db: Session, c: Campaign) -> dict[str, Any]:
    d = summary(db, c)
    states = stage_states(db, c.id)
    d.update(
        brief=json.loads(c.brief_original or "{}"),
        brief_version=c.brief_version,
        normalized_brief=json.loads(c.brief_normalized) if c.brief_normalized else None,
        assumptions=json.loads(c.assumptions) if c.assumptions else [],
        validation=json.loads(c.validation) if c.validation else None,
        website_context=json.loads(c.website_context) if c.website_context else None,
        stage_states={
            k: {"is_outdated": v.is_outdated, "outdated_reason": v.outdated_reason, "outdated_at": iso(v.outdated_at),
                "completed_at": iso(v.completed_at), "current_stage_id": v.current_stage_id}
            for k, v in states.items()
        },
        stage_labels=STAGE_LABELS,
        stages=STAGES,
    )
    latest = engine.latest_execution(db, PARENT_TYPE, c.id)
    d["latest_execution"] = engine.execution_to_dict(latest) if latest else None
    d["healthcare_disclaimer"] = None
    if d["normalized_brief"] and d["normalized_brief"].get("is_healthcare"):
        from ..content.health_claims import disclaimer

        d["healthcare_disclaimer"] = disclaimer()
    return d


def outputs_payload(db: Session, c: Campaign, output_type: str | None = None, versions: bool = False) -> list[dict[str, Any]]:
    return [versioning.output_to_dict(db, o, include_versions=versions) for o in campaign_outputs(db, c.id, output_type)]


def list_campaigns(db: Session, *, limit: int, offset: int, q: str | None, status: str | None, demo: str) -> dict[str, Any]:
    query = select(Campaign)
    if q:
        like = f"%{q.strip()}%"
        query = query.where(or_(Campaign.name.ilike(like), Campaign.identifier.ilike(like), Campaign.brief_original.ilike(like)))
    if demo == "mine":
        query = query.where(Campaign.is_demo.is_(False))
    elif demo == "demo":
        query = query.where(Campaign.is_demo.is_(True))
    rows = db.execute(query.order_by(Campaign.updated_at.desc())).scalars().all()
    items = [summary(db, c) for c in rows]
    if status:
        items = [i for i in items if i["status"] == status]
    total = len(items)
    return {"items": items[offset: offset + limit], "total": total, "limit": limit, "offset": offset}


def stage_detail(db: Session, c: Campaign, stage_key: str) -> dict[str, Any]:
    from .constants import STAGE_OUTPUTS

    if stage_key not in STAGES:
        raise AppError(404, "NOT_FOUND", f"Unknown stage {stage_key}")
    st = stage_states(db, c.id).get(stage_key)
    stage_row = db.get(ExecutionStage, st.current_stage_id) if st and st.current_stage_id else None
    outputs = []
    for ot in STAGE_OUTPUTS.get(stage_key, []):
        outputs += outputs_payload(db, c, ot)
    data: dict[str, Any] = {
        "stage_key": stage_key,
        "label": STAGE_LABELS[stage_key],
        "is_outdated": bool(st and st.is_outdated),
        "outdated_reason": st.outdated_reason if st else None,
        "last_completed": engine.stage_to_dict(stage_row) if stage_row else None,
        "output_ref": json.loads(stage_row.output_ref) if stage_row and stage_row.output_ref else None,
        "outputs": outputs,
    }
    if stage_key == "INPUT_VALIDATION":
        data["validation"] = json.loads(c.validation) if c.validation else None
    if stage_key == "BRIEF_NORMALIZATION":
        data["original_brief"] = json.loads(c.brief_original)
        data["normalized_brief"] = json.loads(c.brief_normalized) if c.brief_normalized else None
    if stage_key == "QUALITY_ASSURANCE":
        data["findings"] = findings_payload(db, c)
    return data


def findings_payload(db: Session, c: Campaign) -> list[dict[str, Any]]:
    rows = db.execute(select(CampaignFinding).where(CampaignFinding.campaign_id == c.id)
                      .order_by(CampaignFinding.blocks_completion.desc(), CampaignFinding.severity, CampaignFinding.rule_id)).scalars().all()
    return [{"id": r.id, "rule_id": r.rule_id, "severity": r.severity, "category": r.category, "description": r.description,
             "evidence": r.evidence, "field": r.field, "recommended_correction": r.recommended_correction,
             "blocks_completion": r.blocks_completion, "source": r.source, "execution_id": r.execution_id} for r in rows]


def counts(db: Session, include_demo: bool) -> dict[str, Any]:
    q = select(Campaign)
    if not include_demo:
        q = q.where(Campaign.is_demo.is_(False))
    rows = db.execute(q).scalars().all()
    by: dict[str, int] = {}
    for c in rows:
        s = derived_status(db, c)
        by[s] = by.get(s, 0) + 1
    return {"total": len(rows), "by_status": by}

