"""Campaign job handler: dispatches stages through the shared job engine."""
from __future__ import annotations

from typing import Any

from sqlalchemy.orm import Session

from ...database import new_session
from ...models.campaign import Campaign, CampaignStageState
from ...utils.clock import utcnow
from ..jobs.registry import BaseHandler, StageContext, StageOutcome, register
from . import stages as stage_registry
from .constants import MODULE, PARENT_TYPE
from .context import load_ctx

# Importing registers each stage implementation.
from .stages import objective, validation_stages  # noqa: F401,E402


def implemented_stages() -> list[str]:
    from .constants import STAGES

    return [s for s in STAGES if s in stage_registry.REGISTRY]


class CampaignHandler(BaseHandler):
    parent_type = PARENT_TYPE
    module = MODULE

    def run_stage(self, ctx: StageContext) -> Any:
        with new_session() as db:
            c = load_ctx(db, ctx.parent_id)
        return stage_registry.REGISTRY[ctx.stage_key].run(ctx, c)

    def commit_stage(self, db: Session, ctx: StageContext, result: Any) -> StageOutcome:
        c = load_ctx(db, ctx.parent_id)
        outcome = stage_registry.REGISTRY[ctx.stage_key].commit(db, ctx, c, result)
        st = db.get(CampaignStageState, (ctx.parent_id, ctx.stage_key))
        if st is None:
            st = CampaignStageState(campaign_id=ctx.parent_id, stage_key=ctx.stage_key)
            db.add(st)
        st.is_outdated = False
        st.outdated_reason = None
        st.outdated_at = None
        st.current_stage_id = ctx.stage_id
        st.completed_at = utcnow()
        camp = db.get(Campaign, ctx.parent_id)
        if camp is not None:
            camp.content_version += 1
        return outcome

    def finalize(self, db: Session, execution_id: str, final_status: str) -> list[str]:
        from .finalize import finalize_campaign

        return finalize_campaign(db, execution_id, final_status)

    def title(self, db: Session, parent_id: str) -> str:
        c = db.get(Campaign, parent_id)
        return c.name if c else parent_id


register(CampaignHandler())
