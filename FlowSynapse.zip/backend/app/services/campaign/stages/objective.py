"""Stage 3 - OBJECTIVE_ANALYSIS (AI, schema-validated)."""
from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from ....ai.mock_provider import register_mock
from ...jobs.registry import StageContext, StageOutcome
from ..context import CampaignCtx
from . import register
from .common import brief_facts, require_normalized, save, strip_demo

Source = Literal["user_provided", "generated_suggestion", "assumption"]


class Tagged(BaseModel):
    text: str = Field(min_length=1, max_length=1500)
    source: Source


class ObjectiveAnalysis(BaseModel):
    primary_business_objective: Tagged
    marketing_objective: Tagged
    desired_conversion_action: Tagged
    target_service: Tagged
    geographic_scope: Tagged
    audience_characteristics: list[Tagged] = Field(min_length=1, max_length=12)
    audience_needs: list[Tagged] = Field(min_length=1, max_length=12)
    main_messaging_opportunity: Tagged
    constraints: list[Tagged] = Field(default_factory=list, max_length=20)
    missing_information: list[Tagged] = Field(default_factory=list, max_length=20)
    assumptions_needing_review: list[Tagged] = Field(default_factory=list, max_length=20)


INSTRUCTIONS = (
    "Analyse the campaign brief. Return the primary business objective, marketing objective, desired conversion "
    "action, target service, geographic scope, audience characteristics and needs, main messaging opportunity, "
    "constraints, missing information and assumptions needing review. Tag every item with source: user_provided "
    "(stated in the brief), generated_suggestion (your proposal) or assumption (not supplied; must be reviewed)."
)


# Only the inputs the dependency graph declares for this stage (5.5).
OBJECTIVE_KEYS = (
    "business_name", "industry", "description", "location", "service_areas", "primary_service", "secondary_services",
    "value_proposition", "brand_messaging", "objective", "primary_conversion_goal", "secondary_goals", "language",
    "tone", "competitors", "target_geography", "age_range", "audience_description", "needs_interests", "problems",
    "intent", "exclusions", "offer_details", "approved_claims", "prohibited_claims", "brand_guidelines",
    "additional_instructions", "is_healthcare",
)


def _t(text: str, source: str) -> dict[str, str]:
    return {"text": text, "source": source}


@register_mock("OBJECTIVE_ANALYSIS")
def mock_objective(d: dict[str, Any]) -> dict[str, Any]:
    svc = d["primary_service"]
    geo = d["target_geography"] or d["location"]
    audience = d["audience_description"]
    constraints = [_t(f"Prohibited claim: {c}", "user_provided") for c in d["prohibited_claims"]]
    constraints.append(_t("Paid-media budget and dates are fixed by the brief (handled by the budget and calendar stages)",
                          "user_provided"))
    if d["is_healthcare"]:
        constraints.append(_t("Healthcare advertising: platform policies and local regulations must be reviewed; no outcome guarantees",
                              "generated_suggestion"))
    missing = []
    for key, label in (("age_range", "Audience age range"), ("needs_interests", "Audience needs/interests"),
                       ("competitors", "Competitors"), ("value_proposition", "Value proposition")):
        if not d.get(key):
            missing.append(_t(f"{label} not supplied", "assumption"))
    assumptions = []
    for key in ("description", "value_proposition", "offer_details"):
        v = d.get(key) or ""
        if v.upper().startswith("DEMO ASSUMPTION"):
            assumptions.append(_t(f"{key.replace('_', ' ').capitalize()}: {strip_demo(v)}", "assumption"))
    needs = [_t(f"Clear information about {svc.lower()} and how to take the next step", "generated_suggestion")]
    if d.get("needs_interests"):
        needs.insert(0, _t(d["needs_interests"], "user_provided"))
    if d.get("problems"):
        needs.append(_t(d["problems"], "user_provided"))
    return {
        "primary_business_objective": _t(d["objective"], "user_provided"),
        "marketing_objective": _t(f"Drive qualified {d['primary_conversion_goal'].lower()} for {svc} within {geo}", "generated_suggestion"),
        "desired_conversion_action": _t(d["primary_conversion_goal"], "user_provided"),
        "target_service": _t(svc, "user_provided"),
        "geographic_scope": _t(geo, "user_provided"),
        "audience_characteristics": [_t(audience, "user_provided")] + (
            [_t(f"Age range: {d['age_range']}", "user_provided")] if d.get("age_range") else [_t("Adults (age range not supplied)", "assumption")]),
        "audience_needs": needs,
        "main_messaging_opportunity": _t(
            f"{strip_demo(d.get('value_proposition')) or 'Convenient access to ' + svc} - leading to {d['primary_conversion_goal'].lower()}",
            "generated_suggestion"),
        "constraints": constraints,
        "missing_information": missing,
        "assumptions_needing_review": assumptions,
    }


class ObjectiveStage:
    key = "OBJECTIVE_ANALYSIS"

    def run(self, ctx: StageContext, c: CampaignCtx) -> Any:
        n = require_normalized(c)
        facts = brief_facts(n)
        data = {k: facts[k] for k in OBJECTIVE_KEYS}
        ctx.input_snapshot = {"brief_content_version": c.content_version}
        assert ctx.ai is not None
        return ctx.ai.generate("OBJECTIVE_ANALYSIS", ObjectiveAnalysis, data, INSTRUCTIONS).model_dump()

    def commit(self, db: Session, ctx: StageContext, c: CampaignCtx, result: Any) -> StageOutcome:
        vid = save(db, ctx, c, "objective_analysis", result)
        return StageOutcome(output_ref={"output_versions": [vid]})


register(ObjectiveStage())
