"""Stages 1 (INPUT_VALIDATION) and 2 (BRIEF_NORMALIZATION) - deterministic."""
from __future__ import annotations

import json
from typing import Any

from sqlalchemy.orm import Session

from ....models.campaign import Campaign
from ...jobs.errors import StageError
from ...jobs.registry import StageContext, StageOutcome
from ..context import CampaignCtx
from ..normalization import normalize
from ..validation import validate_brief
from . import register


class InputValidation:
    key = "INPUT_VALIDATION"

    def run(self, ctx: StageContext, c: CampaignCtx) -> Any:
        ctx.provider, ctx.model, ctx.is_mock = "rules", "deterministic", False
        ctx.input_snapshot = {"brief_content_version": c.content_version}
        res = validate_brief(c.brief)
        if not res.ok:
            fields = ", ".join(sorted({e["field"] for e in res.errors}))
            raise StageError("BRIEF_INVALID", f"The brief has {len(res.errors)} blocking validation error(s) ({fields}).",
                             False, "Fix the highlighted fields in the brief, then run again.")
        return res.as_dict()

    def commit(self, db: Session, ctx: StageContext, c: CampaignCtx, result: Any) -> StageOutcome:
        camp = db.get(Campaign, c.campaign_id)
        if camp is not None:
            camp.validation = json.dumps(result)
            camp.brief_valid = True
        return StageOutcome(output_ref={"validation": result},
                            warnings=[w["message"] for w in result["warnings"]])


class BriefNormalization:
    key = "BRIEF_NORMALIZATION"

    def run(self, ctx: StageContext, c: CampaignCtx) -> Any:
        ctx.provider, ctx.model, ctx.is_mock = "rules", "deterministic", False
        ctx.input_snapshot = {"brief_content_version": c.content_version}
        return normalize(c.brief)

    def commit(self, db: Session, ctx: StageContext, c: CampaignCtx, result: Any) -> StageOutcome:
        camp = db.get(Campaign, c.campaign_id)
        if camp is not None:
            camp.brief_normalized = json.dumps(result)
            camp.assumptions = json.dumps(result["assumptions"])
        return StageOutcome(output_ref={"normalized_brief_content_version": c.content_version,
                                        "duration_days": result["campaign"]["duration_days"],
                                        "assumptions": len(result["assumptions"])})


register(InputValidation())
register(BriefNormalization())
