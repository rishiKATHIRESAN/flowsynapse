"""One module per campaign stage. Each exposes a ``Stage`` with ``run`` (compute,
no DB writes) and ``commit`` (persist outputs in the stage's commit transaction)."""
from __future__ import annotations

from typing import Any, Protocol

from sqlalchemy.orm import Session

from ...jobs.registry import StageContext, StageOutcome
from ..context import CampaignCtx


class CampaignStage(Protocol):
    key: str

    def run(self, ctx: StageContext, c: CampaignCtx) -> Any: ...

    def commit(self, db: Session, ctx: StageContext, c: CampaignCtx, result: Any) -> StageOutcome: ...


REGISTRY: dict[str, CampaignStage] = {}


def register(stage: CampaignStage) -> CampaignStage:
    REGISTRY[stage.key] = stage
    return stage
