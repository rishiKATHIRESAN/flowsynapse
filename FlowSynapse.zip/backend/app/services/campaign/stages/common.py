"""Helpers shared by campaign stage implementations."""
from __future__ import annotations

from typing import Any

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from ....models.outputs import Output
from ...content.versioning import Provenance, upsert_generated
from ...jobs.errors import StageError
from ...jobs.registry import StageContext
from ..constants import PARENT_TYPE
from ..context import CampaignCtx


def provenance(ctx: StageContext, c: CampaignCtx, item_id: str | None = None) -> Provenance:
    p = ctx.ai.provenance() if ctx.ai else {}
    return Provenance(
        provider=p.get("provider") or "mock",
        model=p.get("model"),
        is_mock=bool(p.get("is_mock", True)),
        execution_id=ctx.execution_id,
        stage_key=ctx.stage_key,
        item_id=item_id,
        source_input_version=f"campaign_content_v{c.content_version}",
    )


def save(
    db: Session,
    ctx: StageContext,
    c: CampaignCtx,
    output_type: str,
    content: Any,
    *,
    item_key: str = "",
    position: int = 0,
    content_status: str | None = None,
    validity: str = "VALID",
    validity_details: Any = None,
    prov: Provenance | None = None,
) -> str:
    out, v = upsert_generated(
        db,
        parent_type=PARENT_TYPE,
        parent_id=c.campaign_id,
        output_type=output_type,
        content=content,
        prov=prov or provenance(ctx, c, item_key or None),
        item_key=item_key,
        position=position,
        content_status=content_status,
        is_demo=c.is_demo,
        validity=validity,
        validity_details=validity_details,
    )
    return v.id if v else (out.active_version_id or "")


def retire_missing(db: Session, campaign_id: str, output_type: str, keep_keys: set[str]) -> None:
    """Items no longer produced by a regeneration are marked discarded (kept for history)."""
    db.execute(
        update(Output)
        .where(Output.parent_type == PARENT_TYPE, Output.parent_id == campaign_id,
               Output.output_type == output_type, Output.item_key.not_in(keep_keys))
        .values(is_discarded=True)
        .execution_options(synchronize_session=False)
    )


def existing_keys(db: Session, campaign_id: str, output_type: str) -> list[str]:
    return list(db.execute(select(Output.item_key).where(
        Output.parent_type == PARENT_TYPE, Output.parent_id == campaign_id, Output.output_type == output_type)).scalars())


def require_normalized(c: CampaignCtx) -> dict[str, Any]:
    if c.normalized is None:
        raise StageError("BRIEF_NOT_NORMALIZED", "The brief has not been validated and normalized.", False,
                         "Fix the brief validation errors and run again.")
    return c.normalized


def require_output(c: CampaignCtx, output_type: str, stage_label: str) -> dict[str, Any]:
    o = c.one(output_type)
    if o is None:
        raise StageError("UPSTREAM_MISSING", f"{stage_label} output is missing.", False, f"Run the {stage_label} stage first.")
    return o.content


def brief_facts(n: dict[str, Any]) -> dict[str, Any]:
    """Compact, factual subset of the normalized brief passed to AI prompts."""
    b, cp, a, o = n["business"], n["campaign"], n["audience"], n["offer"]
    return {
        "business_name": b["name"], "industry": b["industry"], "description": b["description"],
        "location": b["location"]["original"], "service_areas": b["service_areas"], "primary_service": b["primary_service"],
        "secondary_services": b["secondary_services"], "value_proposition": b["value_proposition"],
        "brand_messaging": b["brand_messaging"], "campaign_name": cp["name"], "objective": cp["objective"],
        "primary_conversion_goal": cp["primary_conversion_goal"], "secondary_goals": cp["secondary_goals"],
        "start_date": cp["start_date"], "end_date": cp["end_date"], "duration_days": cp["duration_days"],
        "paid_channels": cp["paid_channels"], "organic_channels": cp["organic_channels"], "language": cp["language"],
        "tone": cp["tone"], "competitors": cp["competitors"], "target_geography": a["target_geography"],
        "age_range": a["age_range"], "audience_description": a["description"], "needs_interests": a["needs_interests"],
        "problems": a["problems"], "intent": a["intent"], "exclusions": a["exclusions"], "offer_details": o["details"],
        "landing_page_url": o["landing_page_url"], "call_to_action": o["call_to_action"], "contact_method": o["contact_method"],
        "approved_claims": o["approved_claims"], "prohibited_claims": o["prohibited_claims"],
        "brand_guidelines": o["brand_guidelines"], "additional_instructions": o["additional_instructions"],
        "is_healthcare": n["is_healthcare"],
    }


def strip_demo(text: str | None) -> str:
    if not text:
        return ""
    t = text.strip()
    if t.upper().startswith("DEMO ASSUMPTION:"):
        t = t[len("DEMO ASSUMPTION:"):].strip()
    return t
