"""Campaign exports: datasets (CSV/XLSX) and the campaign pack PDF.

All content comes from stored, latest-edited data read in one snapshot
transaction; amounts are read from the stored rows and never recomputed.
"""
from __future__ import annotations

import json
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...models.campaign import Campaign, CampaignFinding, CampaignStageState
from ...models.exports import FileExport
from ...models.outputs import Output, OutputVersion
from ...utils.errors import AppError
from ..reporting.document import DEMO_BANNER, MOCK_BANNER, STALE_BANNER, Dataset, ExportData
from ..reporting.lifecycle import generate_export
from .constants import MODULE, PARENT_TYPE, STAGE_LABELS


def _outputs(db: Session, cid: str) -> dict[str, list[Output]]:
    rows = db.execute(select(Output).where(Output.parent_type == PARENT_TYPE, Output.parent_id == cid,
                                           Output.is_discarded.is_(False))
                      .order_by(Output.output_type, Output.position, Output.item_key)).scalars().all()
    out: dict[str, list[Output]] = {}
    for r in rows:
        out.setdefault(r.output_type, []).append(r)
    return out


def _origin_label(db: Session, o: Output) -> str:
    v = db.get(OutputVersion, o.active_version_id) if o.active_version_id else None
    if v is None:
        return ""
    if v.origin == "MANUALLY_EDITED":
        orig = db.get(OutputVersion, v.original_generation_version_id) if v.original_generation_version_id else None
        base = "Mock-generated" if (orig and orig.is_mock) else "AI-generated"
        return f"{base}, edited by you"
    return "Mock-generated" if v.is_mock else f"AI-generated ({v.provider})"


def collect(db: Session, campaign_id: str, allow_stale: bool, for_format: str) -> ExportData:
    from .pack import build_pack_doc, pack_datasets

    c = db.get(Campaign, campaign_id)
    if c is None:
        raise AppError(404, "NOT_FOUND", f"Campaign {campaign_id} not found")
    states = db.execute(select(CampaignStageState).where(CampaignStageState.campaign_id == campaign_id)).scalars().all()
    stale = [s.stage_key for s in states if s.is_outdated]
    if stale and not allow_stale:
        raise AppError(409, "STALE_OUTPUTS",
                       "Export blocked: some outputs are outdated (" + ", ".join(STAGE_LABELS[s] for s in stale)
                       + "). Regenerate them, or export with allow_stale=true to get a file marked STALE.",
                       {"outdated_stages": stale})
    blockers = db.execute(select(CampaignFinding).where(CampaignFinding.campaign_id == campaign_id,
                                                        CampaignFinding.blocks_completion.is_(True))).scalars().all()
    if blockers and for_format in ("pdf", "xlsx", "zip"):
        raise AppError(409, "BLOCKING_FINDINGS",
                       f"Export blocked by {len(blockers)} blocking QA finding(s). Fix them and re-run QA.",
                       {"findings": [b.description for b in blockers][:20]})
    outs = _outputs(db, campaign_id)
    labels = []
    if c.is_demo:
        labels.append(DEMO_BANNER)
    if any(db.get(OutputVersion, o.active_version_id).is_mock for lst in outs.values() for o in lst
           if o.active_version_id and db.get(OutputVersion, o.active_version_id)):
        labels.append(MOCK_BANNER)
    if stale:
        labels.append(STALE_BANNER)
    datasets = pack_datasets(db, c, outs, _origin_label)
    doc = build_pack_doc(db, c, outs, _origin_label, labels) if for_format == "pdf" else None
    source_versions = {f"{o.output_type}:{o.item_key}": o.active_version_id for lst in outs.values() for o in lst}
    return ExportData(
        doc=doc,
        datasets=datasets,
        download_base=f"{c.identifier}_{c.name}",
        source_version=str(c.content_version),
        source_versions=source_versions,
        is_demo=c.is_demo,
        is_stale=bool(stale),
        labels=labels,
    )


def export_campaign(campaign_id: str, fmt: str, dataset: str | None = None, allow_stale: bool = False) -> FileExport:
    return generate_export(
        module=MODULE, parent_type=PARENT_TYPE, parent_id=campaign_id, fmt=fmt, dataset=dataset,
        collect=lambda db: collect(db, campaign_id, allow_stale, fmt),
    )


def dataset_names(datasets: list[Dataset]) -> list[str]:
    return [d.name for d in datasets]


def _j(v: Any) -> str:
    return json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else ("" if v is None else str(v))
