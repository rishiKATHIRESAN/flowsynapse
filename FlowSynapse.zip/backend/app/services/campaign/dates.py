"""Date and duration semantics (master prompt 5.7).

Start and end dates are inclusive: ``duration_days = (end - start).days + 1``.
The user supplies end date or duration (or both); a missing one is derived; a
conflict is a field-level error on both fields. ``duration_days`` is the single
source of truth used everywhere else.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, timedelta

from ...utils.clock import local_today

MAX_DURATION_DAYS = 365
_ISO = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class DateError(ValueError):
    pass


def parse_iso_date(value: object) -> date:
    if isinstance(value, date):
        return value
    if not isinstance(value, str) or not _ISO.match(value.strip()):
        raise DateError("must be an ISO calendar date (YYYY-MM-DD)")
    try:
        return date.fromisoformat(value.strip())
    except ValueError:
        raise DateError("is not a valid calendar date") from None


def inclusive_days(start: date, end: date) -> int:
    return (end - start).days + 1


@dataclass
class Period:
    start: date | None = None
    end: date | None = None
    duration_days: int | None = None
    errors: list[dict[str, str]] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors and self.start is not None and self.end is not None


def _err(fieldname: str, code: str, message: str) -> dict[str, str]:
    return {"field": fieldname, "code": code, "message": message}


def resolve_period(
    start: object,
    end: object = None,
    duration: object = None,
    *,
    start_field: str = "start_date",
    end_field: str = "end_date",
    duration_field: str = "duration_days",
    max_days: int = MAX_DURATION_DAYS,
) -> Period:
    """Validate and derive the period without ever changing submitted values."""
    p = Period()
    blank = lambda v: v is None or (isinstance(v, str) and not v.strip())  # noqa: E731
    if blank(start):
        p.errors.append(_err(start_field, "REQUIRED", "Start date is required"))
    else:
        try:
            p.start = parse_iso_date(start)
        except DateError as e:
            p.errors.append(_err(start_field, "INVALID_DATE", f"Start date {e}"))
    if not blank(end):
        try:
            p.end = parse_iso_date(end)
        except DateError as e:
            p.errors.append(_err(end_field, "INVALID_DATE", f"End date {e}"))
    if not blank(duration):
        try:
            d = int(str(duration).strip())
            if str(duration).strip() != str(d):
                raise ValueError
            if d < 1:
                p.errors.append(_err(duration_field, "INVALID_DURATION", "Duration must be at least 1 day"))
            elif d > max_days:
                p.errors.append(_err(duration_field, "DURATION_TOO_LONG", f"Duration must be at most {max_days} days"))
            else:
                p.duration_days = d
        except (TypeError, ValueError):
            p.errors.append(_err(duration_field, "INVALID_DURATION", "Duration must be a whole number of days"))
    if blank(end) and blank(duration):
        p.errors.append(_err(end_field, "REQUIRED", "Provide an end date or a duration"))
        p.errors.append(_err(duration_field, "REQUIRED", "Provide an end date or a duration"))
    if p.errors or p.start is None:
        return p
    if p.end is not None and p.end < p.start:
        p.errors.append(_err(end_field, "END_BEFORE_START", "End date is before the start date"))
        return p
    if p.end is not None and p.duration_days is not None:
        if inclusive_days(p.start, p.end) != p.duration_days:
            msg = (f"Dates give {inclusive_days(p.start, p.end)} days (inclusive) but duration is "
                   f"{p.duration_days}; change one so they agree")
            p.errors.append(_err(end_field, "DURATION_DATE_MISMATCH", msg))
            p.errors.append(_err(duration_field, "DURATION_DATE_MISMATCH", msg))
            return p
    elif p.end is not None:
        p.duration_days = inclusive_days(p.start, p.end)
    elif p.duration_days is not None:
        p.end = p.start + timedelta(days=p.duration_days - 1)
    if p.duration_days is not None and p.duration_days > max_days:
        p.errors.append(_err(end_field, "DURATION_TOO_LONG", f"Campaigns can last at most {max_days} days"))
    return p


def next_monday(today: date | None = None) -> date:
    """Next Monday strictly after ``today`` (APP_TIMEZONE)."""
    today = today or local_today()
    days = (7 - today.weekday()) % 7 or 7
    return today + timedelta(days=days)


def demo_period(today: date | None = None) -> tuple[date, date]:
    start = next_monday(today)
    return start, start + timedelta(days=13)
