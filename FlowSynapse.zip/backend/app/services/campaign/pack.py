"""Campaign pack: datasets for XLSX/CSV and the PDF document (5.3 stage 12).

Built only from stored, latest-edited data. Sections for stages not yet run
say so explicitly instead of inventing content.
"""
from __future__ import annotations

import json
from typing import Any, Callable

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...models.campaign import Campaign, CampaignFinding
from ...models.outputs import Output
from ..reporting.document import Bullets, Dataset, Paragraph, ReportDoc, Section, Table
from .brief import FIELD_LABELS

OriginFn = Callable[[Session, Output], str]


def _c(o: Output) -> dict[str, Any]:
    return json.loads(o.content) if o.content else {}


def _s(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, dict) and "text" in v and "source" in v:
        return f"{v['text']} [{v['source']}]"
    if isinstance(v, list):
        return "; ".join(_s(x) for x in v)
    if isinstance(v, dict):
        return "; ".join(f"{k}: {_s(x)}" for k, x in v.items())
    return str(v)


def brief_rows(c: Campaign) -> list[list[Any]]:
    original = json.loads(c.brief_original or "{}")
    rows = []
    for k, v in original.items():
        rows.append([FIELD_LABELS.get(k, k), _s(v)])
    return rows


def normalized_rows(c: Campaign) -> list[list[Any]]:
    n = json.loads(c.brief_normalized) if c.brief_normalized else {}
    rows: list[list[Any]] = []
    for section in ("business", "campaign", "audience", "offer"):
        for k, v in (n.get(section) or {}).items():
            rows.append([section, k, _s(v)])
    if n:
        rows.append(["flags", "is_healthcare", str(n.get("is_healthcare"))])
    return rows


def assumption_rows(c: Campaign) -> list[list[Any]]:
    return [[a.get("field"), a.get("value"), a.get("source"), a.get("note")] for a in json.loads(c.assumptions or "[]")]


def objective_rows(outs: dict[str, list[Output]]) -> list[list[Any]]:
    o = (outs.get("objective_analysis") or [None])[0]
    if o is None:
        return []
    rows = []
    for k, v in _c(o).items():
        items = v if isinstance(v, list) else [v]
        for it in items:
            rows.append([k, it.get("text") if isinstance(it, dict) else _s(it), it.get("source") if isinstance(it, dict) else ""])
    return rows


def pack_datasets(db: Session, c: Campaign, outs: dict[str, list[Output]], origin: OriginFn) -> list[Dataset]:
    from . import pack_sections

    ds = [
        Dataset("Summary", ["Field", "Value"], [["Campaign", c.name], ["Identifier", c.identifier],
                                                ["Content version", str(c.content_version)],
                                                ["Demonstration data", "yes" if c.is_demo else "no"]]),
        Dataset("Brief", ["Field", "Value"], brief_rows(c)),
        Dataset("Normalized Brief", ["Section", "Field", "Value"], normalized_rows(c)),
        Dataset("Objectives", ["Item", "Text", "Source"], objective_rows(outs)),
    ]
    ds += pack_sections.extra_datasets(db, c, outs, origin)
    findings = db.execute(select(CampaignFinding).where(CampaignFinding.campaign_id == c.id)).scalars().all()
    ds.append(Dataset("QA Findings", ["Severity", "Rule", "Category", "Description", "Field", "Recommended correction", "Blocks"],
                      [[f.severity, f.rule_id, f.category, f.description, f.field or "", f.recommended_correction or "",
                        "yes" if f.blocks_completion else "no"] for f in findings]))
    ds.append(Dataset("Assumptions", ["Field", "Value", "Source", "Note"], assumption_rows(c)))
    return ds


def build_pack_doc(db: Session, c: Campaign, outs: dict[str, list[Output]], origin: OriginFn, labels: list[str]) -> ReportDoc:
    from . import pack_sections

    n = json.loads(c.brief_normalized) if c.brief_normalized else {}
    camp = n.get("campaign", {})
    doc = ReportDoc(
        title=f"Campaign Pack - {c.name}",
        subtitle=f"{(n.get('business') or {}).get('name') or ''}",
        identifier=c.identifier,
        labels=labels,
        meta=[("Campaign ID", c.id), ("Period", f"{camp.get('start_date')} to {camp.get('end_date')} ({camp.get('duration_days')} days)"),
              ("Content version", str(c.content_version)),
              ("Note", "Proposals only: no ad-platform upload, no publishing, no live-account data. Generated content is never described as compliant.")],
    )
    sec = doc.sections
    sec.append(Section("1. Executive summary", pack_sections.executive_summary(c, n, outs)))
    sec.append(Section("2. Original brief", [Table(["Field", "Value"], brief_rows(c), [1, 3])]))
    sec.append(Section("3. Normalized brief", [Table(["Section", "Field", "Value"], normalized_rows(c), [1, 1.4, 3])]))
    obj = objective_rows(outs)
    sec.append(Section("4. Objectives", [Table(["Item", "Text", "Source"], obj, [1.2, 3, 1])] if obj
                       else [Paragraph("Objective analysis has not been generated yet.", "note")]))
    sec.extend(pack_sections.middle_sections(db, c, n, outs, origin))
    sec.append(Section("14. Assumptions & limitations", [
        Table(["Field", "Value", "Source", "Note"], assumption_rows(c), [1, 2, 1, 2]),
        Bullets([
            "Mock output is deterministic template output, not real AI.",
            "Keyword themes, audiences and budgets are proposals, not platform research or live-account data.",
            "The tracking plan is a generated plan - not verified or installed.",
            "Budget allocation is proposed, not actual spend; no leads, CPL or revenue are forecast.",
        ]),
    ]))
    sec.extend(pack_sections.final_sections(db, c, n, outs))
    return doc
