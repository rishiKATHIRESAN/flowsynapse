"""Campaign brief schema, required fields and the demonstration brief (5.1, 5.2)."""
from __future__ import annotations

from datetime import date
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from .dates import demo_period

PAID_CHANNELS = ("google_ads", "meta_ads")
ORGANIC_CHANNELS = ("instagram", "facebook", "linkedin")
CURRENCIES = ("INR", "USD", "EUR", "GBP", "JPY", "AED", "SGD", "AUD", "CAD")

S = 200  # short text
M = 2000  # medium text
L = 5000  # long text


class Cadence(BaseModel):
    model_config = ConfigDict(extra="forbid")
    type: Literal["daily", "every_n_days", "weekdays", "times_per_week", "custom"] = "every_n_days"
    n: int | None = Field(2, ge=1, le=60)
    weekdays: list[int] | None = None  # 0=Mon..6=Sun
    times_per_week: int | None = Field(None, ge=1, le=7)
    custom_dates: list[str] | None = None
    max_gap_days: int = Field(3, ge=1, le=60)


class BriefInput(BaseModel):
    """Everything is optional at the schema level so drafts can be saved;
    required-ness is enforced by stage 1 validation with field-level errors."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    # Business
    business_name: str | None = Field(None, max_length=S)
    industry: str | None = Field(None, max_length=S)
    business_description: str | None = Field(None, max_length=L)
    website_url: str | None = Field(None, max_length=M)
    location: str | None = Field(None, max_length=S)
    service_areas: list[str] = Field(default_factory=list, max_length=50)
    primary_service: str | None = Field(None, max_length=S)
    secondary_services: list[str] = Field(default_factory=list, max_length=50)
    value_proposition: str | None = Field(None, max_length=M)
    brand_messaging: str | None = Field(None, max_length=M)
    # Campaign
    campaign_name: str | None = Field(None, max_length=S)
    objective: str | None = Field(None, max_length=M)
    primary_conversion_goal: str | None = Field(None, max_length=M)
    secondary_goals: list[str] = Field(default_factory=list, max_length=20)
    start_date: str | None = Field(None, max_length=20)
    end_date: str | None = Field(None, max_length=20)
    duration_days: int | str | None = None
    total_budget: str | int | float | None = None
    currency: str | None = Field("INR", max_length=8)
    paid_channels: list[str] = Field(default_factory=list, max_length=5)
    organic_channels: list[str] = Field(default_factory=list, max_length=5)
    language: str | None = Field(None, max_length=60)
    tone: str | None = Field(None, max_length=S)
    competitors: list[str] = Field(default_factory=list, max_length=30)
    existing_campaign_info: str | None = Field(None, max_length=L)
    posting_cadence: Cadence = Field(default_factory=Cadence)
    concept_count: int = Field(3, ge=1, le=6)
    # Audience
    target_geography: str | None = Field(None, max_length=M)
    age_range: str | None = Field(None, max_length=60)
    audience_description: str | None = Field(None, max_length=L)
    needs_interests: str | None = Field(None, max_length=M)
    problems: str | None = Field(None, max_length=M)
    intent: str | None = Field(None, max_length=M)
    exclusions: str | None = Field(None, max_length=M)
    existing_research: str | None = Field(None, max_length=L)
    # Offer & landing page
    offer_details: str | None = Field(None, max_length=L)
    landing_page_url: str | None = Field(None, max_length=M)
    call_to_action: str | None = Field(None, max_length=S)
    contact_method: str | None = Field(None, max_length=S)
    booking_method: str | None = Field(None, max_length=S)
    approved_claims: list[str] = Field(default_factory=list, max_length=30)
    prohibited_claims: list[str] = Field(default_factory=list, max_length=30)
    brand_guidelines: str | None = Field(None, max_length=L)
    additional_instructions: str | None = Field(None, max_length=L)
    # Healthcare override (None = detect from industry/description)
    is_healthcare: bool | None = None


REQUIRED_FIELDS: dict[str, str] = {
    "business_name": "Business name",
    "industry": "Industry",
    "business_description": "Business description",
    "location": "Location",
    "primary_service": "Primary service/product",
    "campaign_name": "Campaign name",
    "objective": "Objective",
    "primary_conversion_goal": "Primary conversion goal",
    "start_date": "Start date",
    "total_budget": "Total paid-media budget",
    "currency": "Currency",
    "paid_channels": "Paid channels",
    "language": "Language",
    "target_geography": "Target geography",
    "audience_description": "Audience description",
    "offer_details": "Offer/service details",
    "call_to_action": "Call to action",
    "contact_method": "Contact/conversion method",
}
# end_date OR duration_days is also required (checked by the date rules).

FIELD_LABELS: dict[str, str] = {
    **REQUIRED_FIELDS,
    "end_date": "End date",
    "duration_days": "Duration (days)",
    "website_url": "Website URL",
    "landing_page_url": "Landing page URL",
    "service_areas": "Service areas",
    "secondary_services": "Secondary services",
    "value_proposition": "Value proposition",
    "brand_messaging": "Existing brand messaging",
    "secondary_goals": "Secondary goals",
    "organic_channels": "Organic channels",
    "tone": "Tone",
    "competitors": "Competitors",
    "existing_campaign_info": "Existing campaign info",
    "posting_cadence": "Posting cadence",
    "concept_count": "Number of concepts",
    "age_range": "Age range",
    "needs_interests": "Needs / interests",
    "problems": "Problems",
    "intent": "Intent",
    "exclusions": "Exclusions / restrictions",
    "existing_research": "Existing research",
    "booking_method": "Booking/enquiry method",
    "approved_claims": "Approved claims",
    "prohibited_claims": "Prohibited claims",
    "brand_guidelines": "Brand guidelines",
    "additional_instructions": "Additional instructions",
    "is_healthcare": "Healthcare rules",
}


def demo_brief(today: date | None = None, fixed: bool = False) -> dict[str, Any]:
    """The Be Well Hospitals demonstration brief (5.1). ``fixed`` uses the test
    dates 2026-11-02 -> 2026-11-15; otherwise next Monday -> +13 days."""
    if fixed:
        start, end = date(2026, 11, 2), date(2026, 11, 15)
    else:
        start, end = demo_period(today)
    return {
        "business_name": "Be Well Hospitals",
        "industry": "Healthcare - hospital / orthopaedics",
        "business_description": "DEMO ASSUMPTION: Multi-speciality hospital offering orthopaedic consultations in Selaiyur, Chennai",
        "website_url": None,
        "location": "Selaiyur, Chennai, Tamil Nadu, India",
        "service_areas": ["Selaiyur", "Tambaram", "Chennai"],
        "primary_service": "Orthopaedic consultation",
        "secondary_services": [],
        "value_proposition": "DEMO ASSUMPTION: Convenient local access to orthopaedic consultation and clear next steps",
        "brand_messaging": None,
        "campaign_name": "Be Well Orthopaedic Consultation - Demo",
        "objective": "Generate orthopaedic consultation leads",
        "primary_conversion_goal": "Consultation enquiry (form submission or phone call)",
        "secondary_goals": [],
        "start_date": start.isoformat(),
        "end_date": end.isoformat(),
        "duration_days": 14,
        "total_budget": "15000",
        "currency": "INR",
        "paid_channels": ["google_ads", "meta_ads"],
        "organic_channels": ["instagram", "facebook"],
        "language": "English",
        "tone": "Professional and reassuring",
        "competitors": [],
        "existing_campaign_info": None,
        "posting_cadence": {"type": "every_n_days", "n": 2, "weekdays": None, "times_per_week": None, "custom_dates": None, "max_gap_days": 3},
        "concept_count": 3,
        "target_geography": "Selaiyur and surrounding Chennai areas",
        "age_range": None,
        "audience_description": "Adults seeking information about joint pain, orthopaedic consultation, or mobility problems",
        "needs_interests": None,
        "problems": None,
        "intent": None,
        "exclusions": None,
        "existing_research": None,
        "offer_details": "DEMO ASSUMPTION: Orthopaedic consultation enquiry; availability and fees to be confirmed by the hospital",
        "landing_page_url": "https://example.com/orthopaedic-consultation",
        "call_to_action": "Book a consultation",
        "contact_method": "DEMO ASSUMPTION: Enquiry form or phone call",
        "booking_method": None,
        "approved_claims": ["DEMO ASSUMPTION: Orthopaedic consultations available in Selaiyur, Chennai"],
        "prohibited_claims": [
            "Guaranteed relief or cure",
            "'best'/'No.1' superlatives",
            "Before/after promises",
            "Invented doctors, credentials, prices, testimonials",
        ],
        "brand_guidelines": None,
        "additional_instructions": None,
        "is_healthcare": None,
    }
