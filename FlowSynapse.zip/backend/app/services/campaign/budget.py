"""Budget semantics and arithmetic (master prompt 5.8).

Decimal end to end - no floats anywhere in this module. The user-entered
budget is authoritative. Allocation uses whole major currency units and the
largest-remainder method so the allocation sum equals the total exactly.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import ROUND_DOWN, ROUND_HALF_UP, Decimal, InvalidOperation

CURRENCY_EXPONENT = {"INR": 2, "USD": 2, "EUR": 2, "GBP": 2, "JPY": 0, "AED": 2, "SGD": 2, "AUD": 2, "CAD": 2}
CHANNEL_ORDER = ("google_ads", "meta_ads")
# Default rule for two-channel lead generation (labelled "default rule, not a proven optimum").
DEFAULT_WEIGHTS = {"google_ads": Decimal("0.60"), "meta_ads": Decimal("0.40")}
MAX_BUDGET = Decimal("1000000000000")  # 1e12 major units


class BudgetError(ValueError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def exponent(currency: str) -> int:
    return CURRENCY_EXPONENT.get(currency.upper(), 2)


def parse_amount(value: object, currency: str = "INR", allow_zero: bool = False) -> Decimal:
    if value is None or (isinstance(value, str) and not value.strip()):
        raise BudgetError("REQUIRED", "Amount is required")
    if isinstance(value, bool):
        raise BudgetError("INVALID_AMOUNT", "Amount must be a number")
    text = str(value).strip().replace(",", "")
    try:
        d = Decimal(text)
    except InvalidOperation:
        raise BudgetError("INVALID_AMOUNT", "Amount must be a number") from None
    if not d.is_finite():
        raise BudgetError("INVALID_AMOUNT", "Amount must be a finite number")
    if d < 0 or (d == 0 and not allow_zero):
        raise BudgetError("NON_POSITIVE_AMOUNT", "Amount must be greater than zero" if not allow_zero else "Amount cannot be negative")
    exp = exponent(currency)
    if d.as_tuple().exponent < -exp:  # type: ignore[operator]
        raise BudgetError("TOO_PRECISE", f"{currency} amounts allow at most {exp} decimal places")
    if d > MAX_BUDGET:
        raise BudgetError("AMOUNT_TOO_LARGE", "Amount is unrealistically large")
    return d


def to_str(d: Decimal, currency: str) -> str:
    exp = exponent(currency)
    q = Decimal(1).scaleb(-exp)
    return str(d.quantize(q))


@dataclass
class Allocation:
    channel: str
    amount: Decimal
    weight: Decimal

    def percentage(self, total: Decimal) -> Decimal:
        if total == 0:
            return Decimal("0.00")
        return (self.amount * 100 / total).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    def daily(self, duration_days: int) -> Decimal:
        return (self.amount / Decimal(duration_days)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def normalize_weights(channels: list[str], weights: dict[str, Decimal] | None = None) -> dict[str, Decimal]:
    ordered = order_channels(channels)
    if not ordered:
        raise BudgetError("NO_CHANNELS", "At least one paid channel is required")
    if weights is None:
        if set(ordered) == set(DEFAULT_WEIGHTS):
            weights = dict(DEFAULT_WEIGHTS)
        else:
            weights = {c: Decimal(1) for c in ordered}
    ws = {c: Decimal(str(weights.get(c, 0))) for c in ordered}
    total = sum(ws.values(), Decimal(0))
    if total <= 0 or any(w < 0 for w in ws.values()):
        raise BudgetError("INVALID_WEIGHTS", "Weights must be non-negative and not all zero")
    return {c: ws[c] / total for c in ordered}


def order_channels(channels: list[str]) -> list[str]:
    known = [c for c in CHANNEL_ORDER if c in channels]
    extra = sorted(c for c in set(channels) if c not in CHANNEL_ORDER)
    return known + extra


def allocate(total: Decimal, channels: list[str], weights: dict[str, Decimal] | None = None) -> list[Allocation]:
    """Largest-remainder allocation in whole major units.

    raw_i = total * weight_i; floor to whole units; distribute leftover units one
    at a time to the largest fractional remainders, ties by channel order.
    If ``total`` has a fractional part it is added to the first channel so the
    sum is still exact.
    """
    w = normalize_weights(channels, weights)
    ordered = list(w)
    whole_total = total.to_integral_value(rounding=ROUND_DOWN)
    fraction = total - whole_total
    raws = {c: whole_total * w[c] for c in ordered}
    floors = {c: raws[c].to_integral_value(rounding=ROUND_DOWN) for c in ordered}
    leftover = int(whole_total - sum(floors.values(), Decimal(0)))
    by_remainder = sorted(ordered, key=lambda c: (-(raws[c] - floors[c]), ordered.index(c)))
    for i in range(leftover):
        floors[by_remainder[i % len(by_remainder)]] += 1
    if fraction:
        floors[ordered[0]] += fraction
    out = [Allocation(c, floors[c], w[c]) for c in ordered]
    assert sum((a.amount for a in out), Decimal(0)) == total
    return out


@dataclass
class EditCheck:
    ok_final: bool
    total_allocated: Decimal
    unallocated: Decimal
    findings: list[dict[str, str]]


def check_manual(total: Decimal, currency: str, rows: dict[str, object], paid_channels: list[str]) -> tuple[dict[str, Decimal], EditCheck]:
    """Validate a manual allocation edit. Raises BudgetError for invalid values
    (negative, non-numeric, non-paid channel). Over-allocation -> blocking
    finding; under-allocation -> warning."""
    parsed: dict[str, Decimal] = {}
    for ch, val in rows.items():
        if ch not in paid_channels:
            raise BudgetError("CHANNEL_NOT_PAID", f"{ch} is not a paid channel in the brief; it cannot receive budget")
        parsed[ch] = parse_amount(val, currency, allow_zero=True)
    for ch in paid_channels:
        parsed.setdefault(ch, Decimal(0))
    allocated = sum(parsed.values(), Decimal(0))
    findings = []
    if allocated > total:
        findings.append({"severity": "BLOCKER", "code": "OVER_ALLOCATED",
                         "message": f"Allocated {to_str(allocated, currency)} exceeds the total budget {to_str(total, currency)}"})
    elif allocated < total:
        findings.append({"severity": "WARNING", "code": "UNALLOCATED",
                         "message": f"Unallocated {to_str(total - allocated, currency)} of {to_str(total, currency)}"})
    return parsed, EditCheck(allocated <= total, allocated, total - allocated, findings)
