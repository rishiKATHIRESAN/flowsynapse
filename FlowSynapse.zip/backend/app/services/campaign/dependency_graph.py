"""Campaign stage dependency graph and invalidation (master prompt 5.5).

Implemented as data. A stage is directly affected when one of its input fields
or upstream stage outputs changes; staleness propagates only along these
edges. QA and the pack always re-run after any change. BRIEF_NORMALIZATION is
deterministic and re-run automatically on every brief save.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .constants import STAGES

BUSINESS = {"business_name", "industry", "business_description", "website_url", "location", "service_areas",
            "primary_service", "secondary_services", "value_proposition", "brand_messaging"}
AUDIENCE = {"target_geography", "age_range", "audience_description", "needs_interests", "problems", "intent",
            "exclusions", "existing_research"}
OFFER = {"offer_details", "booking_method"}
CLAIMS = {"approved_claims", "prohibited_claims"}
BRAND = {"brand_guidelines", "brand_messaging"}
DATES = {"start_date", "end_date", "duration_days"}

STAGE_FIELDS: dict[str, set[str]] = {
    "OBJECTIVE_ANALYSIS": BUSINESS | AUDIENCE | OFFER | CLAIMS | BRAND | {
        "language", "tone", "competitors", "existing_campaign_info", "objective", "primary_conversion_goal",
        "secondary_goals", "additional_instructions", "is_healthcare"},
    "STRATEGY": {"paid_channels", "organic_channels", "target_geography"},
    "CONCEPTS": {"call_to_action", "contact_method", "approved_claims", "prohibited_claims", "concept_count"},
    "GOOGLE_ADS": {"landing_page_url", "language"},
    "META_ADS": {"landing_page_url", "language"},
    "SOCIAL_PLAN": DATES | {"posting_cadence", "organic_channels"},
    "TRACKING_PLAN": {"landing_page_url", "campaign_name", "paid_channels", "organic_channels"},
    "BUDGET_ALLOCATION": {"total_budget", "currency", "paid_channels"} | DATES,
}

STAGE_DEPS: dict[str, set[str]] = {
    "OBJECTIVE_ANALYSIS": set(),
    "STRATEGY": {"OBJECTIVE_ANALYSIS"},
    "CONCEPTS": {"STRATEGY"},
    "GOOGLE_ADS": {"CONCEPTS", "STRATEGY"},
    "META_ADS": {"CONCEPTS", "STRATEGY"},
    "SOCIAL_PLAN": {"STRATEGY", "CONCEPTS"},
    "TRACKING_PLAN": {"GOOGLE_ADS", "META_ADS"},
    "BUDGET_ALLOCATION": {"STRATEGY"},
    "QUALITY_ASSURANCE": set(STAGES[2:10]),
    "PACK_GENERATION": set(STAGES[2:11]),
}

ALWAYS_AFTER_CHANGE = ["QUALITY_ASSURANCE", "PACK_GENERATION"]


@dataclass
class Change:
    fields: set[str] = field(default_factory=set)
    outputs: set[str] = field(default_factory=set)  # stage keys whose outputs were edited/regenerated


def dependents(stage: str) -> list[str]:
    """All stages transitively depending on ``stage`` (in workflow order)."""
    out: set[str] = set()
    frontier = {stage}
    while frontier:
        nxt = {s for s, deps in STAGE_DEPS.items() if deps & frontier and s not in out}
        out |= nxt
        frontier = nxt
    return [s for s in STAGES if s in out]


def affected_stages(change: Change) -> list[str]:
    """Stages that become outdated for ``change`` (workflow order).

    Does not include BRIEF_NORMALIZATION (recomputed on save) and does not
    include the stages whose outputs were edited themselves.
    """
    direct = {s for s, fs in STAGE_FIELDS.items() if fs & change.fields}
    result: set[str] = set(direct)
    for s in direct | set(change.outputs):
        result |= set(dependents(s))
    if change.fields or change.outputs:
        result |= set(ALWAYS_AFTER_CHANGE)
    result -= set(change.outputs)
    return [s for s in STAGES if s in result]


def upstream(stage: str) -> list[str]:
    out: set[str] = set()
    frontier = set(STAGE_DEPS.get(stage, set()))
    while frontier:
        out |= frontier
        frontier = {d for s in frontier for d in STAGE_DEPS.get(s, set())} - out
    return [s for s in STAGES if s in out]


def reason_text(change: Change, stage: str) -> str:
    parts = []
    hit = sorted(STAGE_FIELDS.get(stage, set()) & change.fields)
    if hit:
        parts.append("brief field(s) changed: " + ", ".join(hit))
    ups = sorted(set(STAGE_DEPS.get(stage, set())) & change.outputs)
    if ups:
        parts.append("upstream output edited: " + ", ".join(ups))
    if not parts:
        parts.append("an upstream stage became outdated" if stage not in ALWAYS_AFTER_CHANGE
                     else "campaign content changed; QA and pack must be re-run")
    return "; ".join(parts)
