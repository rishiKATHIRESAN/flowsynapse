"""Stage 2 - BRIEF_NORMALIZATION (deterministic, master prompt 5.3).

The original input is preserved unchanged; this produces a separate
normalized view and the list of labelled assumptions.
"""
from __future__ import annotations

from typing import Any

from ..content.health_claims import detect_healthcare
from .brief import BriefInput
from .budget import exponent, order_channels, parse_amount, to_str
from .dates import resolve_period

DEMO_PREFIX = "DEMO ASSUMPTION:"
DEMO_PLACEHOLDER_HOSTS = ("example.com", "example.org", "example.net")


def _clean(s: str | None) -> str | None:
    if s is None:
        return None
    s = " ".join(s.split())
    return s or None


def _dedupe(items: list[str]) -> list[str]:
    seen: set[str] = set()
    out = []
    for i in items:
        c = _clean(i)
        if c and c.lower() not in seen:
            seen.add(c.lower())
            out.append(c)
    return out


def structure_location(loc: str | None) -> dict[str, Any]:
    original = loc or ""
    parts = [p.strip() for p in original.split(",") if p.strip()]
    out: dict[str, Any] = {"original": original, "locality": None, "city": None, "state": None, "country": None}
    if len(parts) >= 4:
        out.update(locality=", ".join(parts[:-3]), city=parts[-3], state=parts[-2], country=parts[-1])
    elif len(parts) == 3:
        out.update(city=parts[0], state=parts[1], country=parts[2])
    elif len(parts) == 2:
        out.update(city=parts[0], country=parts[1])
    elif len(parts) == 1:
        out.update(city=parts[0])
    out["best_effort"] = True
    return out


def normalize(brief: BriefInput) -> dict[str, Any]:
    """Assumes stage 1 passed (dates/budget valid)."""
    currency = (brief.currency or "INR").upper()
    period = resolve_period(brief.start_date, brief.end_date, brief.duration_days)
    budget = parse_amount(brief.total_budget, currency)
    assumptions: list[dict[str, str]] = []

    def label_assumption(field: str, value: str | None) -> None:
        if value and value.strip().upper().startswith(DEMO_PREFIX):
            assumptions.append({"field": field, "value": value, "source": "demo_assumption",
                                "note": "Labelled DEMO ASSUMPTION - not a verified fact about the business"})

    for f in ("business_description", "value_proposition", "offer_details", "contact_method"):
        label_assumption(f, getattr(brief, f))
    for c in brief.approved_claims:
        label_assumption("approved_claims", c)
    if not brief.value_proposition:
        assumptions.append({"field": "value_proposition", "value": f"Assumed: clear, local access to {brief.primary_service}",
                            "source": "assumption", "note": "Not supplied - review before use"})
    if not brief.tone:
        assumptions.append({"field": "tone", "value": "Assumed: professional and clear", "source": "assumption",
                            "note": "Not supplied"})
    if not brief.age_range:
        assumptions.append({"field": "age_range", "value": "Assumed: adults 18+", "source": "assumption", "note": "Not supplied"})
    landing = _clean(brief.landing_page_url)
    if landing and any(h in landing for h in DEMO_PLACEHOLDER_HOSTS):
        assumptions.append({"field": "landing_page_url", "value": landing, "source": "demo_placeholder",
                            "note": "DEMO PLACEHOLDER - reserved example domain, replace before use"})
    if not landing:
        assumptions.append({"field": "landing_page_url", "value": "", "source": "missing",
                            "note": "Landing page not supplied - tracking URLs are placeholders"})

    is_hc = brief.is_healthcare
    detected = detect_healthcare(brief.industry, brief.business_description, brief.primary_service)
    return {
        "business": {
            "name": _clean(brief.business_name),
            "industry": _clean(brief.industry),
            "description": _clean(brief.business_description),
            "website_url": _clean(brief.website_url),
            "location": structure_location(brief.location),
            "service_areas": _dedupe(brief.service_areas),
            "primary_service": _clean(brief.primary_service),
            "secondary_services": _dedupe(brief.secondary_services),
            "value_proposition": _clean(brief.value_proposition),
            "brand_messaging": _clean(brief.brand_messaging),
        },
        "campaign": {
            "name": _clean(brief.campaign_name),
            "objective": _clean(brief.objective),
            "primary_conversion_goal": _clean(brief.primary_conversion_goal),
            "secondary_goals": _dedupe(brief.secondary_goals),
            "start_date": period.start.isoformat() if period.start else None,
            "end_date": period.end.isoformat() if period.end else None,
            "duration_days": period.duration_days,
            "budget": {"amount": to_str(budget, currency), "currency": currency, "exponent": exponent(currency),
                       "minor_units": int(budget.scaleb(exponent(currency)))},
            "paid_channels": order_channels(_dedupe(brief.paid_channels)),
            "organic_channels": _dedupe(brief.organic_channels),
            "language": _clean(brief.language),
            "tone": _clean(brief.tone),
            "competitors": _dedupe(brief.competitors),
            "existing_campaign_info": _clean(brief.existing_campaign_info),
            "posting_cadence": brief.posting_cadence.model_dump(),
            "concept_count": brief.concept_count,
        },
        "audience": {
            "target_geography": _clean(brief.target_geography),
            "age_range": _clean(brief.age_range),
            "description": _clean(brief.audience_description),
            "needs_interests": _clean(brief.needs_interests),
            "problems": _clean(brief.problems),
            "intent": _clean(brief.intent),
            "exclusions": _clean(brief.exclusions),
            "existing_research": _clean(brief.existing_research),
        },
        "offer": {
            "details": _clean(brief.offer_details),
            "landing_page_url": landing,
            "call_to_action": _clean(brief.call_to_action),
            "contact_method": _clean(brief.contact_method),
            "booking_method": _clean(brief.booking_method),
            "approved_claims": _dedupe(brief.approved_claims),
            "prohibited_claims": _dedupe(brief.prohibited_claims),
            "brand_guidelines": _clean(brief.brand_guidelines),
            "additional_instructions": _clean(brief.additional_instructions),
        },
        "is_healthcare": detected if is_hc is None else bool(is_hc),
        "is_healthcare_detected": detected,
        "is_healthcare_overridden": is_hc is not None,
        "assumptions": assumptions,
    }
