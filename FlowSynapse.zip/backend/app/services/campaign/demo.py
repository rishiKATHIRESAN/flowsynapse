"""Campaign demo data (Be Well Hospitals) and dashboard counter registration."""
from __future__ import annotations

from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...api.dashboard import register_counter
from ...database import session_scope
from ...models.campaign import Campaign
from ..demo import DemoModule, register
from ..jobs import engine
from ..records import delete_parent_children
from .brief import demo_brief
from .constants import MODULE, PARENT_TYPE

DEMO_KEY = "campaign-bewell-ortho"


def load() -> dict[str, Any]:
    from .orchestrator import implemented_stages
    from .service import create_campaign

    with session_scope(immediate=True) as db:
        c = db.execute(select(Campaign).where(Campaign.demo_key == DEMO_KEY)).scalar_one_or_none()
        if c is None:
            c = create_campaign(db, demo_brief(), is_demo=True, demo_key=DEMO_KEY)
        if engine.latest_execution(db, PARENT_TYPE, c.id) is None:
            # Demo runs always use the mock provider through the normal pipeline.
            engine.create_execution(db, parent_type=PARENT_TYPE, parent_id=c.id,
                                    stages=[engine.StageSpec(s) for s in implemented_stages()],
                                    provider=engine.ProviderInfo("mock", "mock-deterministic-v1", True),
                                    is_demo=True, title=c.name, module=MODULE)
        return {"created": True, "id": c.id}


def roots(db: Session) -> list[str]:
    return list(db.execute(select(Campaign.id).where(Campaign.is_demo.is_(True))).scalars())


def delete_root(db: Session, cid: str) -> list[str]:
    files = delete_parent_children(db, PARENT_TYPE, cid)
    c = db.get(Campaign, cid)
    if c is not None:
        db.delete(c)
    return files


def real_dependents(db: Session, demo_ids: set[str]) -> list[dict[str, Any]]:
    return []  # funnels register their own reference check


def keep_as_own(db: Session, cid: str) -> None:
    from sqlalchemy import update

    from ...models.jobs import Execution
    from ...models.outputs import Output

    c = db.get(Campaign, cid)
    if c is None or not c.is_demo:
        return
    c.is_demo = False
    c.demo_key = None
    db.execute(update(Output).where(Output.parent_type == PARENT_TYPE, Output.parent_id == cid).values(is_demo=False))
    db.execute(update(Execution).where(Execution.parent_type == PARENT_TYPE, Execution.parent_id == cid).values(is_demo=False))


register(DemoModule(MODULE, 1, load, roots, delete_root, real_dependents, keep_as_own))


def _counter(db: Session, include_demo: bool) -> dict[str, Any]:
    from .service import counts

    return counts(db, include_demo)


register_counter(MODULE, _counter)
