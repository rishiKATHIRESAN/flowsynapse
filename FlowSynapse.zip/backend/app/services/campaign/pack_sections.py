"""Pack sections 5-13 and 15-17 (extended as stages are implemented)."""
from __future__ import annotations

import json
from typing import Any, Callable

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...models.campaign import Campaign, CampaignFinding
from ...models.outputs import Output
from ..reporting.document import Bullets, Dataset, Paragraph, Section, Table

OriginFn = Callable[[Session, Output], str]


def _c(o: Output) -> dict[str, Any]:
    return json.loads(o.content) if o.content else {}


def not_generated(what: str) -> list[Any]:
    return [Paragraph(f"{what} has not been generated yet.", "note")]


def executive_summary(c: Campaign, n: dict[str, Any], outs: dict[str, list[Output]]) -> list[Any]:
    b, cp = n.get("business", {}), n.get("campaign", {})
    budget = cp.get("budget", {})
    lines = [
        f"Business: {b.get('name')} ({b.get('industry')})",
        f"Objective: {cp.get('objective')}",
        f"Primary conversion goal: {cp.get('primary_conversion_goal')}",
        f"Paid channels: {', '.join(cp.get('paid_channels', []))}; organic: {', '.join(cp.get('organic_channels', [])) or 'none'}",
        f"Total proposed paid-media budget: {budget.get('amount')} {budget.get('currency')}",
    ]
    strat = (outs.get("strategy") or [None])[0]
    if strat is not None:
        lines.append("Strategy summary: " + str(_c(strat).get("campaign_summary", "")))
    return [Bullets(lines)]


def extra_datasets(db: Session, c: Campaign, outs: dict[str, list[Output]], origin: OriginFn) -> list[Dataset]:
    return []


def middle_sections(db: Session, c: Campaign, n: dict[str, Any], outs: dict[str, list[Output]], origin: OriginFn) -> list[Section]:
    titles = ["5. Strategy & positioning", "6. Audience segments", "7. Messaging pillars", "8. Concepts",
              "9. Google Ads proposals", "10. Meta Ads proposals", "11. Social calendar", "12. Tracking & measurement plan",
              "13. Budget allocation"]
    return [Section(t, not_generated(t.split(". ", 1)[1])) for t in titles]


def final_sections(db: Session, c: Campaign, n: dict[str, Any], outs: dict[str, list[Output]]) -> list[Section]:
    findings = db.execute(select(CampaignFinding).where(CampaignFinding.campaign_id == c.id)).scalars().all()
    qa: list[Any] = [Table(["Severity", "Rule", "Description", "Correction"],
                           [[f.severity, f.rule_id, f.description, f.recommended_correction or ""] for f in findings], [1, 1, 3, 2])] \
        if findings else not_generated("Quality assurance")
    return [
        Section("15. QA results", qa),
        Section("16. Outstanding actions", [Bullets([f.recommended_correction or f.description for f in findings
                                                     if f.severity in ("BLOCKER", "WARNING")] or ["None recorded."])]),
        Section("17. Recommended implementation sequence", [Bullets([
            "Review and confirm all assumptions and healthcare/claims findings with the business.",
            "Finalise landing page and tracking implementation before launching ads.",
            "Set up Google Ads and Meta Ads campaigns manually from the proposals; verify policies and character limits in each platform.",
            "Publish organic posts on the suggested dates after your own review.",
            "Monitor results using the measurement plan; adjust allocation based on real data.",
        ])]),
    ]
