"""Idempotency-Key handling (master prompt 2.5).

Usage in a route::

    return run_idempotent(request, "create_campaign", body, lambda db: (201, payload, "campaign", id))

The whole operation runs in one ``BEGIN IMMEDIATE`` transaction together with
the key row, so a replay returns exactly what was created and a failure (any
exception or non-2xx) rolls the key back so the client can fix and retry.
"""
from __future__ import annotations

import hashlib
import json
import logging
import re
from datetime import timedelta
from decimal import Decimal
from typing import Any, Callable

from fastapi import Request
from fastapi.responses import JSONResponse
from sqlalchemy import delete, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..database import new_immediate_session, with_lock_retry
from ..models.idempotency import IdempotencyKey
from ..utils.clock import utcnow
from ..utils.errors import AppError

log = logging.getLogger("flowsynapse.idempotency")

KEY_RE = re.compile(r"^[A-Za-z0-9._:-]{1,128}$")
TTL = timedelta(hours=24)
IN_PROGRESS_TIMEOUT = timedelta(minutes=5)
MAX_STORED_BODY = 256_000
VOLATILE_FIELDS = {"client_timestamp", "request_id"}

Operation = Callable[[Session], tuple[int, Any, str | None, str | None]]


def _normalize(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: _normalize(v) for k, v in sorted(value.items()) if k not in VOLATILE_FIELDS}
    if isinstance(value, (list, tuple)):
        return [_normalize(v) for v in value]
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, bool) or value is None:
        return value
    if isinstance(value, (int, float, Decimal)):
        d = Decimal(str(value)).normalize()
        return format(d, "f")
    return str(value)


def fingerprint(body: Any, path_params: dict[str, Any], query: dict[str, Any] | None = None) -> str:
    canonical = json.dumps(
        {"body": _normalize(body), "path": _normalize(path_params), "query": _normalize(query or {})},
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def scope_for(request: Request) -> tuple[str, dict[str, Any]]:
    route = request.scope.get("route")
    template = getattr(route, "path", request.url.path)
    params = dict(request.path_params)
    return f"{request.method} {template} {json.dumps(params, sort_keys=True)}", params


def validate_key(key: str | None) -> str | None:
    if key is None:
        return None
    if not KEY_RE.match(key):
        raise AppError(
            422,
            "INVALID_IDEMPOTENCY_KEY",
            "Idempotency-Key must be 1-128 characters of A-Z a-z 0-9 . _ : -",
            {"fields": [{"field": "Idempotency-Key", "code": "INVALID", "message": "invalid format"}]},
        )
    return key


def _response(status: int, body: Any, replayed: bool = False) -> JSONResponse:
    headers = {"Idempotent-Replayed": "true"} if replayed else {}
    return JSONResponse(status_code=status, content=body, headers=headers)


def execute(
    scope: str,
    key: str | None,
    operation_name: str,
    fp: str,
    op: Operation,
) -> tuple[int, Any, bool]:
    """Core logic, independent of FastAPI. Returns (status, body, replayed)."""

    def attempt() -> tuple[int, Any, bool]:
        db = new_immediate_session()
        try:
            if key is not None:
                now = utcnow()
                existing = db.execute(
                    select(IdempotencyKey).where(IdempotencyKey.scope == scope, IdempotencyKey.key == key)
                ).scalar_one_or_none()
                if existing is not None:
                    expired = existing.expires_at <= now
                    stale_progress = existing.state == "IN_PROGRESS" and existing.created_at <= now - IN_PROGRESS_TIMEOUT
                    if expired or stale_progress:
                        db.delete(existing)
                        db.flush()
                    elif existing.request_fingerprint != fp:
                        raise AppError(
                            422,
                            "IDEMPOTENCY_KEY_REUSED",
                            "This Idempotency-Key was already used with a different request. Use a new key.",
                        )
                    elif existing.state == "IN_PROGRESS":
                        raise AppError(
                            409,
                            "IDEMPOTENCY_IN_PROGRESS",
                            "A request with this Idempotency-Key is still being processed.",
                            headers={"Retry-After": "1"},
                        )
                    else:
                        body = json.loads(existing.response_body or "null")
                        db.rollback()
                        return int(existing.response_status or 200), body, True
                row = IdempotencyKey(
                    key=key,
                    scope=scope,
                    operation=operation_name,
                    request_fingerprint=fp,
                    state="IN_PROGRESS",
                    created_at=now,
                    expires_at=now + TTL,
                )
                db.add(row)
                db.flush()
            status, body, rtype, rid = op(db)
            if not (200 <= status < 300):
                db.rollback()
                return status, body, False
            if key is not None:
                stored = json.dumps(body, default=str)
                if len(stored) > MAX_STORED_BODY:
                    stored = json.dumps({"resource_type": rtype, "resource_id": rid, "truncated": True})
                row.state = "COMPLETED"
                row.response_status = status
                row.response_body = stored
                row.resource_type = rtype
                row.resource_id = rid
            db.commit()
            return status, body, False
        except IntegrityError as exc:
            db.rollback()
            if key is not None and "idempotency_keys" in str(exc):
                raise AppError(
                    409,
                    "IDEMPOTENCY_IN_PROGRESS",
                    "A request with this Idempotency-Key is being processed.",
                    headers={"Retry-After": "1"},
                ) from exc
            raise
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    return with_lock_retry(attempt)


def run_idempotent(
    request: Request,
    operation_name: str,
    body: Any,
    op: Operation,
    query: dict[str, Any] | None = None,
) -> JSONResponse:
    key = validate_key(request.headers.get("Idempotency-Key"))
    scope, params = scope_for(request)
    fp = fingerprint(body, params, query)
    status, payload, replayed = execute(scope, key, operation_name, fp, op)
    return _response(status, payload, replayed)


def cleanup_expired(batch: int = 500) -> int:
    """Delete expired rows in batches; never IN_PROGRESS rows younger than the timeout."""
    total = 0
    while True:
        db = new_immediate_session()
        try:
            now = utcnow()
            ids = db.execute(
                select(IdempotencyKey.id)
                .where(IdempotencyKey.expires_at <= now)
                .where(
                    (IdempotencyKey.state == "COMPLETED")
                    | (IdempotencyKey.created_at <= now - IN_PROGRESS_TIMEOUT)
                )
                .limit(batch)
            ).scalars().all()
            if not ids:
                db.rollback()
                return total
            db.execute(delete(IdempotencyKey).where(IdempotencyKey.id.in_(ids)))
            db.commit()
            total += len(ids)
        finally:
            db.close()
