"""Shared content status model (master prompt 4.1).

Content states, not an approval system. Generation status and staleness are
separate fields. There is no "published"/"scheduled" state.
"""
from __future__ import annotations

import json
from typing import Any

from ...utils.clock import iso, utcnow
from ...utils.errors import AppError

DRAFT = "DRAFT"
READY_FOR_REVIEW = "READY_FOR_REVIEW"
NEEDS_REVISION = "NEEDS_REVISION"
READY_TO_EXPORT = "READY_TO_EXPORT"
STATES = (DRAFT, READY_FOR_REVIEW, NEEDS_REVISION, READY_TO_EXPORT)

TRANSITIONS: dict[str, frozenset[str]] = {
    DRAFT: frozenset({READY_FOR_REVIEW}),
    READY_FOR_REVIEW: frozenset({NEEDS_REVISION, READY_TO_EXPORT, DRAFT}),
    NEEDS_REVISION: frozenset({DRAFT, READY_FOR_REVIEW}),
    READY_TO_EXPORT: frozenset({NEEDS_REVISION, DRAFT}),
}

RESET_ON_EDIT = frozenset({READY_FOR_REVIEW, READY_TO_EXPORT})


def is_allowed(frm: str, to: str) -> bool:
    return to in TRANSITIONS.get(frm, frozenset())


def check_transition(frm: str | None, to: str) -> None:
    if to not in STATES:
        raise AppError(422, "VALIDATION_ERROR", f"Unknown content status {to}",
                       {"fields": [{"field": "status", "code": "INVALID", "message": f"must be one of {', '.join(STATES)}"}]})
    current = frm or DRAFT
    if not is_allowed(current, to):
        allowed = sorted(TRANSITIONS.get(current, frozenset()))
        raise AppError(
            409,
            "INVALID_STATUS_TRANSITION",
            f"Cannot change content status from {current} to {to}. Allowed: {', '.join(allowed) or 'none'}.",
            {"from": current, "to": to, "allowed": allowed},
        )


def append_history(history_json: str | None, frm: str | None, to: str, reason: str) -> str:
    hist: list[dict[str, Any]] = json.loads(history_json) if history_json else []
    hist.append({"from": frm, "to": to, "reason": reason, "at": iso(utcnow())})
    return json.dumps(hist[-50:])
