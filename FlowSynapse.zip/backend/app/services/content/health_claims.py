"""Deterministic healthcare detection and risky-claim scanner (master prompt 5.1).

Reused by the Campaign, Funnel, Blog and Social modules. Lists are configurable
in ``health_rules.json``. Findings are review prompts, never a compliance verdict.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, Iterable

RULES_PATH = Path(__file__).with_name("health_rules.json")


@dataclass(frozen=True)
class ClaimFinding:
    category: str
    severity: str
    phrase: str
    field: str
    suggestion: str

    def as_dict(self) -> dict[str, str]:
        return {
            "category": self.category,
            "severity": self.severity,
            "phrase": self.phrase,
            "field": self.field,
            "suggestion": self.suggestion,
        }


@lru_cache(maxsize=1)
def rules() -> dict[str, Any]:
    return json.loads(RULES_PATH.read_text(encoding="utf-8"))


@lru_cache(maxsize=1)
def _compiled() -> list[tuple[re.Pattern[str], dict[str, Any]]]:
    out = []
    for r in rules()["risky_phrases"]:
        flags = 0 if r.get("case_sensitive") else re.IGNORECASE
        out.append((re.compile(r"(?<![\w])(" + r["pattern"] + r")(?![\w])", flags), r))
    return out


def disclaimer() -> str:
    return str(rules()["disclaimer"])


def detect_healthcare(*texts: str | None) -> bool:
    blob = " ".join(t for t in texts if t).lower()
    for kw in rules()["healthcare_keywords"]:
        if re.search(r"(?<![\w])" + re.escape(kw.lower()) + r"(?![\w])", blob):
            return True
    return False


def scan_text(text: str | None, field: str = "", allowed: Iterable[str] = ()) -> list[ClaimFinding]:
    """Scan one text. Phrases contained in an approved claim are not flagged."""
    if not text:
        return []
    allowed_l = [a.lower() for a in allowed if a]
    found: list[ClaimFinding] = []
    seen: set[tuple[str, str]] = set()
    for rx, r in _compiled():
        for m in rx.finditer(text):
            phrase = m.group(1)
            if any(phrase.lower() in a for a in allowed_l):
                continue
            key = (r["category"], phrase.lower())
            if key in seen:
                continue
            seen.add(key)
            found.append(ClaimFinding(r["category"], r["severity"], phrase, field, r["suggestion"]))
    return found


def scan_content(content: Any, field: str = "", allowed: Iterable[str] = ()) -> list[ClaimFinding]:
    """Recursively scan strings in dicts/lists, recording the field path."""
    out: list[ClaimFinding] = []
    allowed = list(allowed)
    if isinstance(content, str):
        return scan_text(content, field, allowed)
    if isinstance(content, dict):
        for k, v in content.items():
            out += scan_content(v, f"{field}.{k}" if field else str(k), allowed)
    elif isinstance(content, list):
        for i, v in enumerate(content):
            out += scan_content(v, f"{field}[{i}]", allowed)
    return out
