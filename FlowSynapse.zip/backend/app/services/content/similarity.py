"""Deterministic near-duplicate detection (token-overlap Jaccard)."""
from __future__ import annotations

import re
from typing import Sequence

DEFAULT_THRESHOLD = 0.6
_STOP = {"the", "a", "an", "and", "or", "of", "to", "in", "for", "with", "on", "your", "you", "our", "is", "are", "at", "by"}


def tokens(text: str) -> set[str]:
    return {t for t in re.findall(r"[\w']+", (text or "").lower()) if t not in _STOP and len(t) > 1}


def jaccard(a: str, b: str) -> float:
    ta, tb = tokens(a), tokens(b)
    if not ta and not tb:
        return 1.0
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def near_duplicates(texts: Sequence[str], threshold: float = DEFAULT_THRESHOLD) -> list[tuple[int, int, float]]:
    """Pairs (i, j, score) with i < j whose similarity is >= threshold."""
    out = []
    for i in range(len(texts)):
        for j in range(i + 1, len(texts)):
            s = jaccard(texts[i], texts[j])
            if s >= threshold:
                out.append((i, j, round(s, 3)))
    return out
