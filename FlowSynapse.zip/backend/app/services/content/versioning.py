"""Output provenance and versioning helpers (master prompt 3.2, 3.5).

* Generation creates version 1 with full provenance.
* A manual edit creates a MANUALLY_EDITED version that keeps
  ``original_generation_version_id``; no-op edits create nothing.
* Regeneration creates a REGENERATED version (new provider provenance).
* Restore creates a new version copying the old content (history is never
  rewritten).
* A new version becomes active only inside the same transaction that inserts it
  (callers validate content first), so a failed regeneration never touches the
  previously active version.
* Optimistic concurrency: callers pass the expected active version number.

Callers must run inside a ``BEGIN IMMEDIATE`` transaction so ``max + 1``
version numbering is serialised.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from sqlalchemy import func, select, update
from sqlalchemy.orm import Session

from ...config import get_settings
from ...models.outputs import Output, OutputVersion
from ...utils.clock import iso, utcnow
from ...utils.errors import AppError
from . import content_status as cs


@dataclass
class Provenance:
    provider: str | None
    model: str | None
    is_mock: bool
    execution_id: str | None = None
    stage_key: str | None = None
    item_id: str | None = None
    source_input_version: str | None = None
    generated_at: datetime | None = None

    @property
    def origin(self) -> str:
        return "MOCK_GENERATED" if self.is_mock else "AI_GENERATED"


def canonical(content: Any) -> str:
    return json.dumps(content, sort_keys=True, ensure_ascii=False, separators=(",", ":"), default=str)


def content_hash(content: Any) -> str:
    return hashlib.sha256(canonical(content).encode("utf-8")).hexdigest()


def _next_number(db: Session, output_id: str) -> int:
    n = db.execute(select(func.max(OutputVersion.version_number)).where(OutputVersion.output_id == output_id)).scalar()
    return int(n or 0) + 1


def _activate(db: Session, output: Output, version: OutputVersion) -> None:
    db.execute(
        update(OutputVersion)
        .where(OutputVersion.output_id == output.id, OutputVersion.is_active.is_(True))
        .values(is_active=False)
        .execution_options(synchronize_session=False)
    )
    db.flush()
    version.is_active = True
    db.add(version)
    db.flush()
    output.active_version_id = version.id
    output.version_number = version.version_number
    output.content = version.content


def _new_version(
    db: Session,
    output: Output,
    content: Any,
    origin: str,
    prov: Provenance | None,
    *,
    previous: OutputVersion | None,
    original_id: str | None,
    edit_summary: str | None = None,
) -> OutputVersion:
    v = OutputVersion(
        output_id=output.id,
        output_type=output.output_type,
        parent_type=output.parent_type,
        parent_id=output.parent_id,
        version_number=_next_number(db, output.id),
        is_active=False,
        content=canonical(content),
        content_hash=content_hash(content),
        origin=origin,
        provider=prov.provider if prov else None,
        model=prov.model if prov else None,
        is_mock=bool(prov.is_mock) if prov else False,
        generated_at=(prov.generated_at or utcnow()) if prov and origin != "MANUALLY_EDITED" else None,
        execution_id=prov.execution_id if prov else None,
        stage_key=prov.stage_key if prov else None,
        item_id=prov.item_id if prov else None,
        source_input_version=prov.source_input_version if prov else None,
        previous_version_id=previous.id if previous else None,
        original_generation_version_id=original_id,
        edit_summary=edit_summary,
    )
    _activate(db, output, v)
    if v.original_generation_version_id is None and origin in ("AI_GENERATED", "MOCK_GENERATED", "REGENERATED"):
        v.original_generation_version_id = v.id
    prune(db, output)
    return v


def active_version(db: Session, output: Output) -> OutputVersion | None:
    if not output.active_version_id:
        return None
    return db.get(OutputVersion, output.active_version_id)


def create_output(
    db: Session,
    *,
    parent_type: str,
    parent_id: str,
    output_type: str,
    content: Any,
    prov: Provenance,
    item_key: str = "",
    position: int = 0,
    inputs: Any = None,
    content_status: str | None = None,
    is_demo: bool = False,
    validity: str = "VALID",
    validity_details: Any = None,
) -> tuple[Output, OutputVersion]:
    out = Output(
        parent_type=parent_type,
        parent_id=parent_id,
        output_type=output_type,
        item_key=item_key,
        position=position,
        inputs=None if inputs is None else canonical(inputs),
        content_status=content_status,
        generation_status="COMPLETED",
        is_demo=is_demo,
        validity=validity,
        validity_details=None if validity_details is None else canonical(validity_details),
    )
    db.add(out)
    db.flush()
    v = _new_version(db, out, content, prov.origin, prov, previous=None, original_id=None)
    return out, v


def upsert_generated(
    db: Session,
    *,
    parent_type: str,
    parent_id: str,
    output_type: str,
    content: Any,
    prov: Provenance,
    item_key: str = "",
    position: int = 0,
    inputs: Any = None,
    content_status: str | None = None,
    is_demo: bool = False,
    validity: str = "VALID",
    validity_details: Any = None,
    overwrite_edits: bool = True,
) -> tuple[Output, OutputVersion | None]:
    """Create the output, or add a REGENERATED version to an existing one.

    Returns (output, new_version or None if skipped because the active version
    is a manual edit and ``overwrite_edits`` is False).
    """
    out = db.execute(
        select(Output).where(
            Output.parent_type == parent_type,
            Output.parent_id == parent_id,
            Output.output_type == output_type,
            Output.item_key == item_key,
        )
    ).scalar_one_or_none()
    if out is None:
        return create_output(
            db, parent_type=parent_type, parent_id=parent_id, output_type=output_type, content=content,
            prov=prov, item_key=item_key, position=position, inputs=inputs, content_status=content_status,
            is_demo=is_demo, validity=validity, validity_details=validity_details,
        )
    cur = active_version(db, out)
    if cur is not None and cur.origin == "MANUALLY_EDITED" and not overwrite_edits:
        return out, None
    v = _new_version(db, out, content, "REGENERATED", prov, previous=cur, original_id=None)
    v.original_generation_version_id = v.id
    out.position = position
    if inputs is not None:
        out.inputs = canonical(inputs)
    out.generation_status = "COMPLETED"
    out.generation_error = None
    out.is_outdated = False
    out.outdated_reason = None
    out.is_discarded = False
    out.validity = validity
    out.validity_details = None if validity_details is None else canonical(validity_details)
    if content_status is not None:
        out.content_status = content_status
    return out, v


def check_expected(output: Output, expected_version: int | None) -> None:
    if expected_version is None:
        raise AppError(
            428,
            "PRECONDITION_REQUIRED",
            "Send If-Match (or expected_version) with the version you edited.",
            {"current_version": output.version_number},
        )
    if int(expected_version) != output.version_number:
        raise AppError(
            409,
            "VERSION_CONFLICT",
            f"This output changed (now version {output.version_number}); reload or reapply your edit.",
            {"current_version": output.version_number, "expected_version": int(expected_version)},
        )


def edit_output(
    db: Session,
    output: Output,
    new_content: Any,
    expected_version: int | None,
    edit_summary: str | None = None,
) -> OutputVersion | None:
    """Manual edit. Returns the new version, or None for a no-op edit."""
    check_expected(output, expected_version)
    cur = active_version(db, output)
    if cur is not None and cur.content_hash == content_hash(new_content):
        return None
    original = cur.original_generation_version_id if cur else None
    v = _new_version(
        db, output, new_content, "MANUALLY_EDITED", None, previous=cur, original_id=original,
        edit_summary=(edit_summary or "Edited by user")[:500],
    )
    if output.content_status in cs.RESET_ON_EDIT:
        output.status_history = cs.append_history(output.status_history, output.content_status, cs.DRAFT, "edited")
        output.content_status = cs.DRAFT
    return v


def restore_version(db: Session, output: Output, version_id: str, expected_version: int | None) -> OutputVersion:
    check_expected(output, expected_version)
    old = db.get(OutputVersion, version_id)
    if old is None or old.output_id != output.id:
        raise AppError(404, "NOT_FOUND", "Version not found for this output")
    cur = active_version(db, output)
    prov = Provenance(old.provider, old.model, old.is_mock, old.execution_id, old.stage_key, old.item_id,
                      old.source_input_version, old.generated_at)
    v = _new_version(
        db, output, json.loads(old.content), old.origin, prov if old.origin != "MANUALLY_EDITED" else None,
        previous=cur, original_id=old.original_generation_version_id,
        edit_summary=f"Restored from version {old.version_number}",
    )
    if output.content_status in cs.RESET_ON_EDIT:
        output.status_history = cs.append_history(output.status_history, output.content_status, cs.DRAFT, "restored")
        output.content_status = cs.DRAFT
    return v


def set_content_status(db: Session, output: Output, to: str) -> None:
    cs.check_transition(output.content_status, to)
    output.status_history = cs.append_history(output.status_history, output.content_status, to, "user")
    output.content_status = to


def prune(db: Session, output: Output) -> int:
    keep = get_settings().OUTPUT_VERSIONS_KEEP
    versions = db.execute(
        select(OutputVersion).where(OutputVersion.output_id == output.id).order_by(OutputVersion.version_number.desc())
    ).scalars().all()
    if len(versions) <= keep:
        return 0
    protected = {output.active_version_id}
    protected |= {v.original_generation_version_id for v in versions if v.original_generation_version_id}
    removed = 0
    for v in versions[keep:]:
        if v.id in protected:
            continue
        db.execute(
            update(OutputVersion).where(OutputVersion.previous_version_id == v.id).values(previous_version_id=None)
        )
        db.delete(v)
        removed += 1
    return removed


def provenance_label(v: OutputVersion | None, db: Session | None = None) -> str:
    """Human label; edited content is never presented as raw AI output."""
    if v is None:
        return "No content"
    if v.origin == "MANUALLY_EDITED":
        base = "Generated"
        if db is not None and v.original_generation_version_id:
            orig = db.get(OutputVersion, v.original_generation_version_id)
            if orig is not None:
                base = "Mock-generated" if orig.is_mock else "AI-generated"
        return f"{base}, edited by you"
    return "Mock-generated (not real AI)" if v.is_mock else f"AI-generated ({v.provider}/{v.model})"


def version_to_dict(v: OutputVersion) -> dict[str, Any]:
    return {
        "id": v.id,
        "version_number": v.version_number,
        "is_active": v.is_active,
        "origin": v.origin,
        "provider": v.provider,
        "model": v.model,
        "is_mock": v.is_mock,
        "generated_at": iso(v.generated_at),
        "execution_id": v.execution_id,
        "stage_key": v.stage_key,
        "item_id": v.item_id,
        "source_input_version": v.source_input_version,
        "previous_version_id": v.previous_version_id,
        "original_generation_version_id": v.original_generation_version_id,
        "edit_summary": v.edit_summary,
        "created_at": iso(v.created_at),
        "content": json.loads(v.content),
    }


def output_to_dict(db: Session, out: Output, include_versions: bool = False) -> dict[str, Any]:
    v = active_version(db, out)
    d: dict[str, Any] = {
        "id": out.id,
        "output_type": out.output_type,
        "item_key": out.item_key,
        "position": out.position,
        "inputs": json.loads(out.inputs) if out.inputs else None,
        "content": json.loads(out.content) if out.content else None,
        "version": out.version_number,
        "content_status": out.content_status,
        "generation_status": out.generation_status,
        "generation_error": out.generation_error,
        "is_outdated": out.is_outdated,
        "outdated_reason": out.outdated_reason,
        "validity": out.validity,
        "validity_details": json.loads(out.validity_details) if out.validity_details else None,
        "is_discarded": out.is_discarded,
        "is_demo": out.is_demo,
        "origin": v.origin if v else None,
        "provider": v.provider if v else None,
        "model": v.model if v else None,
        "is_mock": v.is_mock if v else None,
        "provenance_label": provenance_label(v, db),
        "updated_at": iso(out.updated_at),
    }
    if include_versions:
        vs = db.execute(
            select(OutputVersion).where(OutputVersion.output_id == out.id).order_by(OutputVersion.version_number.desc())
        ).scalars().all()
        d["versions"] = [version_to_dict(x) for x in vs]
    return d
