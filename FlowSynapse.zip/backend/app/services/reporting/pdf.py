"""PDF rendering (ReportLab). User/AI text is XML-escaped; long strings wrap;
empty data renders a visible note; chart failures produce a visible
'Section unavailable' note and a warning (COMPLETED_WITH_WARNINGS)."""
from __future__ import annotations

import io
import re
from typing import Any
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    Image as RLImage,
    KeepTogether,
    PageBreak,
    Paragraph as RLParagraph,
    SimpleDocTemplate,
    Spacer,
    Table as RLTable,
    TableStyle,
)

from .document import Bullets, Chart, Image, KeyValue, Paragraph, ReportDoc, Table
from .fonts import font_names, register_fonts

_ZW = "​"


def _wrap_long(text: str) -> str:
    # Allow breaks inside long URLs/tokens: insert zero-width spaces.
    def brk(m: re.Match[str]) -> str:
        s = m.group(0)
        return _ZW.join(s[i : i + 20] for i in range(0, len(s), 20))

    return re.sub(r"\S{40,}", brk, text)


def esc(value: Any, unicode_ok: bool = True) -> str:
    text = "" if value is None else str(value)
    if not unicode_ok:
        text = text.replace("₹", "INR ")
    return escape(_wrap_long(text)).replace("\n", "<br/>")


class PdfWarnings(list):  # type: ignore[type-arg]
    pass


def _styles() -> dict[str, ParagraphStyle]:
    reg, bold = font_names()
    base = getSampleStyleSheet()
    return {
        "title": ParagraphStyle("t", parent=base["Title"], fontName=bold, fontSize=20, leading=24),
        "subtitle": ParagraphStyle("st", parent=base["Normal"], fontName=reg, fontSize=11, leading=14, alignment=TA_CENTER),
        "h1": ParagraphStyle("h1", parent=base["Heading1"], fontName=bold, fontSize=14, leading=18, spaceBefore=8),
        "body": ParagraphStyle("b", parent=base["Normal"], fontName=reg, fontSize=9, leading=12),
        "cell": ParagraphStyle("c", parent=base["Normal"], fontName=reg, fontSize=8, leading=10),
        "cellh": ParagraphStyle("ch", parent=base["Normal"], fontName=bold, fontSize=8, leading=10),
        "note": ParagraphStyle("n", parent=base["Normal"], fontName=reg, fontSize=8, leading=10, textColor=colors.HexColor("#555555")),
        "warning": ParagraphStyle("w", parent=base["Normal"], fontName=bold, fontSize=9, leading=12, textColor=colors.HexColor("#9a3412")),
        "banner": ParagraphStyle("bn", parent=base["Normal"], fontName=bold, fontSize=10, leading=13, alignment=TA_CENTER,
                                 textColor=colors.white, backColor=colors.HexColor("#b45309"), borderPadding=4),
    }


def render_pdf(doc: ReportDoc, path: str, labels: list[str] | None = None) -> list[str]:
    """Render ``doc`` to ``path``. Returns warnings (non-essential failures)."""
    unicode_ok = register_fonts()
    st = _styles()
    warnings: list[str] = []
    width = A4[0] - 30 * mm
    story: list[Any] = []
    banners = list(dict.fromkeys((labels or []) + doc.labels))

    def P(text: Any, style: str = "body") -> RLParagraph:
        return RLParagraph(esc(text, unicode_ok), st[style])

    # Title page
    story.append(Spacer(1, 30 * mm))
    story.append(P(doc.title, "title"))
    if doc.subtitle:
        story.append(P(doc.subtitle, "subtitle"))
    story.append(Spacer(1, 6 * mm))
    for b in banners:
        story.append(P(b, "banner"))
        story.append(Spacer(1, 2 * mm))
    meta_rows = [("Identifier", doc.identifier)] + list(doc.meta)
    story.append(_kv_table(meta_rows, st, width, unicode_ok))
    story.append(PageBreak())

    for section in doc.sections:
        story.append(P(section.title, "h1"))
        if not section.blocks:
            story.append(P("No data for this section.", "note"))
        for block in section.blocks:
            story.extend(_block(block, st, width, unicode_ok, warnings))
            story.append(Spacer(1, 3 * mm))

    footer_text = " | ".join([doc.identifier] + banners[:2])

    def on_page(canvas: Any, _doc: Any) -> None:
        canvas.saveState()
        canvas.setFont(font_names()[0], 7)
        canvas.drawString(15 * mm, 8 * mm, (footer_text if unicode_ok else footer_text.replace("₹", "INR"))[:150])
        canvas.drawRightString(A4[0] - 15 * mm, 8 * mm, f"Page {canvas.getPageNumber()}")
        canvas.restoreState()

    SimpleDocTemplate(path, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=15 * mm,
                      bottomMargin=15 * mm, title=doc.title, author="FlowSynapse").build(
        story, onFirstPage=on_page, onLaterPages=on_page
    )
    return warnings


def _kv_table(rows: list[tuple[str, Any]], st: dict[str, ParagraphStyle], width: float, unicode_ok: bool) -> RLTable:
    data = [[RLParagraph(esc(k, unicode_ok), st["cellh"]), RLParagraph(esc(v, unicode_ok), st["cell"])] for k, v in rows]
    if not data:
        data = [[RLParagraph("No data", st["cell"]), ""]]
    t = RLTable(data, colWidths=[width * 0.3, width * 0.7])
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#cbd5e1")),
                           ("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#f1f5f9"))]))
    return t


def _block(block: Any, st: dict[str, ParagraphStyle], width: float, unicode_ok: bool, warnings: list[str]) -> list[Any]:
    if isinstance(block, Paragraph):
        return [RLParagraph(esc(block.text, unicode_ok), st.get(block.style, st["body"]))]
    if isinstance(block, Bullets):
        if not block.items:
            return [RLParagraph("None.", st["note"])]
        return [RLParagraph("• " + esc(i, unicode_ok), st["body"]) for i in block.items]
    if isinstance(block, KeyValue):
        return [_kv_table(block.rows, st, width, unicode_ok)]
    if isinstance(block, Table):
        if not block.rows:
            return [RLParagraph("No rows.", st["note"])]
        weights = block.col_widths or [1.0] * len(block.headers)
        total = sum(weights)
        cols = [width * w / total for w in weights]
        data = [[RLParagraph(esc(h, unicode_ok), st["cellh"]) for h in block.headers]]
        for row in block.rows:
            data.append([RLParagraph(esc(c, unicode_ok), st["cell"]) for c in row])
        t = RLTable(data, colWidths=cols, repeatRows=1)
        t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#cbd5e1")),
                               ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e2e8f0")),
                               ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        return [t]
    if isinstance(block, (Chart, Image)):
        try:
            png = block.render()
            img = RLImage(io.BytesIO(png))
            ratio = img.imageHeight / float(img.imageWidth or 1)
            w = min(width, 160 * mm)
            img.drawWidth, img.drawHeight = w, w * ratio
            if img.drawHeight > 200 * mm:
                img.drawHeight = 200 * mm
                img.drawWidth = img.drawHeight / ratio
            return [KeepTogether([RLParagraph(esc(block.title, unicode_ok), st["cellh"]), img])]
        except Exception as exc:
            if isinstance(block, Image) and block.essential:
                raise
            msg = f"Section unavailable: {block.title} could not be rendered ({type(exc).__name__})."
            warnings.append(msg)
            return [RLParagraph(esc(msg, unicode_ok), st["warning"])]
    return []
