"""Excel and CSV rendering with formula-injection neutralisation."""
from __future__ import annotations

import csv
import io
import re
import zipfile
from decimal import Decimal
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill

from .document import Dataset

FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")
_NUMERIC = re.compile(r"^-?\d+(\.\d+)?$")
_SHEET_BAD = re.compile(r"[\[\]\:\*\?\/\\]")


def neutralize(value: Any) -> Any:
    """Prefix risky strings with an apostrophe so spreadsheets never evaluate them.
    Plain negative numbers stay numeric-looking text (e.g. '-5' is data, kept)."""
    if value is None:
        return ""
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (int, float, Decimal)):
        return str(value)
    s = str(value)
    if s.startswith(FORMULA_PREFIXES) and not _NUMERIC.match(s):
        return "'" + s
    return s


def sheet_name(name: str, used: set[str]) -> str:
    base = _SHEET_BAD.sub("_", name)[:31] or "Sheet"
    candidate, i = base, 2
    while candidate.lower() in used:
        suffix = f" ({i})"
        candidate = base[: 31 - len(suffix)] + suffix
        i += 1
    used.add(candidate.lower())
    return candidate


def render_xlsx(path: str, datasets: list[Dataset], summary: list[tuple[str, Any]] | None = None) -> None:
    wb = Workbook()
    ws0 = wb.active
    used: set[str] = set()
    ws0.title = sheet_name("Summary", used)
    for k, v in summary or []:
        ws0.append([neutralize(k), neutralize(v)])
    ws0.column_dimensions["A"].width = 28
    ws0.column_dimensions["B"].width = 90
    header_fill = PatternFill("solid", fgColor="E2E8F0")
    for ds in datasets:
        if ds.name.lower() == "summary":
            ws = ws0
            if ws.max_row > 1:
                ws.append([])
        else:
            ws = wb.create_sheet(sheet_name(ds.name, used))
        ws.append([neutralize(h) for h in ds.headers])
        for c in ws[ws.max_row]:
            c.font = Font(bold=True)
            c.fill = header_fill
        if not ds.rows:
            ws.append(["(no rows)"])
        for row in ds.rows:
            ws.append([neutralize(v) for v in row])
        for i, _h in enumerate(ds.headers, start=1):
            letter = ws.cell(row=1, column=i).column_letter
            ws.column_dimensions[letter].width = 24 if i > 1 else 18
        for r in ws.iter_rows(min_row=2):
            for c in r:
                c.alignment = Alignment(wrap_text=True, vertical="top")
    wb.save(path)


def csv_bytes(ds: Dataset, bom: bool = True) -> bytes:
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\r\n")
    w.writerow([neutralize(h) for h in ds.headers])
    for row in ds.rows:
        w.writerow([neutralize(v) for v in row])
    data = buf.getvalue().encode("utf-8")
    return (b"\xef\xbb\xbf" + data) if bom else data


def render_csv(path: str, ds: Dataset, bom: bool = True) -> None:
    with open(path, "wb") as f:
        f.write(csv_bytes(ds, bom))


def render_zip(path: str, files: dict[str, bytes]) -> None:
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for name, data in files.items():
            z.writestr(name, data)
