"""A small renderer-independent report model shared by all modules."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Union


@dataclass
class Paragraph:
    text: str
    style: str = "body"  # body | note | warning


@dataclass
class Bullets:
    items: list[str]


@dataclass
class KeyValue:
    rows: list[tuple[str, Any]]


@dataclass
class Table:
    headers: list[str]
    rows: list[list[Any]]
    col_widths: list[float] | None = None  # relative weights


@dataclass
class Chart:
    """Non-essential: a failure yields a visible 'Section unavailable' note."""

    title: str
    render: Callable[[], bytes]  # returns PNG bytes


@dataclass
class Image:
    title: str
    render: Callable[[], bytes]  # PNG bytes
    essential: bool = False


Block = Union[Paragraph, Bullets, KeyValue, Table, Chart, Image]


@dataclass
class Section:
    title: str
    blocks: list[Block] = field(default_factory=list)


@dataclass
class ReportDoc:
    title: str
    identifier: str
    subtitle: str = ""
    labels: list[str] = field(default_factory=list)  # banners e.g. DEMONSTRATION DATA
    meta: list[tuple[str, Any]] = field(default_factory=list)
    sections: list[Section] = field(default_factory=list)


@dataclass
class Dataset:
    name: str  # sheet / csv dataset name
    headers: list[str]
    rows: list[list[Any]]


@dataclass
class ExportData:
    """What a module collects inside one read transaction (snapshot)."""

    doc: ReportDoc | None
    datasets: list[Dataset]
    download_base: str
    source_version: str | None = None
    source_versions: dict[str, Any] = field(default_factory=dict)
    is_demo: bool = False
    is_stale: bool = False
    labels: list[str] = field(default_factory=list)
    extra_files: dict[str, bytes] = field(default_factory=dict)  # e.g. svg/markdown


DEMO_BANNER = "DEMONSTRATION DATA - synthetic example, not a real campaign"
MOCK_BANNER = "Demo/Mock mode - not real AI output"
STALE_BANNER = "STALE - some outputs are outdated; regenerate before use"
