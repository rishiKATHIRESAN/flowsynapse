"""Bundled DejaVu Sans registration (renders ₹). Falls back to Helvetica and the
text "INR" if registration fails (logged)."""
from __future__ import annotations

import logging
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

log = logging.getLogger("flowsynapse.reporting")

FONT_DIR = Path(__file__).resolve().parent / "fonts"
_state = {"registered": None}  # type: dict[str, bool | None]

REGULAR = "DejaVuSans"
BOLD = "DejaVuSans-Bold"

CURRENCY_EXPONENT = {"INR": 2, "USD": 2, "EUR": 2, "GBP": 2, "JPY": 0, "AED": 2, "SGD": 2, "AUD": 2, "CAD": 2}
CURRENCY_SYMBOL = {"INR": "₹", "USD": "$", "EUR": "€", "GBP": "£", "JPY": "¥"}


def register_fonts(force_fail: bool = False) -> bool:
    if _state["registered"] is not None and not force_fail:
        return bool(_state["registered"])
    try:
        if force_fail:
            raise OSError("forced failure (test)")
        from reportlab.lib.fonts import addMapping
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont

        pdfmetrics.registerFont(TTFont(REGULAR, str(FONT_DIR / "DejaVuSans.ttf")))
        pdfmetrics.registerFont(TTFont(BOLD, str(FONT_DIR / "DejaVuSans-Bold.ttf")))
        addMapping(REGULAR, 0, 0, REGULAR)
        addMapping(REGULAR, 1, 0, BOLD)
        _state["registered"] = True
    except Exception as exc:
        log.warning("Unicode font registration failed (%s); PDFs will show 'INR' instead of the rupee sign", exc)
        _state["registered"] = False
    return bool(_state["registered"])


def reset_fonts_state() -> None:
    _state["registered"] = None


def font_names() -> tuple[str, str]:
    return (REGULAR, BOLD) if register_fonts() else ("Helvetica", "Helvetica-Bold")


def symbol(currency: str, unicode_ok: bool = True) -> str:
    cur = currency.upper()
    if cur == "INR" and not unicode_ok:
        return "INR "
    sym = CURRENCY_SYMBOL.get(cur)
    return sym if sym else f"{cur} "


def format_money(amount: Decimal | str | int, currency: str = "INR", unicode_ok: bool = True) -> str:
    """Display formatting only (never used for arithmetic). Indian grouping for INR."""
    d = Decimal(str(amount))
    exp = CURRENCY_EXPONENT.get(currency.upper(), 2)
    q = Decimal(1).scaleb(-exp)
    d = d.quantize(q, rounding=ROUND_HALF_UP)
    neg = d < 0
    d = abs(d)
    whole, _, frac = f"{d:f}".partition(".")
    if currency.upper() == "INR" and len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        whole = ",".join(groups + [tail])
    else:
        whole = f"{int(whole):,}"
    text = whole if (exp == 0 or frac.strip("0") == "") else f"{whole}.{frac}"
    return ("-" if neg else "") + symbol(currency, unicode_ok) + text
