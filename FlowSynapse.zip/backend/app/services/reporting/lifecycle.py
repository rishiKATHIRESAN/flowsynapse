"""Export lifecycle (master prompt 2.7).

1. write txn: FileExport row PENDING;
2. read txn: the module collects all data in ONE transaction (WAL snapshot);
3. render to a temp file inside the export directory (no DB transaction open);
4. ``os.replace`` to a unique server-generated name; write txn: COMPLETED /
   COMPLETED_WITH_WARNINGS, or FAILED with no file left behind.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import unicodedata
import uuid
from datetime import timedelta
from pathlib import Path
from typing import Any, Callable
from urllib.parse import quote

from fastapi.responses import FileResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ...config import get_settings
from ...database import new_session, session_scope
from ...models.exports import FileExport
from ...utils.clock import iso, utcnow
from ...utils.errors import AppError
from .document import ExportData
from .pdf import render_pdf
from .tabular import render_csv, render_xlsx, render_zip

log = logging.getLogger("flowsynapse.exports")

MEDIA = {
    "pdf": "application/pdf",
    "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "csv": "text/csv; charset=utf-8",
    "zip": "application/zip",
    "svg": "image/svg+xml",
    "md": "text/markdown; charset=utf-8",
    "txt": "text/plain; charset=utf-8",
}

TEST_HOOKS: dict[str, Callable[..., Any]] = {}

_ILLEGAL = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def exports_dir() -> Path:
    d = get_settings().exports_dir
    d.mkdir(parents=True, exist_ok=True)
    return d.resolve()


def safe_path(name: str) -> Path:
    """Resolve a server-generated name inside the export directory only."""
    base = exports_dir()
    p = (base / name).resolve()
    if base not in p.parents:
        raise AppError(400, "INVALID_PATH", "Export path escapes the export directory")
    return p


def sanitize_download_name(name: str, max_len: int = 120) -> str:
    name = unicodedata.normalize("NFKC", name)
    name = _ILLEGAL.sub("_", name).strip(" .")
    name = re.sub(r"\s+", "_", name)
    name = re.sub(r"_+", "_", name)
    if not name or name.upper().split(".")[0] in {"CON", "PRN", "AUX", "NUL", "COM1", "LPT1"}:
        name = "export" + (name and "_" + name)
    if len(name) > max_len:
        stem, dot, ext = name.rpartition(".")
        if dot and len(ext) <= 5:
            name = stem[: max_len - len(ext) - 1] + "." + ext
        else:
            name = name[:max_len]
    return name


def content_disposition(download_name: str) -> str:
    ascii_name = download_name.encode("ascii", "ignore").decode() or "export"
    ascii_name = ascii_name.replace('"', "")
    return f"attachment; filename=\"{ascii_name}\"; filename*=UTF-8''{quote(download_name)}"


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def generate_export(
    *,
    module: str,
    parent_type: str,
    parent_id: str,
    fmt: str,
    collect: Callable[[Session], ExportData],
    dataset: str | None = None,
) -> FileExport:
    fmt = fmt.lower()
    if fmt not in MEDIA:
        raise AppError(422, "UNSUPPORTED_FORMAT", f"Unsupported export format {fmt}")
    with session_scope(immediate=True) as db:
        row = FileExport(module=module, parent_type=parent_type, parent_id=parent_id, format=fmt, dataset=dataset,
                         status="PENDING")
        db.add(row)
        db.flush()
        export_id = row.id

    # Snapshot read: one transaction for all data.
    db = new_session()
    try:
        db.begin()
        data = collect(db)
        db.rollback()
    except AppError:
        db.rollback()
        db.close()
        _fail(export_id, "Export refused")
        raise
    except Exception as exc:
        db.rollback()
        db.close()
        _fail(export_id, f"Could not read data: {type(exc).__name__}")
        raise AppError(500, "EXPORT_FAILED", "The export could not be generated (data read failed).") from exc
    db.close()

    ts = utcnow().strftime("%Y%m%dT%H%M%S")
    final_name = f"{module}_{parent_id[:12]}_{ts}_{uuid.uuid4().hex[:8]}.{fmt}"
    final = safe_path(final_name)
    tmp = safe_path(f".tmp_{uuid.uuid4().hex}.{fmt}")
    warnings: list[str] = []
    labels = list(dict.fromkeys(data.labels))
    try:
        hook = TEST_HOOKS.get("render")
        if hook:
            hook(fmt)
        if fmt == "pdf":
            if data.doc is None:
                raise AppError(422, "UNSUPPORTED_FORMAT", "PDF is not available for this export")
            warnings = render_pdf(data.doc, str(tmp), labels)
        elif fmt == "xlsx":
            summary = [("Banner", lb) for lb in labels]
            if data.doc:
                summary = [("Report", data.doc.title), ("Identifier", data.doc.identifier)] + summary + list(data.doc.meta)
            render_xlsx(str(tmp), data.datasets, summary)
        elif fmt == "csv":
            ds = data.datasets[0] if dataset is None else next((d for d in data.datasets if d.name == dataset), None)
            if ds is None:
                raise AppError(422, "UNKNOWN_DATASET", f"Unknown dataset {dataset}. Available: {[d.name for d in data.datasets]}")
            if labels:
                ds = type(ds)(ds.name, ds.headers, ds.rows + [[f"# {lb}"] + [""] * (len(ds.headers) - 1) for lb in labels])
            render_csv(str(tmp), ds)
        elif fmt == "zip":
            from .tabular import csv_bytes

            files = {f"{_slug(d.name)}.csv": csv_bytes(d) for d in data.datasets}
            files.update(data.extra_files)
            if labels:
                files["README.txt"] = ("\r\n".join(labels) + "\r\n").encode("utf-8")
            render_zip(str(tmp), files)
        else:  # svg / md / txt from extra_files
            payload = data.extra_files.get(fmt)
            if payload is None:
                raise AppError(422, "UNSUPPORTED_FORMAT", f"{fmt} is not available for this export")
            tmp.write_bytes(payload)
        os.replace(tmp, final)
    except AppError:
        _cleanup(tmp)
        _fail(export_id, "Export refused")
        raise
    except Exception as exc:
        _cleanup(tmp)
        _cleanup(final)
        log.exception("export %s failed", export_id)
        _fail(export_id, f"Rendering failed: {type(exc).__name__}")
        raise AppError(500, "EXPORT_FAILED", "The export could not be generated; no file was produced.") from exc
    finally:
        _cleanup(tmp)

    with session_scope(immediate=True) as db:
        row = db.get(FileExport, export_id)
        assert row is not None
        row.status = "COMPLETED_WITH_WARNINGS" if warnings else "COMPLETED"
        row.file_name = final_name
        row.download_name = sanitize_download_name(f"{data.download_base}.{fmt}")
        row.content_hash = _sha256(final)
        row.size_bytes = final.stat().st_size
        row.source_version = data.source_version
        row.source_versions = json.dumps(data.source_versions, default=str)
        row.warnings = json.dumps(warnings) if warnings else None
        row.is_demo = data.is_demo
        row.is_stale = data.is_stale
        row.finished_at = utcnow()
        row.last_accessed_at = utcnow()
        db.flush()
        db.expunge(row)
        return row


def _slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", s.lower()).strip("_") or "data"


def _cleanup(p: Path) -> None:
    try:
        if p.exists():
            p.unlink()
    except OSError:
        log.warning("could not remove %s", p)


def _fail(export_id: str, message: str) -> None:
    with session_scope(immediate=True) as db:
        row = db.get(FileExport, export_id)
        if row is not None:
            row.status = "FAILED"
            row.error = message[:500]
            row.finished_at = utcnow()


def file_response(row: FileExport) -> FileResponse:
    if row.status not in ("COMPLETED", "COMPLETED_WITH_WARNINGS") or not row.file_name:
        raise AppError(409, "EXPORT_NOT_AVAILABLE", f"Export is {row.status}; regenerate it.")
    path = safe_path(row.file_name)
    if row.purged_at is not None or not path.exists():
        raise AppError(410, "EXPORT_PURGED", "This export file was removed by retention. Regenerate it.",
                       {"action": "regenerate"})
    with session_scope() as db:
        r = db.get(FileExport, row.id)
        if r is not None:
            r.last_accessed_at = utcnow()
    headers = {"Content-Disposition": content_disposition(row.download_name or row.file_name),
               "X-Export-Id": row.id}
    if row.source_version:
        headers["X-Source-Version"] = row.source_version
    return FileResponse(path, media_type=MEDIA[row.format], headers=headers)


def export_to_dict(row: FileExport) -> dict[str, Any]:
    return {
        "id": row.id,
        "module": row.module,
        "parent_type": row.parent_type,
        "parent_id": row.parent_id,
        "format": row.format,
        "dataset": row.dataset,
        "status": row.status,
        "download_name": row.download_name,
        "size_bytes": row.size_bytes,
        "content_hash": row.content_hash,
        "source_version": row.source_version,
        "source_versions": json.loads(row.source_versions) if row.source_versions else {},
        "warnings": json.loads(row.warnings) if row.warnings else [],
        "error": row.error,
        "is_demo": row.is_demo,
        "is_stale": row.is_stale,
        "purged": row.purged_at is not None,
        "created_at": iso(row.created_at),
        "finished_at": iso(row.finished_at),
    }


def cleanup_exports() -> int:
    """Delete files older than EXPORT_RETENTION_DAYS, skipping recently
    accessed files and those referenced by non-terminal rows. Orphan temp
    files are removed. Deletion failures are logged and retried next run."""
    s = get_settings()
    now = utcnow()
    cutoff = now - timedelta(days=s.EXPORT_RETENTION_DAYS)
    recent = now - timedelta(minutes=10)
    removed = 0
    d = exports_dir()
    with session_scope(immediate=True) as db:
        rows = db.execute(
            select(FileExport).where(FileExport.purged_at.is_(None), FileExport.file_name.is_not(None))
        ).scalars().all()
        for r in rows:
            if r.status == "PENDING" or r.created_at > cutoff:
                continue
            if r.last_accessed_at and r.last_accessed_at > recent:
                continue
            p = d / str(r.file_name)
            try:
                if p.exists():
                    p.unlink()
                r.purged_at = now
                removed += 1
            except OSError:
                log.warning("could not delete export %s (in use?); will retry", p)
        pending_names = {r.file_name for r in rows if r.status == "PENDING"}
    for tmp in d.glob(".tmp_*"):
        if tmp.name in pending_names:
            continue
        try:
            age = now.timestamp() - tmp.stat().st_mtime
            if age > 3600:
                tmp.unlink()
        except OSError:
            pass
    return removed
