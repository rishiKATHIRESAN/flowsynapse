"""matplotlib charts rendered to in-memory PNG (Agg backend, figures closed)."""
from __future__ import annotations

import io
from typing import Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from .fonts import FONT_DIR  # noqa: E402

_PALETTE = ["#2563eb", "#f59e0b", "#10b981", "#ef4444", "#8b5cf6", "#06b6d4", "#84cc16"]


def _font() -> None:
    from matplotlib import font_manager

    path = FONT_DIR / "DejaVuSans.ttf"
    if path.exists():
        try:
            font_manager.fontManager.addfont(str(path))
            plt.rcParams["font.family"] = "DejaVu Sans"
        except Exception:
            pass


def bar_chart(labels: Sequence[str], values: Sequence[float], title: str, ylabel: str = "") -> bytes:
    _font()
    fig, ax = plt.subplots(figsize=(6.4, 3.2), dpi=110)
    try:
        if not labels:
            ax.text(0.5, 0.5, "No data", ha="center", va="center")
            ax.axis("off")
        else:
            ax.bar(list(labels), list(values), color=_PALETTE[: len(labels)] or _PALETTE)
            ax.set_ylabel(ylabel)
            for i, v in enumerate(values):
                ax.annotate(f"{v:,.0f}", (i, v), ha="center", va="bottom", fontsize=8)
            ax.spines[["top", "right"]].set_visible(False)
        ax.set_title(title, fontsize=10)
        buf = io.BytesIO()
        fig.tight_layout()
        fig.savefig(buf, format="png")
        return buf.getvalue()
    finally:
        plt.close(fig)


def pie_chart(labels: Sequence[str], values: Sequence[float], title: str) -> bytes:
    _font()
    fig, ax = plt.subplots(figsize=(4.6, 3.2), dpi=110)
    try:
        if not values or sum(values) <= 0:
            ax.text(0.5, 0.5, "No data", ha="center", va="center")
            ax.axis("off")
        else:
            ax.pie(list(values), labels=list(labels), autopct="%1.0f%%", colors=_PALETTE[: len(values)], textprops={"fontsize": 8})
        ax.set_title(title, fontsize=10)
        buf = io.BytesIO()
        fig.tight_layout()
        fig.savefig(buf, format="png")
        return buf.getvalue()
    finally:
        plt.close(fig)
