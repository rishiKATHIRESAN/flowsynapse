"""Importing this module registers every module's job handler, mock templates,
dashboard counters and demo-data loaders."""
from __future__ import annotations

from .campaign import orchestrator  # noqa: F401
from .campaign import demo as campaign_demo  # noqa: F401
