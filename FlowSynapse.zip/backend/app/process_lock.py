"""Exclusive OS-level process lock (master prompt 2.6).

Uses ``msvcrt.locking`` on Windows and ``fcntl.flock`` on POSIX. The OS releases
the lock automatically when the process dies, so a leftover lock *file* without
a held lock is safe to acquire. A lock held by a live process is never stolen.
"""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# Windows byte-range locks are mandatory, so lock a byte beyond the info
# payload; other processes can still read who holds the lock.
_LOCK_OFFSET = 1 << 16


class LockHeldError(Exception):
    def __init__(self, info: dict[str, Any] | None) -> None:
        self.info = info or {}
        pid = self.info.get("pid", "unknown")
        super().__init__(f"Another FlowSynapse backend (PID {pid}) is using this database.")


def read_lock_info(path: Path) -> dict[str, Any] | None:
    try:
        with open(path, "rb") as f:
            raw = f.read(4096).split(b"\x00")[0].strip()
        return json.loads(raw.decode("utf-8")) if raw else None
    except (OSError, ValueError):
        return None


class ProcessLock:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._fd: int | None = None

    @property
    def held(self) -> bool:
        return self._fd is not None

    def acquire(self, port: int | None = None) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(str(self.path), os.O_RDWR | os.O_CREAT, 0o644)
        try:
            if sys.platform == "win32":
                import msvcrt

                os.lseek(fd, _LOCK_OFFSET, os.SEEK_SET)
                msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            os.close(fd)
            raise LockHeldError(read_lock_info(self.path)) from None
        info = {
            "pid": os.getpid(),
            "started_at": datetime.now(timezone.utc).isoformat(),
            "port": port,
        }
        os.lseek(fd, 0, os.SEEK_SET)
        payload = json.dumps(info).encode("utf-8")
        os.write(fd, payload + b"\x00" * max(0, 256 - len(payload)))
        self._fd = fd

    def release(self) -> None:
        if self._fd is None:
            return
        fd = self._fd
        self._fd = None
        try:
            if sys.platform == "win32":
                import msvcrt

                os.lseek(fd, _LOCK_OFFSET, os.SEEK_SET)
                msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(fd, fcntl.LOCK_UN)
        except OSError:  # pragma: no cover - already released by OS
            pass
        finally:
            os.close(fd)

    def __enter__(self) -> "ProcessLock":
        self.acquire()
        return self

    def __exit__(self, *exc: object) -> None:
        self.release()
