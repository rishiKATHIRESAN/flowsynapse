"""Safe schema migration (master prompt 2.4).

Procedure for an existing, non-empty database with pending revisions:
disk check -> backup (SQLite backup API) -> verify backup -> migrate a working
copy -> verify the copy -> atomic swap -> drift check. Any failure leaves the
original database byte-identical and raises :class:`MigrationError` naming the
failing step, the original error, the backup location and a recovery command.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import shutil
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from alembic import command
from alembic.autogenerate import compare_metadata
from alembic.config import Config
from alembic.migration import MigrationContext
from alembic.script import ScriptDirectory
from sqlalchemy import create_engine, pool

from .config import BACKEND_DIR, Settings, get_settings

log = logging.getLogger("flowsynapse.migrations")

BACKUP_KEEP = 5


class MigrationError(Exception):
    def __init__(self, step: str, original: str, backup: Path | None = None, recovery: str = "") -> None:
        self.step = step
        self.original = original
        self.backup = backup
        self.recovery = recovery
        parts = [f"Migration failed at step '{step}': {original}."]
        parts.append("The original database was left unchanged.")
        if backup:
            parts.append(f"Verified backup: {backup}.")
        if recovery:
            parts.append(f"Recovery: {recovery}")
        super().__init__(" ".join(parts))


class NewerDatabaseError(Exception):
    pass


class PendingMigrationsError(Exception):
    pass


@dataclass
class MigrationResult:
    action: str  # "fresh" | "upgraded" | "up_to_date"
    from_revision: str | None
    to_revision: str
    backup: Path | None = None
    drift: list[str] = field(default_factory=list)


# Test hooks: name -> callable raising to simulate a failure at that step.
TEST_HOOKS: dict[str, Callable[[], None]] = {}


def _hook(name: str) -> None:
    fn = TEST_HOOKS.get(name)
    if fn:
        fn()


# ---------------------------------------------------------------------------
# Alembic helpers
# ---------------------------------------------------------------------------

def alembic_config(db_url: str | None = None) -> Config:
    cfg = Config(str(BACKEND_DIR / "alembic.ini"))
    cfg.set_main_option("script_location", str(BACKEND_DIR / "alembic"))
    if db_url:
        cfg.attributes["db_url"] = db_url
    return cfg


def script_directory() -> ScriptDirectory:
    return ScriptDirectory.from_config(alembic_config())


def code_heads() -> list[str]:
    return list(script_directory().get_heads())


def code_head() -> str:
    heads = code_heads()
    if len(heads) != 1:
        raise RuntimeError(f"Expected a single Alembic head, found {heads}")
    return heads[0]


def known_revisions() -> set[str]:
    return {r.revision for r in script_directory().walk_revisions()}


def _url(path: Path) -> str:
    return "sqlite:///" + path.as_posix()


def db_revision(path: Path) -> str | None:
    if not path.exists():
        return None
    con = sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True)
    try:
        row = con.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='alembic_version'"
        ).fetchone()
        if not row:
            return None
        r = con.execute("SELECT version_num FROM alembic_version").fetchone()
        return r[0] if r else None
    finally:
        con.close()


def _user_tables(con: sqlite3.Connection) -> list[str]:
    rows = con.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
    ).fetchall()
    return [r[0] for r in rows]


def row_counts(path: Path) -> dict[str, int]:
    con = sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True)
    try:
        return {t: con.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0] for t in _user_tables(con)}
    finally:
        con.close()


def is_empty_db(path: Path) -> bool:
    if not path.exists() or path.stat().st_size == 0:
        return True
    con = sqlite3.connect(str(path))
    try:
        return len(_user_tables(con)) == 0
    finally:
        con.close()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def checkpoint(path: Path) -> None:
    """Fold the WAL into the main file so file-level operations are safe."""
    if not path.exists():
        return
    con = sqlite3.connect(str(path))
    try:
        con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    finally:
        con.close()


def sqlite_backup(src: Path, dst: Path) -> None:
    """Online backup API copy (safe for WAL databases)."""
    if dst.exists():
        dst.unlink()
    s = sqlite3.connect(str(src))
    d = sqlite3.connect(str(dst))
    try:
        s.backup(d)
    finally:
        d.close()
        s.close()
    _remove_sidecars(dst)


def _remove_sidecars(path: Path) -> None:
    for suffix in ("-wal", "-shm", "-journal"):
        p = Path(str(path) + suffix)
        if p.exists():
            try:
                p.unlink()
            except OSError:  # pragma: no cover - windows file in use
                log.warning("could not remove %s", p)


def integrity_ok(path: Path) -> bool:
    con = sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True)
    try:
        return con.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    finally:
        con.close()


def fk_violations(path: Path) -> list[tuple[Any, ...]]:
    con = sqlite3.connect(str(path))
    try:
        return list(con.execute("PRAGMA foreign_key_check").fetchall())
    finally:
        con.close()


def free_disk_bytes(path: Path) -> int:
    return shutil.disk_usage(str(path.parent)).free


def required_index_names() -> set[str]:
    from .database import Base
    import app.models  # noqa: F401

    names: set[str] = set()
    for table in Base.metadata.tables.values():
        for ix in table.indexes:
            if ix.name:
                names.add(str(ix.name))
    return names


def existing_index_names(path: Path) -> set[str]:
    con = sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True)
    try:
        return {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='index'")}
    finally:
        con.close()


def intentional_row_changes(from_rev: str | None, to_rev: str) -> set[str]:
    out: set[str] = set()
    for rev in script_directory().iterate_revisions(to_rev, from_rev or "base"):
        mod = rev.module
        out.update(getattr(mod, "INTENTIONAL_ROW_CHANGES", []) or [])
    return out


def check_drift(path: Path) -> list[str]:
    """Compare model metadata with the migrated schema (no diff expected)."""
    from .database import Base
    import app.models  # noqa: F401

    eng = create_engine(_url(path), poolclass=pool.NullPool)
    try:
        with eng.connect() as conn:
            mc = MigrationContext.configure(conn, opts={"render_as_batch": True})
            diffs = compare_metadata(mc, Base.metadata)
    finally:
        eng.dispose()
    return [repr(d) for d in diffs]


def _run_upgrade(path: Path, target: str = "head") -> None:
    command.upgrade(alembic_config(_url(path)), target)


# ---------------------------------------------------------------------------
# Backups
# ---------------------------------------------------------------------------

def _backup_dir(settings: Settings) -> Path:
    d = settings.backups_dir
    d.mkdir(parents=True, exist_ok=True)
    return d


def make_backup(db_path: Path, settings: Settings, label: str) -> Path:
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    dst = _backup_dir(settings) / f"flowsynapse_{ts}_{label}.db"
    sqlite_backup(db_path, dst)
    manifest = {
        "source": str(db_path),
        "source_revision": db_revision(db_path),
        "sha256": sha256_file(dst),
        "row_counts": row_counts(dst),
        "size": dst.stat().st_size,
        "created_at": ts,
    }
    Path(str(dst) + ".manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return dst


def verify_backup(backup: Path, expected_revision: str | None, expected_counts: dict[str, int] | None) -> None:
    _hook("verify_backup")
    if not integrity_ok(backup):
        raise RuntimeError("backup integrity_check failed")
    if db_revision(backup) != expected_revision:
        raise RuntimeError("backup revision differs from source")
    manifest_path = Path(str(backup) + ".manifest.json")
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("sha256") != sha256_file(backup):
            raise RuntimeError("backup checksum does not match manifest")
    if expected_counts is not None and row_counts(backup) != expected_counts:
        raise RuntimeError("backup row counts differ from source")


def prune_backups(settings: Settings, keep: int = BACKUP_KEEP) -> list[Path]:
    d = settings.backups_dir
    if not d.exists():
        return []
    backups = sorted(d.glob("flowsynapse_*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
    removed = []
    for old in backups[keep:]:
        try:
            old.unlink()
            mf = Path(str(old) + ".manifest.json")
            if mf.exists():
                mf.unlink()
            removed.append(old)
        except OSError:  # pragma: no cover
            log.warning("could not prune backup %s", old)
    return removed


def cleanup_leftovers(db_path: Path) -> list[Path]:
    removed = []
    for p in db_path.parent.glob(db_path.name + ".migrating*"):
        try:
            p.unlink()
            removed.append(p)
        except OSError:  # pragma: no cover
            log.warning("could not remove leftover %s", p)
    return removed


# ---------------------------------------------------------------------------
# Main procedure
# ---------------------------------------------------------------------------

def pending(db_path: Path) -> bool:
    if is_empty_db(db_path):
        return True
    return db_revision(db_path) != code_head()


def safe_migrate(settings: Settings | None = None, db_path: Path | None = None) -> MigrationResult:
    settings = settings or get_settings()
    db_path = db_path or settings.db_path
    db_path.parent.mkdir(parents=True, exist_ok=True)
    head = code_head()
    recovery_cmd = "python -m app.cli restore-backup <backup-file>  (see README 'Restoring a backup')"

    cleanup_leftovers(db_path)

    if is_empty_db(db_path):
        _run_upgrade(db_path)
        return MigrationResult("fresh", None, head, drift=check_drift(db_path))

    current = db_revision(db_path)
    if current is not None and current not in known_revisions():
        raise NewerDatabaseError(
            f"Database revision {current} is newer than (or unknown to) this code (head {head}). "
            "Nothing was changed. Upgrade FlowSynapse or restore a backup."
        )
    if current == head:
        return MigrationResult("up_to_date", current, head, drift=check_drift(db_path))

    # 1. Disk space
    checkpoint(db_path)
    size = db_path.stat().st_size
    need = 2 * size + settings.MIN_FREE_DISK_MB * 1024 * 1024
    try:
        _hook("disk_check")
        free = free_disk_bytes(db_path)
    except Exception as exc:
        raise MigrationError("disk_check", str(exc), None, "Free disk space and retry.") from exc
    if free < need:
        raise MigrationError(
            "disk_check",
            f"insufficient free disk space ({free // (1024 * 1024)} MB free, {need // (1024 * 1024)} MB required)",
            None,
            "Free disk space and start again.",
        )

    pre_counts = row_counts(db_path)
    # 2. Backup
    try:
        _hook("backup")
        backup = make_backup(db_path, settings, f"pre_{head}")
    except Exception as exc:
        raise MigrationError("backup", str(exc), None, "Check the data directory is writable.") from exc
    # 3. Verify backup
    try:
        verify_backup(backup, current, pre_counts)
    except Exception as exc:
        raise MigrationError("verify_backup", str(exc), None, "Investigate disk health; no migration was attempted.") from exc

    # 4. Migrate a working copy
    work = db_path.with_name(db_path.name + ".migrating")
    try:
        sqlite_backup(db_path, work)
        _hook("migrate")
        _run_upgrade(work)
        checkpoint(work)
        _remove_sidecars(work)
        # 5. Verify the migrated copy
        _hook("verify_migrated")
        if not integrity_ok(work):
            raise RuntimeError("integrity_check on migrated copy failed")
        fk = fk_violations(work)
        if fk:
            raise RuntimeError(f"foreign_key_check reported {len(fk)} violation(s)")
        if db_revision(work) != head:
            raise RuntimeError("migrated copy is not at head revision")
        post_counts = row_counts(work)
        allowed = intentional_row_changes(current, head)
        for table, n in pre_counts.items():
            if table == "alembic_version" or table in allowed:
                continue
            if post_counts.get(table) != n:
                raise RuntimeError(f"row count changed for table {table}: {n} -> {post_counts.get(table)}")
        missing = required_index_names() - existing_index_names(work)
        if missing:
            raise RuntimeError(f"missing indexes after migration: {sorted(missing)}")
    except MigrationError:
        cleanup_leftovers(db_path)
        raise
    except Exception as exc:
        cleanup_leftovers(db_path)
        raise MigrationError("migrate", str(exc), backup, recovery_cmd) from exc

    # 6. Swap atomically
    try:
        _hook("swap")
        checkpoint(db_path)
        _remove_sidecars(db_path)
        os.replace(work, db_path)
    except Exception as exc:
        cleanup_leftovers(db_path)
        raise MigrationError("swap", str(exc), backup, recovery_cmd) from exc

    prune_backups(settings)
    drift = check_drift(db_path)
    if drift:
        log.warning("schema drift detected after migration: %s", drift)
    return MigrationResult("upgraded", current, head, backup=backup, drift=drift)


def restore_backup(backup: Path, settings: Settings | None = None) -> Path:
    """Verify a backup and swap it in, keeping a safety backup of the current DB."""
    settings = settings or get_settings()
    db_path = settings.db_path
    if not backup.exists():
        raise FileNotFoundError(f"backup not found: {backup}")
    rev = db_revision(backup)
    verify_backup(backup, rev, None)
    manifest_path = Path(str(backup) + ".manifest.json")
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("row_counts") and manifest["row_counts"] != row_counts(backup):
            raise RuntimeError("backup row counts do not match its manifest")
    safety = None
    if db_path.exists() and not is_empty_db(db_path):
        checkpoint(db_path)
        safety = make_backup(db_path, settings, "pre_restore")
    tmp = db_path.with_name(db_path.name + ".restoring")
    sqlite_backup(backup, tmp)
    if not integrity_ok(tmp):
        tmp.unlink()
        raise RuntimeError("restored copy failed integrity_check")
    _remove_sidecars(db_path)
    os.replace(tmp, db_path)
    return safety or db_path
