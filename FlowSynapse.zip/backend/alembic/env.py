"""Alembic environment bound to the FlowSynapse metadata."""
from __future__ import annotations

from alembic import context
from sqlalchemy import create_engine, pool

from app.database import Base
import app.models  # noqa: F401  (populate metadata)

config = context.config
target_metadata = Base.metadata


def _url() -> str:
    url = config.attributes.get("db_url") or config.get_main_option("sqlalchemy.url")
    if not url:
        from app.config import get_settings

        url = get_settings().database_url
    return url


def run_migrations_offline() -> None:
    context.configure(
        url=_url(),
        target_metadata=target_metadata,
        literal_binds=True,
        render_as_batch=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connection = config.attributes.get("connection")
    if connection is not None:
        context.configure(connection=connection, target_metadata=target_metadata, render_as_batch=True)
        with context.begin_transaction():
            context.run_migrations()
        return
    engine = create_engine(_url(), poolclass=pool.NullPool)
    with engine.connect() as conn:
        # Foreign keys OFF while batch operations recreate tables; checked afterwards.
        conn.exec_driver_sql("PRAGMA foreign_keys=OFF")
        conn.commit()
        context.configure(connection=conn, target_metadata=target_metadata, render_as_batch=True)
        with context.begin_transaction():
            context.run_migrations()
    engine.dispose()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
