"""phase 4 outputs and versions

Revision ID: 0004_outputs
Revises: 0003_jobs
Create Date: 2026-10-21 12:19:42.716287
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

import app.models.base  # noqa: F401  (custom column types)


revision: str = '0004_outputs'
down_revision: Union[str, None] = '0003_jobs'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# Tables whose pre-existing row counts this revision intentionally changes
# (checked by the safe-migration verifier). Empty = no intentional change.
INTENTIONAL_ROW_CHANGES: list[str] = []


def upgrade() -> None:

    op.create_table('outputs',
    sa.Column('id', sa.String(length=32), nullable=False),
    sa.Column('parent_type', sa.String(length=32), nullable=False),
    sa.Column('parent_id', sa.String(length=32), nullable=False),
    sa.Column('output_type', sa.String(length=48), nullable=False),
    sa.Column('item_key', sa.String(length=64), nullable=False),
    sa.Column('position', sa.Integer(), nullable=False),
    sa.Column('inputs', sa.Text(), nullable=True),
    sa.Column('content', sa.Text(), nullable=True),
    sa.Column('active_version_id', sa.String(length=32), nullable=True),
    sa.Column('version_number', sa.Integer(), nullable=False),
    sa.Column('content_status', sa.String(length=24), nullable=True),
    sa.Column('generation_status', sa.String(length=16), nullable=False),
    sa.Column('generation_error', sa.Text(), nullable=True),
    sa.Column('is_outdated', sa.Boolean(), nullable=False),
    sa.Column('outdated_reason', sa.Text(), nullable=True),
    sa.Column('validity', sa.String(length=16), nullable=False),
    sa.Column('validity_details', sa.Text(), nullable=True),
    sa.Column('is_discarded', sa.Boolean(), nullable=False),
    sa.Column('is_demo', sa.Boolean(), nullable=False),
    sa.Column('status_history', sa.Text(), nullable=True),
    sa.Column('created_at', app.models.base.UTCDateTime(), nullable=False),
    sa.Column('updated_at', app.models.base.UTCDateTime(), nullable=False),
    sa.CheckConstraint("content_status IS NULL OR content_status IN ('DRAFT','READY_FOR_REVIEW','NEEDS_REVISION','READY_TO_EXPORT')", name=op.f('ck_outputs_content_status_valid')),
    sa.CheckConstraint("generation_status IN ('PENDING','RUNNING','COMPLETED','FAILED')", name=op.f('ck_outputs_generation_status_valid')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_outputs')),
    sa.UniqueConstraint('parent_type', 'parent_id', 'output_type', 'item_key', name='uq_outputs_identity')
    )
    with op.batch_alter_table('outputs', schema=None) as batch_op:
        batch_op.create_index('ix_outputs_parent', ['parent_type', 'parent_id', 'output_type'], unique=False)

    op.create_table('output_versions',
    sa.Column('id', sa.String(length=32), nullable=False),
    sa.Column('output_id', sa.String(length=32), nullable=False),
    sa.Column('output_type', sa.String(length=48), nullable=False),
    sa.Column('parent_type', sa.String(length=32), nullable=False),
    sa.Column('parent_id', sa.String(length=32), nullable=False),
    sa.Column('version_number', sa.Integer(), nullable=False),
    sa.Column('is_active', sa.Boolean(), nullable=False),
    sa.Column('content', sa.Text(), nullable=False),
    sa.Column('content_hash', sa.String(length=64), nullable=False),
    sa.Column('origin', sa.String(length=24), nullable=False),
    sa.Column('provider', sa.String(length=32), nullable=True),
    sa.Column('model', sa.String(length=128), nullable=True),
    sa.Column('is_mock', sa.Boolean(), nullable=False),
    sa.Column('generated_at', app.models.base.UTCDateTime(), nullable=True),
    sa.Column('execution_id', sa.String(length=32), nullable=True),
    sa.Column('stage_key', sa.String(length=48), nullable=True),
    sa.Column('item_id', sa.String(length=64), nullable=True),
    sa.Column('source_input_version', sa.String(length=64), nullable=True),
    sa.Column('previous_version_id', sa.String(length=32), nullable=True),
    sa.Column('original_generation_version_id', sa.String(length=32), nullable=True),
    sa.Column('edit_summary', sa.Text(), nullable=True),
    sa.Column('created_at', app.models.base.UTCDateTime(), nullable=False),
    sa.CheckConstraint("origin IN ('AI_GENERATED','MOCK_GENERATED','MANUALLY_EDITED','REGENERATED')", name=op.f('ck_output_versions_origin_valid')),
    sa.ForeignKeyConstraint(['execution_id'], ['executions.id'], name=op.f('fk_output_versions_execution_id_executions'), ondelete='SET NULL'),
    sa.ForeignKeyConstraint(['original_generation_version_id'], ['output_versions.id'], name=op.f('fk_output_versions_original_generation_version_id_output_versions'), ondelete='SET NULL'),
    sa.ForeignKeyConstraint(['output_id'], ['outputs.id'], name=op.f('fk_output_versions_output_id_outputs'), ondelete='CASCADE'),
    sa.ForeignKeyConstraint(['previous_version_id'], ['output_versions.id'], name=op.f('fk_output_versions_previous_version_id_output_versions'), ondelete='SET NULL'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_output_versions')),
    sa.UniqueConstraint('output_id', 'version_number', name='uq_output_versions_number')
    )
    with op.batch_alter_table('output_versions', schema=None) as batch_op:
        batch_op.create_index('ix_output_versions_execution', ['execution_id'], unique=False)
        batch_op.create_index('ix_output_versions_output', ['output_id', 'version_number'], unique=False)
        batch_op.create_index('uq_output_versions_one_active', ['output_id'], unique=True, sqlite_where=sa.text('is_active = 1'))




def downgrade() -> None:
    raise NotImplementedError("Downgrades are not supported; restore a backup instead.")
