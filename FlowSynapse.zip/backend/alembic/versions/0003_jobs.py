"""phase 3 job engine

Revision ID: 0003_jobs
Revises: 0002_idempotency
Create Date: 2026-10-21 11:56:33.896745
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

import app.models.base  # noqa: F401  (custom column types)


revision: str = '0003_jobs'
down_revision: Union[str, None] = '0002_idempotency'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# Tables whose pre-existing row counts this revision intentionally changes
# (checked by the safe-migration verifier). Empty = no intentional change.
INTENTIONAL_ROW_CHANGES: list[str] = []


def upgrade() -> None:

    op.create_table('executions',
    sa.Column('id', sa.String(length=32), nullable=False),
    sa.Column('parent_type', sa.String(length=32), nullable=False),
    sa.Column('parent_id', sa.String(length=32), nullable=False),
    sa.Column('scope', sa.String(length=24), nullable=False),
    sa.Column('status', sa.String(length=32), nullable=False),
    sa.Column('retry_of_execution_id', sa.String(length=32), nullable=True),
    sa.Column('attempt_number', sa.Integer(), nullable=False),
    sa.Column('params', sa.Text(), nullable=False),
    sa.Column('claimed_by', sa.String(length=64), nullable=True),
    sa.Column('claim_token', sa.String(length=32), nullable=True),
    sa.Column('claimed_at', app.models.base.UTCDateTime(), nullable=True),
    sa.Column('heartbeat_at', app.models.base.UTCDateTime(), nullable=True),
    sa.Column('cancel_requested', sa.Boolean(), nullable=False),
    sa.Column('error_code', sa.String(length=64), nullable=True),
    sa.Column('error_message', sa.Text(), nullable=True),
    sa.Column('retryable', sa.Boolean(), nullable=True),
    sa.Column('ai_calls_used', sa.Integer(), nullable=False),
    sa.Column('provider', sa.String(length=32), nullable=True),
    sa.Column('model', sa.String(length=128), nullable=True),
    sa.Column('is_mock', sa.Boolean(), nullable=False),
    sa.Column('is_demo', sa.Boolean(), nullable=False),
    sa.Column('max_duration_seconds', sa.Integer(), nullable=True),
    sa.Column('warnings_count', sa.Integer(), nullable=False),
    sa.Column('created_at', app.models.base.UTCDateTime(), nullable=False),
    sa.Column('started_at', app.models.base.UTCDateTime(), nullable=True),
    sa.Column('finished_at', app.models.base.UTCDateTime(), nullable=True),
    sa.Column('row_version', sa.Integer(), nullable=False),
    sa.CheckConstraint("scope IN ('FULL','STAGE_RETRY','STAGE_REGENERATE','OUTPUT_REGENERATE','ITEM_RETRY')", name=op.f('ck_executions_scope_valid')),
    sa.CheckConstraint("status IN ('PENDING','RUNNING','COMPLETED','COMPLETED_WITH_WARNINGS','FAILED','CANCELLED')", name=op.f('ck_executions_status_valid')),
    sa.ForeignKeyConstraint(['retry_of_execution_id'], ['executions.id'], name=op.f('fk_executions_retry_of_execution_id_executions'), ondelete='SET NULL'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_executions'))
    )
    with op.batch_alter_table('executions', schema=None) as batch_op:
        batch_op.create_index('ix_executions_parent', ['parent_type', 'parent_id', 'created_at'], unique=False)
        batch_op.create_index('ix_executions_status', ['status'], unique=False)
        batch_op.create_index('uq_executions_one_active', ['parent_type', 'parent_id'], unique=True, sqlite_where=sa.text("status IN ('PENDING','RUNNING')"))

    op.create_table('execution_stages',
    sa.Column('id', sa.String(length=32), nullable=False),
    sa.Column('execution_id', sa.String(length=32), nullable=False),
    sa.Column('stage_key', sa.String(length=48), nullable=False),
    sa.Column('item_id', sa.String(length=64), nullable=False),
    sa.Column('position', sa.Integer(), nullable=False),
    sa.Column('status', sa.String(length=24), nullable=False),
    sa.Column('required', sa.Boolean(), nullable=False),
    sa.Column('carried_from_stage_id', sa.String(length=32), nullable=True),
    sa.Column('output_ref', sa.Text(), nullable=True),
    sa.Column('input_snapshot', sa.Text(), nullable=True),
    sa.Column('error_code', sa.String(length=64), nullable=True),
    sa.Column('error_message', sa.Text(), nullable=True),
    sa.Column('retryable', sa.Boolean(), nullable=True),
    sa.Column('attempt_count', sa.Integer(), nullable=False),
    sa.Column('ai_calls_used', sa.Integer(), nullable=False),
    sa.Column('provider', sa.String(length=32), nullable=True),
    sa.Column('model', sa.String(length=128), nullable=True),
    sa.Column('is_mock', sa.Boolean(), nullable=True),
    sa.Column('warnings', sa.Text(), nullable=True),
    sa.Column('started_at', app.models.base.UTCDateTime(), nullable=True),
    sa.Column('finished_at', app.models.base.UTCDateTime(), nullable=True),
    sa.CheckConstraint("status IN ('PENDING','RUNNING','COMPLETED','FAILED','CANCELLED','SKIPPED','CARRIED_FORWARD')", name=op.f('ck_execution_stages_status_valid')),
    sa.ForeignKeyConstraint(['carried_from_stage_id'], ['execution_stages.id'], name=op.f('fk_execution_stages_carried_from_stage_id_execution_stages'), ondelete='SET NULL'),
    sa.ForeignKeyConstraint(['execution_id'], ['executions.id'], name=op.f('fk_execution_stages_execution_id_executions'), ondelete='CASCADE'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_execution_stages')),
    sa.UniqueConstraint('execution_id', 'stage_key', 'item_id', name='uq_execution_stages_key')
    )
    with op.batch_alter_table('execution_stages', schema=None) as batch_op:
        batch_op.create_index('ix_execution_stages_execution', ['execution_id', 'position'], unique=False)
        batch_op.create_index('ix_execution_stages_stage_key', ['stage_key'], unique=False)

    op.create_table('workflow_runs',
    sa.Column('id', sa.String(length=32), nullable=False),
    sa.Column('module', sa.String(length=32), nullable=False),
    sa.Column('parent_type', sa.String(length=32), nullable=False),
    sa.Column('parent_id', sa.String(length=32), nullable=False),
    sa.Column('execution_id', sa.String(length=32), nullable=False),
    sa.Column('title', sa.String(length=200), nullable=False),
    sa.Column('status', sa.String(length=32), nullable=False),
    sa.Column('scope', sa.String(length=24), nullable=False),
    sa.Column('provider', sa.String(length=32), nullable=True),
    sa.Column('is_mock', sa.Boolean(), nullable=False),
    sa.Column('is_demo', sa.Boolean(), nullable=False),
    sa.Column('created_at', app.models.base.UTCDateTime(), nullable=False),
    sa.Column('started_at', app.models.base.UTCDateTime(), nullable=True),
    sa.Column('finished_at', app.models.base.UTCDateTime(), nullable=True),
    sa.ForeignKeyConstraint(['execution_id'], ['executions.id'], name=op.f('fk_workflow_runs_execution_id_executions'), ondelete='CASCADE'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_workflow_runs')),
    sa.UniqueConstraint('execution_id', name=op.f('uq_workflow_runs_execution_id'))
    )
    with op.batch_alter_table('workflow_runs', schema=None) as batch_op:
        batch_op.create_index('ix_workflow_runs_created', ['created_at'], unique=False)
        batch_op.create_index('ix_workflow_runs_module', ['module'], unique=False)




def downgrade() -> None:
    raise NotImplementedError("Downgrades are not supported; restore a backup instead.")
