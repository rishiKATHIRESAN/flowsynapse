"""phase 5 file exports

Revision ID: 0005_exports
Revises: 0004_outputs
Create Date: 2026-10-21 12:25:56.041267
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

import app.models.base  # noqa: F401  (custom column types)


revision: str = '0005_exports'
down_revision: Union[str, None] = '0004_outputs'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# Tables whose pre-existing row counts this revision intentionally changes
# (checked by the safe-migration verifier). Empty = no intentional change.
INTENTIONAL_ROW_CHANGES: list[str] = []


def upgrade() -> None:

    op.create_table('file_exports',
    sa.Column('id', sa.String(length=32), nullable=False),
    sa.Column('module', sa.String(length=32), nullable=False),
    sa.Column('parent_type', sa.String(length=32), nullable=False),
    sa.Column('parent_id', sa.String(length=32), nullable=False),
    sa.Column('format', sa.String(length=8), nullable=False),
    sa.Column('dataset', sa.String(length=48), nullable=True),
    sa.Column('status', sa.String(length=32), nullable=False),
    sa.Column('file_name', sa.String(length=200), nullable=True),
    sa.Column('download_name', sa.String(length=200), nullable=True),
    sa.Column('content_hash', sa.String(length=64), nullable=True),
    sa.Column('size_bytes', sa.Integer(), nullable=True),
    sa.Column('source_version', sa.String(length=64), nullable=True),
    sa.Column('source_versions', sa.Text(), nullable=True),
    sa.Column('warnings', sa.Text(), nullable=True),
    sa.Column('error', sa.Text(), nullable=True),
    sa.Column('is_demo', sa.Boolean(), nullable=False),
    sa.Column('is_stale', sa.Boolean(), nullable=False),
    sa.Column('created_at', app.models.base.UTCDateTime(), nullable=False),
    sa.Column('finished_at', app.models.base.UTCDateTime(), nullable=True),
    sa.Column('last_accessed_at', app.models.base.UTCDateTime(), nullable=True),
    sa.Column('purged_at', app.models.base.UTCDateTime(), nullable=True),
    sa.CheckConstraint("status IN ('PENDING','COMPLETED','COMPLETED_WITH_WARNINGS','FAILED')", name=op.f('ck_file_exports_status_valid')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_file_exports'))
    )
    with op.batch_alter_table('file_exports', schema=None) as batch_op:
        batch_op.create_index('ix_file_exports_parent', ['parent_type', 'parent_id', 'created_at'], unique=False)




def downgrade() -> None:
    raise NotImplementedError("Downgrades are not supported; restore a backup instead.")
