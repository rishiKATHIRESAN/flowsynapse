"""phase 2 idempotency keys

Revision ID: 0002_idempotency
Revises: 0001_baseline
Create Date: 2026-10-21 11:48:14.295251
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

import app.models.base  # noqa: F401  (custom column types)


revision: str = '0002_idempotency'
down_revision: Union[str, None] = '0001_baseline'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# Tables whose pre-existing row counts this revision intentionally changes
# (checked by the safe-migration verifier). Empty = no intentional change.
INTENTIONAL_ROW_CHANGES: list[str] = []


def upgrade() -> None:

    op.create_table('idempotency_keys',
    sa.Column('id', sa.String(length=32), nullable=False),
    sa.Column('key', sa.String(length=128), nullable=False),
    sa.Column('scope', sa.String(length=512), nullable=False),
    sa.Column('operation', sa.String(length=128), nullable=False),
    sa.Column('request_fingerprint', sa.String(length=64), nullable=False),
    sa.Column('state', sa.String(length=16), nullable=False),
    sa.Column('response_status', sa.Integer(), nullable=True),
    sa.Column('response_body', sa.Text(), nullable=True),
    sa.Column('resource_type', sa.String(length=64), nullable=True),
    sa.Column('resource_id', sa.String(length=64), nullable=True),
    sa.Column('created_at', app.models.base.UTCDateTime(), nullable=False),
    sa.Column('expires_at', app.models.base.UTCDateTime(), nullable=False),
    sa.CheckConstraint("state IN ('IN_PROGRESS','COMPLETED')", name=op.f('ck_idempotency_keys_state_valid')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_idempotency_keys')),
    sa.UniqueConstraint('scope', 'key', name='uq_idempotency_keys_scope_key')
    )
    with op.batch_alter_table('idempotency_keys', schema=None) as batch_op:
        batch_op.create_index('ix_idempotency_keys_expires_at', ['expires_at'], unique=False)




def downgrade() -> None:
    raise NotImplementedError("Downgrades are not supported; restore a backup instead.")
