"""phase 6 campaigns

Revision ID: 0006_campaigns
Revises: 0005_exports
Create Date: 2026-10-21 12:41:43.451737
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

import app.models.base  # noqa: F401  (custom column types)


revision: str = '0006_campaigns'
down_revision: Union[str, None] = '0005_exports'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# Tables whose pre-existing row counts this revision intentionally changes
# (checked by the safe-migration verifier). Empty = no intentional change.
INTENTIONAL_ROW_CHANGES: list[str] = []


def upgrade() -> None:

    op.create_table('campaigns',
    sa.Column('id', sa.String(length=32), nullable=False),
    sa.Column('identifier', sa.String(length=32), nullable=False),
    sa.Column('name', sa.String(length=200), nullable=False),
    sa.Column('brief_original', sa.Text(), nullable=False),
    sa.Column('brief_normalized', sa.Text(), nullable=True),
    sa.Column('assumptions', sa.Text(), nullable=True),
    sa.Column('brief_valid', sa.Boolean(), nullable=False),
    sa.Column('validation', sa.Text(), nullable=True),
    sa.Column('content_version', sa.Integer(), nullable=False),
    sa.Column('brief_version', sa.Integer(), nullable=False),
    sa.Column('is_demo', sa.Boolean(), nullable=False),
    sa.Column('demo_key', sa.String(length=64), nullable=True),
    sa.Column('website_context', sa.Text(), nullable=True),
    sa.Column('created_at', app.models.base.UTCDateTime(), nullable=False),
    sa.Column('updated_at', app.models.base.UTCDateTime(), nullable=False),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_campaigns')),
    sa.UniqueConstraint('identifier', name=op.f('uq_campaigns_identifier'))
    )
    with op.batch_alter_table('campaigns', schema=None) as batch_op:
        batch_op.create_index('ix_campaigns_demo_key', ['demo_key'], unique=True)
        batch_op.create_index('ix_campaigns_updated', ['updated_at'], unique=False)

    op.create_table('campaign_findings',
    sa.Column('id', sa.String(length=32), nullable=False),
    sa.Column('campaign_id', sa.String(length=32), nullable=False),
    sa.Column('execution_id', sa.String(length=32), nullable=True),
    sa.Column('rule_id', sa.String(length=48), nullable=False),
    sa.Column('severity', sa.String(length=16), nullable=False),
    sa.Column('category', sa.String(length=48), nullable=False),
    sa.Column('description', sa.Text(), nullable=False),
    sa.Column('evidence', sa.Text(), nullable=True),
    sa.Column('field', sa.String(length=200), nullable=True),
    sa.Column('recommended_correction', sa.Text(), nullable=True),
    sa.Column('blocks_completion', sa.Boolean(), nullable=False),
    sa.Column('source', sa.String(length=16), nullable=False),
    sa.Column('created_at', app.models.base.UTCDateTime(), nullable=False),
    sa.CheckConstraint("severity IN ('BLOCKER','WARNING','INFO')", name=op.f('ck_campaign_findings_severity_valid')),
    sa.ForeignKeyConstraint(['campaign_id'], ['campaigns.id'], name=op.f('fk_campaign_findings_campaign_id_campaigns'), ondelete='CASCADE'),
    sa.ForeignKeyConstraint(['execution_id'], ['executions.id'], name=op.f('fk_campaign_findings_execution_id_executions'), ondelete='SET NULL'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_campaign_findings'))
    )
    with op.batch_alter_table('campaign_findings', schema=None) as batch_op:
        batch_op.create_index('ix_campaign_findings_campaign', ['campaign_id'], unique=False)

    op.create_table('campaign_stage_states',
    sa.Column('campaign_id', sa.String(length=32), nullable=False),
    sa.Column('stage_key', sa.String(length=48), nullable=False),
    sa.Column('is_outdated', sa.Boolean(), nullable=False),
    sa.Column('outdated_reason', sa.Text(), nullable=True),
    sa.Column('outdated_at', app.models.base.UTCDateTime(), nullable=True),
    sa.Column('current_stage_id', sa.String(length=32), nullable=True),
    sa.Column('completed_at', app.models.base.UTCDateTime(), nullable=True),
    sa.ForeignKeyConstraint(['campaign_id'], ['campaigns.id'], name=op.f('fk_campaign_stage_states_campaign_id_campaigns'), ondelete='CASCADE'),
    sa.PrimaryKeyConstraint('campaign_id', 'stage_key', name=op.f('pk_campaign_stage_states'))
    )



def downgrade() -> None:
    raise NotImplementedError("Downgrades are not supported; restore a backup instead.")
