# FlowSynapse — Implementation Checklist

Source of truth for scope: `FlowSynapse_Master_Prompt_v6.md` (sections referenced as §N).
Progress narrative, commands and results live in `docs/BUILD_STATE.md`.
The **Verification status** column of the traceability matrix below is **generated**
by `scripts/run_traceability` from real test results — never edit it by hand.

## Phases (§18) — module order: Campaign → Funnel → SEO → Website → Blog → Social

| Phase | Scope | Depends | Gate | State |
|---|---|---|---|---|
| 1 | Foundation: toolchain check, repo, `.env.example`, skeletons, `/api/health`, proxy+CORS, Alembic baseline, setup/start scripts with port checks | — | fresh setup; UI shows connected; migration fresh/re-run tests | DONE |
| 2 | Core platform: error format, logging+redaction, Host/Origin/body protections, idempotency, process lock + startup order + shutdown | 1 | idempotency + process-model tests | DONE |
| 3 | Job engine: state machine, claiming, heartbeat/watchdog, cancellation, recovery, retry-as-new-execution, `WorkflowRun` | 2 | §15.13 job-engine tests | DONE |
| 4 | AI layer: provider abstraction, MockProvider + failure plans, structured output, retry budget, `OutputVersion`, health checks, settings API | 3 | provider/budget/redaction/versioning tests | DONE |
| 5 | Frontend shell + shared services: nav, API client, shared components, dashboard shell, settings page, content status, health-claims scanner, reporting + `₹` font + export lifecycle, demo-data framework | 4 | tsc + build + frontend tests; export-reliability tests | DONE |
| 6 | Campaign vertical slice: models+migration, brief form + demo brief, validation, normalization, dates, stages 1–3 via job engine, timeline UI, restart persistence, one CSV export | 5 | demo-brief validation; slice journey tests | TODO |
| 7 | Campaign stages 4–5, output editing with versions, dependency graph + invalidation | 6 | dependency/invalidation/versioning/edit tests | TODO |
| 8 | Campaign stages 6–7 (Google/Meta, char limits) | 7 | stage + limit tests | TODO |
| 9 | Shared social-content service + stages 8–10 (social, UTM, budget) | 8 | budget/date/UTM/cadence tests | TODO |
| 10 | Stages 11–12: QA, pack, PDF/XLSX/CSV, history, retry/cancel UI | 9 | **M1 gate** | TODO |
| 11 | Funnel models, config, graph model, validation V01–V14, layout, integrity | 5 | rules + integrity tests | TODO |
| 12 | Funnel execution (7 stages), node content, dependency, campaign context, exports | 10, 11 | execution/export tests | TODO |
| 13 | Funnel interactive diagram + list view + editing UI | 12 | **M2 gate** | TODO |
| 14 | Crawl infra: fetcher, SSRF guard, robots/sitemap, demo site + allowlist, evidence model + coverage | 5 | SSRF/limit/allowlist tests | TODO |
| 15 | SEO rules, report, exports, triage, linked retry runs | 14 | **M3 gate** | TODO |
| 16 | Website intelligence analyzer, report, exports | 14 | **M4 gate** | TODO |
| 17 | Bulk blog generator | 5 | **M5 gate** | TODO |
| 18 | Social module UI: cadence, calendar editing, exports | 9 | **M6 gate** | TODO |
| 19 | Optional Ollama + Gemini providers (mocked HTTP) | 4 | provider error tests | TODO |
| 20 | Integration: dashboard real data, contracts, offline demo, responsive/a11y, docs + `check_docs` | 10,13,15–18 | smoke test | TODO |
| 21 | Full verification, clean clone, OS record, traceability clean, packaging | 20 | §15.10 + all module gates | TODO |

Every phase ends with: phase tests → `scripts/check --fast` → Alembic revision + upgrade test (if schema changed) → `scripts/run_traceability` → update this file and `docs/BUILD_STATE.md` → git commit.

## Requirements traceability matrix (§17.1)

Test kinds: `unit`, `integration`, `api`, `e2e`, `frontend`, `negative` (a negative-path test). Required kinds are `+`-separated.
Status values are generated: `VERIFIED`, `STALE — re-run`, `FAILING`, `NOT RUN`, `TESTING GAP`, `INSUFFICIENT COVERAGE (missing: …)`.

<!-- TRACE:BEGIN -->
| Requirement ID | Description | Module | Implementation files | API endpoint(s) | Model(s) | Required test kinds | Acceptance criteria | Verification status (generated) | Known defects |
|---|---|---|---|---|---|---|---|---|---|
| FS-SYS-001 | `/api/health` identity payload; CORS for dev origins; Vite proxy | SYS | app/api/health.py, app/main.py, frontend/vite.config.ts | GET /api/health | — | api | §2.1 | VERIFIED |  |
| FS-SYS-002 | Frontend connection indicator driven by health identity (foreign service detection) | SYS | frontend/src/api/health.ts, components/ConnectionIndicator.tsx | GET /api/health | — | frontend | §2.1 | VERIFIED |  |
| FS-SYS-003 | Standard error format incl. remapped 422 field errors; no stack traces | SYS | app/utils/errors.py | all | — | api+negative | §2.2 | VERIFIED |  |
| FS-SYS-004 | Structured logging, request ids, rotation, secret redaction | SYS | app/logging_setup.py, app/utils/redact.py | — | — | unit | §2.2, §3.4 | VERIFIED |  |
| FS-SYS-005 | Host header, Origin, content-type and body-size protections | SYS | app/middleware.py | all | — | api+negative | §14 | VERIFIED |  |
| FS-SYS-006 | Idempotency keys (replay, in-progress 409, reuse 422, failure frees key, expiry/cleanup) | SYS | app/services/idempotency.py | POST create/start | IdempotencyKey | integration+api+negative | §2.5 | INSUFFICIENT COVERAGE (missing: api) |  |
| FS-SYS-007 | Process lock, startup order, controlled shutdown with WAL checkpoint | SYS | app/process_lock.py, app/runtime.py | — | — | integration+negative | §2.6 | VERIFIED |  |
| FS-SYS-008 | Restart recovery: RUNNING→FAILED/INTERRUPTED, PENDING stays claimable | SYS | app/services/jobs/recovery.py | — | Execution | integration | §2.6 | VERIFIED |  |
| FS-SYS-010 | Alembic baseline; fresh create; idempotent re-run; single head; no drift | SYS | backend/alembic/, app/migrations.py | — | all | unit+integration | §2.4 | VERIFIED |  |
| FS-SYS-011 | Safe migration copy–verify–migrate–verify–swap with failure injection, disk check, newer-revision refusal, leftovers, upgrade from snapshots | SYS | app/migrations.py | — | all | integration+negative | §2.4, §15.14 | VERIFIED |  |
| FS-SYS-012 | Restore-backup round-trip | SYS | app/migrations.py, scripts/restore_backup.py | — | — | integration | §2.4 | VERIFIED |  |
| FS-SYS-020 | Job state machine: exhaustive execution and stage transition tables | SYS | app/services/jobs/state_machine.py | — | Execution, ExecutionStage | unit | §2.3 | VERIFIED |  |
| FS-SYS-021 | Claiming, one-active-execution (DB partial index), queue cap 429 | SYS | app/services/jobs/engine.py | POST …/executions | Execution | integration+api+negative | §2.3 | INSUFFICIENT COVERAGE (missing: api) |  |
| FS-SYS-022 | Heartbeats, stale detection watchdog, max duration (fake clock) | SYS | app/services/jobs/worker.py | — | Execution | integration | §2.3 | VERIFIED |  |
| FS-SYS-023 | Cancellation races (before claim, mid-stage, after final commit) | SYS | app/services/jobs/engine.py | POST …/cancel | Execution | integration+negative | §2.3 | VERIFIED |  |
| FS-SYS-024 | Terminal immutability; retry creates new execution with CARRIED_FORWARD stages | SYS | app/services/jobs/engine.py | POST …/retry | Execution, ExecutionStage | integration | §2.3, §22.1 | VERIFIED |  |
| FS-SYS-025 | Commit boundaries; worker exception → FAILED with earlier stages intact | SYS | app/services/jobs/worker.py | — | Execution | integration+negative | §2.3 | VERIFIED |  |
| FS-SYS-026 | SQLite contention: lock retry → retryable error; no write txn across provider call | SYS | app/database.py, worker | — | — | integration | §2.3 | VERIFIED |  |
| FS-SYS-027 | WorkflowRun execution history across modules | SYS | app/services/jobs/history.py | GET /api/dashboard/runs | WorkflowRun | api | §4 | INSUFFICIENT COVERAGE (missing: api) |  |
| FS-SYS-030 | Provider abstraction; deterministic MockProvider built from inputs; failure tokens and plans | SYS | app/ai/* | — | — | unit | §3, §3.3 | VERIFIED |  |
| FS-SYS-031 | Structured output validation with one repair attempt; prompt-injection delimiting | SYS | app/ai/runner.py | — | — | unit+negative | §3 | VERIFIED |  |
| FS-SYS-032 | Retry budget: stage/execution AI-call caps; AI_BUDGET_EXHAUSTED; JOB_MAX_ATTEMPTS | SYS | app/ai/runner.py | — | Execution | unit+integration | §3.4 | INSUFFICIENT COVERAGE (missing: integration) |  |
| FS-SYS-033 | Provider health checks + settings API | SYS | app/api/settings.py | GET/PUT /api/settings, POST /api/settings/test-provider | AppSetting | api | §3.4 | VERIFIED |  |
| FS-SYS-034 | Secret never appears in responses, logs or DB across provider error paths | SYS | app/utils/redact.py, providers | — | — | integration+negative | §3.4 | VERIFIED |  |
| FS-SYS-035 | OutputVersion provenance, edit/regenerate/restore, retention, one-active constraint | SYS | app/services/content/versioning.py | — | OutputVersion | integration+negative | §3.2, §3.5, §15.15 | VERIFIED |  |
| FS-SYS-036 | Optimistic concurrency (ETag / If-Match → 409 VERSION_CONFLICT) | SYS | versioning + module APIs | PATCH outputs | OutputVersion | api+negative | §3.5 | INSUFFICIENT COVERAGE (missing: api) |  |
| FS-SYS-037 | Ollama and Gemini providers (mocked HTTP): not running, model missing, 401/403/429/5xx, timeout | SYS | app/ai/ollama_provider.py, gemini_provider.py | — | — | unit+negative | §3, Phase 19 | VERIFIED |  |
| FS-SYS-040 | Shared content status model (every allowed/disallowed pair) | SYS | app/services/content/content_status.py | PATCH …/status | — | unit+negative | §4.1 | VERIFIED |  |
| FS-SYS-041 | Health-claims scanner (configurable lists, `is_healthcare` detection) | SYS | app/services/content/health_claims.py | — | — | unit | §5.1 | VERIFIED |  |
| FS-SYS-042 | Deterministic similarity check | SYS | app/services/content/similarity.py | — | — | unit | §5.3 | VERIFIED |  |
| FS-SYS-043 | Export lifecycle: temp+replace, FAILED leaves no file, path safety, ₹ font/INR fallback, formula injection, retention, 410 | SYS | app/services/reporting/* | GET …/export.* | FileExport | integration+negative | §2.7 | VERIFIED |  |
| FS-SYS-044 | Demo-data framework: idempotent seed, safe removal, refusal with real dependents, keep-as-own | SYS | app/services/demo.py | POST/DELETE /api/demo-data | all is_demo | integration+negative | §3.6 | TESTING GAP |  |
| FS-SYS-045 | List pagination (limit/offset), search/filter | SYS | app/api/* | list endpoints | — | api | §2.2 | NOT STARTED |  |
| FS-SYS-050 | Frontend shell: sidebar/dashboard in catalogue order, error boundary, shared components, unsaved-change warning | SYS | frontend/src/components, layout | — | — | frontend | §4, §11 | VERIFIED |  |
| FS-SYS-051 | Dashboard shows real counts/runs only; demo exclusion toggle | SYS | app/api/dashboard.py, pages/Dashboard.tsx | GET /api/dashboard | — | api+frontend | §4 | INSUFFICIENT COVERAGE (missing: api) |  |
| FS-SYS-052 | Settings page (provider, test provider, demo data controls) | SYS | pages/Settings.tsx | /api/settings | — | frontend | §3 | VERIFIED |  |
| FS-SYS-053 | Offline demo mode: every module demo completes with mock + no network | SYS | app/services/demo.py | — | — | integration | §3.3, §15.16 | TESTING GAP |  |
| FS-SYS-054 | Cross-module contracts (SEO→Website, Website→Campaign, Campaign→Funnel) | SYS | services | — | — | integration | §12 | NOT STARTED |  |
| FS-SYS-055 | End-to-end smoke test over HTTP against a real backend process | SYS | scripts/smoke_test.py | all | — | e2e | §15.8 | NOT STARTED |  |
| FS-SYS-056 | Docs check: config vars documented, README commands exist | SYS | scripts/check_docs.py | — | — | unit | §17 | NOT STARTED |  |
| FS-SYS-058 | Traceability generator rules (unknown ids, hand-set VERIFIED, no-assert tests) | SYS | scripts/run_traceability.py | — | — | unit+negative | §17.1 | TESTING GAP |  |
| FS-M1-001 | Brief validation: required fields, field-level errors, inputs preserved | M1 | services/campaign/validation.py | POST /api/campaigns/{id}/validate | CampaignBrief | unit+api+negative | M1-AC01 | NOT STARTED |  |
| FS-M1-002 | Demo brief populates every required field; passes with zero blockers; demo label retained | M1 | services/campaign/demo_brief.py | POST /api/campaigns | Campaign | integration+e2e | M1-AC01 | NOT STARTED |  |
| FS-M1-003 | Date & duration semantics (inclusive, derived, mismatch, leap/month/year boundaries) | M1 | services/campaign/dates.py | — | — | unit+negative | §5.7 | NOT STARTED |  |
| FS-M1-004 | Brief normalization (stage 2) | M1 | services/campaign/stages/normalization.py | — | CampaignBrief | unit | §5.3 | NOT STARTED |  |
| FS-M1-005 | 12 stages run in fixed order through the job engine with persisted inputs/outputs/timestamps/provenance | M1 | services/campaign/orchestrator.py | POST …/executions | Execution(Stage) | integration+e2e | M1-AC02, M1-AC03 | NOT STARTED |  |
| FS-M1-006 | AI stages output schema-validated and persisted (objective, strategy) | M1 | services/campaign/stages/* | GET …/stages/{key} | CampaignOutput | integration | M1-AC04 | NOT STARTED |  |
| FS-M1-007 | Concepts (configurable count) + near-duplicate flag; edit/keep/regenerate/discard | M1 | stages/concepts.py | PATCH outputs | CampaignOutput | integration+api | §5.3 | NOT STARTED |  |
| FS-M1-008 | Google Ads proposals with configurable char limits; INVALID assets cannot be marked ready | M1 | stages/google_ads.py | — | CampaignOutput | unit+integration+negative | §5.3 | NOT STARTED |  |
| FS-M1-009 | Meta Ads proposals (distinct schema, limits, no sensitive targeting) | M1 | stages/meta_ads.py | — | CampaignOutput | unit+integration | §5.3 | NOT STARTED |  |
| FS-M1-010 | Social plan via shared social service using brief cadence | M1 | services/content/social_content.py | — | SocialContentItem | integration | §5.3, §10 | NOT STARTED |  |
| FS-M1-011 | Tracking plan with deterministic UTMs (encoding, existing query, fragments) | M1 | services/campaign/utm.py | — | CampaignOutput | unit | §5.3 | NOT STARTED |  |
| FS-M1-012 | Budget allocation: Decimal largest-remainder; exact sums; edits; no floats; paid channels only | M1 | services/campaign/budget.py | PATCH budget | CampaignOutput | unit+api+negative | M1-AC05 | NOT STARTED |  |
| FS-M1-013 | QA rules (deterministic) each triggered by a defect fixture | M1 | services/campaign/qa_rules.py | GET …/findings | CampaignFinding | unit+integration | §5.3 | NOT STARTED |  |
| FS-M1-014 | Dependency graph `affected_stages`; input edits invalidate only affected stages | M1 | services/campaign/dependency_graph.py | PATCH …/brief | CampaignStageState | unit+integration | M1-AC06 | NOT STARTED |  |
| FS-M1-015 | Output editing creates versions and invalidates dependents; regenerate; restore | M1 | services/campaign/outputs.py | PATCH/POST outputs | OutputVersion | integration+api+negative | M1-AC07 | NOT STARTED |  |
| FS-M1-016 | Failure & retry: injected META_ADS failure; earlier outputs preserved; only failed stage re-runs | M1 | orchestrator | POST …/retry | Execution | integration+e2e | M1-AC08 | NOT STARTED |  |
| FS-M1-017 | Pack generated from latest stored data | M1 | stages/pack.py | — | CampaignOutput | integration | M1-AC09 | NOT STARTED |  |
| FS-M1-018 | PDF/XLSX/CSV exports contain stored data (compared with DB) | M1 | services/campaign/exports.py | GET …/export.* | CampaignExport | integration+api | M1-AC10 | NOT STARTED |  |
| FS-M1-019 | Stale/blocking export refusal (409) and allow_stale banner | M1 | exports | GET …/export.* | — | api+negative | §5.5 | NOT STARTED |  |
| FS-M1-020 | Saved campaigns reopen after restart | M1 | — | GET /api/campaigns/{id} | Campaign | e2e | M1-AC11 | NOT STARTED |  |
| FS-M1-021 | Cancellation preserves completed stages; duplicate start 409; non-healthcare brief passes | M1 | orchestrator | POST …/cancel | Execution | integration+api+negative | M1-AC12 | NOT STARTED |  |
| FS-M1-022 | Healthcare responsibility rules (scanner findings, disclaimer, no compliance claims) | M1 | health_claims, qa_rules | — | — | integration | §5.1 | NOT STARTED |  |
| FS-M1-023 | Campaign UI: form validation, demo load, run, timeline, edit, retry/cancel, downloads | M1 | frontend/src/modules/campaigns | — | — | frontend | §5.4 | NOT STARTED |  |
| FS-M1-024 | Campaign journey suite (16 capabilities) | M1 | tests/e2e/test_m1_journey.py | — | — | e2e | §1.2 | NOT STARTED |  |
| FS-M2-001 | Funnel config validation + creation (incl. demo funnel) | M2 | services/funnel/config.py | POST /api/funnels | Funnel | api+negative | M2-AC01 | NOT STARTED |  |
| FS-M2-002 | Journey design from templates; nodes/edges generated and persisted | M2 | services/funnel/templates.py | POST …/executions | FunnelNode, FunnelEdge | integration | M2-AC02 | NOT STARTED |  |
| FS-M2-003 | Graph validation V01–V14 (one test per rule + valid graph incl. nurture loop) | M2 | services/funnel/graph_validation.py | POST …/validate | FunnelFinding | unit+negative | M2-AC05 | NOT STARTED |  |
| FS-M2-004 | Deterministic layered layout; saved positions override | M2 | services/funnel/layout.py | PATCH …/layout | FunnelNode | unit | §6.6 | NOT STARTED |  |
| FS-M2-005 | Funnel execution (7 stages), per-node content units, failed-node retry | M2 | services/funnel/orchestrator.py | POST …/executions, …/retry | Execution | integration | M2-AC09 | NOT STARTED |  |
| FS-M2-006 | Node/edge CRUD with revalidation; validation_state server-owned; If-Match | M2 | api/funnels.py | POST/PATCH/DELETE nodes/edges | FunnelNode, FunnelEdge | api+negative | M2-AC04 | NOT STARTED |  |
| FS-M2-007 | Dependency behaviour (§6.5) and layout-only edits do not invalidate | M2 | services/funnel/dependency.py | — | — | integration | M2-AC07 | NOT STARTED |  |
| FS-M2-008 | Node deletion removes incident edges + restorable FunnelGraphVersion; regenerate-with-edits refusal | M2 | services/funnel/graph_service.py | DELETE node | FunnelGraphVersion | integration+negative | §6.8 | NOT STARTED |  |
| FS-M2-009 | Campaign context snapshot, CONTEXT_STALE, refresh | M2 | services/funnel/context.py | POST /api/funnels | Funnel | integration | §12 | NOT STARTED |  |
| FS-M2-010 | Exports PDF/XLSX/CSV/SVG with stored data; SVG well-formed with every node; graph_version recorded | M2 | services/funnel/exports.py | GET …/export.* | FileExport | integration+api | M2-AC08 | NOT STARTED |  |
| FS-M2-011 | Diagram renders backend data; drag/connect/select; list view offers all actions | M2 | frontend/src/modules/funnels | — | — | frontend | M2-AC03, M2-AC04 | NOT STARTED |  |
| FS-M2-012 | Funnel never invokes Campaign Engine stages | M2 | — | — | — | integration | M2-AC09 | NOT STARTED |  |
| FS-M2-013 | Funnel persistence after restart; cancellation preserves completed nodes | M2 | — | — | — | e2e+integration | M2-AC06, M2-AC09 | NOT STARTED |  |
| FS-M2-014 | Funnel journey suite | M2 | tests/e2e/test_m2_journey.py | — | — | e2e | §1.2 | NOT STARTED |  |
| FS-M3-001 | Crawler: limits (pages, depth, size, redirects, timeouts), same-site, bounded | M3 | services/crawl/fetcher.py, crawler.py | — | — | integration+negative | M3-AC01, M3-AC02 | NOT STARTED |  |
| FS-M3-002 | SSRF guard (all ranges, schemes, credentials, redirect hops, DNS→private) | M3 | services/crawl/url_safety.py | — | — | unit+integration+negative | M3-AC09 | NOT STARTED |  |
| FS-M3-003 | robots.txt and sitemap (index, bounded) parsing | M3 | services/crawl/robots.py, sitemap.py | — | — | unit | §7 | NOT STARTED |  |
| FS-M3-004 | SEO rules produce exact findings with stored evidence matching fixture HTML | M3 | services/seo/rules.py | — | Finding, Evidence | integration | M3-AC03 | NOT STARTED |  |
| FS-M3-005 | Coverage panel, failed/excluded pages with reasons, completeness states | M3 | services/crawl/coverage.py | GET /api/seo-audits/{id} | CrawlPage | integration+negative | M3-AC04, M3-AC05, M3-AC06 | NOT STARTED |  |
| FS-M3-006 | SEO report + PDF/XLSX/CSV exports with stored data | M3 | services/seo/seo_reports.py | GET …/report.* | FileExport | integration+api | M3-AC08 | NOT STARTED |  |
| FS-M3-007 | Triage editable without altering evidence | M3 | api/seo.py | PATCH /api/findings/{id}/triage | FindingTriage | api+negative | M3-AC11 | NOT STARTED |  |
| FS-M3-008 | Linked retry runs carry forward fetched pages; originals immutable | M3 | services/seo/seo_service.py | POST …/retry-failed | Audit | integration | §7.1 | NOT STARTED |  |
| FS-M3-009 | Cancellation preserves crawled pages, PARTIAL | M3 | — | POST …/cancel | Audit | integration | M3-AC12 | NOT STARTED |  |
| FS-M3-010 | Prompt-injection pages do not alter behaviour | M3 | — | — | — | integration | M3-AC10 | NOT STARTED |  |
| FS-M3-011 | Demo-site allowlist exact host:port, re-checked on redirects | M3 | url_safety.py | — | — | unit+negative | §7.1 | NOT STARTED |  |
| FS-M3-012 | SEO UI: form, coverage, findings, triage, downloads | M3 | frontend/src/modules/seo | — | — | frontend | §7 | NOT STARTED |  |
| FS-M3-013 | SEO persistence after restart; network-unavailable → actionable FAILED | M3 | — | — | — | e2e+integration+negative | M3-AC07 | NOT STARTED |  |
| FS-M3-014 | SEO journey suite | M3 | tests/e2e/test_m3_journey.py | — | — | e2e | §1.2 | NOT STARTED |  |
| FS-M4-001 | Website analyzer: structure, nav, CTAs, contact paths, trust info from evidence | M4 | services/website/analyzer.py | POST /api/website-reports | Finding | integration | M4-AC01, M4-AC02 | NOT STARTED |  |
| FS-M4-002 | Assessments/recommendations distinguished from observations; cite URLs/snippets | M4 | services/website/analyzer.py | — | Finding | integration | M4-AC03 | NOT STARTED |  |
| FS-M4-003 | Failed pages + limitations displayed; coverage | M4 | — | GET /api/website-reports/{id} | — | integration+negative | M4-AC04 | NOT STARTED |  |
| FS-M4-004 | Reports/exports PDF/XLSX/CSV with stored data | M4 | services/website/website_reports.py | GET …/export.* | FileExport | integration+api | M4-AC05, M4-AC06 | NOT STARTED |  |
| FS-M4-005 | No SEO rule findings in website reports and vice versa | M4 | — | — | — | integration | M4-AC07 | NOT STARTED |  |
| FS-M4-006 | Prompt-injection treated as data | M4 | — | — | — | integration | M4-AC08 | NOT STARTED |  |
| FS-M4-007 | Retry failed pages and cancellation preserve completed work | M4 | — | — | — | integration | M4-AC09 | NOT STARTED |  |
| FS-M4-008 | Website UI and SEO→Website contract | M4 | frontend/src/modules/website | — | — | frontend | §8 | NOT STARTED |  |
| FS-M4-009 | Website persistence after restart + journey suite | M4 | tests/e2e/test_m4_journey.py | — | — | e2e | M4-AC06 | NOT STARTED |  |
| FS-M5-001 | Batch input: trim, dedupe case-insensitive, cap, per-topic limits | M5 | services/blog_service.py | POST /api/blog-batches | BlogBatch | unit+api+negative | M5-AC09 | NOT STARTED |  |
| FS-M5-002 | Per-item independent generation status; partial failure preserves successes | M5 | services/blog_service.py | GET /api/blog-batches/{id} | BlogItem | integration | M5-AC01, M5-AC02, M5-AC03 | NOT STARTED |  |
| FS-M5-003 | Failed-only retry leaves completed items byte-identical | M5 | services/blog_service.py | POST …/retry-failed | BlogItem | integration+negative | M5-AC04 | NOT STARTED |  |
| FS-M5-004 | Edit creates version, resets status to DRAFT; content validation warnings; slug uniqueness | M5 | services/blog_service.py | PATCH /api/blog-items/{id} | OutputVersion | api | M5-AC05 | NOT STARTED |  |
| FS-M5-005 | Exports: MD/TXT per draft, CSV, ZIP with sanitized unique names | M5 | services/blog_exports.py | GET …/export.* | FileExport | integration+api | M5-AC07 | NOT STARTED |  |
| FS-M5-006 | Cancellation preserves completed items | M5 | — | POST …/cancel | — | integration | M5-AC08 | NOT STARTED |  |
| FS-M5-007 | Blog UI | M5 | frontend/src/modules/blogs | — | — | frontend | §9 | NOT STARTED |  |
| FS-M5-008 | Blog persistence after restart + journey suite | M5 | tests/e2e/test_m5_journey.py | — | — | e2e | M5-AC06 | NOT STARTED |  |
| FS-M6-001 | Cadence slot generation for every option within inclusive period | M6 | services/content/social_content.py | — | — | unit | M6-AC02 | NOT STARTED |  |
| FS-M6-002 | Platform-specific content schemas differ | M6 | app/ai/schemas.py | — | SocialContentItem | unit | M6-AC01 | NOT STARTED |  |
| FS-M6-003 | Add/remove/reschedule with revalidation; gap rule; duplicates; out-of-range | M6 | services/content/social_content.py | POST/PATCH/DELETE items | SocialContentItem | integration+api+negative | M6-AC03, M6-AC05 | NOT STARTED |  |
| FS-M6-004 | Content status transitions on social items | M6 | content_status.py | PATCH /api/social-items/{id}/status | — | api+negative | M6-AC04 | NOT STARTED |  |
| FS-M6-005 | Period/cadence change re-plans; items outside flagged outdated | M6 | social_content.py | PATCH /api/social-campaigns/{id} | — | integration | §10.1 | NOT STARTED |  |
| FS-M6-006 | CSV/XLSX exports | M6 | services/social_exports.py | GET …/export.* | FileExport | integration+api | M6-AC07 | NOT STARTED |  |
| FS-M6-007 | Shared-service parity with campaign SOCIAL_PLAN | M6 | social_content.py | — | — | integration | M6-AC08 | NOT STARTED |  |
| FS-M6-008 | No item ever labelled scheduled/published | M6 | — | — | — | integration | M6-AC09 | NOT STARTED |  |
| FS-M6-009 | Failed-item retry and cancellation preserve completed items | M6 | — | — | — | integration | M6-AC10 | NOT STARTED |  |
| FS-M6-010 | Social UI: calendar editing/rescheduling | M6 | frontend/src/modules/social | — | — | frontend | §10 | NOT STARTED |  |
| FS-M6-011 | Social persistence after restart + journey suite | M6 | tests/e2e/test_m6_journey.py | — | — | e2e | M6-AC06 | NOT STARTED |  |
<!-- TRACE:END -->

## Module completion (§15.12) — COMPLETE only when every acceptance criterion maps to VERIFIED requirements

<!-- MODULES:BEGIN -->
| Module | State |
|---|---|
| M1 Campaign Intelligence | NOT COMPLETE |
| M2 Funnel Builder | NOT COMPLETE |
| M3 SEO Audit | NOT COMPLETE |
| M4 Website Intelligence | NOT COMPLETE |
| M5 Bulk Blog | NOT COMPLETE |
| M6 Social Calendar | NOT COMPLETE |
<!-- MODULES:END -->
