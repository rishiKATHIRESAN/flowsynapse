# FlowSynapse

Local, AI-assisted marketing workflow app (FastAPI + SQLite backend, React + Vite frontend). Runs on your PC with no paid services: the default **mock** AI provider is deterministic, offline and clearly labelled "not real AI output".

## Status
Partially built - see `docs/BUILD_STATE.md` for exactly what works and what is not implemented yet. Working today: app shell, dashboard, settings (provider choice/test, demo data), and the Campaign Intelligence module **stages 1-3** (validation, normalization, objective analysis) with run/cancel/retry, restart persistence and CSV export. Other modules show "Not implemented yet".

## Quick start (Windows PowerShell; verified)
```
.\scripts\setup.ps1      # checks Python 3.10+/Node 18+, creates backend/.venv, installs deps, creates backend/.env, migrates DB
.\scripts\start.ps1      # starts backend 127.0.0.1:8000 + UI 127.0.0.1:5173; Ctrl+C stops both
```
macOS/Linux: `./scripts/setup.sh` and `./scripts/start.sh` (NOT VERIFIED on those OSes).

Open http://127.0.0.1:5173 -> Campaign Intelligence -> Create Campaign -> **Load demo brief** -> **Run Campaign Intelligence**. API docs: http://127.0.0.1:8000/docs

## Other commands
- `scripts/check --fast` - backend unit/integration/api tests, frontend typecheck/tests/build
- `scripts/test unit|integration|api|frontend|e2e|all`
- `scripts/run_traceability` - regenerates requirement statuses in `IMPLEMENTATION_CHECKLIST.md`
- `scripts/migrate`, `scripts/restore_backup <file>`

## Configuration
All settings are documented once in `backend/.env.example` (copied to `backend/.env` by setup). Secrets live only in `backend/.env`.

## Troubleshooting
- **Port in use:** `scripts/start --backend-port 8010 --frontend-port 5180`; the script tells you whether the port holds another FlowSynapse or an unrelated service.
- **PowerShell execution policy:** run `powershell -ExecutionPolicy Bypass -File .\scripts\start.ps1` or use the `.bat` scripts.
- **"Backend unreachable":** the backend is not running or failed to start - see `backend/data/logs/backend-console.log`.
- **Reset the database:** stop the app, delete `backend/data/flowsynapse.db*`, run `scripts/migrate`.

## Limitations
Single-user, local, no authentication. Mock output is not real AI. Campaign outputs are proposals - no ad-platform upload or publishing. Data is stored unencrypted in `backend/data/`.
